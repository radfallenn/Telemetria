import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || '';

const supabase = createClient(supabaseUrl, supabaseKey);

async function test() {
  const { data, error } = await supabase
    .from('entries')
    .select(`
          *,
          profiles:profiles!fk_entries_profiles (
            id,
            display_name,
            avatar_url,
            driver_rating,
            safety_rating,
            is_public,
            psn_id
          )
        `)
    .eq('is_public', true)
    .in('trackId', ['1'])
    .limit(2);
    
  console.log('Error 1:', error);
  console.log('Data profile:', data?.[0]?.profiles?.display_name);
}

test();
