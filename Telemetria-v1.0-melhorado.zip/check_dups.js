import fs from 'fs';
const text = fs.readFileSync('src/data/trackPack.ts', 'utf-8');
const ids = [...text.matchAll(/id:\s*"([^"]+)"/g)].map(m => m[1]);
const duplicates = ids.filter((item, index) => ids.indexOf(item) !== index);
console.log('Duplicates in trackPack:', duplicates);

const text2 = fs.readFileSync('src/data/gt7_cars.ts', 'utf-8');
const ids2 = [...text2.matchAll(/id:\s*"([^"]+)"/g)].map(m => m[1]);
const duplicates2 = ids2.filter((item, index) => ids2.indexOf(item) !== index);
console.log('Duplicates in gt7_cars:', duplicates2);
