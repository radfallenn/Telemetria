const fs = require('fs');

const userTracks = [
    {
      "name": "Alsace",
      "category": "original",
      "region": "Europe",
      "layouts_known": 4,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_alsace",
      "hud_ready": true
    },
    {
      "name": "Autodromo Lago Maggiore",
      "category": "original",
      "region": "Europe",
      "layouts_known": 12,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_lago_maggiore",
      "hud_ready": true
    },
    {
      "name": "Autopolis",
      "category": "real",
      "region": "Asia/Oceania",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_autopolis",
      "hud_ready": true
    },
    {
      "name": "Bathurst Mount Panorama",
      "category": "real",
      "region": "Asia/Oceania",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_bathurst",
      "hud_ready": true
    },
    {
      "name": "Blue Moon Bay Speedway",
      "category": "original",
      "region": "America",
      "layouts_known": 6,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_blue_moon_bay",
      "hud_ready": true
    },
    {
      "name": "Brands Hatch",
      "category": "real",
      "region": "Europe",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_brands_hatch",
      "hud_ready": true
    },
    {
      "name": "Broad Bean Raceway",
      "category": "original",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_broad_bean",
      "hud_ready": true
    },
    {
      "name": "Circuit de Barcelona-Catalunya",
      "category": "real",
      "region": "Europe",
      "layouts_known": 3,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_barcelona",
      "hud_ready": true
    },
    {
      "name": "Circuit de la Sarthe",
      "category": "real",
      "region": "Europe",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_le_mans",
      "hud_ready": true
    },
    {
      "name": "Circuit de Spa-Francorchamps",
      "category": "real",
      "region": "Europe",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_spa",
      "hud_ready": true
    },
    {
      "name": "Colorado Springs",
      "category": "rally",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_colorado_springs",
      "hud_ready": true
    },
    {
      "name": "Daytona",
      "category": "real",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_daytona",
      "hud_ready": true
    },
    {
      "name": "Deep Forest Raceway",
      "category": "original",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_deep_forest",
      "hud_ready": true
    },
    {
      "name": "Dragon Trail",
      "category": "original",
      "region": "Europe",
      "layouts_known": 4,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_dragon_trail",
      "hud_ready": true
    },
    {
      "name": "Eiger Nordwand",
      "category": "original",
      "region": "Europe",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_eiger_nordwand",
      "hud_ready": true
    },
    {
      "name": "Fishermans Ranch",
      "category": "rally",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_fishermans_ranch",
      "hud_ready": true
    },
    {
      "name": "Fuji Speedway",
      "category": "real",
      "region": "Asia/Oceania",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_fuji",
      "hud_ready": true
    },
    {
      "name": "Goodwood",
      "category": "real",
      "region": "Europe",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_goodwood",
      "hud_ready": true
    },
    {
      "name": "Grand Valley",
      "category": "original",
      "region": "America",
      "layouts_known": null,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_grand_valley",
      "hud_ready": true
    },
    {
      "name": "High Speed Ring",
      "category": "original",
      "region": "Asia/Oceania",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_high_speed_ring",
      "hud_ready": true
    },
    {
      "name": "Interlagos",
      "category": "real",
      "region": "America",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_interlagos",
      "hud_ready": true
    },
    {
      "name": "Kyoto Driving Park",
      "category": "original",
      "region": "Asia/Oceania",
      "layouts_known": 6,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_kyoto",
      "hud_ready": true
    },
    {
      "name": "Lake Louise",
      "category": "rally",
      "region": "America",
      "layouts_known": 6,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_lake_louise",
      "hud_ready": true
    },
    {
      "name": "Laguna Seca",
      "category": "real",
      "region": "America",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_laguna_seca",
      "hud_ready": true
    },
    {
      "name": "Michelin Raceway Road Atlanta",
      "category": "real",
      "region": "America",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_road_atlanta",
      "hud_ready": true
    },
    {
      "name": "Monza",
      "category": "real",
      "region": "Europe",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_monza",
      "hud_ready": true
    },
    {
      "name": "Mount Panorama Motor Racing Circuit",
      "category": "real",
      "region": "Asia/Oceania",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_mount_panorama",
      "hud_ready": true
    },
    {
      "name": "Nurburgring",
      "category": "real",
      "region": "Europe",
      "layouts_known": 6,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_nurburgring",
      "hud_ready": true
    },
    {
      "name": "Northern Isle Speedway",
      "category": "original",
      "region": "America",
      "layouts_known": 1,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_northern_isle",
      "hud_ready": true
    },
    {
      "name": "Red Bull Ring",
      "category": "real",
      "region": "Europe",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_red_bull_ring",
      "hud_ready": true
    },
    {
      "name": "Sardegna",
      "category": "mixed",
      "region": "Europe",
      "layouts_known": 8,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_sardegna",
      "hud_ready": true
    },
    {
      "name": "Special Stage Route X",
      "category": "original",
      "region": "America",
      "layouts_known": 1,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_ssrx",
      "hud_ready": true
    },
    {
      "name": "Suzuka Circuit",
      "category": "real",
      "region": "Asia/Oceania",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_suzuka",
      "hud_ready": true
    },
    {
      "name": "Sainte-Croix",
      "category": "original",
      "region": "Europe",
      "layouts_known": 6,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_sainte_croix",
      "hud_ready": true
    },
    {
      "name": "Tokyo Expressway",
      "category": "original",
      "region": "Asia/Oceania",
      "layouts_known": 6,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_tokyo_expressway",
      "hud_ready": true
    },
    {
      "name": "Trial Mountain",
      "category": "original",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "custom_redraw_needed",
      "asset_key": "gt7_trial_mountain",
      "hud_ready": true
    },
    {
      "name": "Tsukuba Circuit",
      "category": "real",
      "region": "Asia/Oceania",
      "layouts_known": 1,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_tsukuba",
      "hud_ready": true
    },
    {
      "name": "Watkins Glen",
      "category": "real",
      "region": "America",
      "layouts_known": 2,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_watkins_glen",
      "hud_ready": true
    },
    {
      "name": "Willow Springs",
      "category": "real",
      "region": "America",
      "layouts_known": 5,
      "svg_status": "public_reference_possible",
      "asset_key": "gt7_willow_springs",
      "hud_ready": true
    }
  ];

const categoryMap = {
  original: "Original Circuit",
  real: "Real Circuit",
  rally: "Dirt / Snow",
  mixed: "Dirt / Snow",
};

const regionMap = {
  "America": "Americas",
  "Europe": "Europe",
  "Asia/Oceania": "Asia-Oceania",
};

const defaultPaths = [
    'M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z',
    'M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z',
    'M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z',
    'M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z',
    'M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z',
    'M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z',
    'M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z',
    'M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z'
];

const out = `export const TRACK_PACK_META = {
  pack_name: "GT7 Ultra Track Pack",
  version: "v1.0",
  purpose: ["svg reference", "minimap", "telemetry overlay", "track selector", "region/category filters"]
};

export type Region = 'Americas' | 'Europe' | 'Asia-Oceania';
export type Category = 'Real Circuit' | 'Original Circuit' | 'Dirt / Snow';

export interface TrackDef {
  id: string;
  name: string;
  location: string;
  region: Region;
  category: Category;
  svgViewBox: string;
  svgPath: string;
  layouts?: number | null;
}

export const TRACK_PACK: TrackDef[] = [
${userTracks.map((t, idx) => {
  return `  {
    id: ${JSON.stringify(t.asset_key)},
    name: ${JSON.stringify(t.name)},
    location: '',
    region: ${JSON.stringify(regionMap[t.region])} as Region,
    category: ${JSON.stringify(categoryMap[t.category])} as Category,
    svgViewBox: '0 0 100 100',
    svgPath: ${JSON.stringify(defaultPaths[idx % defaultPaths.length])},
    layouts: ${t.layouts_known}
  }`;
}).join(',\n')}
];
`;

fs.writeFileSync('src/data/trackPack.ts', out);
console.log("Track pack updated with " + userTracks.length + " tracks.");
