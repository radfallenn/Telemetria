-- Para apagar todos os usuários:
-- Vá no painel do Supabase -> Authentication -> Users e exclua todos.
-- Ou execute no SQL Editor (Cuidado! Isso apaga tudo de todos):
-- DELETE FROM auth.users;

-- ==========================================
-- POLÍTICAS DE SEGURANÇA RLS (Row Level Security)
-- ==========================================
-- Para garantir que "Tudo do usuário só é visto por ele, a menos que ele marque como público"

-- 1. Políticas para Perfis (profiles)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Ver próprio perfil" ON profiles
FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Ver perfis públicos" ON profiles
FOR SELECT USING (is_public = true);

CREATE POLICY "Atualizar próprio" ON profiles
FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Criar próprio" ON profiles
FOR INSERT WITH CHECK (auth.uid() = id);


-- 2. Políticas para Carros/Entradas (entries)
ALTER TABLE entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Ver próprias entradas" ON entries
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Ver entradas públicas" ON entries
FOR SELECT USING (
  is_public = true AND EXISTS (SELECT 1 FROM profiles WHERE profiles.id = entries.user_id AND profiles.is_public = true)
);

CREATE POLICY "Inserir próprias" ON entries FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Atualizar próprias" ON entries FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Deletar próprias" ON entries FOR DELETE USING (auth.uid() = user_id);
