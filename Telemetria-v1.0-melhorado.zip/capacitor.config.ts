import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gt7.telemetry',
  appName: 'GT7 Telemetry',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
