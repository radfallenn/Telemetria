# Telemetria v1.0 Melhorado

App Android de telemetria GT7 com layout limpo e foco em corrida.

## Tela principal
- RPM em barra
- Velocidade
- Marcha
- Melhor volta
- Última volta
- Tempo total
- Velocidade máxima
- Média da corrida
- Voltas completas
- Resumo de até 30 voltas

## Média
A média descarta as 2 melhores e as 2 piores voltas. Depois soma o restante e divide por voltas completas menos 4.

## Ações
- Configurar Bridge URL
- Zerar sessão com confirmação
- Copiar resumo completo
- Restaurar sessão ao reabrir
