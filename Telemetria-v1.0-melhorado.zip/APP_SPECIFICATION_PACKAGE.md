# Pacote de Especificação Técnica: GT7 Telemetry & Log Manager (`gt7.online`)

Este documento serve como um **guia descritivo e pacote completo de especificações médicas, estruturais, layouts, conjuntos de dados, modais, abas, pills, cartões e lógicas de validação** do aplicativo **GT7 Telemetry**, configurado e otimizado para reutilização direta em fluxos do tipo *"Build your app"*, migrações, recriação de plataformas ou desenvolvimento nativo no Android Studio com Capacitor/React.

---

## 📱 1. Identificação Geral do Aplicativo
- **Nome Comercial:** `gt7.online`
- **Nome do Projeto no Dispositivo:** `GT7 Telemetry`
- **ID de Pacote (Android App ID):** `com.gt7.telemetry`
- **Stack Tecnológica Core:** React 18+ (SPA), Vite, TypeScript, Tailwind CSS, Capacitor CLI (para embarque nativo no Android).
- **Provedor de Persistência Principal:** Firebase Firestore (para sincronização em nuvem multiusuário) com suporte alternativo para Supabase PostgreSQL / LocalStorage para sessões offline.

---

## 🎨 2. Design System & Identidade Visual
A interface do `gt7.online` segue um modelo de alto contraste, otimizado para smartphones e ambientes de simulação (cockpits de corrida), onde a rapidez na leitura e inserção de dados são cruciais.

### Paleta de Cores (Tailwind CSS)
| Parâmetro Visual | Token de Cor | Descrição de Uso |
| :--- | :--- | :--- |
| **Primary Text** | `Ink Primary (text-slate-900 / dark:text-white)` | Títulos, tempos de volta e valores críticos de telemetria. |
| **Secondary Text** | `Ink Secondary (text-slate-500 / text-neutral-400)` | Placeholders, descrições secundárias e labels de inputs. |
| **App Background** | `bg-app (bg-slate-50 / dark:bg-zinc-950)` | Fundo principal flutuante de baixo cansaço visual. |
| **Card Background** | `bg-card (bg-white / dark:bg-zinc-900)` | Fundo com cantos arredondados contendo listas e seções. |
| **Cell Background** | `bg-cell (bg-slate-100 / dark:bg-zinc-800)` | Fundo para blocos de input, seletores de opções e pílulas ativas. |
| **Accent Blue** | `bg-accent-blue (bg-blue-600 / dark:bg-blue-500)` | Destaques ativos, sliders de ajuste, botões de ação principal. |
| **Success Color** | `text-emerald-500` / `bg-emerald-500` | Exibição de melhor volta pessoal absolute ou setas de progresso. |
| **Danger Color** | `text-rose-500` / `bg-rose-500` | Avisos de limites, exclusões permanentes e redefinição de dados. |

### Tipografia Declarada
- **Geral e Interface:** `Inter` (Sans-serif) para rotulação flexível de tabelas, menus e inputs.
- **Tempos e Dados Numéricos:** `JetBrains Mono` ou `Fira Code` (Monospace, classe `font-mono`). Crucial para garantir o alinhamento de fatias de milissegundos nas listas comparativas sem quebra ou tremulação vertical de caracteres.
- **Estilos de Peso:**
  - `font-black` (900) e `uppercase` com `tracking-widest` para labels de menu superior, filtros e cabeçalhos de coluna compactos.
  - `font-bold` (700) para valores primários e cronometragem.

---

## 📊 3. Especificação do Banco de Dados & Schemas

### Interface das Entradas de Corrida/Laps (`Entry`)
Cada entrada no aplicativo representa uma sessão gravada e possui o seguinte formato tipado em TypeScript (`src/types.ts`):

```typescript
export interface Entry {
  id: string;               // Identificador único (UUID ou gerado pelo Firebase)
  user_id?: string;         // Referência única do piloto logado (Auth)
  trackId: string;          // ID associado à pista correspondente
  carBrand: string;         // Marca do fabricante (Ex: "Porsche", "Ferrari")
  carName: string;          // Nome exato do veículo (Ex: "911 GT3 RS (991) '16")
  carSetup: string;         // Composto de Pneus & Configurações de suspensão/aerodinâmica
  racePosition: string;     // Posição final na prova (Ex: "1", "2")
  tractionControl: string;  // Nível de Controle de Tração (Ex: "0", "1", "3")
  carMap: string;           // Mapa de Combustível / Fuel Map (Ex: "1", "6")
  pitStops: string;         // Número de paradas de box efetuadas (Ex: "0", "2")
  runDate: string;          // Data UTC ou Local de registro (Formato YYYY-MM-DD)
  weather: string;          // Condição Climática (Ex: "Ensolarado", "Chuva Leve")
  lapTime: string;          // Tempo da melhor volta formatado (Ex: "01:37.865")
  totalTime: string;        // Tempo total acumulado da corrida (Ex: "17:57.863")
  provaDeTempo?: string;    // Marcação alternativa de tempo de prova
  avgLapTime: string;       // Média das voltas gravadas
  laps?: string;            // Total de voltas completadas na sessão
  pilot_name?: string;      // Nome do Piloto que efetuou o registro
  transmission?: string;    // Transmissão utilizada: "MT" (Manual) ou "AT" (Automática)
  peripheral?: string;      // Controle utilizado (Ex: "Volante G29", "DualSense")
  evidence_image?: string;  // Link ou base64 de imagem de comprovação de tempo
  velocidade_final?: string;// Velocidade máxima final registrada (Ex: "343 km/h")
  is_public?: boolean;      // Visibilidade na liderança global de pilotos
  customFields?: Record<string, string>; // Parâmetros flexíveis extras criados pelo usuário
}
```

---

## 🧭 4. Arquitetura das Janelas, Abas (Tabs) e Pills

O painel de navegação gerencia o contexto de visualizações principais através de um seletor superior de pílulas (`Pills`) e abas interativas completas:

```
+---------------------------------------------------------------------------------+
|   [LOGOS]   │   [PISTAS]   │   [CARS/CARROS]   │   [NOMES]   │  [DRIVERS/PILOTOS] |
+---------------------------------------------------------------------------------+
```

### 🖼️ Aba 1: Logos (`activeTab === 'logos'`)
Instancia o banco de vetores e logos de alta resolução das marcas oficiais cadastradas (`LogoBankTab.tsx`).
- **Pills e Categorias:** Busca de marcas por ordem alfabética ou país de fabricação.
- **Estrutura do Card:** Grid de logos com suporte a upload em lote de arquivos `.svg`, `.png` ou `.webp`. Permite que o usuário atribua marcas a nomes customizados detectados pela telemetria.

### 🏁 Aba 2: Pistas (`activeTab === 'tracks'`)
Gerenciamento de circuitos e layouts de pista agrupados por pacotes de pista (`trackPack.ts`).
- **Customização de Filtro:** Permite filtrar por continente (América, Europa, Ásia) ou tipo (Circuitos Reais vs. Circuitos Fictícios do GT7).
- **Cards de Exibição:** Mostra o traçado vetorizado da pista, nome oficial, localização geográfica e quantidade de registros de tempos atribuídos.

### 🚗 Aba 3: Cars (`activeTab === 'cars'`)
Catálogo completo baseado no dataset nativo do Gran Turismo 7 (`gt7_cars.ts`).
- **Mecanismo de Filtro:** Campo de busca dinâmico por categoria de performance do carro (Gr.1, Gr.2, Gr.3, Gr.4, Gr.B, N-Class) e tipo de tração (FR, MR, FF, AWD).
- **Cartões (Cards):** Imagem em miniatura do carro, ano de fabricação, grupo técnico, índice de PP oficial padrão e botão rápido para vincular como favorito do perfil.

### 🏷️ Aba 4: Nomes / Car Names (`activeTab === 'car_names'`)
Mecanismo inteligente de saneamento e normalização de strings de veículos (`CarNamesManagerTab.tsx`).
- **Problema resolvido:** Aplicativos de telemetria externos podem enviar nomes ligeiramente incorretos ou com caracteres corrompidos.
- **Funcionamento:** Mapeia variantes textuais brutas enviadas no envio e as vincula a registros bem formados do banco principal de dados do GT7. Exemplo: Corrige automaticamente de `"Porsche 911 GT3 (992) '22_gt7"` para `"911 GT3 (992) '22"`.

### 💾 Aba 5: Dados / Form (`activeTab === 'data'`)
O núcleo operacional para criação, edição estruturada e manutenção das corridas executadas. Contém o formulário de novos registros, personalização de colunas exibidas e controle do layout físico dos cartões de resultados.
- **Pills Dinâmicas de Configuração:** Alterna entre "Campos de Entrada", "Layout de Cards" e "Filtros de Visão".
- **Visualizador em Grid:** Tabela interativa com capacidade de redimensionar cards (`LayoutProfile` dinâmico).

### 👥 Aba 6: Drivers / Pilotos (`activeTab === 'drivers'`)
Gestão das contas de pilotos participantes e do ranking competitivo local/geral.
- **Pills de Classificação:** Ordem por Driver Rating (DR: D, C, B, A, A+, S) ou Safety Rating (SR: E, D, C, B, A, S).
- **Cards de Piloto:** Resumo de estatísticas contendo o total de corridas completas, carro favorito configurado, região de origem e melhor tempo total de voltas registradas.

### 🌅 Aba 7: Cenas / Track Images (`activeTab === 'track_images'`)
Banco de imagens cênicas e cenários oficiais do Gran Turismo 7.
- Permite configurar imagens de fundo dinâmicas para cada pista de forma personalizada, enriquecendo visualmente os cards de cada circuito.

---

## 📋 5. Guia de Preenchimento: "Colar Dados" (Novos Registros)

O recurso **"Colar Dados"** (localizado em novos registros) possui um analisador de expressões regulares integrado capaz de interpretar tanto cadeias de dados semi-estruturadas (`JSON` exportados pelo Bridge APK oficial do GT7) quanto formatações livres copiadas diretamente de planilhas.

Para garantir que todos os campos de telemetria sejam preenchidos perfeitamente, utilize o padrão estruturado abaixo.

### 📐 Estrutura Padrão Recomendada (Copiar & Colar)
Você pode preencher os dados utilizando o caractere ponto e vírgula (`;`) ou quebras de linha normais contendo rótulos claros:

```
Marca: <Nome da Marca>
Carro: <Nome Completo do Carro>
Pneus / Configuração: <Composto de Pneus ou Dados do Setup>
Posição: <Posição de Chegada>
Melhor Volta: <Tempo Formatado MM:SS.mmm>
Tempo Total: <Tempo Total da Corrida MM:SS.mmm ou HH:MM:SS.mmm>
Voltas: <Quantidade de Voltas Completas>
Velocidade Final: <Velocidade Máxima do Stint>
```

#### Exemplo Prático Resumido de Sessão (Copie este bloco para testar a colagem):
```
Resumo da Seção

Marca: Porsche
Carro: 911 GT3 RS (991) '16
Pneus / Configuração: Corrida Macio (RM) / Setup Suspensão Nürburgring

Melhor Volta: 01:39.539
Tempo Total: 17:57.863
Voltas: 10
Velocidade Final: 343 km/h
Posição: 1
```

---

## 🔄 6. Como Funciona a Validação dos Campos de Entrada?

Quando o usuário clica no botão **"Colar Dados"** (Clipboard) ou clica em **"Importar Dados"**:

1. **Tentativa 1 (Estrutura JSON Semântico):** O sistema tenta ler a string como um JSON exportado nativamente pelo dispositivo. Se for sucesso, mapeia as chaves correspondentes.
2. **Tentativa 2 (Expressões Regulares & Chaves Semânticas):** Se for texto puro, analisa linha por linha procurando correspondências inteligentes de termos (em Português ou Inglês):
   - Procurando *"marca"* ou *"brand"* $\rightarrow$ Preenche o campo de Marca do fabricante.
   - Procurando *"carro"*, *"car"* ou *"carname"* $\rightarrow$ Preenche o nome exato do carro e consulta o banco local para autocompletar atributos adicionais.
   - Procurando *"pneus"*, *"pneus / configuração"* ou *"setup"* $\rightarrow$ Define as propriedades de pneus e ajustes mecânicos.
   - Procurando *"posição"*, *"posicao"* ou *"pos"* $\rightarrow$ Registra a colocação final (valida se é número inteiro).
   - Procurando *"melhor"* ou *"best lap"* $\rightarrow$ Mapeia o tempo da melhor volta rápida.
   - Procurando *"tempo total"* ou *"total time"* $\rightarrow$ Mapeia o cronômetro cumulativo da sessão.
   - Procurando *"voltas"* ou *"laps"* $\rightarrow$ Extrai a contagem de voltas executadas.
   - Procurando *"velocidade"* ou *"speed"* $\rightarrow$ Captura a velocidade final em km/h.
3. **Tentativa 3 (Análise Posicional Sequencial):** Caso as tags textuais não estejam presentes, o sistema fatia o texto usando ponto e vírgulas (`;`) em ordem sequencial estrita dos campos:
   $$\text{Marca} \rightarrow \text{Carro} \rightarrow \text{Pneus / Configuração} \rightarrow \text{Posição} \rightarrow \text{Melhor Volta} \rightarrow \text{Tempo Total} \rightarrow \text{Voltas} \rightarrow \text{Velocidade Final}$$

---

## 🛠️ 7. Migração Exclusiva para o Android Studio

Para rodar este pacote com perfeição visual no ecossistema Android do Android Studio:

1. **Configuração do Capacitor:** Certifique-se de que o arquivo `capacitor.config.ts` no diretório raiz do seu workspace aponta o `webDir` para o diretório de build correto do Vite (`dist`):
   ```typescript
   const config: CapacitorConfig = {
     appId: 'com.gt7.telemetry',
     appName: 'GT7 Telemetry',
     webDir: 'dist',
     server: { androidScheme: 'https' }
   };
   ```
2. **Geração do Build de Produção:** Compile o aplicativo Web compacto executando:
   - `npm run build`
3. **Sincronização dos Ativos com a pasta nativa Android:**
   - Execute o sincronizador Capacitor via npx para carregar todos os ativos compilados, telas e regras de estilo Tailwind para dentro da pasta `android/app/src/main/assets/public`:
   - `npx cap sync android`
4. **Execução no Android Studio:** Abra o diretório `/android` como um projeto Android Gradle tradicional no Android Studio para gerar o arquivo `.APK` nativo com transições aceleradas de hardware e suporte a toques responsivos inferiores a 44ms de latência.
