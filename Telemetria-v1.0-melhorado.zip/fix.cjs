const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');
const target = fs.readFileSync('target.txt', 'utf8');

const replacement = `const [trash, setTrash] = useState<{tracks: Track[], entries: Entry[]}>({ tracks: [], entries: [] });
  const [tracks, setTracks] = useState<Track[]>(INITIAL_TRACKS);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [history, setHistory] = useState<Entry[][]>([]);
  const [logoOverrides, setLogoOverrides] = useState<Record<string, string>>({});
  const [logosDatabase, setLogosDatabase] = useState<LogoBrand[]>([{ 
    id: "1", 
    brand: "Gran Turismo", 
    url: "https://raw.githubusercontent.com/toss/tossface/master/dist/svg/u1F3CE.svg" 
  }]);
  const [layout, setLayout] = useState<LayoutProfile>(DEFAULT_LAYOUT);`;

if(code.includes(target)) {
   code = code.replace(target, replacement);
   fs.writeFileSync('src/App.tsx', code);
   console.log('REPLACEMENT SUCCESS!');
} else {
   console.log('COULD NOT FIND TARGET IN APP.TSX');
}
