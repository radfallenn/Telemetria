-- Execute este SQL no SQL Editor do seu Dashboard no Supabase

-- Garantir que as extensões necessárias estão habilitadas
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Garantir permissões de schema
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
GRANT USAGE ON SCHEMA storage TO anon, authenticated, service_role;

-- Forçar o reload do cache do PostgREST logo de cara
NOTIFY pgrst, 'reload schema';

-- Limpeza total de policies para evitar conflitos de nomes antigos ou duplicados
DO $$ 
DECLARE 
    r record;
BEGIN
    FOR r IN (
        SELECT policyname, tablename 
        FROM pg_policies 
        WHERE schemaname = 'public' 
        AND tablename IN ('tracks', 'entries', 'profiles', 'user_settings')
    )
    LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON public.' || r.tablename;
    END LOOP;
END $$;

-- Tabela: tracks
CREATE TABLE IF NOT EXISTS public.tracks (
  id text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  location text,
  "is_public" boolean DEFAULT true,
  created_at timestamp WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id, user_id)
);
ALTER TABLE public.tracks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public Read Tracks" ON public.tracks FOR SELECT USING (true);
CREATE POLICY "Owner Manage Tracks" ON public.tracks FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Tabela: profiles
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  avatar_url text,
  psn_id text,
  bio text,
  driver_rating text,
  safety_rating text,
  favorite_car text,
  home_region text,
  total_races integer DEFAULT 0,
  total_wins integer DEFAULT 0,
  "is_public" boolean DEFAULT true,
  "is_admin" boolean DEFAULT false,
  "show_results" boolean DEFAULT true,
  "show_ranking" boolean DEFAULT true,
  "show_stats" boolean DEFAULT true,
  "show_photo" boolean DEFAULT true,
  "show_bio" boolean DEFAULT true,
  "is_banned" boolean DEFAULT false,
  created_at timestamp WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public Read Profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Owner Manage Profile" ON public.profiles FOR ALL USING (auth.uid() = id);

-- Tabela: entries
CREATE TABLE IF NOT EXISTS public.entries (
  id uuid DEFAULT uuid_generate_v4() NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  "trackId" text NOT NULL,
  "carBrand" text,
  "carName" text,
  "carSetup" text,
  "racePosition" text,
  "tractionControl" text,
  "carMap" text,
  "pitStops" text,
  "runDate" text,
  weather text,
  "lapTime" text,
  "totalTime" text,
  "provaDeTempo" text,
  "avgLapTime" text,
  "transmission" text DEFAULT 'Automática',
  "peripheral" text DEFAULT 'Controle',
  "customFields" jsonb DEFAULT '{}'::jsonb,
  "evidence_image" text,
  "pilot_name" text,
  "laps" text,
  "is_public" boolean DEFAULT true,
  created_at timestamp WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id, user_id),
  FOREIGN KEY ("trackId", user_id) REFERENCES public.tracks(id, user_id) ON DELETE CASCADE
);
ALTER TABLE public.entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public Read Entries" ON public.entries FOR SELECT USING (true);
CREATE POLICY "Owner Manage Entries" ON public.entries FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Tabela: user_settings
CREATE TABLE IF NOT EXISTS public.user_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  layout jsonb,
  logo_overrides jsonb,
  logos_database jsonb,
  cars_database jsonb,
  victory_music_url text,
  updated_at timestamp WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owner Manage Settings" ON public.user_settings FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Índices essenciais para otimização de performance e prevenção de Statement Timeouts (Timeout 57014)
CREATE INDEX IF NOT EXISTS idx_entries_user_id ON public.entries(user_id);
CREATE INDEX IF NOT EXISTS idx_entries_trackId ON public.entries("trackId");
CREATE INDEX IF NOT EXISTS idx_entries_lapTime ON public.entries("lapTime");
CREATE INDEX IF NOT EXISTS idx_tracks_user_id ON public.tracks(user_id);
CREATE INDEX IF NOT EXISTS idx_tracks_name ON public.tracks(name);
CREATE INDEX IF NOT EXISTS idx_profiles_total_wins ON public.profiles(total_wins DESC);

-- Migration: Adicionar colunas caso não existam (para usuários que já criaram tabelas antes)
DO $$ 
BEGIN
    -- Colunas em Entries
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='is_public') THEN
        ALTER TABLE public.entries ADD COLUMN is_public boolean DEFAULT true;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='pilot_name') THEN
        ALTER TABLE public.entries ADD COLUMN "pilot_name" text;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='laps') THEN
        ALTER TABLE public.entries ADD COLUMN "laps" text;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='transmission') THEN
        ALTER TABLE public.entries ADD COLUMN "transmission" text DEFAULT 'Automática';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='peripheral') THEN
        ALTER TABLE public.entries ADD COLUMN "peripheral" text DEFAULT 'Controle';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='evidence_image') THEN
        ALTER TABLE public.entries ADD COLUMN "evidence_image" text;
    END IF;

    -- Colunas em User Settings
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_settings' AND column_name='logos_database') THEN
        ALTER TABLE public.user_settings ADD COLUMN logos_database jsonb;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_settings' AND column_name='cars_database') THEN
        ALTER TABLE public.user_settings ADD COLUMN cars_database jsonb;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_settings' AND column_name='victory_music_url') THEN
        ALTER TABLE public.user_settings ADD COLUMN victory_music_url text;
    END IF;

    -- Colunas em Profiles
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='is_banned') THEN
        ALTER TABLE public.profiles ADD COLUMN is_banned boolean DEFAULT false;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='is_admin') THEN
        ALTER TABLE public.profiles ADD COLUMN is_admin boolean DEFAULT false;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='total_wins') THEN
        ALTER TABLE public.profiles ADD COLUMN total_wins integer DEFAULT 0;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='profiles' AND column_name='total_races') THEN
        ALTER TABLE public.profiles ADD COLUMN total_races integer DEFAULT 0;
    END IF;

    -- Garantir Case Sensitive nas colunas de Entries (Normalização para o App)
    -- Postgres unquoted fica lowercase. O App usa camelCase.
    -- Se as colunas existirem como lowercase mas o app enviar camelCase, o PostgREST pode falhar ou ignorar dependendo da config.
    -- Vamos tentar renomear para garantir que batam com o payload do App.
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='carbrand') THEN
        ALTER TABLE public.entries RENAME COLUMN "carbrand" TO "carBrand";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='carname') THEN
        ALTER TABLE public.entries RENAME COLUMN "carname" TO "carName";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='carsetup') THEN
        ALTER TABLE public.entries RENAME COLUMN "carsetup" TO "carSetup";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='raceposition') THEN
        ALTER TABLE public.entries RENAME COLUMN "raceposition" TO "racePosition";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='tractioncontrol') THEN
        ALTER TABLE public.entries RENAME COLUMN "tractioncontrol" TO "tractionControl";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='carmap') THEN
        ALTER TABLE public.entries RENAME COLUMN "carmap" TO "carMap";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='pitstops') THEN
        ALTER TABLE public.entries RENAME COLUMN "pitstops" TO "pitStops";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='rundate') THEN
        ALTER TABLE public.entries RENAME COLUMN "rundate" TO "runDate";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='laptime') THEN
        ALTER TABLE public.entries RENAME COLUMN "laptime" TO "lapTime";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='totaltime') THEN
        ALTER TABLE public.entries RENAME COLUMN "totaltime" TO "totalTime";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='provadetempo') THEN
        ALTER TABLE public.entries RENAME COLUMN "provadetempo" TO "provaDeTempo";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='avglaptime') THEN
        ALTER TABLE public.entries RENAME COLUMN "avglaptime" TO "avgLapTime";
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='entries' AND column_name='customfields') THEN
        ALTER TABLE public.entries RENAME COLUMN "customfields" TO "customFields";
    END IF;

END $$;

-- Reparo de dados e colunas para garantir visibilidade
DO $$ 
BEGIN
    UPDATE public.profiles SET 
      is_public = true,
      show_results = true,
      show_ranking = true,
      show_stats = true,
      show_photo = true,
      show_bio = true
    WHERE is_public IS NULL OR is_public = false;
    
    UPDATE public.entries SET is_public = true WHERE is_public IS NULL OR is_public = false;
    UPDATE public.tracks SET is_public = true WHERE is_public IS NULL OR is_public = false;
END $$;

-- Criar perfil retroativamente para usuários antigos (desde o começo do app)
INSERT INTO public.profiles (id, display_name, is_public, show_results, show_ranking, show_stats, show_photo, show_bio)
SELECT id, COALESCE(raw_user_meta_data->>'full_name', 'Piloto'), true, true, true, true, true, true
FROM auth.users
WHERE id NOT IN (SELECT id FROM public.profiles);

-- ESSENCIAL: Garantir FK para permitir Joins no PostgREST entre entries e profiles
-- Sem isso, o join via 'profiles (...)' pode falhar se não houver relação explícita no public schema
ALTER TABLE public.entries DROP CONSTRAINT IF EXISTS fk_entries_profiles;
ALTER TABLE public.entries ADD CONSTRAINT fk_entries_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Trigger para criar perfil automaticamente no Signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Bloquear novos cadastros no banco de dados para qualquer e-mail que não seja o do administrador rAd
  IF new.email != 'rAd.endbringer@gmail.com' AND new.email != 'rad.endbringer@gmail.com' THEN
    RAISE EXCEPTION 'A criação de novas contas foi desativada pelo administrador.';
  END IF;

  INSERT INTO public.profiles (id, display_name, is_public, show_results, show_ranking, show_stats, show_photo, show_bio)
  VALUES (new.id, COALESCE(new.raw_user_meta_data->>'full_name', 'Piloto'), true, true, true, true, true, true)
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Tabela de importação temporária
CREATE TABLE IF NOT EXISTS public.gt7_cars_import (
  "ID" INTEGER,
  "ShortName" TEXT,
  "Maker" INTEGER
);

-- Tabela final usada pelo app
CREATE TABLE IF NOT EXISTS public.gt7_cars (
  id INTEGER PRIMARY KEY,
  short_name TEXT NOT NULL,
  maker_id INTEGER,
  thumbnail_file TEXT GENERATED ALWAYS AS (id::TEXT || '.webp') STORED,
  thumbnail_path TEXT GENERATED ALWAYS AS ('assets/cars/' || id::TEXT || '.webp') STORED,
  thumbnail_fallback TEXT DEFAULT 'assets/cars/placeholder.webp',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Migração de import para a tabela final (opcional, pode ser rodado ao inserir no gt7_cars_import)
INSERT INTO public.gt7_cars (id, short_name, maker_id) 
SELECT "ID", "ShortName", "Maker" 
FROM public.gt7_cars_import 
WHERE "ID" IS NOT NULL 
ON CONFLICT (id) DO UPDATE 
SET short_name = EXCLUDED.short_name, maker_id = EXCLUDED.maker_id, updated_at = NOW();

-- View consumida pelo App
CREATE OR REPLACE VIEW public.gt7_cars_with_thumbnails AS
SELECT id, short_name, maker_id, thumbnail_file, thumbnail_path, thumbnail_fallback
FROM public.gt7_cars
ORDER BY short_name ASC;

-- Garantir GRANTs EXPLICITOS
GRANT ALL ON TABLE public.tracks TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.entries TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.profiles TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.user_settings TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.gt7_cars TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.gt7_cars_with_thumbnails TO anon, authenticated, service_role;


-- Bucket de Storage
INSERT INTO storage.buckets (id, name, public)
VALUES ('evidences', 'evidences', true)
ON CONFLICT (id) DO NOTHING;

-- RLS de Storage
DROP POLICY IF EXISTS "Public Read Access" ON storage.objects;
DROP POLICY IF EXISTS "Auth Upload Access" ON storage.objects;
DROP POLICY IF EXISTS "Owner Management Access" ON storage.objects;

CREATE POLICY "Public Read Access" ON storage.objects FOR SELECT USING (bucket_id = 'evidences');
CREATE POLICY "Auth Upload Access" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'evidences' AND auth.role() = 'authenticated');
CREATE POLICY "Owner Management Access" ON storage.objects FOR ALL USING (bucket_id = 'evidences' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Admin Management Access" ON storage.objects FOR ALL USING (bucket_id = 'evidences' AND EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true));

-- Funções Administrativas de Auth
CREATE OR REPLACE FUNCTION public.current_user_is_admin()
RETURNS boolean AS $$
DECLARE
  is_admin boolean;
BEGIN
  SELECT profiles.is_admin INTO is_admin FROM public.profiles WHERE id = auth.uid();
  RETURN COALESCE(is_admin, false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_delete_auth_user(target_user_id uuid)
RETURNS void AS $$
BEGIN
  -- Requer que quem chama seja admin
  IF NOT public.current_user_is_admin() THEN
    RAISE EXCEPTION 'Acesso negado. Apenas administradores podem excluir usuários.';
  END IF;

  -- Deleta o usuário da tabela de autenticação (Cascade fará o resto, desde que o storage já tenha sido limpo via API)
  DELETE FROM auth.users WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.admin_toggle_user_ban(target_user_id uuid, should_ban boolean)
RETURNS void AS $$
BEGIN
  -- Requer que quem chama seja admin
  IF NOT public.current_user_is_admin() THEN
    RAISE EXCEPTION 'Acesso negado. Apenas administradores podem banir usuários.';
  END IF;

  UPDATE public.profiles SET is_banned = should_ban WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Forçar reload do schema schema-cache do Supabase novamente no final do script
NOTIFY pgrst, 'reload schema';


-- GT7 STORAGE + TRACK ASSETS PATCH
-- Run after the current SUPABASE_SCHEMA.sql. It is safe to run more than once.
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1) Dedicated public bucket for car thumbnails, track logos and track backgrounds.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'gt7-assets',
  'gt7-assets',
  true,
  10485760,
  ARRAY['image/png','image/jpeg','image/jpg','image/webp','image/svg+xml','image/gif']
)
ON CONFLICT (id) DO UPDATE
SET public = true,
    file_size_limit = 10485760,
    allowed_mime_types = ARRAY['image/png','image/jpeg','image/jpg','image/webp','image/svg+xml','image/gif'];

-- 2) Car assets table used by src/services/carAssetService.ts.
CREATE TABLE IF NOT EXISTS public.car_assets (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  car_name text NOT NULL,
  car_slug text NOT NULL UNIQUE,
  image_url text NOT NULL,
  storage_path text,
  created_at timestamptz NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at timestamptz NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.car_assets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Car Assets" ON public.car_assets;
DROP POLICY IF EXISTS "Auth Manage Own Car Assets" ON public.car_assets;
DROP POLICY IF EXISTS "Admin Manage Car Assets" ON public.car_assets;
CREATE POLICY "Public Read Car Assets" ON public.car_assets FOR SELECT USING (true);
CREATE POLICY "Auth Manage Own Car Assets" ON public.car_assets FOR ALL
USING (auth.uid() = user_id OR user_id IS NULL)
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);
CREATE POLICY "Admin Manage Car Assets" ON public.car_assets FOR ALL
USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true))
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

-- 3) Track assets table. This keeps logo/background linked to the track,
-- instead of relying only on a large user_settings.logo_overrides JSON field.
CREATE TABLE IF NOT EXISTS public.track_assets (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  track_id text NOT NULL,
  asset_type text NOT NULL CHECK (asset_type IN ('logo', 'background')),
  image_url text NOT NULL,
  storage_path text,
  created_at timestamptz NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at timestamptz NOT NULL DEFAULT timezone('utc'::text, now()),
  UNIQUE(user_id, track_id, asset_type)
);

ALTER TABLE public.track_assets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Track Assets" ON public.track_assets;
DROP POLICY IF EXISTS "Owner Manage Track Assets" ON public.track_assets;
CREATE POLICY "Public Read Track Assets" ON public.track_assets FOR SELECT USING (true);
CREATE POLICY "Owner Manage Track Assets" ON public.track_assets FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 4) Optional Supabase thumbnail table referenced by src/lib/thumbnailSupabase.ts.
CREATE TABLE IF NOT EXISTS public.thumbnails (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  car_name text NOT NULL UNIQUE,
  base64 text,
  image_url text,
  created_at timestamptz NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at timestamptz NOT NULL DEFAULT timezone('utc'::text, now())
);
ALTER TABLE public.thumbnails ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Thumbnails" ON public.thumbnails;
DROP POLICY IF EXISTS "Auth Manage Thumbnails" ON public.thumbnails;
CREATE POLICY "Public Read Thumbnails" ON public.thumbnails FOR SELECT USING (true);
CREATE POLICY "Auth Manage Thumbnails" ON public.thumbnails FOR ALL
USING (auth.uid() = user_id OR user_id IS NULL)
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- 5) Storage policies for gt7-assets.
DROP POLICY IF EXISTS "GT7 Assets Public Read" ON storage.objects;
DROP POLICY IF EXISTS "GT7 Assets Auth Upload" ON storage.objects;
DROP POLICY IF EXISTS "GT7 Assets Owner Update" ON storage.objects;
DROP POLICY IF EXISTS "GT7 Assets Owner Delete" ON storage.objects;
CREATE POLICY "GT7 Assets Public Read" ON storage.objects
FOR SELECT USING (bucket_id = 'gt7-assets');
CREATE POLICY "GT7 Assets Auth Upload" ON storage.objects
FOR INSERT TO authenticated WITH CHECK (bucket_id = 'gt7-assets');
CREATE POLICY "GT7 Assets Owner Update" ON storage.objects
FOR UPDATE TO authenticated USING (bucket_id = 'gt7-assets') WITH CHECK (bucket_id = 'gt7-assets');
CREATE POLICY "GT7 Assets Owner Delete" ON storage.objects
FOR DELETE TO authenticated USING (bucket_id = 'gt7-assets');

GRANT ALL ON TABLE public.car_assets TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.track_assets TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.thumbnails TO anon, authenticated, service_role;

-- 6) Triggers for automated updated_at timestamps
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_profiles_updated_at ON public.profiles;
CREATE TRIGGER set_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS set_user_settings_updated_at ON public.user_settings;
CREATE TRIGGER set_user_settings_updated_at BEFORE UPDATE ON public.user_settings FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS set_car_assets_updated_at ON public.car_assets;
CREATE TRIGGER set_car_assets_updated_at BEFORE UPDATE ON public.car_assets FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS set_track_assets_updated_at ON public.track_assets;
CREATE TRIGGER set_track_assets_updated_at BEFORE UPDATE ON public.track_assets FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS set_thumbnails_updated_at ON public.thumbnails;
CREATE TRIGGER set_thumbnails_updated_at BEFORE UPDATE ON public.thumbnails FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- =========================================================================
-- SEGURANÇA & LIMPEZA DE PILOTOS (Requerido pelo Administrador)
-- ATENÇÃO: Executar este bloco manualmente apenas quando o app estiver offline
-- para evitar deadlocks/timeouts com as conexões ativas do container web.
-- =========================================================================
/*
DO $$
DECLARE
  admin_uuid uuid;
BEGIN
  -- Encontra o ID do administrador 'rAd' na tabela public.profiles
  SELECT id INTO admin_uuid FROM public.profiles WHERE is_admin = true LIMIT 1;
  
  -- Se o admin não foi encontrado pela flag is_admin, tenta localizar pelo e-mail
  IF admin_uuid IS NULL THEN
    SELECT id INTO admin_uuid FROM auth.users WHERE email = 'rAd.endbringer@gmail.com' OR email = 'rad.endbringer@gmail.com' LIMIT 1;
    
    -- Se localizado, garante que a flag 'is_admin' fique ativa no perfil para preservação
    IF admin_uuid IS NOT NULL THEN
      UPDATE public.profiles SET is_admin = true WHERE id = admin_uuid;
    END IF;
  END IF;

  -- Se encontramos o ID do administrador com sucesso
  IF admin_uuid IS NOT NULL THEN
    -- Apaga todos os registros de auth.users que não sejam o administrador
    -- (A cláusula ON DELETE CASCADE remove automaticamente as tabelas associadas)
    DELETE FROM auth.users WHERE id != admin_uuid;
  END IF;
END $$;
*/

NOTIFY pgrst, 'reload schema';
