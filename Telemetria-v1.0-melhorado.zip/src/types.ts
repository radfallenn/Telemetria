export interface Track {
  id: string;
  name: string;
  location?: string;
  packId?: string;
  is_public?: boolean;
}

export interface Entry {
  id: string;
  user_id?: string;
  trackId: string;
  carBrand: string;
  carName: string;
  carSetup: string;
  racePosition: string;
  tractionControl: string;
  carMap: string;
  pitStops: string;
  runDate: string;
  weather: string;
  lapTime: string;
  totalTime: string;
  provaDeTempo?: string;
  avgLapTime: string;
  laps?: string;
  pilot_name?: string;
  transmission?: string;
  peripheral?: string;
  customFields?: Record<string, string>;
  evidence_image?: string;
  is_public?: boolean;
  velocidade_final?: string;
  telemetria_completa?: any;
}

export interface CustomField {
  id: string;
  label: string;
}

export interface FieldConfig {
  id: string;
  label: string;
  colSpan: number; // 1 to 12
  hidden: boolean;
  isCustom?: boolean;
}

export interface LayoutProfile {
  id: string;
  name: string;
  editMode: boolean;
  freeMode: boolean;
  showGridLabels: boolean;
  snapEnabled: boolean;
  cardRadius: number;
  cardPadding: number;
  rowGap: number;
  showActions: boolean;
  smallActions: boolean;
  cellFont: number;
  cellHeight: number;
  statHeight: number;
  actionSize: number;
  gridRowHeight: number;
  canvasMinRows: number;
  titleRatio: number;
  row2Ratio1: number;
  row2Ratio2: number;
  row2Ratio3: number;
  row3Ratio: number;
  row4Ratio: number;
  statsRatio: number;
  titleMode: 'same-line' | 'broken';
  row2Cols: number;
  row3Cols: number;
  row4Cols: number;
  actionAlign: 'left' | 'center' | 'right';
  compactMode?: boolean;
  
  // Legacy fields (kept for migration but optional/deprecated)
  hiddenRows?: string[];
  rowOrder?: string[];
  rowPlacements?: Record<string, { x: number; y: number; w: number; h: number }>;
  labels?: Record<string, string>;
  customFields?: CustomField[];

  // New layout system
  fields: FieldConfig[];
}

export interface LogoBrand {
  id: string;
  brand_name: string;
  brand_slug: string;
  logo_data: string;
  logo_type: 'png' | 'jpg' | 'webp' | 'svg';
  created_at: number;
  updated_at: number;
}

export type DriverRating = 'D' | 'C' | 'B' | 'A' | 'A+' | 'S';
export type SafetyRating = 'E' | 'D' | 'C' | 'B' | 'A' | 'S';

export interface Car {
  car_id: string;
  car_slug: string;
  brand_slug: string;
  brand_name: string;
  car_name: string;
  full_display_name: string;
  year: string | null;
  group_code: string | null;
  category: string;
  type: string;
  model_label: string;
  image_file: string;
  image_url: string | null;
  thumbnail_file: string;
  thumbnail_url: string | null;
  search_aliases: string[];
  insertionCount: number;
}

export interface Brand {
  maker_id: string;
  brand_slug: string;
  brand_name: string;
  country_id: string;
  logo_file: string;
  logo_url: string | null;
  search_terms: string[];
}

export interface UserProfile {
  id: string;
  display_name: string;
  email?: string;
  last_sign_in_at?: string | null;
  is_public?: boolean;
  is_admin?: boolean;
  psn_id?: string;
  avatar_url?: string;
  bio?: string;
  driver_rating?: DriverRating;
  safety_rating?: SafetyRating;
  favorite_car?: string;
  home_region?: string;
  total_races?: number;
  total_wins?: number;
  show_results?: boolean;
  show_ranking?: boolean;
  show_stats?: boolean;
  show_photo?: boolean;
  show_bio?: boolean;
  is_banned?: boolean;
  created_at?: string;
  last_online?: string;
}
