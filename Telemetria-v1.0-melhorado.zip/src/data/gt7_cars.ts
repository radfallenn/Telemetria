import { Car } from '../types';

export const RAW_CARS: any[] = [
  {
    "car_id": "1932",
    "car_slug": "abarth_1500_biposto_bertone_b_a_t_1_52",
    "brand_slug": "abarth",
    "brand_name": "Abarth",
    "car_name": "1500 Biposto Bertone B.A.T 1 '52",
    "full_display_name": "Abarth 1500 Biposto Bertone B.A.T 1 '52",
    "year": "1952",
    "group_code": null,
    "category": "Road Car",
    "type": "Road Car",
    "model_label": "1952 / Road Car / Road Car",
    "image_file": "cars/abarth_1500_biposto_bertone_b_a_t_1_52.png",
    "image_url": null,
    "thumbnail_file": "cars/thumbs/abarth_1500_biposto_bertone_b_a_t_1_52.png",
    "thumbnail_url": null,
    "search_aliases": [
      "1500 Biposto Bertone B.A.T 1 '52",
      "1500 biposto bertone b a t 1 52",
      "Abarth 1500 Biposto Bertone B.A.T 1 '52",
      "abarth 1500 biposto bertone b a t 1 52"
    ]
  },
  {
    "car_id": "1973",
    "car_slug": "abarth_abarth_500_09",
    "brand_slug": "abarth",
    "brand_name": "Abarth",
    "car_name": "Abarth 500 '09",
    "full_display_name": "Abarth Abarth 500 '09",
    "year": "2009",
    "group_code": null,
    "category": "Road Car",
    "type": "Road Car",
    "model_label": "2009 / Road Car / Road Car",
    "image_file": "cars/abarth_abarth_500_09.png",
    "image_url": null,
    "thumbnail_file": "cars/thumbs/abarth_abarth_500_09.png",
    "thumbnail_url": null,
    "search_aliases": [
      "Abarth 500 '09",
      "Abarth Abarth 500 '09",
      "abarth 500 09",
      "abarth abarth 500 09"
    ]
  },
  {
    "car_id": "3438",
    "car_slug": "abarth_abarth_595_ss_70",
    "brand_slug": "abarth",
    "brand_name": "Abarth",
    "car_name": "Abarth 595 SS '70",
    "full_display_name": "Abarth Abarth 595 SS '70",
    "year": "1970",
    "group_code": null,
    "category": "Road Car",
    "type": "Road Car",
    "model_label": "1970 / Road Car / Road Car",
    "image_file": "cars/abarth_abarth_595_ss_70.png",
    "image_url": null,
    "thumbnail_file": "cars/thumbs/abarth_abarth_595_ss_70.png",
    "thumbnail_url": null,
    "search_aliases": [
      "Abarth 595 SS '70",
      "Abarth Abarth 595 SS '70",
      "abarth 595 ss 70",
      "abarth abarth 595 ss 70"
    ]
  },
  {
    "car_id": "3579",
    "car_slug": "afeela_afeela_1_26",
    "brand_slug": "afeela",
    "brand_name": "AFEELA",
    "car_name": "AFEELA 1 '26",
    "full_display_name": "AFEELA AFEELA 1 '26",
    "year": "2026",
    "group_code": null,
    "category": "Road Car",
    "type": "Road Car",
    "model_label": "2026 / Road Car / Road Car",
    "image_file": "cars/afeela_afeela_1_26.png",
    "image_url": null,
    "thumbnail_file": "cars/thumbs/afeela_afeela_1_26.png",
    "thumbnail_url": null,
    "search_aliases": [
      "AFEELA 1 '26",
      "AFEELA AFEELA 1 '26",
      "afeela 1 26",
      "afeela afeela 1 26"
    ]
  },
  {
    "car_id": "3546",
    "car_slug": "afeela_afeela_prototype_2024",
    "brand_slug": "afeela",
    "brand_name": "AFEELA",
    "car_name": "AFEELA Prototype 2024",
    "full_display_name": "AFEELA AFEELA Prototype 2024",
    "year": null,
    "group_code": "X",
    "category": "Race Car",
    "type": "Race Car",
    "model_label": "Sem ano / Race Car / Race Car",
    "image_file": "cars/afeela_afeela_prototype_2024.png",
    "image_url": null,
    "thumbnail_file": "cars/thumbs/afeela_afeela_prototype_2024.png",
    "thumbnail_url": null,
    "search_aliases": [
      "AFEELA AFEELA Prototype 2024",
      "AFEELA Prototype 2024",
      "afeela afeela prototype 2024",
      "afeela prototype 2024"
    ]
  }
  // ... (restante dos dados omitido para brevidade, mas deve ser incluído)
];
