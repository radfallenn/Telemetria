// GT7 Autocomplete Data Pack V2
export const GT7_V2_DATA = {
  "meta": {
    "title": "GT7 Autocomplete Data Pack v2",
    "counts": {
      "cars": 572,
      "makers": 81,
      "countries": 19,
      "tracks": 20
    },
    "use_case": "auto preenchimento de marca, modelo, classe, pista e reaproveitamento de dados salvos"
  },
  "autocomplete": {
    "makers": [
      "AFEELA",
      "AMG",
      "Abarth",
      "Alfa Romeo",
      "Alpine",
      "Amuse",
      "Aston Martin",
      "Audi",
      "Autobianchi",
      "BAC",
      "BMW",
      "BVLGARI",
      "Bugatti",
      "Chaparral",
      "Chevrolet",
      "Chris Holstrom Concepts",
      "Citroen",
      "DMC",
      "DS AUTOMOBILES",
      "Daihatsu",
      "De Tomaso",
      "Dodge",
      "Eckert's Rod & Custom",
      "Ferrari",
      "Fiat",
      "Ford",
      "Garage RCR",
      "Genesis",
      "Gran Turismo",
      "Greddy",
      "Greening Auto Company",
      "Honda",
      "Hyundai",
      "Infiniti",
      "Italdesign",
      "Jaguar",
      "Jeep",
      "KTM",
      "Lamborghini",
      "Lancia",
      "Lexus",
      "MINI",
      "Maserati",
      "Mazda",
      "McLaren",
      "Mercedes-Benz",
      "Mine's",
      "Mitsubishi",
      "NISMO",
      "Nissan",
      "Opel",
      "Pagani",
      "Peugeot",
      "Plymouth",
      "Polestar",
      "Pontiac",
      "Porsche",
      "RE Amemiya",
      "RUF",
      "Radical",
      "Renault",
      "Roadster Shop",
      "Shelby",
      "Skoda",
      "Subaru",
      "Super Formula (Dallara)",
      "Suzuki",
      "TVR",
      "Tesla",
      "Toyota",
      "Volkswagen",
      "Volvo",
      "Wicked Fabrication",
      "Xiaomi",
      "Zagato"
    ],
    "models_by_maker": {
      "AFEELA": [
        "AFEELA 1 '26",
        "AFEELA Prototype 2024"
      ],
      "AMG": [
        "300 SEL 6.8 AMG '71",
        "A 45 AMG '13",
        "GT3 '20",
        "Mercedes-AMG C 63 S '15",
        "Mercedes-AMG GT Black Series '20",
        "Mercedes-AMG GT R '17",
        "Mercedes-AMG GT S '15",
        "Mercedes-AMG GT Safety Car",
        "Mercedes-AMG GT3 '16",
        "Mercedes-Benz AMG VGT",
        "Mercedes-Benz AMG VGT Racing Series",
        "SLS AMG '10",
        "SLS AMG GT3 '11",
        "SLS AMG Gr.4"
      ],
      "Abarth": [
        "1500 Biposto Bertone B.A.T 1 '52",
        "Abarth 500 '09",
        "Abarth 595 SS '70"
      ],
      "Alfa Romeo": [
        "155 2.5 V6 TI '93",
        "4C '14",
        "4C Gr.3",
        "4C Gr.3 Road Car",
        "4C Gr.4",
        "8C 2900B Touring Berlinetta '38",
        "8C Competizione '08",
        "GIULIA TZ2 carrozzata da ZAGATO '65",
        "Giulia GTAm '20",
        "Giulia Sprint GT Veloce '67",
        "MiTo '09"
      ],
      "Alpine": [
        "A110 '17",
        "A110 '72",
        "A220 Race Car '68",
        "Alpine VGT",
        "Alpine VGT '17",
        "Alpine VGT Race"
      ],
      "Amuse": [
        "Amuse NISMO 380RS Super Leggera",
        "Amuse S2000 GT1 Turbo"
      ],
      "Aston Martin": [
        "DB11 '16",
        "DB3S '53",
        "DB5 '64",
        "DBR9 GT1 '10",
        "DP-100 VGT",
        "One-77 '11",
        "V12 Vantage GT3 '12",
        "V8 Vantage Gr.4",
        "V8 Vantage S '15",
        "Valkyrie '21",
        "Vantage '18",
        "Vulcan '16"
      ],
      "Audi": [
        "Audi VGT",
        "Audi e-tron VGT",
        "R18 '16",
        "R18 TDI '11",
        "R8 4.2 '07",
        "R8 Coupé V10 plus '16",
        "R8 LMS '15",
        "R8 LMS Evo '19",
        "RS 5 Turbo DTM '19",
        "Sport quattro S1 Pikes Peak '87",
        "TT Coupe 3.2 quattro '03",
        "TT Cup '16",
        "TTS Coupe '09",
        "TTS Coupe '14"
      ],
      "Autobianchi": [
        "A112 Abarth '85"
      ],
      "BAC": [
        "Mono '16"
      ],
      "BMW": [
        "3.0 CSL '71",
        "3.0 CSL '73",
        "BMW VGT",
        "M2 Competition '18",
        "M3 '03",
        "M3 '07",
        "M3 '89",
        "M3 '97",
        "M3 GT '11",
        "M3 Sport Evolution '89",
        "M4 '14",
        "M4 Gr.4",
        "M4 Safety Car",
        "M6 GT3 Endurance Model '16",
        "M6 GT3 Sprint Model '16",
        "McLaren F1 GTR Race Car '97",
        "Z4 3.0i '03",
        "Z4 GT3 '11",
        "Z8 '01",
        "i3 '15"
      ],
      "BVLGARI": [
        "BVLGARI Aluminium VGT"
      ],
      "Bugatti": [
        "Bugatti VGT",
        "Bugatti VGT (Gr.1)",
        "Chiron '16",
        "Veyron 16.4 '13",
        "Veyron Gr.4"
      ],
      "Chaparral": [
        "2J '70",
        "Chaparral 2X VGT"
      ],
      "Chevrolet": [
        "Camaro 1969 Race-Mod",
        "Camaro SS '16",
        "Camaro Z28 '69",
        "Camaro ZL1 1LE Package '18",
        "Chevelle SS 454 Sport Coupé '70",
        "Corvette (C1) '58",
        "Corvette (C2) '63",
        "Corvette C7 '14",
        "Corvette C7 Gr.3",
        "Corvette C7 Gr.3 Road Car",
        "Corvette C7 Gr.4",
        "Corvette C7 ZR1 '19",
        "Corvette C8 Stingray '20",
        "Corvette CX Concept '25",
        "Corvette CX.R Vision Gran Turismo Concept",
        "Corvette Convertible (C3) '69",
        "Corvette Stingray (C3) '69",
        "Corvette Stingray Racer Concept '59",
        "Corvette Z06 (C5) '01",
        "Corvette ZR-1 (C4) '89",
        "Corvette ZR1 (C6) '09"
      ],
      "Chris Holstrom Concepts": [
        "CHC 1967 Chevy Nova"
      ],
      "Citroen": [
        "BX 19 TRS '87",
        "DS 21 Pallas '70",
        "GT by Citroen Gr.4",
        "GT by Citroen Race Car (Gr.3)",
        "GT by Citroen Road Car"
      ],
      "DMC": [
        "DeLorean S2 '04"
      ],
      "DS AUTOMOBILES": [
        "DS 3 Racing '11"
      ],
      "Daihatsu": [
        "COPEN RJ VGT",
        "Copen '02"
      ],
      "De Tomaso": [
        "Mangusta '69",
        "Mangusta (Christian Dior)",
        "Pantera '71"
      ],
      "Dodge": [
        "Challenger R/T '70",
        "Challenger SRT Demon '18",
        "Charger R/T 426 Hemi '68",
        "Charger SRT Hellcat '15",
        "Charger SRT Hellcat Safety Car",
        "SRT Tomahawk GTS-R VGT",
        "SRT Tomahawk S VGT",
        "SRT Tomahawk VGT (Gr.1)",
        "SRT Tomahawk X VGT",
        "Super Bee '70",
        "Viper GTS '02",
        "Viper GTS '13",
        "Viper Gr.4",
        "Viper SRT GT3-R '15",
        "Viper SRT10 Coupe '06"
      ],
      "Eckert's Rod & Custom": [
        "Mach Forty"
      ],
      "Ferrari": [
        "250 GT Berlinetta passo corto '61",
        "250 GTO '62",
        "296 GT3 '23",
        "296 GTB '22",
        "308 GTB '75",
        "330 P4 '67",
        "365 GTB4 '71",
        "430 Scuderia '07",
        "458 Italia '09",
        "458 Italia GT3 '13",
        "458 Italia Gr.4",
        "500 Mondial Pinin Farina Coupe '54",
        "512 BB '76",
        "812 Superfast '17",
        "Dino 246 GT '71",
        "Enzo Ferrari '02",
        "F12berlinetta '12",
        "F40 '92",
        "F430 '06",
        "F50 '95",
        "F8 Tributo '19",
        "FXX K '14",
        "Ferrari Vision Gran Turismo",
        "GTO '84",
        "LaFerrari '13",
        "Testarossa '91"
      ],
      "Fiat": [
        "500 1.2 8V Lounge SS '08",
        "500 F '68",
        "Panda 30 CL '85"
      ],
      "Ford": [
        "1932 Ford Roadster Hot Rod",
        "Escort RS Cosworth '92",
        "F-150 SVT Raptor '11",
        "Focus Gr.B Rally Car",
        "Focus RS '18",
        "Focus ST '15",
        "Ford GT '06",
        "Ford GT '17",
        "Ford GT LM Race Car Spec II",
        "Ford GT LM Spec II Test Car",
        "Ford GT Race Car '18",
        "GT40 Mark I '66",
        "Mark IV Race Car '67",
        "Mustang 2015 American Racer",
        "Mustang Boss 429 '69",
        "Mustang GT '15",
        "Mustang Gr.3",
        "Mustang Gr.3 Road Car",
        "Mustang Gr.4",
        "Mustang Gr.B Rally Car",
        "Mustang Mach 1 '71",
        "Shelby GT350R '16",
        "Sierra RS 500 Cosworth '87"
      ],
      "Garage RCR": [
        "Civic"
      ],
      "Genesis": [
        "G70 3.3T AWD Prestige Package '22",
        "G70 GR4",
        "Genesis X GR3",
        "Genesis X Gran Berlinetta VGT Concept",
        "Genesis X Gran Racer Vision Gran Turismo Concept"
      ],
      "Gran Turismo": [
        "F1500T-A",
        "F3500-A",
        "F3500-B",
        "Racing Kart 125 Shifter",
        "Red Bull X2014 Junior",
        "Red Bull X2014 Standard",
        "Red Bull X2019 25th Anniversary",
        "Red Bull X2019 Competition"
      ],
      "Greddy": [
        "Greddy Fugu Z"
      ],
      "Greening Auto Company": [
        "Maverick"
      ],
      "Honda": [
        "2&4 powered by RC213V",
        "Beat '91",
        "CR-V e:HEV EX Black Edition '21",
        "Civic Si Extra (EF) '87",
        "Civic SiR-II (EG) '93",
        "Civic Type R (EK) '97",
        "Civic Type R (EK) '98",
        "Civic Type R (EK) Touring Car",
        "Civic Type R (FK2) '15",
        "Civic Type R (FL5) '22",
        "Civic Type R Limited Edition (FK8) '20",
        "Fit Hybrid '14",
        "Honda Sports VGT",
        "Integra Type R (DC2) '95",
        "Integra Type R (DC2) '98",
        "N-ONE RS '22",
        "NSX '17",
        "NSX CONCEPT-GT '16",
        "NSX GT500 '00",
        "NSX GT500 '08",
        "NSX Gr.3",
        "NSX Gr.4",
        "NSX Gr.B Rally Car",
        "NSX Type R '02",
        "NSX Type R '92",
        "RA272 '65",
        "S2000 '99",
        "S660 '15",
        "S800 '66"
      ],
      "Hyundai": [
        "ELANTRA N '23",
        "ELANTRA N TC '24",
        "Genesis Coupe 3.8 '13",
        "Genesis Gr.3",
        "Genesis Gr.4",
        "Genesis Gr.B Rally Car",
        "HYUNDAI N 2025 VGT",
        "HYUNDAI N 2025 VGT (Gr.1)",
        "IONIQ 5 N '24"
      ],
      "Infiniti": [
        "INFINITI CONCEPT VGT"
      ],
      "Italdesign": [
        "Italdesign VGT Off-road Mode",
        "Italdesign VGT Street Mode"
      ],
      "Jaguar": [
        "D-type '54",
        "E-type Coupe '61",
        "F-type Gr.3",
        "F-type Gr.4",
        "F-type R '14",
        "Jaguar VGT Coupe",
        "Jaguar VGT Roadster",
        "Jaguar VGT SV",
        "XJ13 '66",
        "XJ220 '92",
        "XJR-9 '88"
      ],
      "Jeep": [
        "Willys MB '45"
      ],
      "KTM": [
        "X-BOW R '12"
      ],
      "Lamborghini": [
        "Aventador LP 700-4 '11",
        "Aventador LP 750-4 SV '15",
        "Countach 25th Anniversary '88",
        "Countach LP400 '74",
        "Diablo GT '00",
        "Gallardo LP 560-4 '08",
        "Huracan GT3 '15",
        "Huracan Gr.4",
        "Huracan LP 610-4 '15",
        "Lambo V12 VGT",
        "Miura P400 Bertone Prototype '67",
        "Murcielago LP 640 '09",
        "Urus '18",
        "Veneno '14"
      ],
      "Lancia": [
        "Delta HF Integrale Evoluzione '91",
        "Lancia Delta HF Integrale Rally Car '92",
        "Stratos '73"
      ],
      "Lexus": [
        "LC500 '17",
        "LF-LC GT VGT",
        "LFA '10",
        "RC F '14",
        "RC F GT3 '17",
        "RC F GT3 prototype '16",
        "RC F GT500 '16",
        "RC F Gr.4",
        "SC430 GT500 '08"
      ],
      "MINI": [
        "MINI Clubman VGT",
        "MINI Cooper S '05",
        "Mini-Cooper 'S' '65"
      ],
      "Maserati": [
        "A6GCS/53 Spyder '54",
        "GranTurismo S '08",
        "MC20 '20",
        "Merak SS '80"
      ],
      "Mazda": [
        "787B '91",
        "Atenza Gr.3",
        "Atenza Gr.3 Road Car",
        "Atenza Gr.4",
        "Atenza Sedan XD L Package '15",
        "CX-30 X Smart Edition '21",
        "Demio XD Touring '15",
        "Eunos Roadster (NA) '89",
        "LM55 VGT",
        "LM55 VGT (Gr.1)",
        "MAZDA SPIRIT RACING ROADSTER 12R '25",
        "MAZDA3 Gr.4",
        "Mazda3 '19",
        "RX-7 GT-X (FC) '90",
        "RX-7 Spirit R Type A (FD) '02",
        "RX-8 Spirit R '12",
        "RX-VISION '15",
        "RX-VISION GT3 CONCEPT",
        "RX-VISION GT3 CONCEPT Stealth Model",
        "RX500 '70",
        "Roadster NR-A (ND) '22",
        "Roadster S (ND) '15",
        "Roadster Touring Car",
        "efini RX-7 Type R (FD) '91"
      ],
      "McLaren": [
        "650S '14",
        "650S GT3 '15",
        "650S Gr.4",
        "MP4-12C '10",
        "MP4/4 '88",
        "McLaren F1 '94",
        "McLaren F1 GTR - BMW '95",
        "McLaren P1 GTR '16",
        "McLaren VGT",
        "McLaren VGT (Gr.1)"
      ],
      "Mercedes-Benz": [
        "190 E 2.5-16 Evolution II '91",
        "300 SL (W194) '52",
        "300 SL Coupe '54",
        "CLK-LM '98",
        "S Barker Tourer '29",
        "SLR McLaren '09",
        "Sauber Mercedes C9 '89",
        "Unimog Type 411 '62",
        "W 196 R '55"
      ],
      "Mine's": [
        "BNR34 GT-R N1 base"
      ],
      "Mitsubishi": [
        "Concept XR-PHEV EVOLUTION VGT",
        "FTO GP Version R '97",
        "GTO Twin Turbo '91",
        "Lancer Evolution Final '15",
        "Lancer Evolution Final Gr.3",
        "Lancer Evolution Final Gr.4",
        "Lancer Evolution Final Gr.B Rally Car",
        "Lancer Evolution Final Gr.B Road Car",
        "Lancer Evolution III GSR '95",
        "Lancer Evolution IV GSR '96",
        "Lancer Evolution IX MR GSR '06",
        "Lancer Evolution V GSR '98",
        "Lancer Evolution VI GSR T.M. SCP '99",
        "Lancer Evolution VIII MR GSR '04"
      ],
      "NISMO": [
        "400R '95",
        "R34 GT-R Z-tune '05"
      ],
      "Nissan": [
        "180SX Type X '96",
        "Fairlady 240ZG (HS30) '71",
        "Fairlady Z (Z34) '08",
        "Fairlady Z 300ZX TT 2seater '89",
        "Fairlady Z 432 '69",
        "Fairlady Z Version S (Z33) '07",
        "GT-R '17",
        "GT-R GT500 '08",
        "GT-R GT500 '99",
        "GT-R Gr.4",
        "GT-R Gr.B Rally Car",
        "GT-R LM NISMO '15",
        "GT-R NISMO '17",
        "GT-R NISMO (R32) '90",
        "GT-R NISMO GT3 '13",
        "GT-R NISMO GT3 '18",
        "GT-R NISMO GT500 '16",
        "GT-R Premium edition T-spec '24",
        "GT-R Safety Car",
        "NISSAN CONCEPT 2020 VGT",
        "Qashqai Tekna 190 2wd e-Power '22",
        "R32 GT-R V-spec II '94",
        "R33 GT-R V-spec '97",
        "R34 GT-R V-spec II Nur '02",
        "R92CP '92",
        "SILVIA spec-R Aero (S15) '02",
        "Sileighty '98",
        "Silvia K's Aero (S14) '96",
        "Silvia K's Dia Selection (S13) '90",
        "Silvia K's Type S (S14) '94",
        "Silvia Q's (S13) '88",
        "Silvia spec-R Aero (S15) Touring Car",
        "Skyline 2000GT-R (KPGC110) '73",
        "Skyline GT-R GP-Tuned (KPGC10)",
        "Skyline GTS-R (R31) '87",
        "Skyline Hard Top 2000GT-R (KPGC10) '70",
        "Skyline Super Silhouette Group 5 '84",
        "Z Performance '23"
      ],
      "Opel": [
        "Corsa GSE Vision Gran Turismo"
      ],
      "Pagani": [
        "Huayra '13",
        "Zonda R '09"
      ],
      "Peugeot": [
        "205 GTI '88",
        "205 Turbo 16 Evolution 2 '86",
        "208 GTi by Peugeot Sport '14",
        "908 HDi FAP '10",
        "L500R HYbrid VGT 2017",
        "L750R HYbrid VGT 2017",
        "PEUGEOT VGT",
        "PEUGEOT VGT (Gr.3)",
        "RCZ GT Line '15",
        "RCZ Gr.3",
        "RCZ Gr.3 Road Car",
        "RCZ Gr.4",
        "RCZ Gr.B Rally Car",
        "SUV 2008 Allure '21"
      ],
      "Plymouth": [
        "Superbird '70",
        "XNR Ghia Roadster '60"
      ],
      "Polestar": [
        "Polestar 5 Performance"
      ],
      "Pontiac": [
        "Firebird Trans Am '78",
        "GTO 'The Judge' '69"
      ],
      "Porsche": [
        "356 A/1500 GS Carrera '56",
        "356 A/1500 GS GT Carrera Speedster '56",
        "911 Carrera RS (901) '73",
        "911 Carrera RS (964) '92",
        "911 Carrera RS (993) '95",
        "911 Carrera RS CS (993) '95",
        "911 GT1 Strassenversion '97",
        "911 GT3 (996) '01",
        "911 GT3 (997) '09",
        "911 GT3 R (992) '22",
        "911 GT3 RS (991) '16",
        "911 GT3 RS (992) '22",
        "911 RSR (991) '17",
        "911 Turbo (930) '81",
        "911 Turbo Rally (930)",
        "911 Turbo S (992) '20",
        "917 LIVING LEGEND",
        "917K '70",
        "918 Spyder '13",
        "919 Hybrid '16",
        "959 '87",
        "962 C '88",
        "Carrera GT '04",
        "Carrera GTS (904) '64",
        "Cayman GT4 '16",
        "Cayman GT4 Clubsport '16",
        "Mission X '23",
        "Porsche VGT",
        "Porsche VGT Spyder",
        "Spyder type 550/1500RS '55",
        "Taycan Turbo S '19"
      ],
      "RE Amemiya": [
        "RE Amemiya FD3S RX-7"
      ],
      "RUF": [
        "CTR3 '07",
        "RGT 4.2 '16"
      ],
      "Radical": [
        "SR3 SL '13"
      ],
      "Renault": [
        "Avantime 3.0 V6 24V '02",
        "Captur S Edition TCe 140 '21",
        "Clio R.S. 220 Trophy '15",
        "Clio R.S. 220 Trophy '16",
        "Clio V6 24V '00",
        "Espace F1 '95",
        "Kangoo 1.4 '01",
        "Megane Gr.4",
        "Megane R.S. Trophy '11",
        "Megane R.S. Trophy Safety Car",
        "Megane Trophy '11",
        "R.S.01 '16",
        "R.S.01 GT3 '16",
        "R4 GTL '85",
        "R5 Turbo '80",
        "R8 Gordini '66"
      ],
      "Roadster Shop": [
        "Roadster Shop Rampage"
      ],
      "Shelby": [
        "Cobra 427 '66",
        "Cobra Daytona Coupe '64",
        "G.T.350 '65"
      ],
      "Skoda": [
        "SKODA Vision Gran Turismo"
      ],
      "Subaru": [
        "BRZ Drift Car '17",
        "BRZ GT300 '21",
        "BRZ S '15",
        "BRZ S '21",
        "BRZ STI Sport '18",
        "Impreza 22B-STi '98",
        "Impreza Coupe WRX Type R STi Ver.VI '99",
        "Impreza Rally Car '98",
        "Impreza Sedan WRX STi '04",
        "VIZIV GT VGT",
        "WRX Gr.3",
        "WRX Gr.4",
        "WRX Gr.B Rally Car",
        "WRX Gr.B Road Car",
        "WRX STI Isle of Man '16",
        "WRX STI Type S '14"
      ],
      "Super Formula (Dallara)": [
        "SF19 Super Formula / Honda '19",
        "SF19 Super Formula / Toyota '19",
        "SF23 Super Formula / Honda '23",
        "SF23 Super Formula / Toyota '23"
      ],
      "Suzuki": [
        "Cappuccino (EA11R) '91",
        "Carry KC '12",
        "Jimny Sierra JC '18",
        "Jimny XC '18",
        "SUZUKI Vision Gran Turismo (Gr.3 Version)",
        "Suzuki Vision Gran Turismo",
        "Swift Sport '07",
        "Swift Sport '17",
        "Swift Sport Gr.4",
        "V6 Escudo Pikes Peak Special spec.98"
      ],
      "TVR": [
        "Tuscan Speed 6 '00"
      ],
      "Tesla": [
        "Model 3 Performance '23",
        "Model S Signature Performance '12"
      ],
      "Toyota": [
        "2000GT '67",
        "86 GRMN '16",
        "86 GT '15",
        "86 GT 'Limited' '16",
        "86 Gr.4",
        "86 Gr.B Rally Car",
        "AE86 Levin D-Tuned",
        "Alphard Executive Lounge '18",
        "Ambulance Himedic '21",
        "Aqua S '11",
        "C-HR S '18",
        "Celica GT-FOUR Rally Car (ST205) '95",
        "Celica GT-Four (ST205) '94",
        "Corolla Levin 1600GT APEX (AE86) '83",
        "Crown Athlete G '13",
        "Crown Athlete G Safety Car",
        "FT-1",
        "FT-1 VGT",
        "FT-1 VGT (Gr.3)",
        "GR Corolla MORIZO Edition '22",
        "GR Supra RZ '19",
        "GR Supra RZ '20",
        "GR Supra Race Car '19",
        "GR Supra Racing Concept '18",
        "GR Yaris RZ 'High performance' '20",
        "GR010 HYBRID '21",
        "GR010 HYBRID (Olympic Esports Series) '21",
        "GR86 RZ '21",
        "GT-One (TS020) '99",
        "Hiace Van DX '16",
        "Land Cruiser FJ40V '74",
        "MR2 GT-S '97",
        "Prius G '09",
        "RAV4 Adventure '20",
        "S-FR '15",
        "S-FR Racing Concept '16",
        "Sports 800 '65",
        "Sprinter Trueno 1600GT APEX (AE86) '83",
        "Sprinter Trueno 1600GT APEX (S.Shigeno Version)",
        "Supra 3.0GT Turbo A '88",
        "Supra GT Road Car (JZA80)",
        "Supra GT500 '97",
        "Supra RZ '97",
        "TS030 Hybrid '12",
        "TS050 - Hybrid '16",
        "Tundra TRD Pro '19"
      ],
      "Volkswagen": [
        "Beetle 1966 Desert Racer",
        "Beetle Gr.3",
        "GTI Roadster VGT",
        "GTI Supersport VGT",
        "Golf I GTI '83",
        "Golf VII GTI '14",
        "ID.R '19",
        "Polo GTI '14",
        "Sambabus Typ 2 '62",
        "Scirocco Gr.4",
        "Scirocco R '10",
        "Volkswagen 1200 '66",
        "Volkswagen GTI VGT (Gr.3)"
      ],
      "Volvo": [
        "240 SE Estate '93",
        "V40 T5 R-Design '13"
      ],
      "Wicked Fabrication": [
        "Wicked Fabrication GT 51"
      ],
      "Xiaomi": [
        "SU7 Ultra '25"
      ],
      "Zagato": [
        "IsoRivolta Zagato VGT"
      ]
    },
    "all_car_names": [],
    "preset_tags": [
      "WTC 600",
      "WTC 700",
      "WTC 800",
      "WTC 900",
      "PP 500",
      "PP 600",
      "PP 700",
      "PP 800",
      "PP 900",
      "VGT",
      "Gr.1",
      "Gr.2",
      "Gr.3",
      "Gr.4",
      "Gr.B",
      "Gr.X",
      "GT3",
      "GT4",
      "GT500",
      "Super Formula",
      "Safety Car",
      "Touring Car",
      "Rally",
      "Kart",
      "EV/Hybrid"
    ],
    "tracks": [
      "24 Heures du Mans Racing Circuit",
      "Autodromo Nazionale Monza",
      "Autodromo de Interlagos",
      "Autopolis International Racing Course",
      "Circuit de Barcelona-Catalunya Grand Prix Layout",
      "Circuit de Spa-Francorchamps",
      "Daytona Tri-Oval",
      "Deep Forest Raceway",
      "Fuji International Speedway",
      "Grand Valley - Highway 1",
      "High Speed Ring",
      "Michelin Raceway Road Atlanta",
      "Nurburgring Nordschleife",
      "Red Bull Ring",
      "Special Stage Route X",
      "Suzuka Circuit",
      "Trial Mountain Circuit",
      "Tsukuba Circuit",
      "Watkins Glen Long Course",
      "WeatherTech Raceway Laguna Seca"
    ]
  },
  "cars": [],
  "app_persistence_seed": {
    "saved_user_entries": {
      "event_tags": [
        "WTC 600",
        "WTC 700",
        "WTC 800",
        "WTC 900"
      ],
      "class_tags": [
        "Gr.1",
        "Gr.2",
        "Gr.3",
        "Gr.4",
        "Gr.B",
        "Gr.X",
        "Gr.N",
        "VGT"
      ],
      "favorite_cars": [],
      "favorite_tracks": [
        "Suzuka Circuit",
        "Circuit de Spa-Francorchamps",
        "Autodromo de Interlagos",
        "24 Heures du Mans Racing Circuit",
        "Sardegna - Road Track - A"
      ]
    },
    "default_entry_template": {
      "entry_id": "string",
      "date_iso": "YYYY-MM-DD",
      "maker": "string",
      "model": "string",
      "display_name": "string",
      "class_tags": [
        "Gr.3",
        "WTC 800",
        "VGT"
      ],
      "track": "string",
      "pp": "number|null",
      "lap_time": "mm:ss.mmm|null",
      "total_time": "hh:mm:ss.mmm|null",
      "notes": "string"
    }
  }
};
