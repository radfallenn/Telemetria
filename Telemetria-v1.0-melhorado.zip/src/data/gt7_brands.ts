import { Brand } from '../types';

export const RAW_BRANDS: Brand[] = [
  {
    "maker_id": "160",
    "brand_slug": "afeela",
    "brand_name": "AFEELA",
    "country_id": "2",
    "logo_file": "brands/afeela.png",
    "logo_url": null,
    "search_terms": ["AFEELA", "afeela"]
  },
  {
    "maker_id": "153",
    "brand_slug": "amg",
    "brand_name": "AMG",
    "country_id": "5",
    "logo_file": "brands/amg.png",
    "logo_url": null,
    "search_terms": ["AMG", "amg"]
  },
  {
    "maker_id": "125",
    "brand_slug": "abarth",
    "brand_name": "Abarth",
    "country_id": "7",
    "logo_file": "brands/abarth.png",
    "logo_url": null,
    "search_terms": ["Abarth", "abarth"]
  },
  {
    "maker_id": "3",
    "brand_slug": "alfa_romeo",
    "brand_name": "Alfa Romeo",
    "country_id": "7",
    "logo_file": "brands/alfa_romeo.png",
    "logo_url": null,
    "search_terms": ["Alfa Romeo", "alfa romeo"]
  },
  {
    "maker_id": "86",
    "brand_slug": "alpine",
    "brand_name": "Alpine",
    "country_id": "6",
    "logo_file": "brands/alpine.png",
    "logo_url": null,
    "search_terms": ["Alpine", "alpine"]
  },
  {
    "maker_id": "59",
    "brand_slug": "amuse",
    "brand_name": "Amuse",
    "country_id": "2",
    "logo_file": "brands/amuse.png",
    "logo_url": null,
    "search_terms": ["Amuse", "amuse"]
  },
  {
    "maker_id": "4",
    "brand_slug": "aston_martin",
    "brand_name": "Aston Martin",
    "country_id": "4",
    "logo_file": "brands/aston_martin.png",
    "logo_url": null,
    "search_terms": ["Aston Martin", "aston martin"]
  },
  {
    "maker_id": "5",
    "brand_slug": "audi",
    "brand_name": "Audi",
    "country_id": "5",
    "logo_file": "brands/audi.png",
    "logo_url": null,
    "search_terms": ["Audi", "audi"]
  },
  {
    "maker_id": "57",
    "brand_slug": "autobianchi",
    "brand_name": "Autobianchi",
    "country_id": "7",
    "logo_file": "brands/autobianchi.png",
    "logo_url": null,
    "search_terms": ["Autobianchi", "autobianchi"]
  },
  {
    "maker_id": "144",
    "brand_slug": "bac",
    "brand_name": "BAC",
    "country_id": "4",
    "logo_file": "brands/bac.png",
    "logo_url": null,
    "search_terms": ["BAC", "bac"]
  },
  {
    "maker_id": "6",
    "brand_slug": "bmw",
    "brand_name": "BMW",
    "country_id": "5",
    "logo_file": "brands/bmw.png",
    "logo_url": null,
    "search_terms": ["BMW", "bmw"]
  },
  {
    "maker_id": "158",
    "brand_slug": "bvlgari",
    "brand_name": "BVLGARI",
    "country_id": "7",
    "logo_file": "brands/bvlgari.png",
    "logo_url": null,
    "search_terms": ["BVLGARI", "bvlgari"]
  },
  {
    "maker_id": "113",
    "brand_slug": "bugatti",
    "brand_name": "Bugatti",
    "country_id": "5",
    "logo_file": "brands/bugatti.png",
    "logo_url": null,
    "search_terms": ["Bugatti", "bugatti"]
  },
  {
    "maker_id": "93",
    "brand_slug": "chaparral",
    "brand_name": "Chaparral",
    "country_id": "3",
    "logo_file": "brands/chaparral.png",
    "logo_url": null,
    "search_terms": ["Chaparral", "chaparral"]
  },
  {
    "maker_id": "7",
    "brand_slug": "chevrolet",
    "brand_name": "Chevrolet",
    "country_id": "3",
    "logo_file": "brands/chevrolet.png",
    "logo_url": null,
    "search_terms": ["Chevrolet", "chevrolet"]
  },
  {
    "maker_id": "147",
    "brand_slug": "chris_holstrom_concepts",
    "brand_name": "Chris Holstrom Concepts",
    "country_id": "3",
    "logo_file": "brands/chris_holstrom_concepts.png",
    "logo_url": null,
    "search_terms": ["Chris Holstrom Concepts", "chris holstrom concepts"]
  },
  {
    "maker_id": "9",
    "brand_slug": "citroen",
    "brand_name": "Citroen",
    "country_id": "6",
    "logo_file": "brands/citroen.png",
    "logo_url": null,
    "search_terms": ["Citroen", "citroen"]
  },
  {
    "maker_id": "65",
    "brand_slug": "dmc",
    "brand_name": "DMC",
    "country_id": "3",
    "logo_file": "brands/dmc.png",
    "logo_url": null,
    "search_terms": ["DMC", "dmc"]
  },
  {
    "maker_id": "154",
    "brand_slug": "ds_automobiles",
    "brand_name": "DS AUTOMOBILES",
    "country_id": "6",
    "logo_file": "brands/ds_automobiles.png",
    "logo_url": null,
    "search_terms": ["DS AUTOMOBILES", "ds automobiles"]
  },
  {
    "maker_id": "10",
    "brand_slug": "daihatsu",
    "brand_name": "Daihatsu",
    "country_id": "2",
    "logo_file": "brands/daihatsu.png",
    "logo_url": null,
    "search_terms": ["Daihatsu", "daihatsu"]
  },
  {
    "maker_id": "140",
    "brand_slug": "de_tomaso",
    "brand_name": "De Tomaso",
    "country_id": "7",
    "logo_file": "brands/de_tomaso.png",
    "logo_url": null,
    "search_terms": ["De Tomaso", "de tomaso"]
  },
  {
    "maker_id": "11",
    "brand_slug": "dodge",
    "brand_name": "Dodge",
    "country_id": "3",
    "logo_file": "brands/dodge.png",
    "logo_url": null,
    "search_terms": ["Dodge", "dodge"]
  },
  {
    "maker_id": "148",
    "brand_slug": "eckerts_rod_custom",
    "brand_name": "Eckert's Rod & Custom",
    "country_id": "3",
    "logo_file": "brands/eckerts_rod_custom.png",
    "logo_url": null,
    "search_terms": ["Eckert's Rod & Custom", "eckerts rod custom"]
  },
  {
    "maker_id": "110",
    "brand_slug": "ferrari",
    "brand_name": "Ferrari",
    "country_id": "7",
    "logo_file": "brands/ferrari.png",
    "logo_url": null,
    "search_terms": ["Ferrari", "ferrari"]
  },
  {
    "maker_id": "12",
    "brand_slug": "fiat",
    "brand_name": "Fiat",
    "country_id": "7",
    "logo_file": "brands/fiat.png",
    "logo_url": null,
    "search_terms": ["Fiat", "fiat"]
  },
  {
    "maker_id": "13",
    "brand_slug": "ford",
    "brand_name": "Ford",
    "country_id": "3",
    "logo_file": "brands/ford.png",
    "logo_url": null,
    "search_terms": ["Ford", "ford"]
  },
  {
    "maker_id": "157",
    "brand_slug": "garage_rcr",
    "brand_name": "Garage RCR",
    "country_id": "3",
    "logo_file": "brands/garage_rcr.png",
    "logo_url": null,
    "search_terms": ["Garage RCR", "garage rcr"]
  },
  {
    "maker_id": "152",
    "brand_slug": "genesis",
    "brand_name": "Genesis",
    "country_id": "9",
    "logo_file": "brands/genesis.png",
    "logo_url": null,
    "search_terms": ["Genesis", "genesis"]
  },
  {
    "maker_id": "33",
    "brand_slug": "gran_turismo",
    "brand_name": "Gran Turismo",
    "country_id": "0",
    "logo_file": "brands/gran_turismo.png",
    "logo_url": null,
    "search_terms": ["Gran Turismo", "gran turismo"]
  },
  {
    "maker_id": "149",
    "brand_slug": "greddy",
    "brand_name": "Greddy",
    "country_id": "2",
    "logo_file": "brands/greddy.png",
    "logo_url": null,
    "search_terms": ["Greddy", "greddy"]
  },
  {
    "maker_id": "156",
    "brand_slug": "greening_auto_company",
    "brand_name": "Greening Auto Company",
    "country_id": "3",
    "logo_file": "brands/greening_auto_company.png",
    "logo_url": null,
    "search_terms": ["Greening Auto Company", "greening auto company"]
  },
  {
    "maker_id": "15",
    "brand_slug": "honda",
    "brand_name": "Honda",
    "country_id": "2",
    "logo_file": "brands/honda.png",
    "logo_url": null,
    "search_terms": ["Honda", "honda"]
  },
  {
    "maker_id": "16",
    "brand_slug": "hyundai",
    "brand_name": "Hyundai",
    "country_id": "9",
    "logo_file": "brands/hyundai.png",
    "logo_url": null,
    "search_terms": ["Hyundai", "hyundai"]
  },
  {
    "maker_id": "49",
    "brand_slug": "infiniti",
    "brand_name": "Infiniti",
    "country_id": "3",
    "logo_file": "brands/infiniti.png",
    "logo_url": null,
    "search_terms": ["Infiniti", "infiniti"]
  },
  {
    "maker_id": "135",
    "brand_slug": "italdesign",
    "brand_name": "Italdesign",
    "country_id": "7",
    "logo_file": "brands/italdesign.png",
    "logo_url": null,
    "search_terms": ["Italdesign", "italdesign"]
  },
  {
    "maker_id": "17",
    "brand_slug": "jaguar",
    "brand_name": "Jaguar",
    "country_id": "4",
    "logo_file": "brands/jaguar.png",
    "logo_url": null,
    "search_terms": ["Jaguar", "jaguar"]
  },
  {
    "maker_id": "146",
    "brand_slug": "jeep",
    "brand_name": "Jeep",
    "country_id": "3",
    "logo_file": "brands/jeep.png",
    "logo_url": null,
    "search_terms": ["Jeep", "jeep"]
  },
  {
    "maker_id": "121",
    "brand_slug": "ktm",
    "brand_name": "KTM",
    "country_id": "15",
    "logo_file": "brands/ktm.png",
    "logo_url": null,
    "search_terms": ["KTM", "ktm"]
  },
  {
    "maker_id": "112",
    "brand_slug": "lamborghini",
    "brand_name": "Lamborghini",
    "country_id": "7",
    "logo_file": "brands/lamborghini.png",
    "logo_url": null,
    "search_terms": ["Lamborghini", "lamborghini"]
  },
  {
    "maker_id": "18",
    "brand_slug": "lancia",
    "brand_name": "Lancia",
    "country_id": "7",
    "logo_file": "brands/lancia.png",
    "logo_url": null,
    "search_terms": ["Lancia", "lancia"]
  },
  {
    "maker_id": "50",
    "brand_slug": "lexus",
    "brand_name": "Lexus",
    "country_id": "2",
    "logo_file": "brands/lexus.png",
    "logo_url": null,
    "search_terms": ["Lexus", "lexus"]
  },
  {
    "maker_id": "51",
    "brand_slug": "mini",
    "brand_name": "MINI",
    "country_id": "5",
    "logo_file": "brands/mini.png",
    "logo_url": null,
    "search_terms": ["MINI", "mini"]
  },
  {
    "maker_id": "116",
    "brand_slug": "maserati",
    "brand_name": "Maserati",
    "country_id": "7",
    "logo_file": "brands/maserati.png",
    "logo_url": null,
    "search_terms": ["Maserati", "maserati"]
  },
  {
    "maker_id": "21",
    "brand_slug": "mazda",
    "brand_name": "Mazda",
    "country_id": "2",
    "logo_file": "brands/mazda.png",
    "logo_url": null,
    "search_terms": ["Mazda", "mazda"]
  },
  {
    "maker_id": "117",
    "brand_slug": "mclaren",
    "brand_name": "McLaren",
    "country_id": "4",
    "logo_file": "brands/mclaren.png",
    "logo_url": null,
    "search_terms": ["McLaren", "mclaren"]
  },
  {
    "maker_id": "22",
    "brand_slug": "mercedes_benz",
    "brand_name": "Mercedes-Benz",
    "country_id": "5",
    "logo_file": "brands/mercedes_benz.png",
    "logo_url": null,
    "search_terms": ["Mercedes-Benz", "mercedes benz"]
  },
  {
    "maker_id": "162",
    "brand_slug": "mines",
    "brand_name": "Mine's",
    "country_id": "2",
    "logo_file": "brands/mines.png",
    "logo_url": null,
    "search_terms": ["Mine's", "mines"]
  },
  {
    "maker_id": "25",
    "brand_slug": "mitsubishi",
    "brand_name": "Mitsubishi",
    "country_id": "2",
    "logo_file": "brands/mitsubishi.png",
    "logo_url": null,
    "search_terms": ["Mitsubishi", "mitsubishi"]
  },
  {
    "maker_id": "155",
    "brand_slug": "nismo",
    "brand_name": "NISMO",
    "country_id": "2",
    "logo_file": "brands/nismo.png",
    "logo_url": null,
    "search_terms": ["NISMO", "nismo"]
  },
  {
    "maker_id": "28",
    "brand_slug": "nissan",
    "brand_name": "Nissan",
    "country_id": "2",
    "logo_file": "brands/nissan.png",
    "logo_url": null,
    "search_terms": ["Nissan", "nissan"]
  },
  {
    "maker_id": "161",
    "brand_slug": "opel",
    "brand_name": "Opel",
    "country_id": "5",
    "logo_file": "brands/opel.png",
    "logo_url": null,
    "search_terms": ["Opel", "opel"]
  },
  {
    "maker_id": "30",
    "brand_slug": "pagani",
    "brand_name": "Pagani",
    "country_id": "7",
    "logo_file": "brands/pagani.png",
    "logo_url": null,
    "search_terms": ["Pagani", "pagani"]
  },
  {
    "maker_id": "32",
    "brand_slug": "peugeot",
    "brand_name": "Peugeot",
    "country_id": "6",
    "logo_file": "brands/peugeot.png",
    "logo_url": null,
    "search_terms": ["Peugeot", "peugeot"]
  },
  {
    "maker_id": "55",
    "brand_slug": "plymouth",
    "brand_name": "Plymouth",
    "country_id": "3",
    "logo_file": "brands/plymouth.png",
    "logo_url": null,
    "search_terms": ["Plymouth", "plymouth"]
  },
  {
    "maker_id": "163",
    "brand_slug": "polestar",
    "brand_name": "Polestar",
    "country_id": "12",
    "logo_file": "brands/polestar.png",
    "logo_url": null,
    "search_terms": ["Polestar", "polestar"]
  },
  {
    "maker_id": "52",
    "brand_slug": "pontiac",
    "brand_name": "Pontiac",
    "country_id": "3",
    "logo_file": "brands/pontiac.png",
    "logo_url": null,
    "search_terms": ["Pontiac", "pontiac"]
  },
  {
    "maker_id": "136",
    "brand_slug": "porsche",
    "brand_name": "Porsche",
    "country_id": "5",
    "logo_file": "brands/porsche.png",
    "logo_url": null,
    "search_terms": ["Porsche", "porsche"]
  },
  {
    "maker_id": "87",
    "brand_slug": "re_amemiya",
    "brand_name": "RE Amemiya",
    "country_id": "2",
    "logo_file": "brands/re_amemiya.png",
    "logo_url": null,
    "search_terms": ["RE Amemiya", "re amemiya"]
  },
  {
    "maker_id": "35",
    "brand_slug": "ruf",
    "brand_name": "RUF",
    "country_id": "5",
    "logo_file": "brands/ruf.png",
    "logo_url": null,
    "search_terms": ["RUF", "ruf"]
  },
  {
    "maker_id": "141",
    "brand_slug": "radical",
    "brand_name": "Radical",
    "country_id": "4",
    "logo_file": "brands/radical.png",
    "logo_url": null,
    "search_terms": ["Radical", "radical"]
  },
  {
    "maker_id": "34",
    "brand_slug": "renault",
    "brand_name": "Renault",
    "country_id": "6",
    "logo_file": "brands/renault.png",
    "logo_url": null,
    "search_terms": ["Renault", "renault"]
  },
  {
    "maker_id": "151",
    "brand_slug": "roadster_shop",
    "brand_name": "Roadster Shop",
    "country_id": "3",
    "logo_file": "brands/roadster_shop.png",
    "logo_url": null,
    "search_terms": ["Roadster Shop", "roadster shop"]
  },
  {
    "maker_id": "36",
    "brand_slug": "shelby",
    "brand_name": "Shelby",
    "country_id": "3",
    "logo_file": "brands/shelby.png",
    "logo_url": null,
    "search_terms": ["Shelby", "shelby"]
  },
  {
    "maker_id": "159",
    "brand_slug": "skoda",
    "brand_name": "Skoda",
    "country_id": "19",
    "logo_file": "brands/skoda.png",
    "logo_url": null,
    "search_terms": ["Skoda", "skoda"]
  },
  {
    "maker_id": "38",
    "brand_slug": "subaru",
    "brand_name": "Subaru",
    "country_id": "2",
    "logo_file": "brands/subaru.png",
    "logo_url": null,
    "search_terms": ["Subaru", "subaru"]
  },
  {
    "maker_id": "143",
    "brand_slug": "super_formula_dallara",
    "brand_name": "Super Formula (Dallara)",
    "country_id": "2",
    "logo_file": "brands/super_formula_dallara.png",
    "logo_url": null,
    "search_terms": ["Super Formula (Dallara)", "super formula dallara"]
  },
  {
    "maker_id": "39",
    "brand_slug": "suzuki",
    "brand_name": "Suzuki",
    "country_id": "2",
    "logo_file": "brands/suzuki.png",
    "logo_url": null,
    "search_terms": ["Suzuki", "suzuki"]
  },
  {
    "maker_id": "44",
    "brand_slug": "tvr",
    "brand_name": "TVR",
    "country_id": "4",
    "logo_file": "brands/tvr.png",
    "logo_url": null,
    "search_terms": ["TVR", "tvr"]
  },
  {
    "maker_id": "119",
    "brand_slug": "tesla",
    "brand_name": "Tesla",
    "country_id": "3",
    "logo_file": "brands/tesla.png",
    "logo_url": null,
    "search_terms": ["Tesla", "tesla"]
  },
  {
    "maker_id": "43",
    "brand_slug": "toyota",
    "brand_name": "Toyota",
    "country_id": "2",
    "logo_file": "brands/toyota.png",
    "logo_url": null,
    "search_terms": ["Toyota", "toyota"]
  },
  {
    "maker_id": "46",
    "brand_slug": "volkswagen",
    "brand_name": "Volkswagen",
    "country_id": "5",
    "logo_file": "brands/volkswagen.png",
    "logo_url": null,
    "search_terms": ["Volkswagen", "volkswagen"]
  },
  {
    "maker_id": "69",
    "brand_slug": "volvo",
    "brand_name": "Volvo",
    "country_id": "12",
    "logo_file": "brands/volvo.png",
    "logo_url": null,
    "search_terms": ["Volvo", "volvo"]
  },
  {
    "maker_id": "150",
    "brand_slug": "wicked_fabrication",
    "brand_name": "Wicked Fabrication",
    "country_id": "3",
    "logo_file": "brands/wicked_fabrication.png",
    "logo_url": null,
    "search_terms": ["Wicked Fabrication", "wicked fabrication"]
  },
  {
    "maker_id": "164",
    "brand_slug": "xiaomi",
    "brand_name": "Xiaomi",
    "country_id": "20",
    "logo_file": "brands/xiaomi.png",
    "logo_url": null,
    "search_terms": ["Xiaomi", "xiaomi"]
  },
  {
    "maker_id": "134",
    "brand_slug": "zagato",
    "brand_name": "Zagato",
    "country_id": "7",
    "logo_file": "brands/zagato.png",
    "logo_url": null,
    "search_terms": ["Zagato", "zagato"]
  }
];
