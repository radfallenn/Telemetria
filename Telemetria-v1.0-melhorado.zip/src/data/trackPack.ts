export const TRACK_PACK_META = {
  pack_name: "GT7 Ultra Track Pack",
  version: "v1.0",
  purpose: ["svg reference", "minimap", "telemetry overlay", "track selector", "region/category filters"]
};

export type Region = 'Americas' | 'Europe' | 'Asia-Oceania';
export type Category = 'Real Circuit' | 'Original Circuit' | 'Dirt / Snow';

export interface TrackDef {
  id: string;
  name: string;
  location: string;
  region: Region;
  category: Category;
  svgViewBox: string;
  svgPath: string;
  svgVariants?: {
    outline: string;
    outline_thick: string;
    filled: string;
    telemetry_path: string;
  };
  layouts?: number | null;
  assetKey?: string;
  hudReady?: boolean;
}

export const TRACK_PACK: TrackDef[] = [
  {
    id: "gt7_alsace",
    name: "Alsace",
    location: 'France',
    region: "Europe",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
    svgVariants: {
      outline: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      outline_thick: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      filled: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      telemetry_path: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z"
    },
    layouts: 4,
    assetKey: "gt7_alsace",
    hudReady: true
  },
  {
    id: "gt7_lago_maggiore",
    name: "Autodromo Lago Maggiore",
    location: 'Italy',
    region: "Europe",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
    svgVariants: {
      outline: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      outline_thick: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      filled: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      telemetry_path: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z"
    },
    layouts: 12,
    assetKey: "gt7_lago_maggiore",
    hudReady: true
  },
  {
    id: "gt7_autopolis",
    name: "Autopolis",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
    svgVariants: {
      outline: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      outline_thick: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      filled: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      telemetry_path: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_autopolis",
    hudReady: true
  },
  {
    id: "gt7_bathurst",
    name: "Bathurst Mount Panorama",
    location: 'Australia',
    region: "Asia-Oceania",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
    svgVariants: {
      outline: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      outline_thick: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      filled: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      telemetry_path: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z"
    },
    layouts: 1,
    assetKey: "gt7_bathurst",
    hudReady: true
  },
  {
    id: "gt7_blue_moon_bay",
    name: "Blue Moon Bay Speedway",
    location: 'USA',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
    svgVariants: {
      outline: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      outline_thick: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      filled: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      telemetry_path: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z"
    },
    layouts: 6,
    assetKey: "gt7_blue_moon_bay",
    hudReady: true
  },
  {
    id: "gt7_brands_hatch",
    name: "Brands Hatch",
    location: 'UK',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
    svgVariants: {
      outline: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      outline_thick: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      filled: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      telemetry_path: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_brands_hatch",
    hudReady: true
  },
  {
    id: "gt7_broad_bean",
    name: "Broad Bean Raceway",
    location: 'USA',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
    svgVariants: {
      outline: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      outline_thick: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      filled: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      telemetry_path: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z"
    },
    layouts: 2,
    assetKey: "gt7_broad_bean",
    hudReady: true
  },
  {
    id: "gt7_barcelona",
    name: "Circuit de Barcelona-Catalunya",
    location: 'Spain',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
    svgVariants: {
      outline: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      outline_thick: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      filled: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      telemetry_path: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z"
    },
    layouts: 3,
    assetKey: "gt7_barcelona",
    hudReady: true
  },
  {
    id: "gt7_le_mans",
    name: "Circuit de la Sarthe",
    location: 'France',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
    svgVariants: {
      outline: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      outline_thick: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      filled: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      telemetry_path: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_le_mans",
    hudReady: true
  },
  {
    id: "gt7_spa",
    name: "Circuit de Spa-Francorchamps",
    location: 'Belgium',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
    svgVariants: {
      outline: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      outline_thick: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      filled: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      telemetry_path: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z"
    },
    layouts: 2,
    assetKey: "gt7_spa",
    hudReady: true
  },
  {
    id: "gt7_colorado_springs",
    name: "Colorado Springs",
    location: 'USA',
    region: "Americas",
    category: "Dirt / Snow",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
    svgVariants: {
      outline: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      outline_thick: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      filled: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      telemetry_path: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_colorado_springs",
    hudReady: true
  },
  {
    id: "gt7_daytona",
    name: "Daytona",
    location: 'USA',
    region: "Americas",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
    svgVariants: {
      outline: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      outline_thick: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      filled: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      telemetry_path: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z"
    },
    layouts: 2,
    assetKey: "gt7_daytona",
    hudReady: true
  },
  {
    id: "gt7_deep_forest",
    name: "Deep Forest Raceway",
    location: 'Switzerland',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
    svgVariants: {
      outline: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      outline_thick: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      filled: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      telemetry_path: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z"
    },
    layouts: 2,
    assetKey: "gt7_deep_forest",
    hudReady: true
  },
  {
    id: "gt7_dragon_trail",
    name: "Dragon Trail",
    location: 'Croatia',
    region: "Europe",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
    svgVariants: {
      outline: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      outline_thick: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      filled: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      telemetry_path: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z"
    },
    layouts: 4,
    assetKey: "gt7_dragon_trail",
    hudReady: true
  },
  {
    id: "gt7_eiger_nordwand",
    name: "Eiger Nordwand",
    location: 'Switzerland',
    region: "Europe",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
    svgVariants: {
      outline: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      outline_thick: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      filled: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      telemetry_path: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z"
    },
    layouts: 2,
    assetKey: "gt7_eiger",
    hudReady: true
  },
  {
    id: "gt7_fishermans_ranch",
    name: "Fishermans Ranch",
    location: 'USA',
    region: "Americas",
    category: "Dirt / Snow",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
    svgVariants: {
      outline: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      outline_thick: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      filled: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      telemetry_path: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z"
    },
    layouts: 1,
    assetKey: "gt7_fishermans_ranch",
    hudReady: true
  },
  {
    id: "gt7_fuji",
    name: "Fuji Speedway",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
    svgVariants: {
      outline: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      outline_thick: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      filled: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      telemetry_path: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_fuji",
    hudReady: true
  },
  {
    id: "gt7_goodwood",
    name: "Goodwood",
    location: 'UK',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
    svgVariants: {
      outline: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      outline_thick: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      filled: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      telemetry_path: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z"
    },
    layouts: 1,
    assetKey: "gt7_goodwood",
    hudReady: true
  },
  {
    id: "gt7_grand_valley",
    name: "Grand Valley",
    location: 'USA',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
    svgVariants: {
      outline: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      outline_thick: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      filled: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      telemetry_path: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z"
    },
    layouts: 4,
    assetKey: "gt7_grand_valley",
    hudReady: true
  },
  {
    id: "gt7_high_speed_ring",
    name: "High Speed Ring",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
    svgVariants: {
      outline: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      outline_thick: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      filled: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      telemetry_path: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z"
    },
    layouts: 2,
    assetKey: "gt7_high_speed_ring",
    hudReady: true
  },
  {
    id: "gt7_interlagos",
    name: "Interlagos",
    location: 'Brazil',
    region: "Americas",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 82.5,33.8 L 74.2,28.5 C 71.5,26.8 68.2,26.2 65.1,26.7 L 57.8,27.9 C 55.4,28.3 53.1,29.4 51.3,31.1 L 44.5,37.6 C 43.1,38.9 41.3,39.6 39.4,39.5 L 34.2,39.2 C 32.1,39.1 30.1,38.2 28.6,36.7 L 22.8,31.1 C 21.3,29.6 19.3,28.7 17.2,28.7 C 15.1,28.7 13.1,29.6 11.6,31.1 L 6.5,36.2 C 4.2,38.5 3.3,42.0 4.1,45.1 L 7.2,56.8 C 7.8,59.1 9.4,61.1 11.4,62.2 L 20.8,67.6 C 22.8,68.7 25.1,69.1 27.4,68.6 L 35.8,66.8 C 38.6,66.2 41.5,66.7 44.1,68.2 L 52.6,73.1 C 55.1,74.5 58.1,75.0 60.9,74.3 L 73.1,71.2 C 75.8,70.5 78.3,69.0 80.2,66.9 L 91.5,54.2 C 93.3,52.2 94.2,49.5 94.0,46.8 L 93.2,35.6 C 93.1,33.9 92.4,32.3 91.1,31.3 C 89.8,30.3 88.2,29.9 86.6,30.3 L 82.5,33.8 Z",
    svgVariants: {
      outline: "M 82.5,33.8 L 74.2,28.5 C 71.5,26.8 68.2,26.2 65.1,26.7 L 57.8,27.9 C 55.4,28.3 53.1,29.4 51.3,31.1 L 44.5,37.6 C 43.1,38.9 41.3,39.6 39.4,39.5 L 34.2,39.2 C 32.1,39.1 30.1,38.2 28.6,36.7 L 22.8,31.1 C 21.3,29.6 19.3,28.7 17.2,28.7 C 15.1,28.7 13.1,29.6 11.6,31.1 L 6.5,36.2 C 4.2,38.5 3.3,42.0 4.1,45.1 L 7.2,56.8 C 7.8,59.1 9.4,61.1 11.4,62.2 L 20.8,67.6 C 22.8,68.7 25.1,69.1 27.4,68.6 L 35.8,66.8 C 38.6,66.2 41.5,66.7 44.1,68.2 L 52.6,73.1 C 55.1,74.5 58.1,75.0 60.9,74.3 L 73.1,71.2 C 75.8,70.5 78.3,69.0 80.2,66.9 L 91.5,54.2 C 93.3,52.2 94.2,49.5 94.0,46.8 L 93.2,35.6 C 93.1,33.9 92.4,32.3 91.1,31.3 C 89.8,30.3 88.2,29.9 86.6,30.3 L 82.5,33.8 Z",
      outline_thick: "M 82.5,33.8 L 74.2,28.5 C 71.5,26.8 68.2,26.2 65.1,26.7 L 57.8,27.9 C 55.4,28.3 53.1,29.4 51.3,31.1 L 44.5,37.6 C 43.1,38.9 41.3,39.6 39.4,39.5 L 34.2,39.2 C 32.1,39.1 30.1,38.2 28.6,36.7 L 22.8,31.1 C 21.3,29.6 19.3,28.7 17.2,28.7 C 15.1,28.7 13.1,29.6 11.6,31.1 L 6.5,36.2 C 4.2,38.5 3.3,42.0 4.1,45.1 L 7.2,56.8 C 7.8,59.1 9.4,61.1 11.4,62.2 L 20.8,67.6 C 22.8,68.7 25.1,69.1 27.4,68.6 L 35.8,66.8 C 38.6,66.2 41.5,66.7 44.1,68.2 L 52.6,73.1 C 55.1,74.5 58.1,75.0 60.9,74.3 L 73.1,71.2 C 75.8,70.5 78.3,69.0 80.2,66.9 L 91.5,54.2 C 93.3,52.2 94.2,49.5 94.0,46.8 L 93.2,35.6 C 93.1,33.9 92.4,32.3 91.1,31.3 C 89.8,30.3 88.2,29.9 86.6,30.3 L 82.5,33.8 Z",
      filled: "M 82.5,33.8 L 74.2,28.5 C 71.5,26.8 68.2,26.2 65.1,26.7 L 57.8,27.9 C 55.4,28.3 53.1,29.4 51.3,31.1 L 44.5,37.6 C 43.1,38.9 41.3,39.6 39.4,39.5 L 34.2,39.2 C 32.1,39.1 30.1,38.2 28.6,36.7 L 22.8,31.1 C 21.3,29.6 19.3,28.7 17.2,28.7 C 15.1,28.7 13.1,29.6 11.6,31.1 L 6.5,36.2 C 4.2,38.5 3.3,42.0 4.1,45.1 L 7.2,56.8 C 7.8,59.1 9.4,61.1 11.4,62.2 L 20.8,67.6 C 22.8,68.7 25.1,69.1 27.4,68.6 L 35.8,66.8 C 38.6,66.2 41.5,66.7 44.1,68.2 L 52.6,73.1 C 55.1,74.5 58.1,75.0 60.9,74.3 L 73.1,71.2 C 75.8,70.5 78.3,69.0 80.2,66.9 L 91.5,54.2 C 93.3,52.2 94.2,49.5 94.0,46.8 L 93.2,35.6 C 93.1,33.9 92.4,32.3 91.1,31.3 C 89.8,30.3 88.2,29.9 86.6,30.3 L 82.5,33.8 Z",
      telemetry_path: "M 82.5,33.8 L 74.2,28.5 C 71.5,26.8 68.2,26.2 65.1,26.7 L 57.8,27.9 C 55.4,28.3 53.1,29.4 51.3,31.1 L 44.5,37.6 C 43.1,38.9 41.3,39.6 39.4,39.5 L 34.2,39.2 C 32.1,39.1 30.1,38.2 28.6,36.7 L 22.8,31.1 C 21.3,29.6 19.3,28.7 17.2,28.7 C 15.1,28.7 13.1,29.6 11.6,31.1 L 6.5,36.2 C 4.2,38.5 3.3,42.0 4.1,45.1 L 7.2,56.8 C 7.8,59.1 9.4,61.1 11.4,62.2 L 20.8,67.6 C 22.8,68.7 25.1,69.1 27.4,68.6 L 35.8,66.8 C 38.6,66.2 41.5,66.7 44.1,68.2 L 52.6,73.1 C 55.1,74.5 58.1,75.0 60.9,74.3 L 73.1,71.2 C 75.8,70.5 78.3,69.0 80.2,66.9 L 91.5,54.2 C 93.3,52.2 94.2,49.5 94.0,46.8 L 93.2,35.6 C 93.1,33.9 92.4,32.3 91.1,31.3 C 89.8,30.3 88.2,29.9 86.6,30.3 L 82.5,33.8 Z",
    },
    layouts: 1,
    assetKey: "gt7_interlagos",
    hudReady: true
  },
  {
    id: "gt7_kyoto",
    name: "Kyoto Driving Park",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
    svgVariants: {
      outline: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      outline_thick: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      filled: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      telemetry_path: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z"
    },
    layouts: 6,
    assetKey: "gt7_kyoto",
    hudReady: true
  },
  {
    id: "gt7_lake_louise",
    name: "Lake Louise",
    location: 'Canada',
    region: "Americas",
    category: "Dirt / Snow",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
    svgVariants: {
      outline: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      outline_thick: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      filled: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      telemetry_path: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z"
    },
    layouts: 6,
    assetKey: "gt7_lake_louise",
    hudReady: true
  },
  {
    id: "gt7_laguna_seca",
    name: "Laguna Seca",
    location: 'USA',
    region: "Americas",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
    svgVariants: {
      outline: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      outline_thick: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      filled: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      telemetry_path: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z"
    },
    layouts: 1,
    assetKey: "gt7_laguna_seca",
    hudReady: true
  },
  {
    id: "gt7_road_atlanta",
    name: "Michelin Raceway Road Atlanta",
    location: 'USA',
    region: "Americas",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
    svgVariants: {
      outline: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      outline_thick: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      filled: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      telemetry_path: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z"
    },
    layouts: 1,
    assetKey: "gt7_road_atlanta",
    hudReady: true
  },
  {
    id: "gt7_monza",
    name: "Monza",
    location: 'Italy',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
    svgVariants: {
      outline: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      outline_thick: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      filled: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      telemetry_path: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z"
    },
    layouts: 2,
    assetKey: "gt7_monza",
    hudReady: true
  },
  {
    id: "gt7_mount_panorama",
    name: "Mount Panorama Motor Racing Circuit",
    location: 'Australia',
    region: "Asia-Oceania",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
    svgVariants: {
      outline: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      outline_thick: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      filled: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      telemetry_path: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z"
    },
    layouts: 1,
    assetKey: "gt7_bathurst",
    hudReady: true
  },
  {
    id: "gt7_nurburgring",
    name: "Nurburgring",
    location: 'Germany',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
    svgVariants: {
      outline: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      outline_thick: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      filled: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      telemetry_path: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z"
    },
    layouts: 6,
    assetKey: "gt7_nurburgring",
    hudReady: true
  },
  {
    id: "gt7_northern_isle",
    name: "Northern Isle Speedway",
    location: 'USA',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
    svgVariants: {
      outline: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      outline_thick: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      filled: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      telemetry_path: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z"
    },
    layouts: 1,
    assetKey: "gt7_northern_isle",
    hudReady: true
  },
  {
    id: "gt7_red_bull_ring",
    name: "Red Bull Ring",
    location: 'Austria',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
    svgVariants: {
      outline: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      outline_thick: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      filled: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      telemetry_path: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_red_bull_ring",
    hudReady: true
  },
  {
    id: "gt7_sardegna",
    name: "Sardegna",
    location: 'Italy',
    region: "Europe",
    category: "Dirt / Snow",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
    svgVariants: {
      outline: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      outline_thick: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      filled: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      telemetry_path: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z"
    },
    layouts: 8,
    assetKey: "gt7_sardegna",
    hudReady: true
  },
  {
    id: "gt7_ssrx",
    name: "Special Stage Route X",
    location: 'USA',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
    svgVariants: {
      outline: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      outline_thick: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      filled: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z",
      telemetry_path: "M 10 50 L 90 50 Q 90 90 50 90 Q 10 90 10 50 Z"
    },
    layouts: 1,
    assetKey: "gt7_ssrx",
    hudReady: true
  },
  {
    id: "gt7_suzuka",
    name: "Suzuka Circuit",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
    svgVariants: {
      outline: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      outline_thick: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      filled: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      telemetry_path: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_suzuka",
    hudReady: true
  },
  {
    id: "gt7_sainte_croix",
    name: "Sainte-Croix",
    location: 'France',
    region: "Europe",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
    svgVariants: {
      outline: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      outline_thick: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      filled: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z",
      telemetry_path: "M 30 80 L 10 50 Q 10 20 50 20 L 70 30 Q 90 40 80 70 Z"
    },
    layouts: 6,
    assetKey: "gt7_sainte_croix",
    hudReady: true
  },
  {
    id: "gt7_tokyo_expressway",
    name: "Tokyo Expressway",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
    svgVariants: {
      outline: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      outline_thick: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      filled: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z",
      telemetry_path: "M 20 80 L 20 40 Q 40 10 60 40 L 80 50 Q 90 80 60 80 Z"
    },
    layouts: 6,
    assetKey: "gt7_tokyo_expressway",
    hudReady: true
  },
  {
    id: "gt7_trial_mountain",
    name: "Trial Mountain",
    location: 'USA',
    region: "Americas",
    category: "Original Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
    svgVariants: {
      outline: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      outline_thick: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      filled: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z",
      telemetry_path: "M 10 50 Q 30 10 50 50 T 90 50 Q 70 90 50 50 T 10 50 Z"
    },
    layouts: 2,
    assetKey: "gt7_trial_mountain",
    hudReady: true
  },
  {
    id: "gt7_tsukuba",
    name: "Tsukuba Circuit",
    location: 'Japan',
    region: "Asia-Oceania",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
    svgVariants: {
      outline: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      outline_thick: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      filled: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z",
      telemetry_path: "M 50 90 Q 10 90 20 50 T 50 10 T 80 50 T 50 90 Z"
    },
    layouts: 1,
    assetKey: "gt7_tsukuba",
    hudReady: true
  },
  {
    id: "gt7_watkins_glen",
    name: "Watkins Glen",
    location: 'USA',
    region: "Americas",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
    svgVariants: {
      outline: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      outline_thick: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      filled: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z",
      telemetry_path: "M 40 80 C 10 80 10 20 40 20 C 60 20 70 40 80 40 C 90 40 90 60 80 60 C 60 60 60 80 40 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_watkins_glen",
    hudReady: true
  },
  {
    id: "gt7_willow_springs",
    name: "Willow Springs",
    location: 'USA',
    region: "Americas",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
    svgVariants: {
      outline: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      outline_thick: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      filled: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z",
      telemetry_path: "M 20 50 Q 20 20 50 20 Q 80 20 80 50 Q 80 80 50 80 Q 20 80 20 50 Z"
    },
    layouts: 5,
    assetKey: "gt7_willow_springs",
    hudReady: true
  },
  {
    id: "gt7_24h_lemans",
    name: "24 Heures du Mans Racing Circuit",
    location: 'France',
    region: "Europe",
    category: "Real Circuit",
    svgViewBox: '0 0 100 100',
    svgPath: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
    svgVariants: {
      outline: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      outline_thick: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      filled: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z",
      telemetry_path: "M 20 80 Q 10 20 50 20 T 80 50 Q 80 80 50 80 Z"
    },
    layouts: 2,
    assetKey: "gt7_le_mans",
    hudReady: true
  },
];
