// GT7 Autocomplete Starter Pack V1
export const GT7_V1_DATA = {
  "dataset_name": "GT7 Autocomplete Starter Pack",
  "version": "2026-04-19",
  "generated_at": "2026-04-19",
  "autocomplete": {
    "maker_model_index": [
      { "maker": "Honda", "models": ["Civic"] },
      { "maker": "Toyota", "models": ["Supra"] }
    ]
  },
  "cars": [
    { "id": 1, "maker": "Honda", "model": "Civic", "tags": [] },
    { "id": 2, "maker": "Toyota", "model": "Supra", "tags": [] }
  ]
};
