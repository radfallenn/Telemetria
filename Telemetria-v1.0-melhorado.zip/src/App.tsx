/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { safeLocalStorage, safeSessionStorage } from './lib/safeBrowserStorage';
import { 
  Plus, 
  Settings, 
  User,
  ChevronLeft, 
  Trash2, 
  Edit2, 
  Layout, 
  Filter, 
  Search,
  CloudRain,
  Image as ImageIcon,
  Sun,
  Cloud,
  Wind,
  Trophy,
  Clock,
  Gauge,
  BarChart,
  Calendar,
  Car,
  Upload,
  Download,
  X,
  Copy,
  ChevronUp,
  ChevronDown,
  Eye,
  EyeOff,
  RefreshCcw,
  CheckCircle2,
  Save,
  Globe,
  Lock,
  CloudUpload,
  CloudDownload,
  UploadCloud,
  Library,
  List,
  Network,
  Moon,
  Music,
  Check,
  AlertCircle,
  ShieldCheck,
  ShieldAlert,
  Database,
  RotateCcw,
  Sparkles,
  History,
  Zap,
  CloudOff,
  Users,
  Image,
  CarFront,
  Link,
  RefreshCw
} from 'lucide-react';
import { Track, Entry, LayoutProfile, LogoBrand, UserProfile, Brand } from './types';
import { saveLocalRestorePoint, getLocalRestorePoint } from './lib/indexedDB';
import { flags as flagDatabase } from './data/flagDatabase';
import { DEFAULT_LAYOUT, INITIAL_TRACKS, DEFAULT_FIELDS } from './constants';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';

const SAFE_CAR_PLACEHOLDER = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 300">
  <rect width="600" height="300" fill="transparent"/>
  <g opacity="0.18" fill="none" stroke="#8b93a7" stroke-width="10" stroke-linecap="round" stroke-linejoin="round">
    <path d="M105 190h390"/>
    <path d="M155 190l50-70h175l70 70"/>
    <path d="M215 120l-28 70"/>
    <path d="M380 120l32 70"/>
    <circle cx="190" cy="205" r="32"/>
    <circle cx="430" cy="205" r="32"/>
  </g>
</svg>`)}`;

const makeStableEntryId = (entry: Partial<Entry>, index: number) => {
  const base = [
    entry.trackId || 'track',
    entry.carBrand || 'brand',
    entry.carName || 'car',
    entry.runDate || 'date',
    entry.lapTime || 'lap',
    entry.totalTime || 'total',
    index
  ].join('|');

  const slug = normalizeNameForMatching(base).slice(0, 60);
  return `entry_${slug}_${Date.now().toString(36)}_${index}`;
};

const makeId = () => (typeof crypto !== 'undefined' && 'randomUUID' in crypto) ? crypto.randomUUID() : `${Date.now()}_${Math.random().toString(36).slice(2)}`;
const compactOverrides = (overrides: Record<string,string>) => Object.fromEntries(Object.entries(overrides || {}).filter(([_, v]) => typeof v === 'string' && v.trim() !== ''));

const ensureUniqueTracks = (input: Track[]) => {
  const seen = new Set<string>();
  return (input || []).filter(Boolean).map((track, index) => {
    let id = String(track.id || '').trim() || `track_${index}_${makeId()}`;
    if (seen.has(id)) id = `${id}_${index}_${makeId()}`;
    seen.add(id);
    return { ...track, id };
  });
};

const getEnhancedTrackPack = (): Track[] => {
  const newTracks: any[] = [];
  
  TRACK_PACK.forEach(t => {
    // Base track
    newTracks.push({
      id: t.id,
      name: t.name,
      location: t.location,
      packId: t.id
    });
    
    // Add variants if layouts > 1
    if (t.layouts && t.layouts > 1) {
      // Reverse variants for Original Circuits
      if (t.category === 'Original Circuit' && !t.name.includes('Reverse')) {
        newTracks.push({ id: `${t.id}_reverse`, name: `${t.name} (Reverse)`, location: t.location, packId: t.id });
      }
      
      // Known variants for Real and Original Circuits
      const n = t.name.toLowerCase();
      
      if (n.includes('suzuka')) {
         newTracks.push({ id: 'suzuka_east', name: 'Suzuka Circuit East Course', location: t.location, packId: t.id });
      }
      if (n.includes('kyoto')) {
         newTracks.push({ id: 'kyoto_miyabi', name: 'Kyoto Driving Park - Miyabi', location: t.location, packId: t.id });
         newTracks.push({ id: 'kyoto_yamagiwa', name: 'Kyoto Driving Park - Yamagiwa', location: t.location, packId: t.id });
         newTracks.push({ id: 'kyoto_yamagiwa_miyabi', name: 'Kyoto Driving Park - Yamagiwa + Miyabi', location: t.location, packId: t.id });
      }
      if (n.includes('alsace')) {
         newTracks.push({ id: 'alsace_village', name: 'Alsace - Village', location: t.location, packId: t.id });
      }
      if (n.includes('maggiore')) {
         newTracks.push({ id: 'maggiore_center', name: 'Lago Maggiore - Center', location: t.location, packId: t.id });
         newTracks.push({ id: 'maggiore_west', name: 'Lago Maggiore - West', location: t.location, packId: t.id });
         newTracks.push({ id: 'maggiore_east', name: 'Lago Maggiore - East', location: t.location, packId: t.id });
      }
      if (n.includes('nurburgring') || n.includes('nürburgring')) {
         newTracks.push({ id: 'nurburgring_nordschleife', name: 'Nürburgring Nordschleife', location: t.location, packId: t.id });
         newTracks.push({ id: 'nurburgring_24h', name: 'Nürburgring 24h', location: t.location, packId: t.id });
         newTracks.push({ id: 'nurburgring_gp', name: 'Nürburgring GP', location: t.location, packId: t.id });
      }
      if (n.includes('sardegna') && t.category !== 'Dirt / Snow') {
         newTracks.push({ id: 'sardegna_road_a', name: 'Sardegna - Road Track - A', location: t.location, packId: t.id });
         newTracks.push({ id: 'sardegna_road_b', name: 'Sardegna - Road Track - B', location: t.location, packId: t.id });
         newTracks.push({ id: 'sardegna_road_c', name: 'Sardegna - Road Track - C', location: t.location, packId: t.id });
      }
      if (n.includes('dragon trail')) {
         newTracks.push({ id: 'dragon_trail_seaside', name: 'Dragon Trail - Seaside', location: t.location, packId: t.id });
         newTracks.push({ id: 'dragon_trail_gardens', name: 'Dragon Trail - Gardens', location: t.location, packId: t.id });
      }
      if (n.includes('tokyo expressway')) {
         newTracks.push({ id: 'tokyo_east', name: 'Tokyo Expressway - Central Clockwise', location: t.location, packId: t.id });
         newTracks.push({ id: 'tokyo_central', name: 'Tokyo Expressway - East Clockwise', location: t.location, packId: t.id });
         newTracks.push({ id: 'tokyo_south', name: 'Tokyo Expressway - South Clockwise', location: t.location, packId: t.id });
      }
      if (n.includes('fuji')) {
         newTracks.push({ id: 'fuji_short', name: 'Fuji Speedway Short', location: t.location, packId: t.id });
      }
      if (n.includes('interlagos')) {
         // only 1 layout usually
      }
      if (n.includes('sainte-croix') || n.includes('sainte croix')) {
         newTracks.push({ id: 'ste_croix_a', name: 'Sainte-Croix - A', location: t.location, packId: t.id });
         newTracks.push({ id: 'ste_croix_b', name: 'Sainte-Croix - B', location: t.location, packId: t.id });
         newTracks.push({ id: 'ste_croix_c', name: 'Sainte-Croix - C', location: t.location, packId: t.id });
      }
      if (n.includes('willow springs')) {
         newTracks.push({ id: 'willow_big_willow', name: 'Willow Springs - Big Willow', location: t.location, packId: t.id });
         newTracks.push({ id: 'willow_streets', name: 'Willow Springs - Streets of Willow Springs', location: t.location, packId: t.id });
         newTracks.push({ id: 'willow_horse', name: 'Willow Springs - Horse Thief Mile', location: t.location, packId: t.id });
      }
      if (n.includes('daytona')) {
         newTracks.push({ id: 'daytona_tri_oval', name: 'Daytona International Speedway - Tri-Oval', location: t.location, packId: t.id });
         newTracks.push({ id: 'daytona_road', name: 'Daytona International Speedway - Road Course', location: t.location, packId: t.id });
      }
    }
  });

  return ensureUniqueTracks(newTracks);
};

const ensureUniqueEntries = (input: Entry[]): Entry[] => {
  const seen = new Set<string>();

  return (input || []).map((entry, index) => {
    let id = String(entry?.id || '').trim();

    if (!id || seen.has(id)) {
      id = makeId(); // Use the new makeId helper
    }

    seen.add(id);
    return { ...entry, id };
  });
};

export const getTrackSlug = (track: { name?: string, id?: string }) => 
  normalizeNameForMatching(track.name || track.id || 'unknown').slice(0, 60);


const ensureUniqueFields = (fields: import('./types').FieldConfig[]): import('./types').FieldConfig[] => {
  const seen = new Set<string>();

  return (fields || []).map((field, index) => {
    let id = String(field?.id || `field_${index}`);
    if (seen.has(id)) id = `${id}_${index}`;
    seen.add(id);
    return { ...field, id };
  });
};

const getNormalizedFields = (layout: LayoutProfile): import('./types').FieldConfig[] => {
  if (layout.fields && layout.fields.length > 0) return layout.fields;
  
  let fieldsStr = JSON.stringify(DEFAULT_FIELDS);
  let fields: import('./types').FieldConfig[] = JSON.parse(fieldsStr);
  
  if (layout.labels) {
    fields.forEach(f => {
      if (f.id === 'racePosition' && layout.labels?.pos) f.label = layout.labels.pos;
      if (f.id === 'carSetup' && layout.labels?.setup) f.label = layout.labels.setup;
      if (f.id === 'pitStops' && layout.labels?.pits) f.label = layout.labels.pits;
      if (f.id === 'tractionControl' && layout.labels?.tc) f.label = layout.labels.tc;
      if (f.id === 'carMap' && layout.labels?.map) f.label = layout.labels.map;
      if (f.id === 'weather' && layout.labels?.weather) f.label = layout.labels.weather;
      if (f.id === 'lapTime' && layout.labels?.lap) f.label = layout.labels.lap;
      if (f.id === 'totalTime' && layout.labels?.total) f.label = layout.labels.total;
      if (f.id === 'provaDeTempo' && layout.labels?.trial) f.label = layout.labels.trial;
      if (f.id === 'runDate' && layout.labels?.date) f.label = layout.labels.date;
      if (f.id === 'laps' && layout.labels?.laps) f.label = layout.labels.laps;
      if (f.id === 'transmission' && layout.labels?.transmission) f.label = layout.labels.transmission;
      if (f.id === 'peripheral' && layout.labels?.peripheral) f.label = layout.labels.peripheral;
      if (f.id === 'pilot_name' && layout.labels?.pilot) f.label = layout.labels.pilot;
    });
  }

  if (layout.hiddenRows) {
    fields.forEach(f => {
      if (layout.hiddenRows!.includes('row1') && f.id === 'header') f.hidden = true;
      if (layout.hiddenRows!.includes('row2') && ['racePosition', 'carSetup', 'pitStops'].includes(f.id)) f.hidden = true;
      if (layout.hiddenRows!.includes('row3') && ['tractionControl', 'carMap', 'weather'].includes(f.id)) f.hidden = true;
      if (layout.hiddenRows!.includes('row4') && f.id === 'runDate') f.hidden = true;
      if (layout.hiddenRows!.includes('row5') && ['lapTime', 'totalTime'].includes(f.id)) f.hidden = true;
      if (layout.hiddenRows!.includes('row6') && f.id === 'actions') f.hidden = true;
      if (layout.hiddenRows!.includes('row7') && f.id === 'transmission') f.hidden = true;
      if (layout.hiddenRows!.includes('row8') && f.id === 'laps') f.hidden = true;
      if (layout.hiddenRows!.includes('row9') && f.id === 'pilot_name') f.hidden = true;
      if (layout.hiddenRows!.includes('row10') && f.id === 'peripheral') f.hidden = true;
      if (layout.hiddenRows!.includes('row11') && f.id === 'provaDeTempo') f.hidden = true;
    });
  }

  if (layout.customFields) {
    layout.customFields.forEach(cf => {
      // The id in customFields should be the 'base' id. If it already has custom_ prefix, we might double it if we add custom_ again.
      // Based on JSON instruction, we should ensure the ID doesn't double-prefix.
      const baseId = cf.id.startsWith('custom_') ? cf.id.replace('custom_', '') : cf.id;
      fields.push({ id: `custom_${baseId}`, label: cf.label, colSpan: 12, hidden: layout.hiddenRows?.includes(`custom_${baseId}`) || false, isCustom: true });
    });
  }
  
  return ensureUniqueFields(fields);
};
import { TRACK_PACK, Region, Category } from './data/trackPack';
import { RAW_CARS } from './data/gt7_cars';
import { RAW_BRANDS } from './data/gt7_brands';
import { getBrandLogo, findCarByName, getAllBrands } from './services/gt7Database';
import { getLogoUrl, formatDateBr as formatDate, getSmartSearchScore } from './lib/utils';
import { saveThumbnailLocal, getThumbnailLocal, getAllLocalThumbnails, deleteThumbnailLocal, clearAllThumbnailsLocal } from './lib/thumbnailDb';
import { refreshThumbsCache, useCarThumbnail, getMatchedThumbnailSrc, getCachedThumbs, subscribeToThumbs, useAllThumbnails, normalizeNameForMatching, triggerThumbnailUpdate } from './lib/thumbnailCache';
import { getThumbnailSupabase as getThumbnailMetadataFromSupabase } from './lib/thumbnailSupabase';
import { getAllCustomCarsFromFirestore, subscribeToCustomCars, saveCarPageItemToFirestore, deleteCarPageItemFromFirestore, subscribeToCarPage } from './lib/carsDb';
import { saveTrackToFirestore, deleteTrackFromFirestore, subscribeToTracks, saveEntryToFirestore, deleteEntryFromFirestore, subscribeToEntries } from './lib/tracksDb';
import { uploadCarAsset } from './services/carAssetService';
import { uploadTrackAsset, getTrackAssetOverrides } from './services/trackAssetService';
import { addCustomCarsToDatabase } from './services/gt7Database';
import { identifyCarBrand } from './services/aiService';
import { isFirebaseConfigured, uploadBase64ToFirebase, saveThumbnailMetadataToFirestore, getThumbnailMetadataFromFirestore, uploadThumbnailDirectly } from './services/firebaseService';
import { Auth } from './components/Auth';
import { convertToWebP } from './lib/imageUtils';
import { RankingModal } from './components/RankingModal';
import { PublicProfileModal } from './components/PublicProfileModal';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import { supabaseService } from './services/supabaseService';
import { Session } from '@supabase/supabase-js';
import { ProfileModal } from './components/ProfileModal';
import { ProfileSetupOverlay } from './components/ProfileSetupOverlay';
import { UserHub } from './components/UserHub';
import { PilotManager } from './components/PilotManager';
import { PilotRankingList } from './components/PilotRankingList';
import { PublicProfileView } from './components/PublicProfileView';
import { PeripheralIcon } from './components/PeripheralIcon';
import { CarAudioFX } from './components/CarAudioFX';
import { CarNamesManagerTab } from './components/CarNamesManagerTab';
import { TrackImagesTab } from './components/TrackImagesTab';

const ADMIN_EMAIL = ''; // Desativado - usando banco de dados

const COUNTRY_FLAGS: Record<string, string> = {
  'france': '🇫🇷',
  'japan': '🇯🇵',
  'spain': '🇪🇸',
  'united states': '🇺🇸',
  'usa': '🇺🇸',
  'us': '🇺🇸',
  'united kingdom': '🇬🇧',
  'uk': '🇬🇧',
  'great britain': '🇬🇧',
  'croatia': '🇭🇷',
  'switzerland': '🇨🇭',
  'canada': '🇨🇦',
  'brazil': '🇧🇷',
  'italy': '🇮🇹',
  'australia': '🇦🇺',
  'germany': '🇩🇪',
  'austria': '🇦🇹',
  'belgium': '🇧🇪',
  'united arab emirates': '🇦🇪',
  'uae': '🇦🇪'
};

function getCountryFlag(country: string | undefined): string {
  if (!country || typeof country !== 'string') return '';
  const trimmed = country.trim().toLowerCase();
  const normalizedInput = trimmed.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  
  // 1. Exact match in COUNTRY_FLAGS
  if (COUNTRY_FLAGS[trimmed]) return COUNTRY_FLAGS[trimmed];
  
  // 2. Exact match normalized in COUNTRY_FLAGS
  for (const c in COUNTRY_FLAGS) {
    const nc = c.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (normalizedInput === nc) return COUNTRY_FLAGS[c];
  }
  
  // 3. Exact match normalized in flagDatabase
  for (const k in flagDatabase) {
    const nk = k.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (normalizedInput === nk) return flagDatabase[k];
  }
  
  // Helper to check for whole-word match
  const isWholeWord = (text: string, sub: string) => {
    const escaped = sub.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`(^|[^a-zA-Z0-9])` + escaped + `([^a-zA-Z0-9]|$)`, 'i');
    return regex.test(text);
  };

  // 4. Word boundary match normalized in COUNTRY_FLAGS keys
  for (const c in COUNTRY_FLAGS) {
    const nc = c.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (isWholeWord(normalizedInput, nc)) return COUNTRY_FLAGS[c];
  }

  // 5. Word boundary match normalized in flagDatabase keys
  for (const k in flagDatabase) {
    const nk = k.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (isWholeWord(normalizedInput, nk)) return flagDatabase[k];
  }
  
  // 6. Substring fallback to maintain high match rates (only if substring has length >= 4)
  for (const k in flagDatabase) {
    const nk = k.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (nk.length >= 4 && normalizedInput.includes(nk)) {
      return flagDatabase[k];
    }
  }
  
  return '';
}

function getCountryFlagFromTrack(track?: Track) {
  if (!track) return '';
  if (track.location) {
    const flag = getCountryFlag(track.location);
    if (flag) return flag;
  }
  
  // Backwards compatibility/fuzzy search for tracks without explicit location
  const trackName = track?.name || "";
  const name = trackName.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  
  const isWholeWord = (text: string, sub: string) => {
    const escaped = sub.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`(^|[^a-zA-Z0-9])` + escaped + `([^a-zA-Z0-9]|$)`, 'i');
    return regex.test(text);
  };

  // 1. Whole-word match in COUNTRY_FLAGS
  for (const country in COUNTRY_FLAGS) {
    if (isWholeWord(name, country)) return COUNTRY_FLAGS[country];
  }
  
  // 2. Whole-word match in flagDatabase
  for (const key in flagDatabase) {
    const normalizedKey = key.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (isWholeWord(name, normalizedKey)) return flagDatabase[key];
  }
  
  // 3. Fallback to substring matching in COUNTRY_FLAGS
  for (const country in COUNTRY_FLAGS) {
    if (name.includes(country)) return COUNTRY_FLAGS[country];
  }
  
  // 4. Fallback to substring matching in flagDatabase (excluding very short/generic keys like "Spa")
  for (const key in flagDatabase) {
    const normalizedKey = key.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (normalizedKey.length >= 4 && name.includes(normalizedKey)) return flagDatabase[key];
  }

  return '🌐';
}

async function safeLoadGT7Database(databaseUrl: string, fallbackData: any = null) {
  try {
    if (!databaseUrl || typeof databaseUrl !== 'string') {
      throw new Error('URL do banco de dados não informada.');
    }

    const safeUrl = encodeURI(databaseUrl.trim());

    const response = await fetch(safeUrl, {
      method: 'GET',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Falha ao carregar JSON. HTTP ${response.status} - ${response.statusText}`);
    }

    const data = await response.json();

    if (!data || !Array.isArray(data.tracks)) {
      throw new Error('JSON carregado, mas estrutura inválida: data.tracks não encontrado.');
    }

    return {
      success: true,
      data,
      source: 'remote' as const,
      error: null
    };
  } catch (error: any) {
    console.error('Erro ao carregar banco GT7:', error);
    
    let userFriendlyError = error.message;
    const lowercaseError = userFriendlyError.toLowerCase();
    if (lowercaseError.includes('failed to fetch') || lowercaseError.includes('fetch failed') || lowercaseError.includes('network error')) {
      userFriendlyError = 'Falha na conexão (CORS ou URL inválida). Verifique se o endereço está correto e permite acesso externo.';
    }

    if (fallbackData && Array.isArray(fallbackData?.tracks)) {
      return {
        success: true,
        data: fallbackData,
        source: 'fallback' as const,
        error: userFriendlyError
      };
    }

    return {
      success: false,
      data: null,
      source: null,
      error: userFriendlyError || 'Erro desconhecido ao carregar banco de dados.'
    };
  }
}

function normalizeTrack(track: any): Track {
  return {
    ...track,
    id: track?.id || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random())),
    name: track?.display_name || track?.name || 'Unnamed Track',
    location: track?.country || track?.location || '',
  };
}

// Helper to parse lap/total time into milliseconds
function parseLapTime(timeStr: string): number {
  if (!timeStr || timeStr.includes('-') || timeStr === '00:00.000' || timeStr.trim() === '') return Infinity;
  
  const parts = timeStr.split(':').map(p => p.trim());
  
  let hours = 0, mins = 0, secs = 0, ms = 0;
  
  try {
    if (parts.length === 3) {
      hours = parseInt(parts[0], 10) || 0;
      mins = parseInt(parts[1], 10) || 0;
      const secMs = parts[2].split('.');
      secs = parseInt(secMs[0], 10) || 0;
      ms = parseInt(secMs[1] || '0', 10) || 0;
    } else if (parts.length === 2) {
      mins = parseInt(parts[0], 10) || 0;
      const secMs = parts[1].split('.');
      secs = parseInt(secMs[0], 10) || 0;
      ms = parseInt(secMs[1] || '0', 10) || 0;
    } else {
      const secMs = parts[0].split('.');
      secs = parseInt(secMs[0], 10) || 0;
      ms = parseInt(secMs[1] || '0', 10) || 0;
    }
    
    const total = hours * 3600000 + mins * 60000 + secs * 1000 + ms;
    return isNaN(total) ? Infinity : total;
  } catch (e) {
    return Infinity;
  }
}

function AppContent() {
  const { language, setLanguage, t } = useLanguage();
  
  useEffect(() => {
    // Silencia erros genéricos de rede no console para não assustar o usuário
    const handleGlobalError = (event: ErrorEvent | PromiseRejectionEvent) => {
      const msg = (event instanceof ErrorEvent ? event.message : (event as any).reason?.message) || '';
      const lowercaseMsg = msg.toLowerCase();
      
      const isFetchError = 
        lowercaseMsg.includes('failed to fetch') || 
        lowercaseMsg.includes('fetch failed') || 
        lowercaseMsg.includes('networkerror') ||
        lowercaseMsg.includes('network error') ||
        lowercaseMsg.includes('load failed') ||
        lowercaseMsg.includes('conexão') ||
        lowercaseMsg.includes('corrupted') || 
        lowercaseMsg.includes('aborted');

      if (isFetchError) {
        console.warn('Network issue caught by boundary. Suppressed to prevent UI panic.');
        
        // Se estávamos ativamente tentando sincronizar, avisamos o usuário no menu
        if (isSyncingRef.current) {
          setSyncError('Erro de conexão: O Supabase pode estar sendo bloqueado (AdBlock) ou está offline.');
        }
        
        event.preventDefault(); 
      }
    };

    window.addEventListener('error', handleGlobalError);
    window.addEventListener('unhandledrejection', handleGlobalError);
    return () => {
      window.removeEventListener('error', handleGlobalError);
      window.removeEventListener('unhandledrejection', handleGlobalError);
    };
  }, []);

  useEffect(() => {
    refreshThumbsCache();

    // Listeners para captura de entrada (Novo Registro) do APK
    const handleMobileEntry = (ev: any) => {
      if (ev.detail) {
        localStorage.setItem('gt7LastMobileEntry', JSON.stringify(ev.detail));
        (window as any).__gt7MobileEntry = ev.detail;
      }
    };
    window.addEventListener('gt7-mobile-entry', handleMobileEntry);
    
    return () => {
      window.removeEventListener('gt7-mobile-entry', handleMobileEntry);
    };
  }, []);

  const [session, setSession] = useState<Session | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [syncErrorValue, setSyncErrorValue] = useState<string | null>(null);
  
  const setSyncError = (errOption: string | null) => {
    if (errOption && (errOption.toLowerCase().includes('refresh token') || errOption.toLowerCase().includes('refresh_token'))) {
       try { localStorage.clear(); } catch(e) {}
       try { sessionStorage.clear(); } catch(e) {}
       window.location.reload();
       return;
    }
    setSyncErrorValue(errOption);
  };
  const syncError = syncErrorValue;
  
  const isSyncingRef = useRef(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [homeTab, setHomeTab] = useState<'personal' | 'community' | 'telemetry' | 'roadmap'>('personal');
  const [isFullscreenVisual, setIsFullscreenVisual] = useState(false);

  useEffect(() => {
    // Read URLSearchParams
    const urlParams = new URLSearchParams(window.location.search);
    const hasBridgeParam = urlParams.get('bridge') === 'mobile-apk-push';
    const hasTelemetryTab = urlParams.get('tab') === 'telemetry';
    const hasFullscreenParam = urlParams.get('fullscreen') === '1' || urlParams.get('showAllTelemetry') === '1';
    
    let isLocalStorageMobileMode = false;
    try {
      isLocalStorageMobileMode = localStorage.getItem('gt7TelemetryMode') === 'mobile-apk-push';
    } catch(e) {}

    // Check conditions to auto-switch tab and mode
    if (hasBridgeParam || hasTelemetryTab || isLocalStorageMobileMode) {
      setHomeTab('telemetry');
    }
    
    if (hasFullscreenParam) {
      setIsFullscreenVisual(true);
    }

    // Register event listeners according to the APK v1.4.4 requirements
    const handleBridgeReady = () => {
      setHomeTab('telemetry');
      try {
        if (localStorage.getItem('gt7FullscreenPreferred') === 'true') {
          setIsFullscreenVisual(true);
        }
      } catch (e) {}
    };

    const handleMobileTelemetry = () => {
      setHomeTab('telemetry');
      try {
        if (localStorage.getItem('gt7FullscreenPreferred') === 'true') {
          setIsFullscreenVisual(true);
        }
      } catch (e) {}
    };

    const handleMobileEntry = () => {
      setHomeTab('telemetry');
      try {
        if (localStorage.getItem('gt7FullscreenPreferred') === 'true') {
          setIsFullscreenVisual(true);
        }
      } catch (e) {}
    };

    const handleTriggerFullscreenHud = () => {
      setIsFullscreenVisual(true);
    };

    window.addEventListener('gt7-bridge-mobile-ready', handleBridgeReady);
    window.addEventListener('gt7-mobile-telemetry', handleMobileTelemetry);
    window.addEventListener('gt7-mobile-entry', handleMobileEntry);
    window.addEventListener('gt7-trigger-fullscreen-hud', handleTriggerFullscreenHud);

    // Continuous, lightweight checker loop to detect injected localStorage and fallback API sources
    let activeDetection = true;
    const runDetection = async () => {
      if (!activeDetection) return;

      let detected = false;
      let fullscreenPreferred = false;

      // 1. Check window property
      if (window.__gt7MobileBridgeActive === true) {
        detected = true;
      }

      // 2. Check localStorage primary sources
      try {
        const mode = localStorage.getItem('gt7TelemetryMode');
        const httpUrl = localStorage.getItem('gt7BridgeHttpUrl');
        const entryUrl = localStorage.getItem('gt7BridgeEntryUrl');
        const openOnStart = localStorage.getItem('gt7OpenTelemetryOnStart');
        const fsPreferred = localStorage.getItem('gt7FullscreenPreferred');
        const showAll = localStorage.getItem('gt7ShowAllTelemetry');

        if (
          mode === 'mobile-apk-push' ||
          httpUrl ||
          entryUrl ||
          openOnStart === 'true' ||
          fsPreferred === 'true' ||
          showAll === 'true'
        ) {
          detected = true;
          if (fsPreferred === 'true') {
            fullscreenPreferred = true;
          }
        }
      } catch (e) {}

      // 3. Check fallback API endpoints if not yet detected to open telemetry automatically
      if (!detected) {
        const fallbackUrls = [
          'http://127.0.0.1:8787/api/fields',
          'http://127.0.0.1:8787/api/entry',
          'http://127.0.0.1:8787/api/status',
          'http://127.0.0.1:8787/api/map'
        ];
        
        for (const url of fallbackUrls) {
          try {
            const controller = new AbortController();
            const abortId = setTimeout(() => controller.abort(), 800);
            const res = await fetch(url, { signal: controller.signal });
            clearTimeout(abortId);
            if (res.ok) {
              detected = true;
              break;
            }
          } catch (e) {}
        }
      }

      if (detected && activeDetection) {
        setHomeTab('telemetry');
        if (fullscreenPreferred) {
          setIsFullscreenVisual(true);
        }
      }
    };

    // Run immediately and every 1.5 seconds to capture dynamically injected resources/localStorages
    runDetection();
    const detectInterval = setInterval(runDetection, 1500);

    return () => {
      activeDetection = false;
      clearInterval(detectInterval);
      window.removeEventListener('gt7-bridge-mobile-ready', handleBridgeReady);
      window.removeEventListener('gt7-mobile-telemetry', handleMobileTelemetry);
      window.removeEventListener('gt7-mobile-entry', handleMobileEntry);
      window.removeEventListener('gt7-trigger-fullscreen-hud', handleTriggerFullscreenHud);
    };
  }, []);
  const [communityProfiles, setCommunityProfiles] = useState<UserProfile[]>([]);
  const [loadingCommunity, setLoadingCommunity] = useState(false);
  const [communitySearch, setCommunitySearch] = useState('');
  const [selectedPublicProfileId, setSelectedPublicProfileId] = useState<string | null>(null);
  const [isRankingOpen, setIsRankingOpen] = useState(false);
  const [rankingTrackId, setRankingTrackId] = useState<string | null>(null);
  const [isAIAnalystOpen, setIsAIAnalystOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');
  const [homeViewMode, setHomeViewMode] = useState<'card' | 'list'>('card');
  const [trackSortMode, setTrackSortMode] = useState<'records' | 'name'>('records');
  const [trackSearchQuery, setTrackSearchQuery] = useState('');

  // --- Lixeira (Soft Delete) ---
  const [trash, setTrash] = useState<{tracks: Track[], entries: Entry[]}>({ tracks: [], entries: [] });
  const [tracks, setTracks] = useState<Track[]>(() => {
    if (isFirebaseConfigured) {
      return getEnhancedTrackPack();
    }
    try {
      const saved = safeLocalStorage.getItem('gt7_local_tracks');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.length > 0) {
          return ensureUniqueTracks(parsed);
        }
      }
    } catch (e) {
      console.error('Error reading tracks from local storage:', e);
    }
    return getEnhancedTrackPack();
  });
  const [entries, setEntries] = useState<Entry[]>(() => {
    if (isFirebaseConfigured) {
      return [];
    }
    try {
      const saved = safeLocalStorage.getItem('gt7_local_entries');
      if (saved) return ensureUniqueEntries(JSON.parse(saved));
    } catch (e) {
      console.error('Error reading entries from local storage:', e);
    }
    return [];
  });
  const [history, setHistory] = useState<Entry[][]>([]);
  const [hubOpen, setHubOpen] = useState(false);
  const [pilotManagerOpen, setPilotManagerOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoOverrides, setLogoOverrides] = useState<Record<string, string>>(() => {
    try {
      const saved = safeLocalStorage.getItem('gt7_local_logo_overrides');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error reading logo overrides from local storage:', e);
    }
    return {};
  });
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});
  const [logosDatabase, setLogosDatabase] = useState<LogoBrand[]>(() => {
    try {
      const saved = safeLocalStorage.getItem('gt7_local_logos_database');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error reading logos database from local storage:', e);
    }
    return [];
  });
  const [carsDatabase, setCarsDatabase] = useState<any[]>(() => {
    try {
      const saved = safeLocalStorage.getItem('gt7_local_cars_tab_database');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error reading cars database from local storage:', e);
    }
    return [];
  });
  const [layout, setLayout] = useState<LayoutProfile>(() => {
    try {
      const saved = safeLocalStorage.getItem('gt7_local_layout');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error reading layout from local storage:', e);
    }
    return DEFAULT_LAYOUT;
  });
  const [isAdminViewOpen, setIsAdminViewOpen] = useState(false);
  const [linkingForCarName, setLinkingForCarName] = useState<string | null>(null);
  const [isCarModalOpen, setIsCarModalOpen] = useState(false);
  const [selectedCarForPreview, setSelectedCarForPreview] = useState<any>(null);
  const [editingTrack, setEditingTrack] = useState<Track | null>(null);

  useEffect(() => {
    if (isFirebaseConfigured) {
      const unsubCars = subscribeToCustomCars((cars) => {
        addCustomCarsToDatabase(cars);
      });
      const unsubCarPage = subscribeToCarPage((items) => {
        setCarsDatabase(items);
      });
      const unsubTracks = subscribeToTracks((dbTracks) => {
        if (dbTracks) {
          setTracks(prev => {
            const map = new Map(getEnhancedTrackPack().map(t => [t.id, t]));
            dbTracks.forEach(t => map.set(t.id, t));
            return Array.from(map.values());
          });
        }
      });
      const unsubEntries = subscribeToEntries((dbEntries) => {
        if (dbEntries) {
          setEntries(dbEntries);
        }
      });
      return () => {
        unsubCars();
        unsubCarPage();
        unsubTracks();
        unsubEntries();
      };
    }
  }, []);

  // Fast Save to localStorage triggers instantaneously when state changes (after initial load)
  useEffect(() => {
    if (!isInitializing && !isFirebaseConfigured) {
      safeLocalStorage.setItem('gt7_local_tracks', JSON.stringify(tracks));
    }
  }, [tracks, isInitializing]);

  useEffect(() => {
    if (!isInitializing && !isFirebaseConfigured) {
      safeLocalStorage.setItem('gt7_local_entries', JSON.stringify(entries));
    }
  }, [entries, isInitializing]);

  useEffect(() => {
    if (!isInitializing) {
      safeLocalStorage.setItem('gt7_local_logo_overrides', JSON.stringify(logoOverrides));
    }
  }, [logoOverrides, isInitializing]);

  useEffect(() => {
    if (!isInitializing) {
      safeLocalStorage.setItem('gt7_local_logos_database', JSON.stringify(logosDatabase));
    }
  }, [logosDatabase, isInitializing]);

  useEffect(() => {
    if (!isInitializing) {
      safeLocalStorage.setItem('gt7_local_cars_tab_database', JSON.stringify(carsDatabase));
    }
  }, [carsDatabase, isInitializing]);

  useEffect(() => {
    if (!isInitializing) {
      safeLocalStorage.setItem('gt7_local_layout', JSON.stringify(layout));
    }
  }, [layout, isInitializing]);

  // Tracks whether custom changes were made to major databases since the last automatic/manual restore point.
  const hasChangesForBackupRef = useRef(false);

  useEffect(() => {
    if (!isInitializing) {
      hasChangesForBackupRef.current = true;
    }
  }, [tracks, entries, layout, logoOverrides, logosDatabase, carsDatabase, isInitializing]);

  const latestDataRef = useRef({
    tracks,
    entries,
    layout,
    logoOverrides,
    logosDatabase,
    carsDatabase
  });

  useEffect(() => {
    latestDataRef.current = {
      tracks,
      entries,
      layout,
      logoOverrides,
      logosDatabase,
      carsDatabase
    };
  }, [tracks, entries, layout, logoOverrides, logosDatabase, carsDatabase]);

  useEffect(() => {
    const checkAndBackup = async () => {
      if (hasChangesForBackupRef.current) {
        console.log('[Backup Task] Changes detected. Auto-saving local restore point...');
        try {
          const currentData = latestDataRef.current;
          const dataToSave = {
            ...currentData,
            timestamp: new Date().toISOString()
          };
          await saveLocalRestorePoint(dataToSave);
          hasChangesForBackupRef.current = false;
          console.log('[Backup Task] Auto-save local restore point completed successfully at:', new Date().toLocaleTimeString());
        } catch (err) {
          console.error('[Backup Task] Auto-save local restore point failed:', err);
        }
      } else {
        console.log('[Backup Task] No changes detected since last backup. Skipping auto-save.');
      }
    };

    // Run every 1 hour (3600000 ms)
    const ONE_HOUR = 3600000;
    const intervalId = setInterval(checkAndBackup, ONE_HOUR);

    console.log('[Backup Task] Hourly background restore point task initialized.');

    if (typeof window !== 'undefined') {
      (window as any).__triggerBackupTask = checkAndBackup;
      (window as any).__hasChangesForBackup = () => hasChangesForBackupRef.current;
    }

    return () => {
      clearInterval(intervalId);
      if (typeof window !== 'undefined') {
        try {
          delete (window as any).__triggerBackupTask;
          delete (window as any).__hasChangesForBackup;
        } catch (e) {}
      }
    };
  }, []);

  const addLogosToBank = async (logos: {name: string, data: string}[]) => {
    let newLogos = [...logosDatabase];
    const newOverrides = { ...logoOverrides };

    for (const logo of logos) {
      const brandSlug = normalizeBrandName(logo.name);
      let finalLogoData = logo.data;
      if (logo.data.startsWith('data:image/') && isFirebaseConfigured) {
        try {
          const fileExt = logo.data.split(';')[0].split('/')[1] || 'png';
          const storagePath = `logos/${encodeURIComponent(logo.name)}_${Date.now()}.${fileExt}`;
          finalLogoData = await uploadBase64ToFirebase(logo.data, storagePath);
        } catch (fbErr) {
          console.warn("Failed to upload logo to Firebase Storage (falling back to local):", fbErr);
        }
      }

      const newLogo: LogoBrand = {
        id: crypto.randomUUID(),
        brand_name: logo.name,
        brand_slug: brandSlug,
        logo_data: finalLogoData,
        logo_type: 'png',
        created_at: Date.now(),
        updated_at: Date.now()
      };
      
      const existingIndex = newLogos.findIndex(l => l.brand_name.toLowerCase() === logo.name.toLowerCase());
      if (existingIndex >= 0) {
        newLogos[existingIndex] = newLogo;
      } else {
        newLogos.push(newLogo);
      }
      newOverrides[logo.name] = finalLogoData;
    }

    setLogosDatabase(newLogos);
    setLogoOverrides(newOverrides);

    if (session) {
      supabaseService.saveUserSettings(layout, newOverrides, newLogos)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao salvar logos'));
    }
  };

  const updateLogoNameInBank = (id: string, newName: string) => {
    const updated = logosDatabase.map(l => {
      if (l.id === id) {
        return { ...l, brand_name: newName, brand_slug: normalizeBrandName(newName), updated_at: Date.now() };
      }
      return l;
    });
    setLogosDatabase(updated);
    if (session) {
      supabaseService.saveUserSettings(layout, logoOverrides, updated)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao atualizar nome'));
    }
  };

  const deleteLogoFromBank = (id: string) => {
    const filtered = logosDatabase.filter(l => l.id !== id);
    setLogosDatabase(filtered);
    if (session) {
      supabaseService.saveUserSettings(layout, logoOverrides, filtered)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao excluir do banco de logos'));
    }
  };

  const addCarsToBank = async (cars: {name: string, data: string}[]) => {
    setIsSyncing(true);
    setSyncError(null);
    let newCars = [...carsDatabase];
    let errors: string[] = [];

    try {
      for (const car of cars) {
        const brandSlug = normalizeBrandName(car.name);
        let finalCarData = car.data;
        if (car.data.startsWith('data:image/')) {
          try {
            finalCarData = await uploadCarAsset(car.data, car.name, brandSlug);
          } catch (supaErr) {
            if (isFirebaseConfigured) {
              try {
                const fileExt = car.data.split(';')[0].split('/')[1] || 'png';
                const storagePath = `cars_bank/${encodeURIComponent(car.name)}_${Date.now()}.${fileExt}`;
                finalCarData = await uploadBase64ToFirebase(car.data, storagePath);
              } catch (fbErr) {
                // Silently fallback to base64
                finalCarData = car.data;
              }
            } else {
               // Silently fallback to base64 if no firebase
               finalCarData = car.data;
            }
          }
        }

        const existingIndex = newCars.findIndex(c => c.brand_name.toLowerCase() === car.name.toLowerCase());
        const newCar = {
          id: existingIndex >= 0 ? newCars[existingIndex].id : crypto.randomUUID(),
          brand_name: car.name,
          brand_slug: brandSlug,
          logo_data: finalCarData,
          logo_type: 'png',
          created_at: existingIndex >= 0 ? newCars[existingIndex].created_at : Date.now(),
          updated_at: Date.now()
        };
        
        if (isFirebaseConfigured) {
          try {
            await saveCarPageItemToFirestore(newCar);
          } catch (err: any) {
             // Optinally warn, but do not show in UI as it is a frequent occurrence before rules are applied
          }
        }
        
        if (existingIndex >= 0) {
          newCars[existingIndex] = newCar;
        } else {
          newCars.push(newCar);
        }
      }
      
      setCarsDatabase(newCars);
      if (session) {
        try {
          await supabaseService.saveUserSettings(layout, logoOverrides, logosDatabase, newCars);
          setLastSaved(new Date());
        } catch (err: any) {
          errors.push(err.message || 'Erro ao sincronizar carros no Supabase');
        }
      }

      if (errors.length > 0) {
        setSyncError(errors.join(', '));
      }
    } finally {
      setIsSyncing(false);
    }
  };

  const updateCarNameAcrossEntries = async (oldName: string, newName: string) => {
    if (!oldName.trim() || !newName.trim() || oldName === newName) return;

    const updatedEntries = entries.map(e => e.carName === oldName ? { ...e, carName: newName } : e);
    setEntries(updatedEntries);

    const updatedCarsDb = carsDatabase.map(c => c.brand_name === oldName ? { ...c, brand_name: newName, brand_slug: normalizeBrandName(newName), updated_at: Date.now() } : c);
    setCarsDatabase(updatedCarsDb);

    const newOverrides = { ...logoOverrides };
    let overridesChanged = false;
    
    if (newOverrides[`thumb_${oldName}`]) {
      newOverrides[`thumb_${newName}`] = newOverrides[`thumb_${oldName}`];
      delete newOverrides[`thumb_${oldName}`];
      overridesChanged = true;
    }
    if (newOverrides[oldName]) {
      newOverrides[newName] = newOverrides[oldName];
      delete newOverrides[oldName];
      overridesChanged = true;
    }
    
    if (overridesChanged) {
      setLogoOverrides(newOverrides);
    }

    if (session) {
      try {
        const resolvedOverrides = overridesChanged ? newOverrides : logoOverrides;
        await supabaseService.saveAllData(tracks, updatedEntries, layout, resolvedOverrides, logosDatabase, updatedCarsDb);
        setLastSaved(new Date());
      } catch (err: any) {
        setSyncError(err.message || 'Erro ao sincronizar carros após renomeação');
      }
    }
  };

  const updateCarNameInBank = async (id: string, newName: string) => {
    const updatedCar = carsDatabase.find(c => c.id === id);
    if (!updatedCar) return;
    
    const newCar = { ...updatedCar, brand_name: newName, brand_slug: normalizeBrandName(newName), updated_at: Date.now() };

    if (isFirebaseConfigured) {
      try {
        await saveCarPageItemToFirestore(newCar);
      } catch (e) {}
    }
    
    const updated = carsDatabase.map(c => c.id === id ? newCar : c);
    setCarsDatabase(updated);
    if (session) {
      supabaseService.saveUserSettings(layout, logoOverrides, logosDatabase, updated)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao sincronizar carros'));
    }
  };

  const deleteCarFromBank = async (id: string) => {
    if (isFirebaseConfigured) {
      try {
        await deleteCarPageItemFromFirestore(id);
      } catch (e) {}
    }
    
    const filtered = carsDatabase.filter(c => c.id !== id);
    setCarsDatabase(filtered);
    if (session) {
      supabaseService.saveUserSettings(layout, logoOverrides, logosDatabase, filtered)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao sincronizar carros'));
    }
  };

  const handleDeleteAllCars = async () => {
    if (isFirebaseConfigured) {
      for (const car of carsDatabase) {
        try {
          await deleteCarPageItemFromFirestore(car.id);
        } catch (e) {}
      }
    }
    
    setCarsDatabase([]);
    if (session) {
      supabaseService.saveUserSettings(layout, logoOverrides, logosDatabase, [])
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao sincronizar carros'));
    }
  };


  // Update online status and stats every 4 minutes if logged in
  useEffect(() => {
    if (session) {
      // First update immediately
      supabaseService.updateOnlineStatus();
      supabaseService.updateUserStats(session.user.id);

      const interval = setInterval(() => {
        supabaseService.updateOnlineStatus();
      }, 4 * 60 * 1000);

      return () => clearInterval(interval);
    }
  }, [session]);

  const suggestions = useMemo(() => {
    const brands = new Set<string>();
    const carNames = new Set<string>();
    const setups = new Set<string>();
    
    // De banco de dados estático
    RAW_BRANDS.forEach(b => brands.add(b.brand_name));
    RAW_CARS.forEach(c => {
      carNames.add(c.car_name);
      if (c.brand_name) brands.add(c.brand_name);
    });

    // De carros customizados (carsDatabase)
    carsDatabase.forEach(c => {
      if (c.brand_name) carNames.add(c.brand_name);
    });

    // De entradas existentes (preferência do usuário)
    entries.forEach(e => {
      if (e.carBrand) brands.add(e.carBrand);
      if (e.carName) carNames.add(e.carName);
      if (e.carSetup) setups.add(e.carSetup);
    });
    
    return {
      brands: Array.from(brands).sort(),
      carNames: Array.from(carNames).sort(),
      setups: Array.from(setups).sort()
    };
  }, [entries, carsDatabase]);

  const updateTrack = async (id: string, updatesOrName: any, maybeLocation?: string, maybeLogo?: string | null, maybeBackground?: string | null) => {
    let updates: Partial<Track> = {};
    let logo: string | null | undefined = undefined;
    let bgImage: string | null | undefined = undefined;

    if (typeof updatesOrName === 'string') {
      // Chamada via TrackEditModal: (id, name, location, logo, background)
      updates = { name: updatesOrName, location: maybeLocation };
      logo = maybeLogo;
      bgImage = maybeBackground;
    } else {
      // Chamada via AdminPanel: (id, updates)
      updates = updatesOrName;
      logo = (updatesOrName as any).customLogo;
      bgImage = (updatesOrName as any).customBackground;
    }

    const targetTrack = tracks.find(t => t.id === id);
    const resolvedName = updates.name || targetTrack?.name || 'unknown';
    const slug = getTrackSlug({ name: resolvedName, id });

    setIsSyncing(true);
    setSyncError(null);

    // 1. Atualiza o estado LOCAL instantaneamente para atualizar a UI e salvar no localStorage
    setTracks(prev => ensureUniqueTracks(prev.map(t => t.id === id ? { ...t, ...updates } : t)));
    
    const newOverrides = { ...logoOverrides };
    if (logo !== undefined) {
      if (logo) newOverrides[`track_${slug}`] = logo;
      else delete newOverrides[`track_${slug}`];
    }
    if (bgImage !== undefined) {
      if (bgImage) newOverrides[`track_bg_${slug}`] = bgImage;
      else delete newOverrides[`track_bg_${slug}`];
    }

    const cleanedOverrides = compactOverrides(newOverrides);
    setLogoOverrides(cleanedOverrides);
    setLastSaved(new Date());
    
    // Limpa estado de erro de carregamento das novas imagens da pista, permitindo que elas carreguem novamente
    setBrokenImages(prev => {
      if (!prev[`track_${slug}`] && !prev[`track_bg_${slug}`]) return prev;
      const updated = { ...prev };
      delete updated[`track_${slug}`];
      delete updated[`track_bg_${slug}`];
      return updated;
    });

    // 2. Fecha o modal de edição imediatamente
    setEditingTrack(null);
    setIsSyncing(false);

    // 3. Sincroniza com o Supabase em segundo plano sem bloquear a interface de usuário
    if (session) {
      (async () => {
        setIsSyncing(true);
        isSyncingRef.current = true;
        try {
          let finalLogo = logo;
          let finalBg = bgImage;

          // Upload de imagens se forem Base64 locais
          if (logo?.startsWith('data:image/')) {
            finalLogo = await uploadTrackAsset(slug, 'logo', logo);
          }
          if (bgImage?.startsWith('data:image/')) {
            finalBg = await uploadTrackAsset(slug, 'background', bgImage);
          }

          // Se as URLs mudaram pós-upload, atualiza o estado local
          const finalOverrides = { ...cleanedOverrides };
          let changed = false;
          if (finalLogo !== logo && finalLogo !== undefined) {
            if (finalLogo) finalOverrides[`track_${slug}`] = finalLogo;
            else delete finalOverrides[`track_${slug}`];
            changed = true;
          }
          if (finalBg !== bgImage && finalBg !== undefined) {
            if (finalBg) finalOverrides[`track_bg_${slug}`] = finalBg;
            else delete finalOverrides[`track_bg_${slug}`];
            changed = true;
          }

          const resolvedOverrides = compactOverrides(finalOverrides);
          if (changed) {
            setLogoOverrides(resolvedOverrides);
          }

          // Salva as configurações de usuário atualizadas
          await supabaseService.saveUserSettings(layout, resolvedOverrides, logosDatabase, carsDatabase);

          // Sincroniza a definição da pista com a nuvem
          const trackToSync = tracks.find(t => t.id === id);
          const updatedTrackObj = { ...(trackToSync || {}), ...updates, id } as Track;
          if (updatedTrackObj.name) {
            await supabaseService.saveTrack(updatedTrackObj);
          }

          setLastSaved(new Date());
        } catch (err: any) {
          console.error('Background sync failed for track assets/definition:', err);
          setSyncError(err?.message || 'Erro ao sincronizar informações da pista na nuvem');
        } finally {
          setIsSyncing(false);
          isSyncingRef.current = false;
        }
      })();
    }
  };

  const handleOverrideError = (key: string) => {
    console.warn(`Imagem falhou ao carregar: ${key}. Ativando fallback local para a interface sem apagar do banco.`);
    setBrokenImages(prev => {
      if (prev[key]) return prev;
      return { ...prev, [key]: true };
    });
  };

  const normalizeBrandName = (name: string) => 
    name.toLowerCase().replace(/\s+/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, "");

  const getLogoForBrand = (brandName: string) => {
    const slug = normalizeBrandName(brandName);
    const found = logosDatabase.find(l => l.brand_slug === slug);
    return found ? found.logo_data : null;
  };

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setSyncError('Supabase configurado com URL temporária ou ausente. Use o modo local ou configure as chaves reais.');
      setIsInitializing(false);
      return;
    }
    if (!session && tracks.length === 0 && !isInitializing) {
        setTracks([{ id: 'demo-track', name: 'Tokyo Expressway - Leste no Sentido Horário', location: 'Japão' }]);
        setEntries([
        {
          id: 'demo-entry',
          trackId: 'demo-track',
          carBrand: 'Audi',
          carName: "RS 5 Turbo DTM '19",
          pilotName: 'rAd',
          position: '1st Place',
          carSetup: '',
          pitStops: '2',
          tractionControl: 'Level 2',
          fuelMap: '1',
          date: '20/03/2026',
          laps: 1,
          weather: 'Rain',
          lapTime: '01:58.076',
          totalTime: '0:20:44.176',
          transmission: 'Manual',
          peripheral: 'Controller',
          is_public: true
        }
      ]);
    }
  }, [session, tracks.length, isInitializing]);

    const authInitializedRef = useRef(false);

  useEffect(() => {
    if (authInitializedRef.current) return;
    authInitializedRef.current = true;

    const initAuth = async () => {
      try {
        setSyncError(null);
        let currentSession = null;
        try {
           const { data: { session }, error } = await supabase.auth.getSession();
           currentSession = session;
        } catch (e: any) {
           console.warn('Initial session fetch failed:', e.message);
        }
        
        setSession(currentSession);
        if (currentSession) {
          await loadSupabaseData();
        } else {
          const offlineStr = localStorage.getItem('offline_profile');
          if (offlineStr) {
            setUserProfile(JSON.parse(offlineStr));
          } else {
            setUserProfile({
              id: 'offline',
              display_name: 'Offline Driver',
              avatar_url: '',
              driver_rating: 'D',
              safety_rating: 'E'
            } as UserProfile);
          }
          setIsInitializing(false);
        }
      } catch (err: any) {
        console.warn('Initial auth initialization failed:', err.message);
        if (err.message?.toLowerCase().includes('refresh_token') || err.message?.toLowerCase().includes('not found')) {
          try { localStorage.clear(); } catch(e) {}
          try { sessionStorage.clear(); } catch(e) {}
          window.location.reload();
          return;
        }
        if (err.message?.toLowerCase().includes('fetch') || err.message?.toLowerCase().includes('network')) {
          setSyncError('O sistema está em modo OFFLINE (Problema de conexão).');
        }
        setIsInitializing(false);
      }
    };

    initAuth();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      try {
        setSession(session);
        if (session && event === 'SIGNED_IN') {
          loadSupabaseData();
        } else if (event === 'SIGNED_OUT') {
          setIsInitializing(false);
          // Clear data to prevent leakage to another account
          setTracks([]);
          setEntries([]);
          setUserProfile(null);
        }
      } catch (e: any) {
        console.warn('Auth state change handler failed:', e.message);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (homeTab === 'community') {
      fetchCommunityProfiles();
    }
  }, [homeTab]);

  const fetchCommunityProfiles = async () => {
    try {
      setLoadingCommunity(true);
      const data = await supabaseService.getAllPublicProfiles();
      setCommunityProfiles(data);
    } catch (error) {
      console.error('Error fetching public profiles:', error);
    } finally {
      setLoadingCommunity(false);
    }
  };

  const handleManualSave = async () => {
    if (!session) return;
    isSyncingRef.current = true;
    setIsSyncing(true);
    setSyncError(null);
    try {
      // Prioritize uploading any local base64 images to Firebase Storage before saving metadata to database.
      // This ensures "Red and Blue" images (and similar ones) are persisted in the cloud.
      if (isFirebaseConfigured) {
        let currentLogos = [...logosDatabase];
        let currentCars = [...carsDatabase];
        let currentOverrides = { ...logoOverrides };
        let anyUploads = false;

        // Sync Logo Bank
        const newLogos = await Promise.all(currentLogos.map(async (l: any) => {
          if (l.logo_data?.startsWith('data:image/')) {
            try {
              const fileExt = l.logo_data.split(';')[0].split('/')[1] || 'png';
              const path = `logos/${encodeURIComponent(l.brand_name)}_${Date.now()}.${fileExt}`;
              const url = await uploadBase64ToFirebase(l.logo_data, path);
              anyUploads = true;
              return { ...l, logo_data: url, updated_at: Date.now() };
            } catch (e) { return l; }
          }
          return l;
        }));
        if (anyUploads) {
          currentLogos = newLogos;
          setLogosDatabase(newLogos);
        }

        // Sync Car Bank
        const newCars = await Promise.all(currentCars.map(async (c: any) => {
          if (c.logo_data?.startsWith('data:image/')) {
            try {
              const url = await uploadCarAsset(c.logo_data, c.brand_name, c.brand_slug);
              anyUploads = true;
              return { ...c, logo_data: url, updated_at: Date.now() };
            } catch (e) { return c; }
          }
          return c;
        }));
        if (anyUploads) {
          currentCars = newCars;
          setCarsDatabase(newCars);
        }

        // Sync Overrides
        for (const [key, val] of Object.entries(currentOverrides)) {
          const valStr = val as string | null | undefined;
          if (valStr?.startsWith('data:image/')) {
            try {
              let url = valStr;
              if (key.startsWith('track_')) {
                const slug = key.replace('track_', '').replace('bg_', '');
                const type = key.includes('bg_') ? 'background' : 'logo';
                url = await uploadTrackAsset(slug, type, valStr);
              } else {
                 const path = `logos/override_${encodeURIComponent(key)}_${Date.now()}.png`;
                 url = await uploadBase64ToFirebase(valStr, path);
              }
              currentOverrides[key] = url;
              anyUploads = true;
            } catch (e) {}
          }
        }
        if (anyUploads) {
          currentOverrides = compactOverrides(currentOverrides);
          setLogoOverrides(currentOverrides);
        }

        await supabaseService.saveAllData(tracks, entries, layout, currentOverrides, currentLogos, currentCars);
      } else {
        await supabaseService.saveAllData(tracks, entries, layout, logoOverrides, logosDatabase, carsDatabase);
      }
      setLastSaved(new Date());
    } catch (err: any) {
      console.error('Manual save error:', err);
      setSyncError(err.message || 'Erro ao salvar na nuvem');
    } finally {
      setIsSyncing(false);
      isSyncingRef.current = false;
    }
  };

  const loadSupabaseData = async () => {
    if (!import.meta.env.VITE_SUPABASE_URL) return;
    if (isSyncingRef.current) return;
    
    isSyncingRef.current = true;
    setIsSyncing(true);
    setSyncError(null);
    try {
      const [fetchedTracks, fetchedEntries, settings, profile, trackAssetOverrides] = await Promise.all([
        supabaseService.getTracks(),
        supabaseService.getEntries(),
        supabaseService.getUserSettings(),
        supabaseService.getProfile(),
        getTrackAssetOverrides()
      ]);
      
      if (profile) {
        if (profile.is_admin !== true) {
          // Log out immediately if not administrator
          await supabase.auth.signOut();
          setSession(null);
          setUserProfile(null);
          setTracks([]);
          setEntries([]);
          setSyncError(language === 'pt' 
            ? 'Acesso restrito: Apenas o administrador possui permissão de acesso.' 
            : 'Restricted access: Only the administrator can log in.');
          setIsInitializing(false);
          setIsSyncing(false);
          isSyncingRef.current = false;
          setShowAuthModal(true);
          return;
        }
        setUserProfile(profile);
      }
      
      let initialTracks = ensureUniqueTracks(fetchedTracks);
      // Auto-sync missing global tracks for everyone to ensure "all registered tracks" are present.
      const fullPack = getEnhancedTrackPack();
      const existingIdsAndNames = new Set([
        ...initialTracks.map(t => t.id),
        ...initialTracks.map(t => (t.name || "").toLowerCase())
      ]);
      const toAdd = fullPack.filter(p => !existingIdsAndNames.has(p.id) && !existingIdsAndNames.has(p.name.toLowerCase()));
      if (toAdd.length > 0) {
        initialTracks = [...initialTracks, ...toAdd];
      }
      setTracks(initialTracks);
      setEntries(ensureUniqueEntries(fetchedEntries));
      
      setLogoOverrides(prev => {
        const mergedOverrides = { ...prev };
        const incomingOverrides = { ...(settings?.logo_overrides || {}), ...trackAssetOverrides };
        
        // Merge cloud items on top, overwriting any previous local base64 if a cloud URL exists.
        for (const [key, val] of Object.entries(incomingOverrides)) {
          if (val) {
             mergedOverrides[key] = val;
          }
        }
        
        const finalOverrides = compactOverrides(mergedOverrides);
        localStorage.setItem('gt7_local_logo_overrides', JSON.stringify(finalOverrides));
        return finalOverrides;
      });

      if (settings) {
        if (settings.layout) {
          setLayout({ ...DEFAULT_LAYOUT, ...settings.layout, customFields: settings.layout.customFields || [], labels: { ...DEFAULT_LAYOUT.labels, ...(settings.layout.labels || {}) } });
        } else {
          setLayout(DEFAULT_LAYOUT);
        }
        if (settings.logos_database) setLogosDatabase(settings.logos_database);
        if (settings.cars_database) setCarsDatabase(settings.cars_database);
      } else {
        setLayout(DEFAULT_LAYOUT);
      }
      
      setLastSaved(new Date());
    } catch (error: any) {
      console.error('Error loading Supabase data:', error);
      let msg = error.message || String(error);
      const lowercaseMsg = msg.toLowerCase();
      if (lowercaseMsg.includes('failed to fetch') || 
          lowercaseMsg.includes('fetch failed') || 
          lowercaseMsg.includes('network error') ||
          msg.includes('conexão')) {
         setSyncError('O sistema está em modo OFFLINE. Falha de conexão.');
      } else {
        setSyncError(msg || 'Erro na sincronização inicial.');
      }
    } finally {
      setIsSyncing(false);
      setIsInitializing(false);
      isSyncingRef.current = false;
    }
  };

  useEffect(() => {
    if (!session || !userProfile || entries.length === 0) return;
    
    // Auto-repair pilot_name for entries that don't have it (owned by current user)
    const needsRepair = entries.some(e => !e.pilot_name || e.pilot_name === '-');
    if (needsRepair) {
      const repairedEntries = entries.map(e => {
        if (!e.pilot_name || e.pilot_name === '-') {
           return { ...e, pilot_name: userProfile.display_name };
        }
        return e;
      });
      setEntries(repairedEntries);
      if (session) {
         supabaseService.saveAllData(tracks, repairedEntries, layout, logoOverrides).catch(err => console.error('Repair save failed:', err));
      }
    }
  }, [userProfile?.display_name, entries.length, !!session]);

  const [editingLogo, setEditingLogo] = useState<{ brand: string; carName: string } | null>(null);

  const pushToHistory = (currentEntries: Entry[]) => {
    setHistory(prev => [...prev.slice(-19), currentEntries]);
  };

  const undo = () => {
    if (history.length > 0) {
      const previous = history[history.length - 1];
      setEntries(previous);
      setHistory(prev => prev.slice(0, -1));
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault();
        undo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [history]);

  useEffect(() => {
    if (!session) return;
    const interval = setInterval(() => {
      loadSupabaseData();
    }, 1000 * 60 * 30); // Sincronização automática a cada 30 min
    return () => clearInterval(interval);
  }, [session]);

  const [currentTrackId, setCurrentTrackId] = useState<string | null>(null);
  const [selectedTrackForCarLogo, setSelectedTrackForCarLogo] = useState<string>('');

  useEffect(() => {
    if (isCarModalOpen) {
      setSelectedTrackForCarLogo(editingTrack?.id || currentTrackId || '');
    }
  }, [isCarModalOpen, editingTrack, currentTrackId]);

  const handleSelectCar = (car: any, trackId: string | null) => {
    if (trackId) {
      updateTrack(trackId, { customLogo: car.logo_data, customBackground: undefined });
      alert(`Miniatura atualizada para o carro selecionado!`);
      setIsCarModalOpen(false); // Close modal on success
    } else {
      alert("Selecione uma pista para editar antes de escolher a miniatura.");
    }
  };

  const handleOpenCarPreview = (car: any) => {
    setSelectedCarForPreview(car);
    setIsCarModalOpen(true);
  };

  const [trackSubView, setTrackSubView] = useState<'entries' | 'timetrial'>('entries');
  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [editingEntry, setEditingEntry] = useState<Entry | null>(null);
  const [showExitPrompt, setShowExitPrompt] = useState(false);
  const allowExitRef = useRef(false);

  // Theme state
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    if (saved) return saved === 'dark';
    return true; // Default to dark mode
  });

  useEffect(() => {
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const trackNames = useMemo(() => Array.from(new Set(TRACK_PACK.map(t => t.name))).sort(), []);
  const trackLocations = useMemo(() => Array.from(new Set(TRACK_PACK.map(t => t.location).filter(Boolean))).sort(), []);

  const [isLayoutEditorOpen, setIsLayoutEditorOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [ppFilter, setPpFilter] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'lapTime' | 'totalTime'>('lapTime');
  const [trackPromptOpen, setTrackPromptOpen] = useState(false);
  const [expandedCarGroups, setExpandedCarGroups] = useState<Record<string, boolean>>({});
  const [congratsMessage, setCongratsMessage] = useState<string | null>(null);

  useEffect(() => {
    // Reset expanded groups when track changes
    setExpandedCarGroups({});
  }, [currentTrackId]);

  // --- Derived State ---
  useEffect(() => {
    if (layout.rowOrder) {
      const standardRows = ['row1', 'row2', 'row3', 'row4', 'row5', 'row6', 'row7', 'row8', 'row9', 'row10'];
      const missingRows = standardRows.filter(r => !layout.rowOrder.includes(r));
      if (missingRows.length > 0) {
        setLayout(prev => ({
          ...prev,
          rowOrder: Array.from(new Set([...prev.rowOrder, ...missingRows]))
        }));
      }
    }
  }, [layout.rowOrder]);

  const currentTrack = useMemo(() => 
    tracks.find(t => t.id === currentTrackId), 
  [tracks, currentTrackId]);

  const currentPackData = useMemo(() => 
    currentTrack ? TRACK_PACK.find(p => p.id === currentTrack.packId || p.id === currentTrack.id || p.name.toLowerCase() === currentTrack.name.toLowerCase()) : null,
  [currentTrack]);

  const sortedTracks = useMemo(() => {
    let result = [...tracks];
    
    if (trackSearchQuery && trackSearchQuery.trim()) {
      result = result
        .map(t => ({
          item: t,
          score: Math.max(
            getSmartSearchScore(trackSearchQuery, t.name || ''),
            getSmartSearchScore(trackSearchQuery, t.location || '')
          )
        }))
        .filter(x => x.score > 0)
        .sort((a, b) => b.score - a.score) // Order by relevance
        .map(x => x.item);
    } else {
      result.sort((a, b) => {
        if (trackSortMode === 'name') {
          return (a.name || '').localeCompare(b.name || '');
        }
        
        const aCount = entries.filter(e => e.trackId === a.id).length;
        const bCount = entries.filter(e => e.trackId === b.id).length;
        
        if (bCount !== aCount) return bCount - aCount;
        return (a.name || '').localeCompare(b.name || '');
      });
    }

    return result;
  }, [tracks, entries, trackSortMode, trackSearchQuery]);


  useEffect(() => {
    if (isInitializing) return;
    const repairedTracks = ensureUniqueTracks(tracks);
    const repairedEntries = ensureUniqueEntries(entries);
    const tracksChanged = repairedTracks.some((track, index) => track.id !== tracks[index]?.id);
    const entriesChanged = repairedEntries.some((entry, index) => entry.id !== entries[index]?.id);

    if (tracksChanged) setTracks(repairedTracks);
    if (entriesChanged) setEntries(repairedEntries);
  }, [tracks, entries, isInitializing]);

  const groupedEntries = useMemo(() => {
    if (!currentTrackId) return [];
    
    let baseFiltered = entries.filter(e => e.trackId === currentTrackId);
    
    if (trackSubView === 'timetrial') {
      baseFiltered = baseFiltered.filter(e => e.provaDeTempo && e.provaDeTempo !== '' && e.provaDeTempo !== '--:--:--.---');
    }

    const filtered = baseFiltered.filter(e => {
      const matchesSearch = 
        !searchQuery || 
        searchQuery.trim() === '' || 
        getSmartSearchScore(searchQuery, e.carBrand || "") > 0 ||
        getSmartSearchScore(searchQuery, e.carName || "") > 0;
      
      if (!matchesSearch) return false;

      if (ppFilter !== null) {
        const ppField = (layout.customFields || []).find(f => f.label.toUpperCase().trim() === 'PP');
        if (ppField) {
          const val = e.customFields?.[ppField.id];
          if (!val) return false;
          const ppValue = parseInt(val.toString().replace(/[^0-9]/g, ''));
          return ppValue === ppFilter || (ppValue > ppFilter - 100 && ppValue < ppFilter + 1); // Allow small range or exact
        }
        return false;
      }

      return true;
    });

    const groups: Record<string, Entry[]> = {};
    filtered.forEach(entry => {
      if (!groups[entry.carName]) groups[entry.carName] = [];
      groups[entry.carName].push(entry);
    });

    return Object.values(groups).map(groupEntries => {
      const sortedByBest = [...groupEntries].sort((a, b) => {
        if (trackSubView === 'timetrial') {
          return parseLapTime(a.provaDeTempo || '') - parseLapTime(b.provaDeTempo || '');
        }
        const valA = sortBy === 'lapTime' ? parseLapTime(a.lapTime) : parseLapTime(a.totalTime);
        const valB = sortBy === 'lapTime' ? parseLapTime(b.lapTime) : parseLapTime(b.totalTime);
        return valA - valB;
      });
      return {
        carName: groupEntries[0].carName,
        carBrand: groupEntries[0].carBrand,
        entries: groupEntries.sort((a, b) => new Date(b.runDate).getTime() - new Date(a.runDate).getTime()),
        fastestEntry: sortedByBest[0]
      };
    }).sort((a, b) => {
      if (trackSubView === 'timetrial') {
        return parseLapTime(a.fastestEntry.provaDeTempo || '') - parseLapTime(b.fastestEntry.provaDeTempo || '');
      }
      const valA = sortBy === 'lapTime' ? parseLapTime(a.fastestEntry.lapTime) : parseLapTime(a.fastestEntry.totalTime);
      const valB = sortBy === 'lapTime' ? parseLapTime(b.fastestEntry.lapTime) : parseLapTime(b.fastestEntry.totalTime);
      return valA - valB;
    });
  }, [entries, currentTrackId, searchQuery, sortBy, ppFilter, layout.customFields, trackSubView]);

  const flatFilteredEntries = useMemo(() => {
    if (!currentTrackId) return [];

    let baseFiltered = entries.filter(e => e.trackId === currentTrackId);
    
    if (trackSubView === 'timetrial') {
      baseFiltered = baseFiltered.filter(e => e.provaDeTempo && e.provaDeTempo !== '' && e.provaDeTempo !== '--:--:--.---');
    }

    return baseFiltered
      .filter(e => {
        const matchesSearch = 
          (e.carBrand || "").toLowerCase().includes((searchQuery || "").toLowerCase()) ||
          (e.carName || "").toLowerCase().includes((searchQuery || "").toLowerCase());
        
        if (!matchesSearch) return false;

        if (ppFilter !== null) {
          const ppField = (layout.customFields || []).find(f => f.label.toUpperCase().trim() === 'PP');
          if (ppField) {
            const val = e.customFields?.[ppField.id];
            if (!val) return false;
            const ppValue = parseInt(val.toString().replace(/[^0-9]/g, ''));
            return ppValue === ppFilter || (ppValue > ppFilter - 100 && ppValue < ppFilter + 1);
          }
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (trackSubView === 'timetrial') {
          return parseLapTime(a.provaDeTempo || '') - parseLapTime(b.provaDeTempo || '');
        }
        const valA = sortBy === 'lapTime' ? parseLapTime(a.lapTime) : parseLapTime(a.totalTime);
        const valB = sortBy === 'lapTime' ? parseLapTime(b.lapTime) : parseLapTime(b.totalTime);
        return valA - valB;
      });
  }, [entries, currentTrackId, searchQuery, sortBy, ppFilter, layout.customFields, trackSubView]);

  // --- Handlers ---
  const handleUpdateProfile = async (profileUpdate: Partial<UserProfile>) => {
    try {
      const updated = { ...userProfile, ...profileUpdate } as UserProfile;
      setUserProfile(updated);

      if (!session) {
        localStorage.setItem('offline_profile', JSON.stringify(updated));
      } else {
        try {
          await supabaseService.saveProfile(updated);
        } catch (error) {
          console.error('Failed to update profile to Supabase:', error);
        }
      }
      setIsProfileOpen(false);
    } catch (error) {
      console.error('Failed to update profile locally:', error);
      throw error;
    }
  };

  const addTrack = (name: string, location: string = '', packId?: string) => {
    const newTrack: Track = { id: makeId(), name, location, packId };
    setTracks([...tracks, newTrack]);
    if (isFirebaseConfigured) {
      saveTrackToFirestore(newTrack).catch(err => console.error('Firestore saveTrack error:', err));
    }
    if (session) {
      setSyncError(null);
      supabaseService.saveTrack(newTrack)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao salvar track'));
    } else {
      setLastSaved(new Date());
    }
  };

  const deleteTrack = (id: string) => {
    const trackToDelete = tracks.find(t => t.id === id);
    if (!trackToDelete) return;

    if (!confirm(`Are you sure you want to remove this track "${trackToDelete.name}"? All entries on it will be affected.`)) return;

    setTrash(prev => ({
      ...prev,
      tracks: [trackToDelete, ...prev.tracks].slice(0, 50)
    }));

    setTracks(prev => prev.filter(t => t.id !== id));
    setEntries(prev => prev.filter(e => e.trackId !== id));
    if (currentTrackId === id) setCurrentTrackId(null);
    
    if (isFirebaseConfigured) {
      deleteTrackFromFirestore(id).catch(err => console.error('Firestore deleteTrack error:', err));
    }
    if (session) {
      setSyncError(null);
      supabaseService.deleteTrack(id)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao deletar track'));
    } else {
      setLastSaved(new Date());
    }
  };

  const saveEntry = (entryData: Omit<Entry, 'id' | 'trackId'>) => {
    pushToHistory(entries);
    let finalEntry: Entry | null = null;
    let newEntries = [...entries];
    
    // Check for PBs if trackId exists
    const trackIdToUse = editingEntry ? editingEntry.trackId : currentTrackId;
    
    if (trackIdToUse && (entryData.lapTime || entryData.totalTime)) {
      const trackEntries = entries.filter(e => e.trackId === trackIdToUse && (!editingEntry || e.id !== editingEntry.id));
      
      let isNewBestLap = false;
      let isNewBestTotal = false;

      const currentLapMs = parseLapTime(entryData.lapTime);
      const currentTotalMs = parseLapTime(entryData.totalTime);

      if (currentLapMs !== Infinity) {
        const previousLaps = trackEntries.map(e => parseLapTime(e.lapTime)).filter(t => t !== Infinity);
        if (previousLaps.length === 0 || currentLapMs < Math.min(...previousLaps)) {
          isNewBestLap = true;
        }
      }

      if (currentTotalMs !== Infinity) {
        const previousTotals = trackEntries.map(e => parseLapTime(e.totalTime)).filter(t => t !== Infinity);
        if (previousTotals.length === 0 || currentTotalMs < Math.min(...previousTotals)) {
          isNewBestTotal = true;
        }
      }

      if (isNewBestLap && isNewBestTotal) {
        setCongratsMessage('Amazing! New record for Best Lap and Total Time on this track! 🏆🏆');
        setTimeout(() => setCongratsMessage(null), 5000);
      } else if (isNewBestLap) {
        setCongratsMessage('Congratulations! New Best Lap on this track! ⏱️🔥');
        setTimeout(() => setCongratsMessage(null), 5000);
      } else if (isNewBestTotal) {
        setCongratsMessage('Excellent! New Best Total Time on this track! 🏁🚀');
        setTimeout(() => setCongratsMessage(null), 5000);
      }
    }

    if (editingEntry) {
      finalEntry = { ...editingEntry, ...entryData };
      newEntries = entries.map(e => {
        if (e.id === editingEntry.id) return finalEntry!;
        // Sync provaDeTempo for same car on same track
        if (finalEntry?.provaDeTempo && e.trackId === finalEntry.trackId && e.carName === finalEntry.carName) {
          return { ...e, provaDeTempo: finalEntry.provaDeTempo };
        }
        return e;
      });
      setEntries(newEntries);
      setEditingEntry(null);
    } else if (currentTrackId) {
      finalEntry = {
        ...entryData,
        id: makeId(),
        trackId: currentTrackId,
        is_public: entryData.is_public ?? true
      };
      
      // If new entry has trial time, update existing entries for the same car/track
      let updatedExistingEntries = entries;
      if (finalEntry.provaDeTempo) {
        updatedExistingEntries = entries.map(e => 
          (e.trackId === finalEntry!.trackId && e.carName === finalEntry!.carName)
            ? { ...e, provaDeTempo: finalEntry!.provaDeTempo } 
            : e
        );
      }
      
      newEntries = [finalEntry, ...updatedExistingEntries];
      setEntries(newEntries);
    }
    
    if (finalEntry) {
      const entriesToSave = newEntries.filter(e => {
        // We only want to save the new/edited one AND others that were modified
        if (e.id === finalEntry!.id) return true;
        // Find if this entry was one of the ones we just updated with provaDeTempo
        const originalEntry = entries.find(oe => oe.id === e.id);
        return originalEntry && originalEntry.provaDeTempo !== e.provaDeTempo;
      });

      if (isFirebaseConfigured) {
        entriesToSave.forEach(e => {
          saveEntryToFirestore(e).catch(err => console.error('Firestore saveEntry error:', err));
        });
      }
      if (session) {
        setSyncError(null);
        
        // Save using upsert for both the main and affected entries
        const savePromises = entriesToSave.map(e => supabaseService.saveEntry(e));
        
        Promise.all(savePromises)
          .then(() => setLastSaved(new Date()))
          .catch(err => setSyncError(err.message || 'Erro ao salvar entradas'));
      } else {
        setLastSaved(new Date());
      }
    }
    setIsAddingEntry(false);
  };



  useEffect(() => {
    if (session && userProfile?.is_banned) {
      alert('Seu usuário foi bloqueado pelo administrador.');
      supabase.auth.signOut();
    }
  }, [session, userProfile?.is_banned]);

  const importTrackPack = () => {
    if (userProfile?.is_admin !== true) return;
    
    const newTracks = getEnhancedTrackPack();

    setTracks(prev => {
      const existingIds = new Set(prev.map(tr => tr.id));
      const toAdd = newTracks.filter(tr => !existingIds.has(tr.id));
      return [...prev, ...toAdd];
    });
    alert(`GT7 tracks and variants processed.`);
  };

  const deduplicateData = () => {
    // Repair and clean data
    const repairItem = (item: any) => {
      if (!item.id) item.id = makeId();
      if (item.lapTime && typeof item.lapTime === 'string') {
        // Fix potential missing laptime components
        if (!item.lapTime.includes(':')) item.lapTime = '0:' + item.lapTime;
      }
      return item;
    };

    const uniqueTracks = Array.from(new Map(tracks.map(t => [t.id, repairItem(t)])).values());
    const uniqueEntries = Array.from(new Map(entries.map(e => [e.id, repairItem(e)])).values());
    
    let changed = false;
    if (uniqueTracks.length !== tracks.length) {
      setTracks(uniqueTracks);
      changed = true;
    }
    if (uniqueEntries.length !== entries.length) {
      setEntries(uniqueEntries);
      changed = true;
    }
    
    if (changed) {
      alert('Varredura Extrema Concluída: Dados duplicados removidos e campos reparados com sucesso.');
    } else {
      alert('Varredura Completa: Seus dados estão íntegros e otimizados.');
    }
  };

  const scanOrphans = () => {
    const trackIds = new Set(tracks.map(t => t.id));
    const orphans = entries.filter(e => !trackIds.has(e.trackId));
    if (orphans.length > 0) {
      if (confirm(`Found ${orphans.length} orphan entries (no track). Do you want to restore the link to a recovery track?`)) {
        const recoveryId = 'recovered_' + Date.now();
        const recoveryTrack: Track = { id: recoveryId, name: '🏁 Recovery Track', location: 'Auto' };
        setTracks(prev => [...prev, recoveryTrack]);
        setEntries(prev => prev.map(e => !trackIds.has(e.trackId) ? { ...e, trackId: recoveryId } : e));
      }
    } else {
      alert('Varredura completa: Nenhuma entrada órfã encontrada.');
    }
  };

  const clearTrash = () => {
    setTrash({ tracks: [], entries: [] });
  };

  const restoreTrash = () => {
    const trackIds = new Set(tracks.map(t => t.id));
    const entryIds = new Set(entries.map(e => e.id));
    
    const tracksToRestore = trash.tracks.filter(t => !trackIds.has(t.id));
    const entriesToRestore = trash.entries.filter(e => !entryIds.has(e.id));
    
    if (tracksToRestore.length > 0) setTracks(prev => [...prev, ...tracksToRestore]);
    if (entriesToRestore.length > 0) setEntries(prev => [...prev, ...entriesToRestore]);
    
    setTrash({ tracks: [], entries: [] });
    alert('Os dados foram restaurados da lixeira.');
  };

  const deleteEntry = (id: string) => {
    const entryToDelete = entries.find(e => e.id === id);
    if (entryToDelete) {
      setTrash(prev => ({
        ...prev,
        entries: [entryToDelete, ...prev.entries].slice(0, 100)
      }));
    }

    pushToHistory(entries);
    setEntries(entries.filter(e => e.id !== id));
    if (isFirebaseConfigured) {
      deleteEntryFromFirestore(id).catch(err => console.error('Firestore deleteEntry error:', err));
    }
    if (session) {
      setSyncError(null);
      supabaseService.deleteEntry(id)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao deletar entrada'));
    } else {
      setLastSaved(new Date());
    }
  };

  const saveLogoOverride = async (carName: string, logoFile: string) => {
    let finalLogoFile = logoFile;
    if (logoFile.startsWith('data:image/') && isFirebaseConfigured) {
      try {
        const fileExt = logoFile.split(';')[0].split('/')[1] || 'png';
        const storagePath = `logos/${encodeURIComponent(carName)}_${Date.now()}.${fileExt}`;
        finalLogoFile = await uploadBase64ToFirebase(logoFile, storagePath);
      } catch (fbErr) {
        console.warn("Failed to upload logo override to Firebase Storage (falling back to local):", fbErr);
      }
    }

    const newOverrides = { ...logoOverrides, [carName]: finalLogoFile };
    setLogoOverrides(newOverrides);
    if (session) {
      supabaseService.saveUserSettings(layout, newOverrides)
        .then(() => setLastSaved(new Date()))
        .catch(err => setSyncError(err.message || 'Erro ao salvar configuração'));
    } else {
      setLastSaved(new Date());
    }
    setEditingLogo(null);
  };

  const handleSelectCarForLink = async (carLogoData: string | null) => {
    if (!linkingForCarName) return;
    if (!carLogoData) {
      setLinkingForCarName(null);
      return;
    }
    
    try {
      setIsSyncing(true);
      if (isFirebaseConfigured) {
        try {
          const finalUrl = await uploadThumbnailDirectly(linkingForCarName, carLogoData);
          await saveThumbnailMetadataToFirestore(linkingForCarName, finalUrl);
          await saveThumbnailLocal(linkingForCarName, carLogoData);
          await saveLogoOverride(`thumb_${linkingForCarName}`, finalUrl);
        } catch (fbErr) {
          console.warn("Firebase upload failed, using local fallback:", fbErr);
          await saveThumbnailLocal(linkingForCarName, carLogoData);
          await saveLogoOverride(`thumb_${linkingForCarName}`, carLogoData);
        }
      } else {
        await saveThumbnailLocal(linkingForCarName, carLogoData);
        await saveLogoOverride(`thumb_${linkingForCarName}`, carLogoData);
      }

      // Backend backup
      try {
        await fetch('/api/upload-car-thumbnail', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: linkingForCarName,
            base64: carLogoData
          })
        });
      } catch (serverErr) {
        console.warn("Backup failed:", serverErr);
      }

      triggerThumbnailUpdate();
      setLinkingForCarName(null);
      setIsAdminViewOpen(false);
      setIsCarModalOpen(false);
      
      alert(language === 'pt' ? `Imagem vinculada com sucesso para ${linkingForCarName}!` : `Image successfully linked for ${linkingForCarName}!`);
    } catch (err) {
      console.error(err);
      alert('Erro ao vincular imagem.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);
        
        if (data.app === "GT7 Track Times" && data.version === 4) {
          // Convert from v4 format (nested entries)
          const importedTracks: Track[] = [];
          const importedEntries: Entry[] = [];
          
          data.tracks.forEach((t: any) => {
            importedTracks.push({
              id: t.id,
              name: t.name
            });
            
            if (t.entries && Array.isArray(t.entries)) {
              t.entries.forEach((entry: any) => {
                importedEntries.push({
                  id: entry.id,
                  trackId: t.id,
                  carBrand: entry.carBrand || '',
                  carName: entry.carName || '',
                  carSetup: entry.carSetup || '',
                  racePosition: entry.racePosition || '1',
                  tractionControl: entry.ctLevel || '0', // maps ctLevel to tractionControl
                  carMap: entry.carMap || '1',
                  pitStops: entry.pitStops || '0',
                  runDate: entry.runDate || new Date().toISOString().split('T')[0],
                  weather: entry.weather || 'Clear',
                  lapTime: entry.lapTime || '0:00.000',
                  totalTime: entry.totalTime || '00:00.000',
                  avgLapTime: entry.avgLapTime || '0:00.000',
                  transmission: entry.hvm === 'A' ? 'Automatic' : 'Manual',
                });
              });
            }
          });
          
          setTracks(prev => {
            const map = new Map(prev.map(t => [t.id, t]));
            ensureUniqueTracks(importedTracks).forEach(t => { if (!map.has(t.id)) map.set(t.id, t); });
            return Array.from(map.values());
          });
          setEntries(prev => {
            const map = new Map(prev.map(e => [e.id, e]));
            ensureUniqueEntries(importedEntries).forEach(e => { if (!map.has(e.id)) map.set(e.id, e); });
            return Array.from(map.values());
          });
          alert('Version v4 data successfully imported and converted!');
        } else if (data.tracks && data.entries) {
          // Current format
          setTracks(prev => {
            const map = new Map(prev.map(t => [t.id, t]));
            ensureUniqueTracks(data.tracks).forEach(t => { if (!map.has(t.id)) map.set(t.id, t); });
            return Array.from(map.values());
          });
          setEntries(prev => {
            const map = new Map(prev.map(e => [e.id, e]));
            ensureUniqueEntries(data.entries).forEach(e => { if (!map.has(e.id)) map.set(e.id, e); });
            return Array.from(map.values());
          });
          if (data.layout) {
            setLayout(prev => {
              const result = { ...prev, ...data.layout };
              result.customFields = [
                ...prev.customFields, 
                ...(data.layout.customFields || []).filter((cF: any) => !prev.customFields.some(pf => pf.id === cF.id))
              ];
              result.labels = { ...(data.layout.labels || {}), ...prev.labels };
              return result;
            });
          }
          if (data.logoOverrides) {
            setLogoOverrides(prev => {
              const merged = { ...prev };
              for (const key in data.logoOverrides) {
                if (!merged[key] && data.logoOverrides[key]) {
                  merged[key] = data.logoOverrides[key];
                }
              }
              return merged;
            });
          }
          if (data.logosDatabase) {
            setLogosDatabase(prev => {
              const map = new Map(prev.map((l: any) => [l.id, l]));
              data.logosDatabase.forEach((l: any) => { if (!map.has(l.id)) map.set(l.id, l); });
              return Array.from(map.values());
            });
          }
          if (data.carsDatabase) {
            setCarsDatabase(prev => {
              const map = new Map(prev.map((c: any) => [c.id, c]));
              data.carsDatabase.forEach((c: any) => { if (!map.has(c.id)) map.set(c.id, c); });
              return Array.from(map.values());
            });
          }
          alert('Dados importados (mesclados) com sucesso!');
        } else {
          alert('Arquivo JSON inválido ou formato não reconhecido.');
        }
      } catch (error) {
        alert('Erro ao ler o arquivo JSON.');
      }
    };
    reader.readAsText(file);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleExport = () => {
    const data = {
      tracks,
      entries,
      layout,
      logoOverrides,
      logosDatabase,
      carsDatabase
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gt7-track-times-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCreateRestorePoint = async () => {
    try {
      const data = {
        tracks,
        entries,
        layout,
        logoOverrides,
        logosDatabase,
        carsDatabase,
        timestamp: new Date().toISOString()
      };
      
      await saveLocalRestorePoint(data);
      hasChangesForBackupRef.current = false;
      alert(t('restore_point_success'));
    } catch (err) {
      console.error(err);
      alert(t('restore_point_error'));
    }
  };

  const handleApplyRestorePoint = async () => {
    try {
      const data = await getLocalRestorePoint();
      if (!data) {
        alert('Nenhum ponto de restauração encontrado no IndexedDB.');
        return;
      }
      
      if (confirm('Deseja mesclar (adicionar o que falta) os dados do Ponto de Restauração? Nenhum dado atual será apagado.')) {
        // Merge without replacing
        setTracks(prev => {
          const map = new Map(prev.map(t => [t.id, t]));
          (data.tracks || []).forEach((t: Track) => {
            if (!map.has(t.id)) map.set(t.id, t);
          });
          return Array.from(map.values());
        });

        setEntries(prev => {
          const map = new Map(prev.map(e => [e.id, e]));
          (data.entries || []).forEach((e: Entry) => {
            if (!map.has(e.id)) map.set(e.id, e);
          });
          return Array.from(map.values());
        });

        setLogoOverrides(prev => {
          const merged = { ...prev };
          const incoming = data.logoOverrides || {};
          for (const key in incoming) {
            if (!merged[key] && incoming[key]) {
              merged[key] = incoming[key];
            }
          }
          return merged;
        });

        if (data.layout) {
          setLayout(prev => {
            const result = { ...prev, ...data.layout };
            result.customFields = [
              ...prev.customFields, 
              ...(data.layout.customFields || []).filter((cF: any) => !prev.customFields.some(pf => pf.id === cF.id))
            ];
            result.labels = { ...(data.layout.labels || {}), ...prev.labels };
            return result;
          });
        }
        
        if (data.logosDatabase) {
          setLogosDatabase(prev => {
            const map = new Map(prev.map((l: any) => [l.id, l]));
            data.logosDatabase.forEach((l: any) => { if (!map.has(l.id)) map.set(l.id, l); });
            return Array.from(map.values());
          });
        }
        if (data.carsDatabase) {
          setCarsDatabase(prev => {
            const map = new Map(prev.map((c: any) => [c.id, c]));
            data.carsDatabase.forEach((c: any) => { if (!map.has(c.id)) map.set(c.id, c); });
            return Array.from(map.values());
          });
        }

        alert(t('restore_point_applied'));
      }
    } catch (err) {
      console.error(err);
      alert('Erro ao restaurar dados via IndexedDB.');
    }
  };

  const formatMs = (ms: number) => {
    if (!ms || ms <= 0) return "";
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const milliseconds = ms % 1000;
    return `${minutes}:${seconds.toString().padStart(2, '0')}.${milliseconds.toString().padStart(3, '0')}`;
  };

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // ... rest of the code

  const appBgInputRef = useRef<HTMLInputElement>(null);

  const handleAppBgUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const webp = await convertToWebP(file);
        saveLogoOverride('app_bg', webp);
      } catch (err) { console.error(err); }
    }
  };

  const renderLogo = () => (
    <div 
      className="flex flex-col py-6 px-4 cursor-pointer" 
      onClick={() => appBgInputRef.current?.click()}
    >
      <div className="flex items-center justify-end w-full">
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
            <LanguageSwitcher />
            <button 
              onClick={() => {
                if (!session) {
                  setShowAuthModal(true);
                } else {
                  setIsProfileOpen(true);
                }
              }}
              className="p-1 px-2 text-ink-secondary hover:text-accent-blue transition-all flex items-center gap-2 group"
              title="Ver Perfil"
            >
              <div className="w-8 h-8 rounded-full overflow-hidden border border-accent-light bg-bg-cell flex items-center justify-center transition-transform group-hover:scale-110">
                {userProfile?.avatar_url ? (
                  <img src={userProfile.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User size={16} className="opacity-30" />
                )}
              </div>
            </button>
          
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2 text-ink-secondary hover:text-accent-blue transition-colors"
            title="Alternar Tema"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} className="text-ink-secondary" />}
          </button>

          {userProfile?.is_admin === true && (
            <button 
              onClick={() => setIsAdminViewOpen(true)}
              className="p-2 flex items-center justify-center bg-accent-blue/10 rounded-full hover:bg-accent-blue/20 transition-all ml-1"
              title="Painel Administrativo"
            >
              <ShieldCheck size={20} className="text-accent-blue" />
            </button>
          )}

          <button 
            onClick={() => {
              if (!session) {
                setShowAuthModal(true);
              } else {
                setIsSettingsOpen(true);
              }
            }}
            className="p-2 text-ink-secondary hover:text-accent-blue transition-colors"
            title="Configurações"
          >
            <Settings size={20} />
          </button>
        </div>
      </div>
    </div>
  );

  // Reference to hold current UI states for the popstate handler
  const uiStateRef = useRef({
    isAddingEntry,
    isLayoutEditorOpen,
    isSettingsOpen,
    isProfileOpen,
    isRankingOpen,
    isAIAnalystOpen,
    editingTrack: !!editingTrack,
    editingLogo: !!editingLogo,
    trackPromptOpen,
    currentTrackId,
    showExitPrompt,
    isAdminViewOpen
  });

  useEffect(() => {
    uiStateRef.current = {
      isAddingEntry,
      isLayoutEditorOpen,
      isSettingsOpen,
      isProfileOpen,
      isRankingOpen,
      isAIAnalystOpen,
      editingTrack: !!editingTrack,
      editingLogo: !!editingLogo,
      trackPromptOpen,
      currentTrackId,
      showExitPrompt,
      isAdminViewOpen
    };
  }, [isAddingEntry, isLayoutEditorOpen, isSettingsOpen, isProfileOpen, isRankingOpen, isAIAnalystOpen, editingTrack, editingLogo, trackPromptOpen, currentTrackId, showExitPrompt, isAdminViewOpen]);

  useEffect(() => {
    // Push an initial state so we can intercept the first 'back' action
    window.history.pushState({ pwaActivity: true }, '');

    const handlePopState = (e: PopStateEvent) => {
      if (allowExitRef.current) return;

      const state = uiStateRef.current;
      let handled = false;

      // Close topmost modals/menus first
      if (state.showExitPrompt) {
        // If back is pressed while prompt is open, we let the browser exit (don't push state)
        allowExitRef.current = true;
        window.history.back();
        return;
      } else if (state.isAddingEntry) {
        setIsAddingEntry(false);
        setEditingEntry(null);
        handled = true;
      } else if (state.isLayoutEditorOpen) {
        setIsLayoutEditorOpen(false);
        handled = true;
      } else if (state.isAdminViewOpen) {
      setIsAdminViewOpen(false);
      handled = true;
    } else if (state.isSettingsOpen) {
        setIsSettingsOpen(false);
        handled = true;
      } else if (state.isProfileOpen) {
        setIsProfileOpen(false);
        handled = true;
      } else if (state.isRankingOpen) {
        setIsRankingOpen(false);
        handled = true;
      } else if (state.isAIAnalystOpen) {
        setIsAIAnalystOpen(false);
        handled = true;
      } else if (state.editingTrack) {
        setEditingTrack(null);
        handled = true;
      } else if (state.editingLogo) {
        setEditingLogo(null);
        handled = true;
      } else if (state.trackPromptOpen) {
        setTrackPromptOpen(false);
        handled = true;
      } else if (state.currentTrackId) {
        setCurrentTrackId(null);
        handled = true;
      } else {
        // If we're at the main tracking list and no modals are open, show confirm exit prompt
        setShowExitPrompt(true);
        handled = true;
      }

      if (handled) {
        // Push state again so the next back button press will be caught again
        window.history.pushState({ pwaActivity: true }, '');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  if (isInitializing) {
    return (
      <div className="min-h-screen relative flex items-center justify-center bg-[#0a0a0c] overflow-hidden">
        <CarAudioFX />
        {/* Speed lines effect - Headlights and Taillights passing in the dark */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-80 z-0">
          <div className="absolute top-[20%] left-0 w-[40%] h-[2px] bg-red-500 blur-[1px] animate-[passRight_1.2s_ease-in-out_infinite]" style={{ boxShadow: '0 0 10px 2px rgba(239,68,68,0.8)', animationDelay: '0s' }}></div>
          <div className="absolute top-[35%] left-0 w-[60%] h-[1px] bg-white blur-[1px] animate-[passLeft_0.8s_ease-in-out_infinite]" style={{ boxShadow: '0 0 8px 2px rgba(255,255,255,0.9)', animationDelay: '0.3s' }}></div>
          <div className="absolute top-[55%] left-0 w-[80%] h-[3px] bg-red-600 blur-[2px] animate-[passRight_1.5s_ease-in-out_infinite]" style={{ boxShadow: '0 0 15px 4px rgba(220,38,38,0.9)', animationDelay: '0.1s' }}></div>
          <div className="absolute top-[70%] left-0 w-[30%] h-[2px] bg-blue-300 blur-[1px] animate-[passLeft_1.1s_ease-in-out_infinite]" style={{ boxShadow: '0 0 12px 3px rgba(147,197,253,0.8)', animationDelay: '0.5s' }}></div>
          <div className="absolute top-[85%] left-0 w-[50%] h-[1px] bg-white blur-[1px] animate-[passRight_0.9s_ease-in-out_infinite]" style={{ boxShadow: '0 0 8px 1px rgba(255,255,255,0.7)', animationDelay: '0.4s' }}></div>
        </div>
        
        {/* Logo and Status */}
        <div className="relative z-10 flex flex-col items-center">
          <h1 className="text-4xl font-black italic tracking-tighter text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
            GTrace
          </h1>
          <p className="tracking-[0.4em] text-[10px] text-zinc-400 mt-3 uppercase font-mono animate-pulse">
            Inicializando Motor
          </p>
        </div>
      </div>
    );
  }

  const isOfflineMode = Boolean(syncError && syncError.includes('OFFLINE')) ;
  const hasKeys = import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY;

  if (showAuthModal && hasKeys && !session && !isOfflineMode) {
    return <Auth 
      onAuthSuccess={() => {
        setIsInitializing(true);
        setShowAuthModal(false);
      }} 
      onClose={() => setShowAuthModal(false)}
    />;
  }

  if (
    session && 
    userProfile && 
    (!userProfile.display_name || userProfile.display_name === 'Driver' || !userProfile.avatar_url) && 
    !isOfflineMode
  ) {
    return <ProfileSetupOverlay profile={userProfile} onSave={handleUpdateProfile} />;
  }

  if (isFullscreenVisual) {
    return (
      <TelemetryFullscreen
        onClose={() => setIsFullscreenVisual(false)}
        t={t}
      />
    );
  }

  return (
    <div 
      className="min-h-screen bg-bg-app pb-24 overflow-x-hidden max-w-[100vw]"
      style={logoOverrides['app_bg'] ? { backgroundImage: `url(${logoOverrides['app_bg']})`, backgroundSize: 'cover', backgroundAttachment: 'fixed', backgroundPosition: 'center' } : {}}
      onTouchStart={(e) => {
        if (e.touches.length === 2) {
          undo();
        }
      }}
    >
      <input 
        type="file" 
        accept="image/*" 
        ref={appBgInputRef} 
        onChange={handleAppBgUpload} 
        className="hidden" 
      />
      <input 
        type="file" 
        accept=".json" 
        ref={fileInputRef} 
        onChange={handleFileImport} 
        className="hidden" 
      />

      <datalist id="all-suggestions">
        {Array.from(new Set([...suggestions.brands, ...suggestions.carNames])).map((s, idx) => <option key={`all-sug-${idx}-${s}`} value={s} />)}
      </datalist>

      <datalist id="track-names-list">
        {trackNames.map((name, idx) => <option key={`track-name-opt-${idx}-${name}`} value={name} />)}
      </datalist>

      <datalist id="track-locations-list">
        {trackLocations.map((loc, idx) => <option key={`track-loc-opt-${idx}-${loc}`} value={loc} />)}
      </datalist>

      {/* Header */}
      {!currentTrackId ? (
        <header className="sticky top-0 z-30 bg-transparent border-none">
          {renderLogo()}
        </header>
      ) : (
        <header className="sticky top-0 z-30 bg-bg-card border-b border-accent-light px-4 py-2 flex items-center justify-between">
          <button 
            onClick={() => setCurrentTrackId(null)}
            className="p-1.5 -ml-1 rounded-full hover:bg-bg-app transition-colors text-ink-primary"
          >
            <ChevronLeft size={20} />
          </button>
          <div className="flex-1 px-3 min-w-0 flex items-center justify-end mr-2">
            <LanguageSwitcher />
            {lastSaved && (
              <div className="flex items-center gap-1 opacity-40 ml-2">
                 <Save size={10} className="text-ink-secondary" />
                 <span className="text-[8px] font-bold uppercase tracking-widest text-ink-secondary">
                   {session 
                     ? (language === 'pt' ? 'Backup OK' : 'Cloud OK') 
                     : (language === 'pt' ? 'Fast Save' : 'Fast Save')}
                 </span>
              </div>
            )}
          </div>
          {!session && (
            <button 
              onClick={() => setShowAuthModal(true)}
              className="px-4 py-2 bg-accent-blue text-white rounded-full text-xs font-black uppercase tracking-widest hover:bg-accent-blue/90 transition-colors"
            >
              Entrar
            </button>
          )}
          <button 
            onClick={() => {
              if (!session) {
                setShowAuthModal(true);
              } else {
                setRankingTrackId(currentTrackId);
                setIsRankingOpen(true);
              }
            }}
            className="p-2 rounded-full hover:bg-accent-light/50 active:bg-accent-light transition-colors text-ink-primary"
            title="Ver Ranking Global"
          >
            <Trophy size={18} className="text-yellow-500" />
          </button>
          <button 
            onClick={() => {
              if (!session) {
                setShowAuthModal(true);
              } else {
                setIsLayoutEditorOpen(true);
              }
            }}
            className="p-2 rounded-full hover:bg-accent-light/50 active:bg-accent-light transition-colors text-ink-primary"
          >
            <Settings size={18} strokeWidth={2.5} />
          </button>

          {userProfile?.is_admin === true && (
            <button 
              onClick={() => setIsAdminViewOpen(true)}
              className="p-2 rounded-full hover:bg-accent-blue/10 active:bg-accent-blue/20 transition-colors"
              title="Painel Administrativo"
            >
              <ShieldCheck size={18} className="text-accent-blue" />
            </button>
          )}
        </header>
      )}

      <main className="max-w-md mx-auto px-4 pt-6">
        <AnimatePresence mode="wait">
          {editingTrack && (
            <TrackEditModal 
              track={editingTrack}
              currentLogo={logoOverrides[`track_${getTrackSlug(editingTrack)}`]}
              currentBackground={logoOverrides[`track_bg_${getTrackSlug(editingTrack)}`]}
              onSave={updateTrack}
              onDelete={deleteTrack}
              onClose={() => setEditingTrack(null)}
              session={session}
              setShowAuthModal={setShowAuthModal}
            />
          )}
          {!currentTrackId ? (
            <motion.div 
              key="track-list"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              {/* Search Bar */}
              <div className="relative group">
                <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-secondary group-focus-within:text-accent-blue transition-colors" />
                <input 
                  type="text"
                  placeholder={t('search_tracks')}
                  value={trackSearchQuery}
                  onChange={(e) => setTrackSearchQuery(e.target.value)}
                  className="w-full h-11 pl-10 pr-4 bg-white dark:bg-bg-card border border-accent-light rounded-[16px] text-[12px] font-bold text-ink-primary focus:ring-4 focus:ring-accent-blue/10 focus:border-accent-blue transition-all outline-none shadow-sm placeholder:text-ink-secondary/40"
                />
                {trackSearchQuery && (
                  <button 
                    onClick={() => setTrackSearchQuery('')}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1.5 text-ink-secondary hover:text-ink-primary rounded-full hover:bg-black/5 dark:hover:bg-white/5"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between gap-1 sm:gap-2 pb-2 px-0 sm:px-0 sm:pb-0 w-full max-w-full">
                <div className="flex items-center gap-1 sm:gap-2 shrink-1 min-w-0">
                  {/* Tabs selection: Personal vs Community */}
                  <div className="flex items-center p-0.5 bg-white dark:bg-bg-card border border-accent-light rounded-[12px] sm:rounded-[16px] xl:rounded-[22px] shadow-sm shrink-1 min-w-0">
                    <button
                      onClick={() => setHomeTab('personal')}
                      className={`px-2 sm:px-3 py-1.5 sm:py-2 rounded-[10px] xl:rounded-[18px] text-[7.5px] sm:text-[9.5px] font-black uppercase tracking-wider transition-all duration-200 truncate ${
                        homeTab === 'personal' 
                          ? 'bg-accent-blue text-white shadow-md' 
                          : 'text-ink-secondary hover:text-ink-primary'
                      }`}
                    >
                      {t('my_tracks')}
                    </button>
                    <button
                      onClick={() => {
                        if (!session) {
                          setShowAuthModal(true);
                        } else {
                          setHomeTab('community');
                        }
                      }}
                      className={`px-2 sm:px-3 py-1.5 sm:py-2 rounded-[10px] xl:rounded-[18px] text-[7.5px] sm:text-[9.5px] font-black uppercase tracking-wider transition-all duration-200 truncate ${
                        homeTab === 'community' 
                          ? 'bg-accent-blue text-white shadow-md' 
                          : 'text-ink-secondary hover:text-ink-primary'
                      }`}
                    >
                      {t('community_tracks')}
                    </button>
                    <button
                      onClick={() => setHomeTab('telemetry')}
                      className={`px-2 sm:px-3 py-1.5 sm:py-2 rounded-[10px] xl:rounded-[18px] text-[7.5px] sm:text-[9.5px] font-black uppercase tracking-wider transition-all duration-200 truncate ${
                        homeTab === 'telemetry' 
                          ? 'bg-accent-blue text-white shadow-md' 
                          : 'text-ink-secondary hover:text-ink-primary'
                      }`}
                    >
                      Telemetria
                    </button>
                    <button
                      onClick={() => setHomeTab('roadmap')}
                      className={`px-2 sm:px-3 py-1.5 sm:py-2 rounded-[10px] xl:rounded-[18px] text-[7.5px] sm:text-[9.5px] font-black uppercase tracking-wider transition-all duration-200 truncate ${
                        homeTab === 'roadmap' 
                          ? 'bg-accent-blue text-white shadow-md' 
                          : 'text-ink-secondary hover:text-ink-primary'
                      }`}
                    >
                      Roadmap
                    </button>
                  </div>
                  
                  {homeTab === 'personal' && (
                    <>
                      {/* Sorting Controls */}
                      <div className="flex items-center h-8 sm:h-10 bg-white dark:bg-bg-card rounded-[10px] sm:rounded-[14px] p-0.5 sm:p-1 gap-0.5 border border-accent-light shadow-sm shrink-0">
                        <button 
                          onClick={() => setTrackSortMode('records')}
                          className={`w-7 sm:w-9 h-full rounded-[8px] sm:rounded-[10px] flex items-center justify-center transition-all ${
                            trackSortMode === 'records' 
                              ? 'bg-zinc-800 text-white shadow-sm' 
                              : 'text-ink-secondary hover:bg-black/5 dark:hover:bg-white/5'
                          }`}
                          title={t('sort_by_records')}
                        >
                          <BarChart size={12} className="sm:scale-100" />
                        </button>
                        <button 
                          onClick={() => setTrackSortMode('name')}
                          className={`w-7 sm:w-9 h-full rounded-[8px] sm:rounded-[10px] flex items-center justify-center transition-all ${
                            trackSortMode === 'name' 
                              ? 'bg-zinc-800 text-white shadow-sm' 
                              : 'text-ink-secondary hover:bg-black/5 dark:hover:bg-white/5'
                          }`}
                          title={t('sort_alphabetical')}
                        >
                          <span className="text-[8px] sm:text-[10px] font-black italic">AZ</span>
                        </button>
                      </div>

                      {/* View Mode Controls */}
                      <div className="flex items-center h-8 sm:h-10 bg-white dark:bg-bg-card rounded-[10px] sm:rounded-[14px] p-0.5 sm:p-1 gap-0.5 border border-accent-light shadow-sm shrink-0">
                        <button 
                          onClick={() => setHomeViewMode('card')}
                          className={`w-7 sm:w-9 h-full rounded-[8px] sm:rounded-[10px] flex items-center justify-center transition-all ${
                            homeViewMode === 'card' 
                              ? 'bg-zinc-800 text-white shadow-sm' 
                              : 'text-ink-secondary hover:bg-black/5 dark:hover:bg-white/5'
                          }`}
                          title={t('card_view')}
                        >
                          <Layout size={12} className="sm:scale-100" />
                        </button>
                        <button 
                          onClick={() => setHomeViewMode('list')}
                          className={`w-7 sm:w-9 h-full rounded-[8px] sm:rounded-[10px] flex items-center justify-center transition-all ${
                            homeViewMode === 'list' 
                              ? 'bg-zinc-800 text-white shadow-sm' 
                              : 'text-ink-secondary hover:bg-black/5 dark:hover:bg-white/5'
                          }`}
                          title={t('list_view')}
                        >
                          <List size={12} className="sm:scale-100" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
                
                {homeTab === 'personal' && (
                  <button 
                    onClick={() => {
                      if (!session) {
                        setShowAuthModal(true);
                      } else {
                        setTrackPromptOpen(true);
                      }
                    }}
                    className="h-7 sm:h-10 text-[7.5px] sm:text-[10px] font-black uppercase tracking-widest text-white bg-accent-blue px-2 sm:px-4 rounded-[10px] sm:rounded-[12px] shadow-md hover:bg-accent-blue/90 active:scale-95 transition-all duration-200 flex items-center justify-center gap-0.5 shrink-0"
                  >
                    <span>+</span> {t('new_track')}
                  </button>
                )}
              </div>
              
              {homeTab === 'telemetry' ? (
                <LiveTelemetry />
              ) : homeTab === 'roadmap' ? (
                <RoadmapView />
              ) : homeTab === 'personal' ? (
                <>
                  {sortedTracks.length === 0 ? (
                    <div className="py-12 flex flex-col items-center justify-center text-center px-6 bg-white dark:bg-bg-card rounded-[24px] border border-accent-light shadow-sm">
                      <div className="w-16 h-16 bg-accent-blue/5 rounded-full flex items-center justify-center mb-4">
                        <Search size={32} className="text-accent-blue opacity-50" />
                      </div>
                      <h3 className="text-sm font-black uppercase tracking-widest text-ink-primary mb-2">
                        {t('no_tracks_found')}
                      </h3>
                      <p className="text-[11px] font-medium text-ink-secondary leading-relaxed opacity-60 max-w-[200px]">
                        {t('adjust_filters_desc')}
                      </p>
                      {trackSearchQuery && (
                        <button 
                          onClick={() => setTrackSearchQuery('')}
                          className="mt-6 px-6 py-2 bg-accent-blue text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg shadow-accent-blue/20 hover:bg-accent-blue/90 transition-all active:scale-95"
                        >
                          {t('clear')}
                        </button>
                      )}
                    </div>
                  ) : homeViewMode === 'list' ? (
                <div className="bg-bg-card rounded-[12px] border border-accent-light overflow-hidden divide-y divide-accent-light/30 shadow-sm">
                  {sortedTracks.map((track, trackIndex) => {
                    const packData = TRACK_PACK.find(p => p.id === track.packId || p.id === track.id);
                    const recordCount = entries.filter(e => e.trackId === track.id).length;
                    const customBg = brokenImages[`track_bg_${getTrackSlug(track)}`] ? undefined : logoOverrides[`track_bg_${getTrackSlug(track)}`];
                    
                    return (
                      <div 
                        key={`track-list-${track.id}-${trackIndex}`} 
                        className="p-3.5 px-4 flex items-center justify-between hover:bg-accent-blue/5 transition-all cursor-pointer group active:scale-[0.99] relative overflow-hidden min-h-[64px]"
                        onClick={() => setCurrentTrackId(track.id)}
                      >
                        {customBg && (
                          <div className="absolute inset-0 z-0 pointer-events-none">
                            <img 
                              src={customBg} 
                              alt="" 
                              onError={() => handleOverrideError(`track_bg_${getTrackSlug(track)}`)}
                              className="w-full h-full object-cover opacity-90 transition-transform duration-700 group-hover:scale-105" 
                            />
                            <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/75" />
                          </div>
                        )}
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="flex flex-col gap-1 w-full pr-2">
                            <div className="flex items-start gap-2">
                              <span className="text-[12px] shrink-0 mt-0.5 leading-none filter drop-shadow">{getCountryFlagFromTrack(track)}</span>
                              <h5 className={`text-[12px] font-black uppercase tracking-tight leading-tight transition-colors ${customBg ? 'text-white drop-shadow' : 'text-ink-primary group-hover:text-accent-blue'}`}>
                                {track.name}
                              </h5>
                            </div>
                            <div className="flex items-center gap-2 ml-[19px] flex-nowrap overflow-hidden">
                              <span className={`text-[8px] font-black uppercase tracking-widest whitespace-nowrap shrink-0 ${customBg ? 'text-zinc-300' : 'text-ink-secondary opacity-60'}`}>{recordCount} {recordCount === 1 ? t('record_count') : t('records_count')}</span>
                              {packData && (
                                <span className={`text-[8px] shrink-0 font-bold uppercase tracking-widest px-1.5 py-0.5 rounded-full border whitespace-nowrap truncate ${customBg ? 'bg-white/10 border-white/20 text-white' : 'text-accent-blue/80 bg-accent-blue/5 border-accent-blue/10'}`}>
                                  {packData.category}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 relative z-10">
                          <div className={`text-right flex flex-col items-end gap-0.5 px-2.5 py-1 rounded-xl border ${customBg ? 'bg-white/10 border-white/20' : 'bg-accent-blue/5 border-accent-blue/10'}`}>
                            <div className={`text-[12px] font-black font-mono tracking-tighter leading-none ${customBg ? 'text-white' : 'text-accent-blue'}`}>
                              {recordCount}
                            </div>
                            <div className={`text-[7px] font-black uppercase tracking-[0.2em] flex items-center gap-1 ${customBg ? 'text-zinc-300' : 'text-accent-blue/60'}`}>
                              {recordCount === 1 ? t('record_count') : t('records_count')}
                            </div>
                          </div>

                          <button onClick={(e) => { 
                            e.stopPropagation(); 
                            if (!session) {
                              setShowAuthModal(true);
                            } else {
                              setEditingTrack(track); 
                            }
                          }} className={`p-2 transition-colors ${customBg ? 'text-zinc-300 hover:text-white' : 'text-ink-secondary hover:text-accent-blue'}`}><Settings size={18}/></button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="-mx-4 sm:mx-0 grid grid-cols-1 gap-1.5 p-0">
                  {sortedTracks.map((track, trackIndex) => {
                    const packData = TRACK_PACK.find(p => p.id === track.packId || p.id === track.id);
                    const customBg = brokenImages[`track_bg_${getTrackSlug(track)}`] ? undefined : logoOverrides[`track_bg_${getTrackSlug(track)}`];
                    const customMinimap = brokenImages[`track_${getTrackSlug(track)}`] ? undefined : logoOverrides[`track_${getTrackSlug(track)}`];
                    
                    // Calc Best Entry for this track
                    const trackEntries = entries.filter(e => e.trackId === track.id);
                    const bestEntry = trackEntries.length > 0
                      ? [...trackEntries]
                          .filter(e => e.lapTime && e.lapTime !== '0:00.000' && e.lapTime !== '00:00.000')
                          .sort((a, b) => parseLapTime(a.lapTime) - parseLapTime(b.lapTime))[0]
                      : null;
                      
                    const recordCount = trackEntries.length;
                    const isTokyo = track.name.toLowerCase().includes('tokyo');
                    
                    return (
                       <div
                        key={`track-card-${track.id}-${trackIndex}`}
                        onClick={() => setCurrentTrackId(track.id)}
                        className="w-full text-left rounded-none sm:rounded-[20px] min-h-[150px] sm:min-h-[165px] flex flex-col justify-between p-5 px-6 group cursor-pointer relative overflow-hidden transition-all duration-300 shadow-xl hover:shadow-2xl hover:-translate-y-0.5 bg-[#12151c] border-y sm:border border-white/[0.08]"
                      >
                        {/* Custom Background Image / Overlay - No filters/gradients to keep image fully clear */}
                        {customBg ? (
                          <div className="absolute inset-0 z-0 pointer-events-none">
                            <img 
                              src={customBg} 
                              alt="" 
                              onError={() => handleOverrideError(`track_bg_${getTrackSlug(track)}`)}
                              className="w-full h-full object-cover opacity-100 transition-transform duration-[1000ms] group-hover:scale-[1.03]" 
                            />
                            {/* Linear dark overlay mask to slightly shade the image background without hidden filters */}
                            <div className="absolute inset-0 bg-black/45" />
                          </div>
                        ) : (
                          /* Carbon mesh fallback pattern */
                          <div className="absolute inset-0 z-0 pointer-events-none opacity-40 bg-gradient-to-br from-[#1b202e] to-[#0e1116]" />
                        )}
                        
                        {/* Interactive glow effect on hover */}
                        <div className="absolute -inset-px rounded-none sm:rounded-[20px] bg-gradient-to-r from-accent-blue/0 via-accent-blue/15 to-accent-blue/0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 duration-500" />
                        
                        {/* Top Left Area - Flag + Name + Records count */}
                        <div className="flex justify-between items-start relative z-10 w-full">
                          <div className="flex flex-col gap-1.5 max-w-[55%]">
                            <div className="flex items-center gap-2.5">
                              <div className="w-10 h-6.5 rounded-md select-none shrink-0 shadow-md border border-white/20 bg-black/45 flex items-center justify-center text-lg overflow-hidden leading-none pb-0.5">
                                {getCountryFlagFromTrack(track)}
                              </div>
                              <h4 className="font-black tracking-tight leading-tight text-white text-[15px] sm:text-[18px] uppercase italic [text-shadow:_0_2px_8px_rgba(0,0,0,1),_0_2px_4px_rgba(0,0,0,1)]">
                                {track.name}
                              </h4>
                            </div>
                            
                            <div className="flex items-center gap-2 mt-1 px-0.5">
                              <span className="text-[9.5px] font-black uppercase tracking-widest text-white bg-black/60 px-2 py-0.5 rounded border border-white/20 [text-shadow:_0_1.5px_3px_rgba(0,0,0,1)]">
                                {recordCount} {recordCount === 1 ? t('record_count') : t('records_count')}
                              </span>
                              {packData && (
                                <span className="text-[8.5px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-white/25 border border-white/20 text-white [text-shadow:_0_1.5px_3px_rgba(0,0,0,1)]">
                                  {packData.category}
                                </span>
                              )}
                            </div>
                          </div>
                          
                          {/* Top Right Area - Wireframe Track Map (miniature map) next to action buttons */}
                          {customMinimap ? (
                            <div className="absolute -right-8 sm:-right-12 top-1/2 -translate-y-1/2 flex items-center justify-end z-20 pointer-events-none h-[140%] sm:h-[160%] w-[65%] sm:w-[60%]">
                              <img 
                                src={customMinimap} 
                                alt="Circuit miniature map" 
                                onError={() => handleOverrideError(`track_${getTrackSlug(track)}`)}
                                className={`w-full h-full object-contain object-right filter brightness-[1.3] drop-shadow-[0_2px_10px_rgba(0,0,0,1)] transition-transform duration-700 ${isTokyo ? 'scale-[0.80] origin-right group-hover:scale-[0.85]' : 'group-hover:scale-105'} `} 
                              />
                            </div>
                          ) : packData ? (
                            <div className="absolute -right-4 sm:-right-8 top-1/2 -translate-y-1/2 flex items-center justify-end z-20 opacity-30 pointer-events-none h-[100%] w-[55%] group-hover:opacity-50 transition-opacity">
                              <svg viewBox={packData.svgViewBox} className="w-full h-full stroke-white fill-none stroke-[2] drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)]">
                                <path d={packData.svgVariants?.outline_thick || packData.svgPath} />
                              </svg>
                            </div>
                          ) : (
                            /* Symmetrical placeholder to maintain UI integrity if no logo uploaded */
                            <div className="absolute right-0 top-1/2 -translate-y-1/2 flex items-center justify-end z-20 opacity-20 pointer-events-none h-full w-[45%]">
                              <span className="text-4xl [text-shadow:_0_2px_6px_rgba(0,0,0,1)] pr-6">🏁</span>
                            </div>
                          )}
                        </div>
                        
                        {/* Bottom Area - Best Lap on top, Car details on bottom Left, Action buttons on Right */}
                        <div className="flex items-end justify-between w-full mt-3 relative z-10 pt-1.5 border-t border-white/[0.12]">
                          {/* Best Lap and Car details stacked vertically */}
                          <div className="flex flex-col gap-0.5 justify-end min-w-0 max-w-[60%]">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[7.5px] font-black uppercase tracking-wider text-white bg-black/55 border border-white/35 px-1.5 py-0.5 rounded leading-none shrink-0 [text-shadow:_0_1.5px_3px_rgba(0,0,0,1)]">
                                BEST LAP
                              </span>
                              <span className="text-[12px] font-mono font-black text-white px-0.5 leading-none [text-shadow:_0_2.5px_6px_rgba(0,0,0,1)] flex items-center gap-1">
                                {bestEntry ? bestEntry.lapTime : '--:--.---'}
                                {bestEntry && <PeripheralIcon peripheral={bestEntry.peripheral} size={10} className="opacity-80" />}
                              </span>
                            </div>
                            
                            <p className="text-[10px] font-extrabold text-white truncate leading-tight mt-0.5 [text-shadow:_0_2px_6px_rgba(0,0,0,1)] min-h-[14px]" title={bestEntry ? `${bestEntry.carBrand} ${bestEntry.carName}` : ''}>
                              {bestEntry ? `${bestEntry.carBrand} ${bestEntry.carName}` : t('no_records')}
                            </p>
                          </div>
                          
                          {/* Right side Action Buttons (Bottom Right) */}
                          <div className="flex items-center gap-1.5 pl-2 shrink-0 z-30">

                            <button 
                              onClick={(e) => { 
                                e.stopPropagation(); 
                                if (!session) {
                                  setShowAuthModal(true);
                                } else {
                                  setEditingTrack(track); 
                                }
                              }} 
                              className="p-2 rounded-xl bg-black/60 border border-white/25 hover:bg-black/80 text-white transition-all active:scale-95 shadow-lg backdrop-blur-md"
                              title="Configurações da Pista"
                            >
                              <Settings size={15} />
                            </button>
                            
                            <div className="p-2 rounded-xl bg-white text-black hover:bg-zinc-200 transition-all duration-300 active:scale-95 shadow-lg flex items-center justify-center">
                              <ChevronLeft className="rotate-180 transition-transform duration-350 group-hover:translate-x-0.5" size={15} />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          ) : (
            <div className="space-y-6">
              {selectedPublicProfileId ? (
                <div className="space-y-4">
                  <button 
                    onClick={() => setSelectedPublicProfileId(null)}
                    className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-accent-blue mb-2 hover:opacity-70 transition-opacity"
                  >
                    <ChevronLeft size={16} /> Back to Ranking
                  </button>
                  
                  <div className="bg-bg-card rounded-[32px] border border-accent-light shadow-sm relative">
                    <PublicProfileView userId={selectedPublicProfileId} />
                  </div>
                </div>
              ) : (
                <div className="space-y-8">
                  {/* Ranking Header Image Match */}
                  <div className="bg-bg-card rounded-[40px] p-8 border border-accent-light shadow-xl flex items-center gap-6 relative group">
                    <div className="p-5 bg-ink-primary rounded-[28px] text-bg-app relative z-10 shadow-2xl group-hover:scale-110 transition-transform">
                      <Trophy size={32} />
                    </div>
                    <div className="relative z-10">
                      <h2 className="text-3xl font-black uppercase tracking-tight text-ink-primary leading-none flex items-center gap-3">
                        RANKING CENTRAL
                      </h2>
                      <p className="text-[11px] font-black uppercase tracking-[0.3em] text-ink-secondary mt-3 opacity-50">COMMUNITY TOP DRIVERS</p>
                    </div>
                    
                    {/* Abstract Shapes */}
                    <div className="absolute top-0 right-0 p-12 opacity-[0.02] rotate-12 group-hover:rotate-45 transition-all duration-1000">
                      <Trophy size={200} />
                    </div>
                  </div>

                  <PilotRankingList onSelectPilot={setSelectedPublicProfileId} />
                </div>
              )}
            </div>
          )}
            </motion.div>
          ) : (
            <motion.div 
              key="entry-list"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-4"
            >
              {/* Track Name Header */}
              {currentTrack && !brokenImages[`track_bg_${getTrackSlug(currentTrack)}`] && logoOverrides[`track_bg_${getTrackSlug(currentTrack)}`] ? (
                <div className="relative overflow-hidden bg-bg-card rounded-[18px] border border-accent-light p-6 py-8 shadow-xl flex flex-col gap-1 group transition-all duration-300 hover:shadow-2xl">
                  <div className="absolute inset-0 z-0 pointer-events-none">
                    <img 
                      src={logoOverrides[`track_bg_${getTrackSlug(currentTrack)}`]} 
                      alt="" 
                      onError={() => handleOverrideError(`track_bg_${getTrackSlug(currentTrack)}`)}
                      className="w-full h-full object-cover opacity-90 transition-transform duration-700 group-hover:scale-105" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/75" />
                  </div>
                  <div className="flex items-center justify-between relative z-10">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl filter drop-shadow leading-none shrink-0">{getCountryFlagFromTrack(currentTrack)}</span>
                      <h2 className="text-xl font-black italic text-white leading-tight break-words drop-shadow-md">{currentTrack.name}</h2>
                    </div>
                    <button 
                      onClick={() => setEditingTrack(currentTrack)}
                      className="p-2.5 text-zinc-300 hover:text-white bg-white/10 backdrop-blur-sm border border-white/20 rounded-[20px] shadow-sm transition-all active:scale-95"
                      title="Edit Track"
                    >
                      <Settings size={20} />
                    </button>
                  </div>
                  {currentTrack.location && (
                    <p className="text-[10px] font-black uppercase tracking-widest text-zinc-300 ml-[36px] relative z-10 font-mono drop-shadow">
                      {currentTrack.location}
                    </p>
                  )}
                </div>
              ) : (
                <div className={`relative overflow-hidden bg-bg-card rounded-[18px] border border-accent-light p-6 py-6 shadow-xl flex flex-col gap-1 group transition-all duration-300 hover:shadow-2xl ${currentPackData ? 'min-h-[120px]' : ''}`}>
                   {currentPackData && (
                    <div className="absolute -right-8 top-1/2 -translate-y-1/2 opacity-[0.08] pointer-events-none w-[60%] h-[120%] z-0">
                      <svg viewBox={currentPackData.svgViewBox} className="w-full h-full stroke-ink-primary fill-none stroke-[3] drop-shadow-xl">
                        <path d={currentPackData.svgVariants?.outline_thick || currentPackData.svgPath} />
                      </svg>
                    </div>
                  )}
                  <div className="flex items-center justify-between relative z-10">
                    <div className="flex items-center gap-3">
                      <span className="text-xl filter drop-shadow-sm shrink-0">{getCountryFlagFromTrack(currentTrack)}</span>
                      <h2 className="text-lg font-black italic text-ink-primary leading-tight break-words">{currentTrack?.name}</h2>
                    </div>
                    <button 
                      onClick={() => setEditingTrack(currentTrack!)}
                      className="p-2.5 text-ink-secondary hover:text-accent-blue bg-white/50 backdrop-blur-sm border border-accent-light rounded-[20px] shadow-sm transition-all active:scale-95"
                      title="Edit Track"
                    >
                      <Settings size={20} />
                    </button>
                  </div>
                  {currentTrack?.location && (
                    <p className="text-[10px] font-bold uppercase tracking-widest text-ink-secondary ml-10 opacity-60 relative z-10">
                      {currentTrack.location}
                    </p>
                  )}
                </div>
              )}

              {/* Sub-navigation Tabs */}
              <div className="flex p-1 bg-bg-card border border-accent-light rounded-2xl gap-1 shrink-0">
                <button 
                  onClick={() => setTrackSubView('entries')}
                  className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 ${trackSubView === 'entries' ? 'bg-ink-primary text-bg-app shadow-md' : 'text-ink-secondary hover:bg-accent-light'}`}
                >
                  <History size={12} />
                  {t('records')}
                </button>
                <button 
                  onClick={() => setTrackSubView('timetrial')}
                  className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 ${trackSubView === 'timetrial' ? 'bg-accent-blue text-white shadow-md' : 'text-ink-secondary hover:bg-accent-light'}`}
                >
                  <Clock size={12} />
                  {t('time_trial')}
                </button>
              </div>

              {/* Search & Filter */}
              <div className="space-y-3">
                <div className="bg-bg-card p-2 rounded-[24px] shadow-sm border border-accent-light flex items-center gap-2">
                  <Search className="text-ink-secondary opacity-30 ml-2" size={16} />
                  <input 
                    type="text"
                    list="all-suggestions"
                    placeholder={t('search')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1 bg-transparent text-sm font-black focus:outline-none text-ink-primary placeholder:text-ink-secondary/30 h-8"
                  />
                </div>
                
                <div className="squircle-container flex-col h-auto gap-2 py-2">
                  <div className="flex items-center gap-1 w-full overflow-x-auto no-scrollbar">
                    <div className="flex items-center h-10 bg-white dark:bg-bg-card rounded-[22px] p-1 gap-1 border border-accent-light shrink-0 shadow-sm">
                      <button 
                        onClick={() => setViewMode('card')}
                        className={`w-9 h-full squircle-tab flex items-center justify-center ${viewMode === 'card' ? 'squircle-tab-active' : 'squircle-tab-inactive'}`}
                        title="Card View"
                      >
                        <Layout size={16} />
                      </button>
                      <button 
                        onClick={() => setViewMode('list')}
                        className={`w-9 h-full squircle-tab flex items-center justify-center ${viewMode === 'list' ? 'squircle-tab-active' : 'squircle-tab-inactive'}`}
                        title="List View"
                      >
                        <List size={16} />
                      </button>
                    </div>

                    <div className="flex items-center gap-1 h-10 bg-white dark:bg-bg-card rounded-[22px] p-1 border border-accent-light shrink-0 flex-1 justify-center shadow-sm">
                      <button 
                        onClick={() => setPpFilter(null)}
                        className={`squircle-tab h-full text-[9px] ${ppFilter === null ? 'squircle-tab-active' : 'squircle-tab-inactive'}`}
                      >
                        {t('all')}
                      </button>
                      {[600, 700, 800, 900].map(pp => (
                        <button 
                          key={pp}
                          onClick={() => setPpFilter(ppFilter === pp ? null : pp)}
                          className={`squircle-tab h-full text-[9px] px-2.5 ${ppFilter === pp ? 'squircle-tab-active' : 'squircle-tab-inactive'}`}
                        >
                          {pp}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 w-full">
                    <div className="flex-1 flex gap-1 h-10 bg-white dark:bg-bg-card rounded-[22px] p-1 border border-accent-light shadow-sm">
                      <button 
                        onClick={() => setSortBy('lapTime')}
                        className={`flex-1 h-full squircle-tab text-[9px] flex items-center justify-center gap-1.5 ${sortBy === 'lapTime' ? 'squircle-tab-active' : 'squircle-tab-inactive'}`}
                      >
                        <Clock size={12} />
                        <span className="truncate">LAP</span>
                      </button>
                      <button 
                        onClick={() => setSortBy('totalTime')}
                        className={`flex-1 h-full squircle-tab text-[9px] flex items-center justify-center gap-1.5 ${sortBy === 'totalTime' ? 'squircle-tab-active' : 'squircle-tab-inactive'}`}
                      >
                        <Trophy size={12} />
                        <span className="truncate">TOTAL</span>
                      </button>
                    </div>

                    <button 
                      onClick={() => {
                        if (!session) {
                          setShowAuthModal(true);
                        } else {
                          setIsAIAnalystOpen(true);
                        }
                      }}
                      className={`w-12 h-10 squircle-tab flex items-center justify-center group shrink-0 ${isAIAnalystOpen ? 'squircle-tab-active' : 'squircle-tab-inactive bg-white dark:bg-bg-card border border-accent-light shadow-sm'}`}
                    >
                      <Sparkles size={16} className={`transition-all ${isAIAnalystOpen ? 'text-white' : 'text-accent-blue/60 group-hover:text-accent-blue'}`} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Entries */}
              <div className="space-y-4">
                {groupedEntries.length === 0 ? (
                  <div className="py-20 text-center">
                    <div className="w-12 h-12 bg-accent-light rounded-full flex items-center justify-center mx-auto mb-4">
                      <Car className="text-ink-secondary opacity-40" size={24} />
                    </div>
                    <p className="text-ink-secondary text-xs font-bold uppercase tracking-widest">
                      {trackSubView === 'timetrial' ? t('no_time_trial') : t('no_records')}
                    </p>
                  </div>
                ) : trackSubView === 'timetrial' ? (
                  <div className="space-y-4">
                    {/* Time Trial Specialized View */}
                    <div className="bg-accent-blue/5 border border-accent-blue/10 rounded-[32px] p-6 mb-4">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-accent-blue text-white rounded-xl shadow-lg">
                          <Trophy size={16} />
                        </div>
                        <div>
                          <h3 className="text-sm font-black uppercase tracking-tight text-ink-primary">{t('time_trial_ranking')}</h3>
                          <p className="text-[9px] font-black uppercase tracking-widest text-accent-blue opacity-70">{t('best_laps_recorded')}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid gap-1.5 p-1">
                      {(viewMode === 'list' ? flatFilteredEntries : groupedEntries).map((item, idx) => {
                        const entry = 'fastestEntry' in item ? item.fastestEntry : item;
                        return (
                          <motion.div 
                            key={`tt-${entry.trackId}-${entry.id}-${normalizeNameForMatching(entry.carName)}-${idx}`}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            onClick={() => {
                              setEditingEntry(entry);
                              setIsAddingEntry(true);
                            }}
                            className="bg-bg-card border border-accent-light p-2.5 px-3.5 rounded-[12px] shadow-sm hover:shadow-md transition-all cursor-pointer group flex items-center justify-between"
                          >
                            <div className="flex items-center gap-4">
                              <div className="w-8 h-8 rounded-full bg-bg-app flex items-center justify-center font-mono font-black text-xs text-ink-secondary border border-accent-light">
                                {idx + 1}
                              </div>
                              <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center p-1 border border-accent-light/50 group-hover:border-accent-blue/30 transition-all overflow-hidden relative">
                                {(() => {
                                  const customThumbnail = getMatchedThumbnailSrc(entry.carName);
                                  const matchedCar = findCarByName(entry.carName);
                                  const dbThumbnail = matchedCar?.thumbnail_url ? `/${matchedCar.thumbnail_url}` : null;
                                  const logoUrl = getLogoUrl(resolveLogoLocal(entry.carName, entry.carBrand, logoOverrides, logosDatabase));
                                  return (
                                    <>
                                      <img 
                                        src={customThumbnail} 
                                        alt={entry.carName}
                                        className="w-[120%] h-[120%] object-contain mix-blend-multiply transition-all group-hover:scale-110" 
                                        referrerPolicy="no-referrer"
                                        onError={(e) => { 
                                          const target = e.currentTarget;
                                          if (dbThumbnail && !target.dataset.triedDb) {
                                            target.dataset.triedDb = 'true';
                                            target.src = dbThumbnail;
                                          } else if (!target.dataset.triedPlaceholder) {
                                            target.dataset.triedPlaceholder = 'true';
                                            target.src = SAFE_CAR_PLACEHOLDER;
                                          } else {
                                            if (logoUrl) { 
                                              target.src = logoUrl; 
                                            } else { 
                                              target.style.display = 'none'; 
                                            }
                                          }
                                        }} 
                                      />
                                      {!logoUrl && !matchedCar && <Car className="absolute text-ink-secondary/20 z-0" size={24} />}
                                    </>
                                  );
                                })()}
                              </div>
                              <div>
                                <h4 className="text-sm font-black text-ink-primary group-hover:text-accent-blue transition-colors leading-none uppercase italic">
                                  {entry.carName}
                                </h4>
                                <div className="flex items-center gap-2 mt-1.5">
                                  <span className="text-[8px] font-black tracking-widest uppercase text-ink-secondary opacity-50 px-2 py-0.5 border border-accent-light rounded-full">{entry.carBrand}</span>
                                  <span className="text-[8px] font-black tracking-widest uppercase text-accent-blue/80 bg-accent-blue/5 px-2 py-0.5 rounded-full">{entry.carSetup || '700 Race Medium'}</span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="text-right">
                              <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary opacity-40 mb-0.5">{t('best_lap')}</p>
                              <p className="text-xl font-mono font-black text-accent-blue tracking-tighter leading-none">
                                {entry.provaDeTempo}
                              </p>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>
                ) : viewMode === 'list' ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-bg-card rounded-[12px] border border-accent-light overflow-hidden divide-y divide-accent-light/30 shadow-sm"
                  >
                    {flatFilteredEntries.map((entry, idx) => (
                      <div 
                        key={`entry-flat-${entry.id}-${idx}`} 
                        className="p-2.5 px-3.5 flex items-center justify-between hover:bg-accent-blue/5 transition-all cursor-pointer group active:scale-[0.99]"
                        onClick={() => {
                          setEditingEntry(entry);
                          setIsAddingEntry(true);
                        }}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-5 text-center font-black text-[9px] text-ink-secondary/30 italic">#{idx + 1}</div>
                          <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center p-1 border border-accent-light/50 shadow-inner group-hover:border-accent-blue/30 transition-colors overflow-hidden relative">
                            {(() => {
                                  const customThumbnail = getMatchedThumbnailSrc(entry.carName);
                                  const matchedCar = findCarByName(entry.carName);
                                  const dbThumbnail = matchedCar?.thumbnail_url ? `/${matchedCar.thumbnail_url}` : null;
                                  const logoUrl = getLogoUrl(resolveLogoLocal(entry.carName, entry.carBrand, logoOverrides, logosDatabase));
                                  return (
                                    <>
                                      <img 
                                        src={customThumbnail} 
                                        alt={entry.carName}
                                        className="w-[120%] h-[120%] object-contain mix-blend-multiply transition-all group-hover:scale-110" 
                                        referrerPolicy="no-referrer"
                                        onError={(e) => { 
                                          const target = e.currentTarget;
                                          if (dbThumbnail && !target.dataset.triedDb) {
                                            target.dataset.triedDb = 'true';
                                            target.src = dbThumbnail;
                                          } else if (!target.dataset.triedPlaceholder) {
                                            target.dataset.triedPlaceholder = 'true';
                                            target.src = SAFE_CAR_PLACEHOLDER;
                                          } else {
                                            if (logoUrl) { 
                                              target.src = logoUrl; 
                                            } else { 
                                              target.style.display = 'none'; 
                                            }
                                          }
                                        }} 
                                      />
                                      {!logoUrl && !matchedCar && <span className="absolute text-[8px] font-black opacity-20 uppercase tracking-tighter z-0">{entry.carBrand.substring(0, 3)}</span>}
                                    </>
                                  );
                            })()}
                          </div>
                          <div>
                            <h5 className="text-[11px] font-black uppercase tracking-tight text-ink-primary group-hover:text-accent-blue transition-colors flex items-center gap-1.5">
                              {entry.carName}
                              {idx === 0 && <Sparkles size={10} className="text-yellow-500 fill-yellow-500" />}
                            </h5>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-[8px] font-bold text-ink-secondary opacity-60 uppercase tracking-wider">{entry.carBrand}</span>
                              <span className="text-[8px] font-bold text-accent-blue/60 uppercase tracking-widest px-1.5 py-0.5 bg-accent-blue/5 rounded-full">{entry.carSetup || 'Default'}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right flex flex-col items-end gap-0.5">
                          <div className="text-[14px] font-black text-ink-primary font-mono tracking-tighter leading-none flex items-center justify-end gap-1.5">
                            {sortBy === 'lapTime' ? entry.lapTime : entry.totalTime}
                            <PeripheralIcon peripheral={entry.peripheral} size={12} className="opacity-80 text-ink-secondary" />
                          </div>
                          <div className="text-[7px] font-black uppercase tracking-[0.2em] text-ink-secondary hover:text-accent-blue transition-colors flex items-center gap-1">
                            {sortBy === 'lapTime' ? t('best_lap') : t('total_time')}
                            <div className="w-1 h-1 rounded-full bg-accent-blue" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                ) : (
                  groupedEntries.map((group, grpIdx) => {
                    const isExpanded = expandedCarGroups[group.carName];
                    const hasMultiple = group.entries.length > 1;
                    const groupKey = `${currentTrackId}-${normalizeNameForMatching(group.carBrand || '')}-${normalizeNameForMatching(group.carName || '')}`;

                    if (!hasMultiple) {
                      const entry = group.entries[0];
                      return (
                        <EntryCard 
                          key={`single-${entry.trackId}-${entry.id}-${normalizeNameForMatching(entry.carName)}-${grpIdx}`} 
                          entry={entry} 
                          tracks={tracks}
                          layout={layout}
                          logoOverrides={logoOverrides}
                          logosDatabase={logosDatabase}
                          userDisplayName={userProfile?.display_name}
                          onSaveThumbnailOverride={saveLogoOverride}
                          onOpenCars={(carName) => {
                            setLinkingForCarName(carName);
                            setIsAdminViewOpen(true);
                          }}
                          onEdit={() => {
                            setEditingEntry(entry);
                            setIsAddingEntry(true);
                          }}
                          onDelete={() => {
                            if (!session) {
                              setShowAuthModal(true);
                            } else {
                              deleteEntry(entry.id);
                            }
                          }}
                          onEditLogo={(brand, carName) => {
                            if (!session) {
                              setShowAuthModal(true);
                            } else {
                              setEditingLogo({ brand, carName });
                            }
                          }}
                        />
                      );
                    }

                    return (
                      <div key={`group-${groupKey}-${grpIdx}`} className="space-y-2">
                        <div className="relative">
                          <EntryCard 
                            entry={group.fastestEntry} 
                            tracks={tracks}
                            layout={layout}
                            logoOverrides={logoOverrides}
                            logosDatabase={logosDatabase}
                            userDisplayName={userProfile?.display_name}
                            onSaveThumbnailOverride={saveLogoOverride}
                            onOpenCars={(carName) => {
                              setLinkingForCarName(carName);
                              setIsAdminViewOpen(true);
                            }}
                            groupAction={
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setExpandedCarGroups(prev => ({...prev, [group.carName]: !prev[group.carName]}));
                                }}
                                className="squircle-action px-2.5 py-1 rounded-[14px] text-[8.5px] font-extrabold uppercase tracking-widest flex items-center gap-1 hover:bg-accent-light/10 text-white bg-black/45 border border-white/10 shadow-sm whitespace-nowrap transition-transform active:scale-95 duration-100"
                              >
                                {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                                {group.entries.length} {group.entries.length === 1 ? t('record_count') : t('records_count')}
                              </button>
                            }
                            onEdit={() => {
                              setEditingEntry(group.fastestEntry);
                              setIsAddingEntry(true);
                            }}
                            onDelete={() => {
                              if (!session) {
                                setShowAuthModal(true);
                              } else {
                                deleteEntry(group.fastestEntry.id);
                              }
                            }}
                            onEditLogo={(brand, carName) => {
                              if (!session) {
                                setShowAuthModal(true);
                              } else {
                                setEditingLogo({ brand, carName });
                              }
                            }}
                          />
                        </div>

                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div 
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="pl-4 space-y-4 border-l-2 border-accent-blue/10 overflow-hidden"
                            >
                              {group.entries.filter(e => e.id !== group.fastestEntry.id).map((entry, idx) => (
                                <EntryCard 
                                  key={`expanded-${entry.trackId}-${entry.id}-${normalizeNameForMatching(entry.carName)}-${idx}`} 
                                  entry={entry} 
                                  tracks={tracks}
                                  layout={layout}
                                  logoOverrides={logoOverrides}
                                  logosDatabase={logosDatabase}
                                  userDisplayName={userProfile?.display_name}
                                  onSaveThumbnailOverride={saveLogoOverride}
                                  onOpenCars={(carName) => {
                                    setLinkingForCarName(carName);
                                    setIsAdminViewOpen(true);
                                  }}
                                  onEdit={() => {
                                    setEditingEntry(entry);
                                    setIsAddingEntry(true);
                                  }}
                                  onDelete={() => {
                                    if (!session) {
                                      setShowAuthModal(true);
                                    } else {
                                      deleteEntry(entry.id);
                                    }
                                  }}
                                  onEditLogo={(brand, carName) => {
                                    if (!session) {
                                      setShowAuthModal(true);
                                    } else {
                                      setEditingLogo({ brand, carName });
                                    }
                                  }}
                                />
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Floating Action Button */}
      {currentTrackId && !isAddingEntry && (
        <motion.button
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          onClick={() => {
            if (!session) {
              setShowAuthModal(true);
            } else {
              setIsAddingEntry(true);
            }
          }}
          className="fixed bottom-8 right-8 w-16 h-16 bg-accent-blue text-white rounded-[24px] shadow-2xl flex items-center justify-center active:scale-90 transition-all z-40 border-4 border-white/10"
        >
          <Plus size={32} />
        </motion.button>
      )}

      {/* Modals */}
      <AnimatePresence>
        {isAddingEntry && (
          <EntryForm 
            entry={editingEntry}
            layout={layout}
            userDisplayName={userProfile?.display_name}
            logoOverrides={logoOverrides}
            logosDatabase={logosDatabase}
            isTimeTrial={trackSubView === 'timetrial'}
            onSave={saveEntry}
            onEditLogo={(brand, carName) => setEditingLogo({ brand, carName })}
            onDelete={(id) => deleteEntry(id)}
            onClose={() => {
              setIsAddingEntry(false);
              setEditingEntry(null);
            }}
            suggestions={suggestions}
          />
        )}
        {isLayoutEditorOpen && (
          <LayoutEditor 
            layout={layout}
            onSave={(newLayout) => {
              setLayout(newLayout);
              if (session) {
                supabaseService.saveUserSettings(newLayout, logoOverrides)
                  .then(() => setLastSaved(new Date()))
                  .catch(err => setSyncError(err.message || 'Erro ao salvar layout'));
              } else {
                setLastSaved(new Date());
              }
            }}
            onClose={() => setIsLayoutEditorOpen(false)}
          />
        )}
        {editingLogo && (
          <LogoEditor 
            brand={editingLogo.brand}
            carName={editingLogo.carName}
            currentLogo={resolveLogoLocal(editingLogo.carName, editingLogo.brand, logoOverrides, logosDatabase)}
            logosDatabase={logosDatabase}
            onAddLogos={newLogos => {
              const updated = [...logosDatabase, ...newLogos];
              setLogosDatabase(updated);
              if (session) {
                supabaseService.saveUserSettings(layout, logoOverrides, updated)
                  .then(() => setLastSaved(new Date()))
                  .catch(err => setSyncError(err.message || 'Erro ao salvar logos'));
              }
            }}
            onSave={(logoFile) => saveLogoOverride(editingLogo.carName, logoFile)}
            onClose={() => setEditingLogo(null)}
          />
        )}
        {trackPromptOpen && (
          <TrackSelectorModal 
            onAdd={(name, location, packId) => {
              addTrack(name, location, packId);
              setTrackPromptOpen(false);
            }}
            onClose={() => setTrackPromptOpen(false)}
          />
        )}
        {isProfileOpen && (
          <ProfileModal 
            profile={userProfile || {} as UserProfile}
            entries={entries}
            onSave={handleUpdateProfile}
            onClose={() => setIsProfileOpen(false)}
            canClaimAdmin={true}
          />
        )}
        {isRankingOpen && rankingTrackId && (
          <RankingModal 
            trackId={rankingTrackId}
            trackName={tracks.find(t => t.id === rankingTrackId)?.name || 'Track'}
            logoOverrides={logoOverrides}
            logosDatabase={logosDatabase}
            onClose={() => setIsRankingOpen(false)}
            onOpenProfile={(uid) => {
              setSelectedPublicProfileId(uid);
              setIsRankingOpen(false);
            }}
          />
        )}
        {isAdminViewOpen && (
          <AdminPanel 
            onClose={() => {
              setIsAdminViewOpen(false);
              setLinkingForCarName(null);
            }}
            onSaveCloud={handleManualSave}
            onLoadCloud={loadSupabaseData}
            onDeduplicate={deduplicateData}
            onScanOrphans={scanOrphans}
            onRestoreTrash={restoreTrash}
            onImportTrackPack={importTrackPack}
            onUpdateTrack={updateTrack}
            onDeleteTrack={deleteTrack}
            tracks={tracks}
            trashCount={{ tracks: trash.tracks.length, entries: trash.entries.length }}
            isSyncing={isSyncing}
            syncError={syncError}
            onOpenPilotManager={() => {
              setPilotManagerOpen(true);
              setIsAdminViewOpen(false);
            }}
            logosDatabase={logosDatabase}
            onAddLogos={addLogosToBank}
            onDeleteLogo={deleteLogoFromBank}
            onUpdateName={updateLogoNameInBank}
            onSaveAll={handleManualSave}
            carsDatabase={carsDatabase}
            onAddCars={addCarsToBank}
            onDeleteCar={deleteCarFromBank}
            onDeleteAllCars={handleDeleteAllCars}
            onUpdateCarName={updateCarNameInBank}
            isCarModalOpen={isCarModalOpen}
            setIsCarModalOpen={setIsCarModalOpen}
            selectedCarForPreview={selectedCarForPreview}
            setSelectedCarForPreview={setSelectedCarForPreview}
            onOpenCarPreview={handleOpenCarPreview}
            linkingForCarName={linkingForCarName}
            onSelectCarForLink={handleSelectCarForLink}
            entries={entries}
            suggestions={suggestions}
            onRenameCar={updateCarNameAcrossEntries}
          />
        )}
        {isCarModalOpen && selectedCarForPreview && (
          <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setIsCarModalOpen(false)}>
             <div className="bg-bg-card p-6 rounded-3xl border border-accent-light max-w-sm w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150" onClick={(e) => e.stopPropagation()}>
               <div className="w-full aspect-video bg-bg-app rounded-2xl overflow-hidden flex items-center justify-center p-4 border border-accent-light">
                 <img src={selectedCarForPreview.logo_data} alt={selectedCarForPreview.brand_name} className="max-w-full max-h-full object-contain hover:scale-105 transition-transform duration-300" />
               </div>
               
               <div className="text-center space-y-1">
                 <h3 className="text-xl font-bold text-ink-primary tracking-tight leading-tight">{selectedCarForPreview.brand_name}</h3>
                 <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-40">Banco de Carros</p>
                 {linkingForCarName && (
                   <p className="text-xs font-bold text-accent-blue mt-2 max-w-xs mx-auto break-all">
                     {language === 'pt' ? `Vincular imagem do carro para: ${linkingForCarName}` : `Link car image to: ${linkingForCarName}`}
                   </p>
                 )}
               </div>

               <div className="flex gap-2 w-full pt-1">
                 {linkingForCarName && (
                   <button 
                     onClick={() => {
                       handleSelectCarForLink(selectedCarForPreview.logo_data);
                     }}
                     className="flex-1 bg-emerald-500 py-3 rounded-xl font-black text-white text-[10px] uppercase tracking-wider hover:opacity-90 transition-all shadow-lg shadow-emerald-500/15 active:scale-[0.98]"
                   >
                     {language === 'pt' ? "Vincular" : "Link Car"}
                   </button>
                 )}
                 <button 
                   onClick={() => {
                     setIsCarModalOpen(false);
                   }} 
                   className={`bg-accent-blue py-3 rounded-xl font-black text-white text-[10px] uppercase tracking-wider hover:opacity-90 transition-all shadow-lg shadow-accent-blue/15 active:scale-[0.98] ${linkingForCarName ? 'px-4' : 'w-full'}`}
                 >
                   {linkingForCarName ? (language === 'pt' ? "Cancelar" : "Cancel") : "OK"}
                 </button>
               </div>
             </div>
          </div>
        )}
        {selectedPublicProfileId && homeTab !== 'community' && (
          <PublicProfileModal 
            userId={selectedPublicProfileId}
            logoOverrides={logoOverrides}
            logosDatabase={logosDatabase}
            onClose={() => setSelectedPublicProfileId(null)}
          />
        )}
        {pilotManagerOpen && (
          <PilotManager 
            onClose={() => setPilotManagerOpen(false)}
            onSelectUser={(userId) => {
              setSelectedPublicProfileId(userId);
              setPilotManagerOpen(false);
            }}
            isAdmin={userProfile?.is_admin}
          />
        )}
        {hubOpen && (
          <UserHub 
            onClose={() => setHubOpen(false)}
            onSelectUser={(userId) => {
              setSelectedPublicProfileId(userId);
              setHubOpen(false);
            }}
          />
        )}
        {isSettingsOpen && (
          <SettingsMenu 
            tracks={tracks}
            onClose={() => setIsSettingsOpen(false)}
            onSaveCloud={handleManualSave}
            onLoadCloud={loadSupabaseData}
            onSignOut={() => supabase.auth.signOut()}
            onCreateRestorePoint={handleCreateRestorePoint}
            onApplyRestorePoint={handleApplyRestorePoint}
            onImport={(data?: any) => {
              if (data && data.tracks) {
                // Bulk import from database
                const existingNames = new Set(tracks.map(t => (t.name || "").toLowerCase()));
                const newTracks = (data.tracks || []).filter((t: Track) => t && t.name && !existingNames.has(t.name.toLowerCase()));
                if (newTracks.length > 0) {
                  setTracks(prev => [...prev, ...newTracks]);
                }
              } else {
                handleImportClick();
              }
            }}
            onExport={handleExport}
            onLayoutEditor={() => setIsLayoutEditorOpen(true)}
            onDeduplicate={deduplicateData}
            onScanOrphans={scanOrphans}
            onClearTrash={clearTrash}
            onRestoreTrash={restoreTrash}
            trashCount={{ tracks: trash.tracks.length, entries: trash.entries.length }}
            isSyncing={isSyncing}
            syncError={syncError}
            session={session}
          />
        )}
        {isAIAnalystOpen && currentTrackId && (
          <AIAnalystModal 
            trackName={tracks.find(t => t.id === currentTrackId)?.name || 'Track'}
            entries={entries.filter(e => e.trackId === currentTrackId)}
            onClose={() => setIsAIAnalystOpen(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showExitPrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] bg-bg-dark/80 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-bg-card rounded-2xl border border-accent-light p-6 w-full max-w-sm flex flex-col items-center text-center"
            >
              <h2 className="text-xl font-black uppercase text-ink-primary mb-2">{t('exit_app')}</h2>
              <p className="text-sm font-medium text-ink-secondary mb-6">{t('exit_app_desc')}</p>
              <div className="flex gap-3 w-full justify-center">
                <button
                  onClick={() => {
                    setShowExitPrompt(false);
                    // Push state again so the next back button press will be caught again
                    window.history.pushState({ pwaActivity: true }, '');
                  }}
                  className="px-6 py-2.5 rounded-xl text-sm font-bold text-ink-secondary bg-ink-secondary/5 hover:bg-ink-secondary/10 transition-colors"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={() => {
                    allowExitRef.current = true;
                    if (window.history.length > 2) {
                      window.history.go(-2);
                    } else {
                      window.close();
                      window.history.back(); // Fallback
                    }
                  }}
                  className="px-6 py-2.5 bg-red-500/10 text-red-500 rounded-xl text-sm font-bold hover:bg-red-500 hover:text-white transition-all shadow-[0_0_15px_rgba(239,68,68,0.3)] hover:shadow-none border border-red-500/20"
                >
                  {t('exit')}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Congrats Toast / Overlay */}
      <AnimatePresence>
        {congratsMessage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[500] flex items-center justify-center p-6 bg-black/60 backdrop-blur-md cursor-pointer"
            onClick={() => setCongratsMessage(null)}
          >
            <motion.div
              initial={{ y: 100, opacity: 0, scale: 0.5, rotate: -5 }}
              animate={{ y: 0, opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 1.5, y: -100 }}
              transition={{ type: "spring", damping: 15, stiffness: 100 }}
              className="bg-white/10 backdrop-blur-2xl border-4 border-white/20 p-8 sm:p-12 rounded-[48px] shadow-[0_0_100px_rgba(255,255,255,0.2)] max-w-lg w-full text-center relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Decorative elements */}
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 opacity-10"
              >
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-tr from-yellow-500 via-transparent to-blue-500 blur-3xl rounded-full" />
              </motion.div>

              <div className="relative z-10 space-y-6">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(251,191,36,0.5)]"
                >
                  <Trophy size={48} className="text-white drop-shadow-md" />
                </motion.div>

                <div className="space-y-2">
                  <h2 className="text-4xl font-black uppercase italic tracking-tighter text-white drop-shadow-lg">
                    Recorde Batido!
                  </h2>
                  <p className="text-xl font-bold text-white/80 leading-tight">
                    {congratsMessage}
                  </p>
                </div>

                <div className="flex justify-center gap-4 pt-4">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.4 + (i * 0.1) }}
                      className="text-2xl"
                    >
                      ⭐
                    </motion.div>
                  ))}
                </div>
              </div>
              
              {/* Simple Particle Effect representation */}
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 rounded-full bg-yellow-400"
                    initial={{ x: "50%", y: "50%", opacity: 1 }}
                    animate={{ 
                      x: `${50 + (Math.random() - 0.5) * 100}%`, 
                      y: `${50 + (Math.random() - 0.5) * 100}%`,
                      opacity: 0,
                      scale: 0
                    }}
                    transition={{ duration: 1.5, repeat: Infinity, delay: Math.random() * 2 }}
                  />
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

import supabaseSchemaRaw from '../SUPABASE_SCHEMA.sql?raw';

import { TelemetryProvider, useTelemetry } from './contexts/TelemetryContext';
import { LiveTelemetry } from './components/LiveTelemetry';
import { TelemetryFullscreen } from './components/TelemetryFullscreen';
import { RoadmapView } from './components/RoadmapView';

export default function App() {
  return (
    <LanguageProvider>
      <TelemetryProvider>
        <AppContent />
      </TelemetryProvider>
    </LanguageProvider>
  );
}

const LanguageSwitcher = () => {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center bg-bg-app border border-accent-light p-1 rounded-full shadow-sm">
      <button
        onClick={() => setLanguage('en')}
        className={`w-7 h-7 flex items-center justify-center rounded-full transition-all ${
          language === 'en' ? 'bg-accent-blue text-white shadow-md scale-110' : 'hover:bg-accent-light opacity-60 hover:opacity-100'
        }`}
        title="English"
      >
        <span className="text-sm">🇺🇸</span>
      </button>
      <button
        onClick={() => setLanguage('pt')}
        className={`w-7 h-7 flex items-center justify-center rounded-full transition-all ${
          language === 'pt' ? 'bg-accent-blue text-white shadow-md scale-110' : 'hover:bg-accent-light opacity-60 hover:opacity-100'
        }`}
        title="Português"
      >
        <span className="text-sm">🇧🇷</span>
      </button>
    </div>
  );
};

interface EntryCardProps {
  key?: string;
  entry: Entry & { profiles?: UserProfile | null };
  tracks: Track[];
  layout: LayoutProfile;
  logoOverrides: Record<string, string>;
  logosDatabase?: LogoBrand[];
  onEdit: () => void;
  onDelete: () => void;
  onEditLogo: (brand: string, carName: string) => void;
  userDisplayName?: string;
  groupAction?: React.ReactNode;
  onSaveThumbnailOverride?: (carName: string, logoFile: string) => void;
  onOpenCars?: (carName: string) => void;
}

const normalizeBrandNameHelper = (name: string | null | undefined) => {
  if (!name) return "";
  return name.toLowerCase().replace(/\s+/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, "");
};

const getLogoFromLocalBank = (name: string | null | undefined, logosDatabase: LogoBrand[] = []) => {
  const slug = normalizeBrandNameHelper(name);
  if (!slug) return null;
  
  // Exact match
  const found = logosDatabase.find(l => l.brand_slug === slug);
  if (found) return found.logo_data;
  
  // Partial match: e.g. "Mazda LM55 VGT" starts with "mazda"
  const partialMatch = logosDatabase.find(l => l.brand_slug && slug.startsWith(l.brand_slug));
  if (partialMatch) return partialMatch.logo_data;
  
  return null;
};

const resolveLogoLocal = (carName: string, carBrand: string, logoOverrides: Record<string, string>, logosDatabase: LogoBrand[] = []) => {
  return logoOverrides[carName] || 
         logoOverrides[carBrand] || 
         getLogoFromLocalBank(carName, logosDatabase) || 
         getLogoFromLocalBank(carBrand, logosDatabase) || 
         getBrandLogo(carBrand);
};

export function CarThumbnailImg({
  carName,
  dbThumbnail,
  className,
  onError,
  onMissing,
  onLoad,
  ...props
}: {
  carName: string;
  dbThumbnail?: string | null;
  className?: string;
  onError?: (e: React.SyntheticEvent<HTMLImageElement>) => void;
  onMissing?: () => void;
  onLoad?: () => void;
  [key: string]: any;
}) {
  const customSrc = useCarThumbnail(carName);
  const [src, setSrc] = useState<string>(customSrc || dbThumbnail || SAFE_CAR_PLACEHOLDER);
  const lastFailedRef = useRef<string | null>(null);

  useEffect(() => {
    let active = true;

    async function load() {
      lastFailedRef.current = null;

      if (isFirebaseConfigured) {
        try {
          const firestoreUrl = await getThumbnailMetadataFromFirestore(carName);
          if (firestoreUrl && active) {
            setSrc(firestoreUrl);
            return;
          }
        } catch (err) {
          console.warn('Error loading Firestore thumbnail image:', err);
        }
      }

      const local = await getThumbnailLocal(carName);
      if (!active) return;

      if (local) {
        setSrc(local);
      } else if (dbThumbnail) {
        setSrc(dbThumbnail);
      } else if (customSrc) {
        setSrc(customSrc);
      } else {
        onMissing?.();
        setSrc(SAFE_CAR_PLACEHOLDER);
      }
    }

    load();
    return () => { active = false; };
  }, [carName, dbThumbnail, customSrc, onMissing]);

  return (
    <img
      src={src || SAFE_CAR_PLACEHOLDER}
      alt={carName}
      className={className}
      referrerPolicy="no-referrer"
      onLoad={(e) => {
        if (src && src !== SAFE_CAR_PLACEHOLDER) {
          lastFailedRef.current = null;
          onLoad?.();
        }
      }}
      onError={(e) => {
        if (lastFailedRef.current === e.currentTarget.currentSrc || src === SAFE_CAR_PLACEHOLDER) {
          onMissing?.();
          e.currentTarget.onerror = null;
          e.currentTarget.src = SAFE_CAR_PLACEHOLDER;
          return;
        }

        lastFailedRef.current = e.currentTarget.currentSrc;
        onMissing?.();

        if (onError) {
          onError(e);
        } else {
          setSrc(SAFE_CAR_PLACEHOLDER);
        }
      }}
      {...props}
    />
  );
}

const ThumbnailItem = React.memo(({ name, applyThumbnail, isUploading }: { name: string, applyThumbnail: (name: string) => void, isUploading: boolean }) => {
  return (
    <div 
      onClick={() => {
        if (!isUploading) {
          applyThumbnail(name);
        }
      }}
      className="bg-bg-cell border border-accent-light/30 rounded-2xl p-2 flex flex-col items-center justify-between hover:border-accent-blue cursor-pointer transition-all hover:scale-[1.02] hover:shadow-md group h-[110px]"
    >
      <div className="w-full flex-1 flex items-center justify-center overflow-hidden pb-1 max-h-[60px]">
        <CarThumbnailImg 
          carName={name} 
          className="w-[125%] h-[125%] object-contain mix-blend-multiply transition-transform group-hover:scale-110"
        />
      </div>
      <span className="text-[9px] font-black text-center text-ink-primary truncate w-full mt-1 px-1">
        {name}
      </span>
    </div>
  );
});

function EntryCard({ entry, tracks, layout, logoOverrides, logosDatabase = [], onEdit, onDelete, onEditLogo, userDisplayName, groupAction, onSaveThumbnailOverride, onOpenCars }: EntryCardProps) {
  const { t, language } = useLanguage();
  const track = tracks.find(t => t.id === entry.trackId);
  const normalizedFields = getNormalizedFields(layout);
  
  const [cardExpanded, setCardExpanded] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);
  const fileInputRefForThumb = useRef<HTMLInputElement>(null);
  const [thumbnailSrc, setThumbnailSrc] = useState(() => getMatchedThumbnailSrc(entry.carName));
  const [isPlaceholder, setIsPlaceholder] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);
  const savedThumbs = useAllThumbnails();

  const handleCardClick = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (
      target.closest('button') || 
      target.closest('label') || 
      target.closest('input') || 
      target.closest('select') || 
      target.closest('.fixed')
    ) {
      return;
    }
    setCardExpanded(prev => !prev);
  };

  const weatherValForBg = (entry.weather || "").toLowerCase();
  const bgImageUrl = '/assets/weather/dry.png';

  const fetchLocalThumbs = async () => { await refreshThumbsCache(); };

  useEffect(() => {
    fetchLocalThumbs();
  }, []);

  useEffect(() => {
    let active = true;
    const checkLocal = async () => {
      if (isFirebaseConfigured) {
        try {
          const firestoreUrl = await getThumbnailMetadataFromFirestore(entry.carName);
          if (firestoreUrl && active) {
            setThumbnailSrc(firestoreUrl);
            setIsPlaceholder(false);
            return;
          }
        } catch (err) {
          console.warn("Error getting Firestore thumbnail in entry card:", err);
        }
      }

      const localBase64 = await getThumbnailLocal(entry.carName);
      if (active) {
        if (localBase64) {
          setThumbnailSrc(localBase64);
          setIsPlaceholder(false);
        } else if (logoOverrides && logoOverrides[`thumb_${entry.carName}`]) {
          setThumbnailSrc(logoOverrides[`thumb_${entry.carName}`]);
          setIsPlaceholder(false);
        } else {
          setThumbnailSrc(`${getMatchedThumbnailSrc(entry.carName)}?r=${refreshKey}`);
          setIsPlaceholder(false);
        }
      }
    };
    checkLocal();
    return () => { active = false; };
  }, [entry.carName, refreshKey, logoOverrides]);

  const similaritySuggestions = useMemo(() => {
    if (savedThumbs.length === 0) return [];
    
    // Normalize target name - e.g. "650S GT3 '15" -> ["650s", "gt3"]
    const targetWords = entry.carName.toLowerCase()
      .replace(/['"\(\)]/g, '')
      .split(/[\s_\-]+/)
      .filter(w => w.length > 1);

    if (targetWords.length === 0) return [];

    return savedThumbs
      .map(name => {
        const nameWords = name.toLowerCase()
          .replace(/['"\(\)]/g, '')
          .split(/[\s_\-]+/)
          .filter(w => w.length > 1);
        
        // Count how many words overlap
        const matches = targetWords.filter(w => nameWords.includes(w));
        // Compute score: Jaccard or overlap
        const score = matches.length / Math.max(targetWords.length, nameWords.length);
        
        return { name, score, matchesCount: matches.length };
      })
      .filter(item => item.matchesCount > 0) // At least 1 word matches
      .sort((a, b) => b.score - a.score || b.matchesCount - a.matchesCount)
      .slice(0, 5); // top 5 matches
  }, [savedThumbs, entry.carName]);

  const applyExistingThumbnail = async (existingName: string) => {
    setIsUploading(true);
    try {
      // 1. Check if the image exists in IndexedDB first
      let base64data = await getThumbnailLocal(existingName);

      // 2. Otherwise fetch from standard server asset folder
      if (!base64data) {
        const imgUrl = `/assets/cars/${encodeURIComponent(existingName)}.webp`;
        const response = await fetch(imgUrl);
        if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
        const blob = await response.blob();
        
        base64data = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(blob);
        });
      }

      if (base64data) {
        // Upload to Firebase Storage!
        if (isFirebaseConfigured) {
          try {
            const finalUrl = await uploadThumbnailDirectly(entry.carName, base64data);
            if (onSaveThumbnailOverride) {
              onSaveThumbnailOverride(`thumb_${entry.carName}`, finalUrl);
            }
          } catch (fbErr) {
            console.warn("Firebase Storage upload failed, using local fallback:", fbErr);
            await saveThumbnailLocal(entry.carName, base64data);
            if (onSaveThumbnailOverride) {
              onSaveThumbnailOverride(`thumb_${entry.carName}`, base64data);
            }
          }
        } else {
          // Save to browser's database if Firebase is not active
          await saveThumbnailLocal(entry.carName, base64data);
          if (onSaveThumbnailOverride) {
            onSaveThumbnailOverride(`thumb_${entry.carName}`, base64data);
          }
        }

        // Try copying to the backend as backup (fails silently if offline/standalone)
        try {
          await fetch('/api/upload-car-thumbnail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name: entry.carName,
              base64: base64data
            })
          });
        } catch (serverErr) {
          console.warn("Backend backup failed, thumbnail is stored safely offline in local IndexedDB:", serverErr);
        }
        
        setRefreshKey(prev => prev + 1);
        setIsPlaceholder(false);
        fetchLocalThumbs();
        triggerThumbnailUpdate();
        setShowPicker(false);
      }
    } catch (err) {
      console.error("Error applying existing thumbnail:", err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const base64data = await convertToWebP(file);
      // Upload to Firebase Storage!
      if (isFirebaseConfigured) {
        try {
          const finalUrl = await uploadThumbnailDirectly(entry.carName, base64data);
            if (onSaveThumbnailOverride) {
              onSaveThumbnailOverride(`thumb_${entry.carName}`, finalUrl);
            }
          } catch (fbErr) {
            console.warn("Firebase Storage upload failed for file, using local fallback:", fbErr);
            await saveThumbnailLocal(entry.carName, base64data);
            if (onSaveThumbnailOverride) {
              onSaveThumbnailOverride(`thumb_${entry.carName}`, base64data);
            }
          }
        } else {
          // Put safely in local browser database
          await saveThumbnailLocal(entry.carName, base64data);
          if (onSaveThumbnailOverride) {
            onSaveThumbnailOverride(`thumb_${entry.carName}`, base64data);
          }
        }

        // 2. Put in the API server if possible
        try {
          await fetch('/api/upload-car-thumbnail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name: entry.carName,
              base64: base64data
            })
          });
        } catch (err) {
          console.warn("Backend backup upload failed, but thumbnail is stored safely offline in local IndexedDB:", err);
        }

        setRefreshKey(prev => prev + 1);
        setIsPlaceholder(false);
        triggerThumbnailUpdate();
        fetchLocalThumbs();
        if (fileInputRefForThumb.current) fileInputRefForThumb.current.value = '';
        setShowPicker(false);
      } catch (err) {
        console.error("File upload failed", err);
      } finally {
        setIsUploading(false);
      }
  };

  const displayPilot = (entry.pilot_name && entry.pilot_name !== '-' && entry.pilot_name.trim() !== '') 
    ? entry.pilot_name 
    : (entry.profiles?.display_name || userDisplayName || 'Driver');

  const getPlaceSuffix = (pos: string) => {
    if (language === 'pt') return t('place_th');
    const p = parseInt(pos);
    if (p === 1) return t('place_st');
    if (p === 2) return t('place_nd');
    if (p === 3) return t('place_rd');
    return t('place_th');
  };

  const renderFieldInner = (field: import('./types').FieldConfig) => {
    switch (field.id) {
      case 'header':
        const logoFile = logoOverrides[entry.carName] || 
                         logoOverrides[entry.carBrand] || 
                         getLogoFromLocalBank(entry.carName, logosDatabase) || 
                         getLogoFromLocalBank(entry.carBrand, logosDatabase) || 
                         getBrandLogo(entry.carBrand);
        const logoUrl = getLogoUrl(logoFile);

        const matchedCar = findCarByName(entry.carName);
        const dbThumbnail = matchedCar?.thumbnail_url ? `/${matchedCar.thumbnail_url}` : null;

        return (
          <div className="card-row -mx-1 -mt-1 w-[calc(100%+8px)] h-full flex flex-col gap-3">
            <input type="file" ref={fileInputRefForThumb} onChange={handleFileUpload} accept="image/*" className="hidden" />
            <div className={`cell-container w-full !flex-col !items-start ${layout.compactMode ? '!gap-1 !p-3 min-h-[160px]' : '!gap-2 !p-4 min-h-[230px]'} relative z-0 overflow-hidden`}>
              
              <div className="flex w-full justify-between items-start gap-2 relative z-10 pointer-events-none">
                <button type="button" onClick={(e) => { e.stopPropagation(); e.preventDefault(); onEditLogo(entry.carBrand, entry.carName); }} className={`pointer-events-auto flex-shrink-0 ${layout.compactMode ? 'w-24 h-12' : 'w-32 h-16'} flex items-center justify-start bg-transparent group relative`}>
                  {logoUrl ? <img src={logoUrl} alt={entry.carBrand} className="w-full h-full object-contain object-left scale-[1.6] origin-left" referrerPolicy="no-referrer" onError={(e) => (e.currentTarget.style.display = 'none')} /> : <Car size={layout.compactMode ? 16 : 24} className="text-ink-secondary opacity-20 scale-[2]" />}
                  <div className="absolute inset-0 bg-accent-blue/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"><Edit2 size={layout.compactMode ? 12 : 16} className="text-accent-blue" /></div>
                </button>
                <div className="flex items-center gap-1.5 flex-shrink-0 pointer-events-auto">

                  <div className="p-1.5 rounded-xl bg-accent-light/10 text-ink-secondary hover:text-accent-blue transition-all">
                    {cardExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </div>
                </div>
              </div>

              <div className="flex flex-col min-w-0 w-[55%] sm:w-[65%] mt-2 sm:mt-1 relative z-10 pointer-events-none">
                {track && <div className="text-[7px] font-black text-accent-blue uppercase tracking-[0.2em] mb-0.5 opacity-60 leading-tight pointer-events-auto w-fit">{track.name}</div>}
                <div className="text-[8px] font-black text-ink-secondary/50 uppercase tracking-[0.1em] mb-0 truncate pointer-events-auto w-fit max-w-full">{entry.carBrand}</div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 min-w-0 mt-0.5 pointer-events-auto w-fit max-w-full">
                  <div className={`${layout.compactMode ? 'text-[15px]' : 'text-lg lg:text-xl'} font-bold text-ink-primary line-clamp-2 leading-tight tracking-tight flex-shrink min-w-0 break-words`}>{entry.carName}</div>
                  {groupAction && <div className="flex-shrink-0 self-start sm:self-auto" onClick={(e) => e.stopPropagation()}>{groupAction}</div>}
                </div>
              </div>

              {/* Thumbnail Background Right - Exact Size 315x189 as requested */}
              <div 
                className="absolute right-4 top-1/2 -translate-y-1/2 w-[315px] h-[189px] max-w-[55%] max-h-[90%] pointer-events-auto z-0 flex items-center justify-center overflow-hidden rounded-[4px]" 
                style={{ aspectRatio: '5/3' }}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onOpenCars) {
                    onOpenCars(entry.carName);
                  }
                }}
              >
                <CarThumbnailImg 
                  carName={entry.carName}
                  dbThumbnail={dbThumbnail}
                  className={`w-full h-full object-cover transition-all duration-[4000ms] ease-out ${isPlaceholder ? 'opacity-0' : 'opacity-100 group-hover:scale-[1.12] group-hover:translate-x-1.5 group-hover:translate-y-0.5 group-hover:brightness-[1.15] cursor-pointer origin-center'}`}
                  style={{ objectPosition: '50% 30%' }}
                  title={language === 'pt' ? "Ver Banco de Carros" : "Go to Cars Bank"}
                  onMissing={() => setIsPlaceholder(true)}
                  onLoad={() => setIsPlaceholder(false)}
                />
                {!isPlaceholder && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setShowFullscreen(true);
                    }}
                    className="absolute bottom-2 right-2 z-10 bg-black/60 hover:bg-black/90 text-white p-1.5 rounded-full shadow-lg border border-white/20 transition-all cursor-pointer flex items-center justify-center active:scale-95"
                    title={language === 'pt' ? 'Ver em tela cheia' : 'View full screen'}
                  >
                    <Eye size={13} className="stroke-[2.5]" />
                  </button>
                )}
                {isPlaceholder && (
                  <div 
                    className="absolute inset-0 flex flex-col items-center justify-center hover:bg-black/5 transition-colors rounded-xl pointer-events-auto"
                  >
                    <div className="flex gap-2">
                      <button 
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onOpenCars) onOpenCars(entry.carName);
                        }}
                        className="bg-bg-app border border-accent-light text-ink-secondary/60 hover:text-accent-blue p-2.5 rounded-full shadow-sm transition-colors"
                        title={language === 'pt' ? "Ver Banco de Carros" : "Go to Cars Bank"}
                      >
                        <ImageIcon size={18} />
                      </button>
                      <button 
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          fileInputRefForThumb.current?.click();
                        }}
                        className="bg-bg-app border border-accent-light text-ink-secondary/60 hover:text-accent-blue p-2.5 rounded-full shadow-sm transition-colors"
                        title={language === 'pt' ? "Upload de Carro" : "Upload Car Image"}
                      >
                        <Upload size={18} />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      case 'racePosition':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label">{t('place')}</p><p className="cell-value whitespace-nowrap">{entry.racePosition}{getPlaceSuffix(entry.racePosition || '1')}</p></div>;
      case 'carSetup':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label">{t('setup')}</p><p className="cell-value whitespace-nowrap">{entry.carSetup}</p></div>;
      case 'pitStops':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label">{t('pits')}</p><p className="cell-value whitespace-nowrap">{entry.pitStops}</p></div>;
      case 'tractionControl':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label">{t('tc')}</p><p className="cell-value whitespace-nowrap">{t('level')} {entry.tractionControl}</p></div>;
      case 'carMap':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label text-center">{t('map')}</p><p className="cell-value text-center">{entry.carMap}</p></div>;
      case 'weather':
        const weatherVal = (entry.weather || "").toLowerCase();
        let displayWeather = entry.weather || "";
        if (weatherVal.includes('clear') || weatherVal.includes('sol')) displayWeather = t('weather_sun');
        else if (weatherVal.includes('cloudy') || weatherVal.includes('nublado')) displayWeather = t('weather_cloudy');
        else if (weatherVal.includes('light rain') || weatherVal.includes('chuva leve')) displayWeather = t('weather_rain');
        else if (weatherVal.includes('heavy rain') || weatherVal.includes('chuva pesada')) displayWeather = t('weather_storm');
        
        return (
          <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}>
            <p className="cell-label">{t('weather')}</p>
            <p className="cell-value whitespace-nowrap flex items-center gap-1">
              {weatherVal.includes('rain') || weatherVal.includes('chuva') ? <CloudRain size={12} className="text-ink-secondary" /> : <Sun size={12} className="text-amber-500" />}
              {displayWeather.replace(/☀️|🌧️/g, '').trim()}
            </p>
          </div>
        );
      case 'runDate':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label flex items-center gap-1"><Calendar size={8} className="opacity-40" /> {t('date')}</p><p className="cell-value">{formatDate(entry.runDate)}</p></div>;
      case 'lapTime':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`} style={{ height: layout.compactMode ? Math.max(32, layout.statHeight * 0.75) : layout.statHeight }}><p className="cell-label flex items-center gap-1"><Clock size={8} className="opacity-40" /> {t('best_lap')}</p><div className="flex items-center gap-1.5"><p className={`cell-value time-mono text-success ${layout.compactMode ? 'text-sm' : ''}`}>{entry.lapTime}</p><PeripheralIcon peripheral={entry.peripheral} size={12} className="opacity-60 text-success" /></div></div>;
      case 'totalTime':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`} style={{ height: layout.compactMode ? Math.max(32, layout.statHeight * 0.75) : layout.statHeight }}><p className="cell-label flex items-center gap-1"><Trophy size={8} className="opacity-40" /> {t('total_time')}</p><p className={`cell-value time-mono text-accent-blue ${layout.compactMode ? 'text-sm' : ''}`}>{entry.totalTime}</p></div>;
      case 'provaDeTempo':
        if (!entry.provaDeTempo) return <div className="h-full w-full"/>;
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`} style={{ height: layout.compactMode ? Math.max(32, layout.statHeight * 0.75) : layout.statHeight }}><p className="cell-label flex items-center gap-1"><Trophy size={8} className="opacity-40" /> {t('time_trial')}</p><p className={`cell-value time-mono text-ink-primary ${layout.compactMode ? 'text-sm' : ''}`}>{entry.provaDeTempo}</p></div>;
      case 'laps':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label flex items-center gap-1"><RefreshCcw size={8} className="opacity-40" /> {t('laps')}</p><p className="cell-value">{entry.laps || '0'}</p></div>;
      case 'transmission':
        const transValue = entry.transmission || 'Manual';
        const displayTrans = transValue === 'Automatic' ? t('trans_automatic') : t('trans_manual');
        return <div className="cell-container h-full w-full"><p className="cell-label">{t('transmission')}</p><p className="cell-value">{displayTrans}</p></div>;
      case 'peripheral':
        const periValue = entry.peripheral || 'Controller';
        const displayPeri = periValue === 'Wheel' ? t('peri_wheel') : t('peri_controller');
        return <div className="cell-container h-full w-full"><p className="cell-label">{t('peripheral')}</p><p className="cell-value">{displayPeri}</p></div>;
      case 'pilot_name':
        return <div className={`cell-container h-full w-full ${layout.compactMode ? 'compact' : ''}`}><p className="cell-label flex items-center gap-1"><User size={8} className="opacity-40" /> {t('driver')}</p><p className="cell-value whitespace-nowrap overflow-hidden text-ellipsis">{displayPilot}</p></div>;
      case 'actions':
        if (!layout.showActions) return <div className="h-full w-full"/>;
        return <div className={`flex items-center pt-2 border-t border-accent-light justify-${layout.actionAlign} h-full w-full`}><div className="flex items-center gap-1"><button type="button" onClick={(e) => { e.stopPropagation(); e.preventDefault(); onEdit(); }} className="p-2 text-ink-secondary hover:text-accent-blue transition-colors"><Edit2 size={layout.actionSize} /></button><button type="button" onClick={(e) => { e.stopPropagation(); e.preventDefault(); onDelete(); }} className="p-2 text-red-400 hover:text-red-500 transition-colors"><Trash2 size={layout.actionSize} /></button></div></div>;
      default:
        let value = entry.customFields?.[field.id.replace('custom_', '')];
        const lowerLabel = field.label.toLowerCase().trim();
        if (!value || value === '-') {
           if (lowerLabel === 'data') value = formatDate(entry.runDate);
           if (lowerLabel === 'voltas') value = entry.laps;
           if (lowerLabel === 'piloto') value = displayPilot;
        }
        return <div className="cell-container h-full w-full"><p className="cell-label">{field.label}</p><p className="cell-value">{value || '-'}</p></div>;
    }
  };

  return (
    <motion.div 
      layout
      onClick={handleCardClick}
      className={`premium-card group relative cursor-pointer ${layout.editMode ? 'border-2 border-accent-blue' : ''}`}
      style={{ 
        backgroundImage: `var(--theme-bg-gradient), url(${bgImageUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        borderRadius: layout.cardRadius, 
        padding: layout.compactMode ? Math.max(8, layout.cardPadding * 0.7) : layout.cardPadding,
      }}
    >
      <div className="grid grid-cols-12" style={{ gap: `${layout.rowGap}px`, gridAutoRows: 'minmax(min-content, max-content)' }}>
        {normalizedFields.filter(f => !f.hidden).map((field, fieldIdx) => {
          if (!cardExpanded) {
            // ONLY show 'header', 'lapTime', and 'totalTime' when collapsed!
            if (field.id !== 'header' && field.id !== 'lapTime' && field.id !== 'totalTime') {
              return null;
            }
          }
          if (field.id === 'provaDeTempo' && !entry.provaDeTempo) return null;
          if (field.id === 'actions' && !layout.showActions) return null;

          // Force span 6 for stats fields to keep them nicely side by side when collapsed
          const colSpanToUse = (!cardExpanded && (field.id === 'lapTime' || field.id === 'totalTime')) 
            ? 6 
            : field.colSpan;

          return (
            <div key={`${field.id}-${fieldIdx}`} style={{ gridColumn: `span ${colSpanToUse} / span ${colSpanToUse}`, minWidth: 0 }}>
              {renderFieldInner(field)}
            </div>
          );
        })}
      </div>
      
      {layout.editMode && (
        <>
          <div className="absolute -top-2.5 left-4 bg-accent-blue text-white text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded shadow-sm">
            {t('designer_active')}
          </div>
          <div className="absolute right-2 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-accent-blue/30 rounded-full" />
        </>
      )}

      <AnimatePresence>
        {showFullscreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={(e) => {
              e.stopPropagation();
              setShowFullscreen(false);
            }}
            className="fixed inset-0 z-[10000] bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4 cursor-zoom-out"
          >
            {/* Top Close Bar */}
            <div className="absolute top-4 right-4 z-[10010] flex items-center gap-3 pointer-events-auto">
              <span className="text-white/60 text-[10px] uppercase font-black tracking-widest hidden sm:inline-block">
                {entry.carName}
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowFullscreen(false);
                }}
                className="bg-white/10 hover:bg-white/20 text-white p-2.5 rounded-full border border-white/10 transition-all active:scale-95 flex items-center justify-center cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Image display wrapper */}
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full max-w-[92vw] md:max-w-4xl max-h-[85vh] flex flex-col items-center justify-center pointer-events-auto select-none"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={thumbnailSrc || SAFE_CAR_PLACEHOLDER}
                alt={entry.carName}
                className="w-full h-auto max-h-[55vh] md:max-h-[65vh] object-contain rounded-2xl shadow-2xl border border-white/10"
                referrerPolicy="no-referrer"
              />
              
              {/* Bottom Label Info in the modal */}
              <div className="w-full mt-4 flex flex-col items-center gap-1 text-center">
                <span className="text-[10px] font-black uppercase tracking-widest text-accent-blue">
                  {entry.carBrand}
                </span>
                <span className="text-sm md:text-base font-bold text-white uppercase tracking-tight">
                  {entry.carName}
                </span>
                {entry.lapTime && (
                  <span className="text-success font-black text-xs md:text-sm font-mono mt-1 px-3 py-1 bg-success/10 border border-success/20 rounded-full">
                    {t('best_lap')}: {entry.lapTime}
                  </span>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function EntryForm({ entry, layout, onSave, onClose, onEditLogo, onDelete, suggestions, userDisplayName, logoOverrides, logosDatabase = [], isTimeTrial }: { 
  entry: Entry | null; 
  layout: LayoutProfile;
  userDisplayName?: string;
  onSave: (data: Omit<Entry, 'id' | 'trackId'>) => void;
  onClose: () => void;
  onEditLogo?: (brand: string, carName: string) => void;
  onDelete?: (id: string) => void;
  suggestions: { brands: string[], carNames: string[], setups: string[] };
  logoOverrides: Record<string, string>;
  logosDatabase?: LogoBrand[];
  isTimeTrial?: boolean;
}) {
  const { t, language } = useLanguage();
  const maskMinutes = (value: string) => {
    let raw = value.replace(/\D/g, '');
    if (raw.length === 0) return '';
    if (raw.length <= 3) return `00:00.${raw.padStart(3, '0')}`;
    if (raw.length <= 5) return `00:${raw.slice(0, -3).padStart(2, '0')}.${raw.slice(-3)}`;
    const m = parseInt(raw.slice(0, -5), 10).toString().padStart(2, '0');
    const s = raw.slice(-5, -3);
    const ms = raw.slice(-3);
    return `${m}:${s}.${ms}`;
  };

  const maskHours = (value: string) => {
    let raw = value.replace(/\D/g, '');
    if (raw.length === 0) return '';
    if (raw.length <= 3) return `0:00:00.${raw.padStart(3, '0')}`;
    if (raw.length <= 5) return `0:00:${raw.slice(0, -3).padStart(2, '0')}.${raw.slice(-3)}`;
    if (raw.length <= 7) return `0:${raw.slice(0, -5).padStart(2, '0')}:${raw.slice(-5, -3)}.${raw.slice(-3)}`;
    const h = parseInt(raw.slice(0, -7), 10);
    const m = raw.slice(-7, -5);
    const s = raw.slice(-5, -3);
    const ms = raw.slice(-3);
    return `${h}:${m}:${s}.${ms}`;
  };
  
  const { telemetry, connectionState } = useTelemetry();

  const [formData, setFormData] = useState<Omit<Entry, 'id' | 'trackId'>>(() => {
    if (entry) {
      const isLapEmpty = (entry.lapTime === '0:00.000' || entry.lapTime === '00:00.000');
      const isTotalEmpty = (entry.totalTime === '0:00:00.000' || entry.totalTime === '00:00:00.000' || entry.totalTime === '00:00.000');
      
      return {
        carBrand: entry.carBrand || '',
        carName: entry.carName || '',
        carSetup: entry.carSetup || '',
        racePosition: entry.racePosition || '1',
        tractionControl: entry.tractionControl || '0',
        carMap: entry.carMap || '1',
        pitStops: entry.pitStops || '0',
        runDate: entry.runDate || new Date().toISOString().split('T')[0],
        weather: entry.weather || 'Clear',
        lapTime: isLapEmpty ? '' : maskMinutes(entry.lapTime),
        totalTime: isTotalEmpty ? '' : maskHours(entry.totalTime),
        provaDeTempo: entry.provaDeTempo || '',
        avgLapTime: entry.avgLapTime || '',
        laps: entry.laps || '0',
        pilot_name: entry.pilot_name || userDisplayName || '',
        transmission: entry.transmission || 'Manual',
        peripheral: entry.peripheral || 'Controle',
        customFields: entry.customFields || {},
        evidence_image: entry.evidence_image || '',
        is_public: entry.is_public !== undefined ? entry.is_public : true,
        velocidade_final: entry.velocidade_final || '',
        telemetria_completa: entry.telemetria_completa || null
      };
    }
    return {
      carBrand: '',
      carName: '',
      carSetup: '',
      racePosition: '1',
      tractionControl: '0',
      carMap: '1',
      pitStops: '0',
      runDate: new Date().toISOString().split('T')[0],
      weather: 'Clear',
      lapTime: '',
      totalTime: '',
      provaDeTempo: '',
      avgLapTime: '',
      laps: '0',
      pilot_name: userDisplayName || '',
      transmission: 'Manual',
      peripheral: 'Controle',
      customFields: {},
      is_public: true,
      velocidade_final: '',
      telemetria_completa: null
    };
  });

  const [isIdentifying, setIsIdentifying] = useState(false);
  const [isCarFocused, setIsCarFocused] = useState(false);
  const [savedThumbs, setSavedThumbs] = useState<string[]>([]);
  const fileInputRefEntry = useRef<HTMLInputElement>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Status de integração do Bridge v1.4.2
  const [bridgeStatus, setBridgeStatus] = useState<'ready' | 'connected' | 'pasted' | 'imported' | 'error'>(() => {
    if ((window as any).__gt7MobileEntry) return 'connected';
    try {
      if (localStorage.getItem('gt7LastMobileEntry')) return 'connected';
    } catch(e) {}
    return 'ready';
  });

  useEffect(() => {
    const handleMobileEntryEvent = (ev: any) => {
      setBridgeStatus('connected');
    };
    window.addEventListener('gt7-mobile-entry', handleMobileEntryEvent);
    return () => {
      window.removeEventListener('gt7-mobile-entry', handleMobileEntryEvent);
    };
  }, []);

  // Update values dynamically matching current telemetry when available
  const manualTotalEdited = useRef(!!(entry && entry.totalTime && entry.totalTime !== ''));

  useEffect(() => {
    manualTotalEdited.current = !!(entry && entry.totalTime && entry.totalTime !== '');
    if (entry) {
      const isLapEmpty = (entry.lapTime === '0:00.000' || entry.lapTime === '00:00.000');
      const isTotalEmpty = (entry.totalTime === '0:00:00.000' || entry.totalTime === '00:00:00.000' || entry.totalTime === '00:00.000');
      setFormData({
        carBrand: entry.carBrand || '',
        carName: entry.carName || '',
        carSetup: entry.carSetup || '',
        racePosition: entry.racePosition || '1',
        tractionControl: entry.tractionControl || '0',
        carMap: entry.carMap || '1',
        pitStops: entry.pitStops || '0',
        runDate: entry.runDate || new Date().toISOString().split('T')[0],
        weather: entry.weather || 'Clear',
        lapTime: isLapEmpty ? '' : maskMinutes(entry.lapTime),
        totalTime: isTotalEmpty ? '' : maskHours(entry.totalTime),
        provaDeTempo: entry.provaDeTempo || '',
        avgLapTime: entry.avgLapTime || '',
        laps: entry.laps || '0',
        pilot_name: entry.pilot_name || userDisplayName || '',
        transmission: entry.transmission || 'Manual',
        peripheral: entry.peripheral || 'Controle',
        customFields: entry.customFields || {},
        evidence_image: entry.evidence_image || '',
        is_public: entry.is_public !== undefined ? entry.is_public : true,
        velocidade_final: entry.velocidade_final || '',
        telemetria_completa: entry.telemetria_completa || null
      });
    }
  }, [entry, userDisplayName]);

  const parseTimeToMs = (timeStr: string): number => {
    if (!timeStr) return 0;
    const cleanStr = timeStr.trim();
    const parts = cleanStr.split(':');
    if (parts.length === 1) {
      const secondsPart = parseFloat(parts[0]);
      return isNaN(secondsPart) ? 0 : Math.round(secondsPart * 1000);
    } else if (parts.length === 2) {
      const minutes = parseInt(parts[0], 10);
      const seconds = parseFloat(parts[1]);
      if (isNaN(minutes) || isNaN(seconds)) return 0;
      return Math.round((minutes * 60 + seconds) * 1000);
    } else if (parts.length === 3) {
      const hours = parseInt(parts[0], 10);
      const minutes = parseInt(parts[1], 10);
      const seconds = parseFloat(parts[2]);
      if (isNaN(hours) || isNaN(minutes) || isNaN(seconds)) return 0;
      return Math.round((hours * 3600 + minutes * 60 + seconds) * 1000);
    }
    return 0;
  };

  const formatMsToTime = (ms: number): string => {
    if (ms <= 0) return '';
    const totalSeconds = Math.floor(ms / 1000);
    const milliseconds = ms % 1000;
    const hours = Math.floor(totalSeconds / 3600);
    const remainSeconds = totalSeconds % 3600;
    const minutes = Math.floor(remainSeconds / 60);
    const seconds = remainSeconds % 60;

    const msStr = milliseconds.toString().padStart(3, '0');
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${msStr}`;
    } else {
      return `${minutes}:${seconds.toString().padStart(2, '0')}.${msStr}`;
    }
  };

  const calculateTotalTimeFromLapAndLaps = (lapTime: string, laps: string | number): string => {
    const lapsNum = typeof laps === 'string' ? parseInt(laps, 10) : laps;
    if (!lapsNum || lapsNum <= 0) return '';
    const lapMs = parseTimeToMs(lapTime);
    if (!lapMs) return '';
    return formatMsToTime(lapMs * lapsNum);
  };

  useEffect(() => {
    if (!manualTotalEdited.current) {
      if (formData.lapTime && formData.laps && parseInt(formData.laps, 10) > 0) {
        const calculated = calculateTotalTimeFromLapAndLaps(formData.lapTime, formData.laps);
        if (calculated) {
          setFormData(prev => ({ ...prev, totalTime: calculated }));
        }
      } else {
        setFormData(prev => ({ ...prev, totalTime: '' }));
      }
    }
  }, [formData.lapTime, formData.laps]);

  useEffect(() => {
    if (telemetry) {
      setFormData(prev => {
        let updatedVel = prev.velocidade_final;
        if (telemetry.speed_kmh !== undefined && telemetry.speed_kmh !== null && telemetry.speed_kmh > 0) {
          updatedVel = prev.velocidade_final && prev.velocidade_final !== '0 km/h' ? prev.velocidade_final : `${Math.round(telemetry.speed_kmh)} km/h`;
        }

        let updatedTotalTime = prev.totalTime;
        const isFinished = telemetry.raceFinished || (telemetry as any).corridaFinalizada === true;
        const totalTimeText = telemetry.total_race_time_text || (telemetry as any).tempoTotalCorrida || (telemetry as any).totalTime;
        
        if (isFinished && totalTimeText && totalTimeText !== '--' && !manualTotalEdited.current) {
          updatedTotalTime = maskHours(totalTimeText);
        }

        const voltasCorrigidas = Math.max(0, (telemetry.completed_laps || 0) - 1);
        const lapsTarget = parseInt(prev.laps, 10);
        if (lapsTarget > 0 && voltasCorrigidas >= lapsTarget && totalTimeText && totalTimeText !== '--' && !manualTotalEdited.current) {
          updatedTotalTime = maskHours(totalTimeText);
        }

        return {
          ...prev,
          velocidade_final: updatedVel,
          totalTime: updatedTotalTime,
          telemetria_completa: prev.telemetria_completa || telemetry
        };
      });
    }
  }, [telemetry]);

  const [copiedField, setCopiedField] = useState<string | null>(null);

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedField(fieldName);
      setTimeout(() => setCopiedField(null), 1500);
    }).catch(() => {
      const input = document.createElement('input');
      input.value = text;
      document.body.appendChild(input);
      input.select();
      try {
        document.execCommand('copy');
        setCopiedField(fieldName);
        setTimeout(() => setCopiedField(null), 1500);
      } catch (err) {}
      document.body.removeChild(input);
    });
  };

  const renderCopyButton = (value: string | undefined | null, fieldName: string) => {
    return null;
  };

  const copyAllFields = () => {
    const weathers: Record<string, string> = {
      'Clear': 'Sol',
      'Cloudy': 'Nublado',
      'Light Rain': 'Chuva Leve',
      'Heavy Rain': 'Chuva Forte'
    };
    const clima = weathers[formData.weather] || formData.weather || 'Sol';
    const transStr = formData.transmission === 'Automatic' ? 'Automática' : 'Manual';
    const periStr = formData.peripheral === 'Wheel' ? 'Volante' : (formData.peripheral === 'Controller' || formData.peripheral === 'Controle' ? 'Controle' : formData.peripheral || 'Controle');

    let formattedDate = formData.runDate;
    if (formData.runDate && formData.runDate.includes('-')) {
       const parts = formData.runDate.split('-');
       if (parts.length === 3) {
          formattedDate = `${parts[2]}/${parts[1]}/${parts[0]}`;
       }
    }

    const text = `Marca: ${formData.carBrand || ''}
Carro: ${formData.carName || ''}
Pneus / Configuração: ${formData.carSetup || ''}
Posição: ${formData.racePosition || '1'}
CT: ${formData.tractionControl || '0'}
Mapeamento: ${formData.carMap || '1'}
Melhor Volta: ${formData.lapTime || '--:--.---'}
Tempo Total: ${formData.totalTime || '--:--.---'}
Data: ${formattedDate || ''}
Clima: ${clima}
Transmissão: ${transStr}
Periférico: ${periStr}
Pits: ${formData.pitStops || '0'}
Voltas: ${formData.laps || '1'}
Driver: ${formData.pilot_name || 'rAd'}
Velocidade Final: ${formData.velocidade_final || '0 km/h'}`;

    copyToClipboard(text, 'all_fields');
    setBridgeStatus('pasted');
    setTimeout(() => setBridgeStatus('imported'), 1500);
  };

  const handleClearPastedData = () => {
    setFormData(prev => ({
      ...prev,
      racePosition: '1',
      tractionControl: '0',
      carMap: '1',
      lapTime: '',
      totalTime: '',
      weather: 'Clear',
      pitStops: '0',
      laps: '0',
      velocidade_final: '',
      telemetria_completa: null,
      customFields: {}
    }));
    setBridgeStatus('ready');
    alert('Dados limpos com sucesso.');
  };

  const parseRawTextBridge = (str: string): any => {
    const result: any = {
      marca: '',
      carro: '',
      pneus_configuracao: '',
      posicao: '1',
      melhor_volta: '',
      tempo_total: '',
      voltas: '1',
      velocidade_final: ''
    };

    if (!str) return result;

    const lines = str.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    let hasKeyWordMatch = false;

    // First try: key-value semantic parsing matching known terms
    for (const line of lines) {
      if (!line) continue;
      
      // Look for custom separator: either colon or semicolon
      let sepIdx = line.indexOf(':');
      if (sepIdx === -1) {
        sepIdx = line.indexOf(';');
      }

      if (sepIdx !== -1) {
        const label = line.substring(0, sepIdx).trim().toLowerCase();
        let val = line.substring(sepIdx + 1).trim();

        if (label && val) {
          // If the value ends with a semicolon or period, trim it
          if (val.endsWith(';')) val = val.slice(0, -1).trim();
          if (val.endsWith('.')) val = val.slice(0, -1).trim();

          if (label.includes('marca') || label === 'brand') {
            result.marca = val;
            hasKeyWordMatch = true;
          } else if (label.includes('carro') || label === 'car' || label === 'carname') {
            result.carro = val;
            hasKeyWordMatch = true;
          } else if (label.includes('pneus') || label.includes('config') || label.includes('setup')) {
            result.pneus_configuracao = val;
            hasKeyWordMatch = true;
          } else if (label.includes('posição') || label.includes('posicao') || label === 'pos' || label.includes('position')) {
            result.posicao = val;
            hasKeyWordMatch = true;
          } else if (label.includes('melhor') || label.includes('lap') || label.includes('volta')) {
            result.melhor_volta = val;
            hasKeyWordMatch = true;
          } else if (label.includes('tempo total') || label.includes('tempototal') || label.includes('totaltime') || label === 'total time') {
            result.tempo_total = val;
            hasKeyWordMatch = true;
          } else if (label.includes('voltas') || label === 'laps') {
            result.voltas = val;
            hasKeyWordMatch = true;
          } else if (label.includes('velocidade') || label.includes('speed') || label.includes('vel')) {
            result.velocidade_final = val;
            hasKeyWordMatch = true;
          }
        }
      } else {
        // Line has no separator, check if it starts with space-separated keyword
        const spaceIdx = line.indexOf(' ');
        if (spaceIdx !== -1) {
          const potentialKey = line.substring(0, spaceIdx).toLowerCase();
          const value = line.substring(spaceIdx + 1).trim();
          if (potentialKey === 'marca' || potentialKey === 'brand') {
            result.marca = value;
            hasKeyWordMatch = true;
          } else if (potentialKey === 'carro' || potentialKey === 'car') {
            result.carro = value;
            hasKeyWordMatch = true;
          } else if (potentialKey === 'posição' || potentialKey === 'posicao' || potentialKey === 'pos') {
            result.posicao = value;
            hasKeyWordMatch = true;
          } else if (potentialKey === 'voltas' || potentialKey === 'laps') {
            result.voltas = value;
            hasKeyWordMatch = true;
          }
        }
      }
    }

    // Second try (Fallback): Positional parsing when there are no semantic labels
    // We split by semicolon first, otherwise we split by newlines.
    if (!hasKeyWordMatch) {
      let tokens: string[] = [];
      if (str.includes(';')) {
        tokens = str.split(';').map(t => t.trim()).filter(Boolean);
      } else {
        tokens = lines;
      }

      // Expected positional sequence:
      // 1. Marca
      // 2. Carro
      // 3. Pneus / Configuração
      // 4. Posição
      // 5. Melhor Volta
      // 6. Tempo Total
      // 7. Voltas
      // 8. Velocidade Final
      if (tokens.length >= 1) result.marca = tokens[0];
      if (tokens.length >= 2) result.carro = tokens[1];
      if (tokens.length >= 3) result.pneus_configuracao = tokens[2];
      if (tokens.length >= 4) result.posicao = tokens[3];
      if (tokens.length >= 5) result.melhor_volta = tokens[4];
      if (tokens.length >= 6) result.tempo_total = tokens[5];
      if (tokens.length >= 7) result.voltas = tokens[6];
      if (tokens.length >= 8) {
        let speed = tokens[7];
        if (speed.endsWith('.')) {
          speed = speed.slice(0, -1).trim();
        }
        result.velocidade_final = speed;
      }
    }

    return result;
  };

  const normalizeBridgeEntry = (input: any) => {
    let data = input;
    if (typeof input === 'string') {
      try {
        const match = input.match(/\{[\s\S]*schema["\s:]+["'](gt7_entry_v1_4_2|gt7_entry_v1_4_1|gt7_entry_v1)["'][\s\S]*\}/) || input.match(/\{[\s\S]*\}/);
        if (match) {
            data = JSON.parse(match[0]);
        } else {
            data = JSON.parse(input);
        }
      } catch(e) { 
        data = parseRawTextBridge(input); 
      }
    }
    if (!data) return null;
    
    // Clean unwanted entries from incoming telemetry as required: "remove_from_clean_telemetry"
    const removeKeys = ["chuva", "controleTracao", "controleTracaoAtivo", "tcs", "tcsActive"];
    removeKeys.forEach(k => {
      delete data[k];
      if (data.telemetry) delete data.telemetry[k];
      if (data.telemetria_completa) delete data.telemetria_completa[k];
      if (data.rawTelemetry) delete data.rawTelemetry[k];
    });

    if (data.schema !== 'gt7_entry_v1_4_2' && data.schema !== 'gt7_entry_v1_4_1' && data.schema !== 'gt7_entry_v1') {
       if (!data.marca && !data.carro && data.posicao === undefined) return null;
    }
    return data;
  };

  const applyBridgeEntryToNewRecord = (brEntry: any) => {
    if (!brEntry) {
      setBridgeStatus('error');
      alert('JSON inválido ou incompatível com GT7 Bridge.');
      return;
    }
    
    const getMappedValue = (obj: any, keys: string[], fallback: any) => {
      if (!obj) return fallback;
      for (const key of keys) {
        if (obj[key] !== undefined && obj[key] !== null) {
          return obj[key];
        }
      }
      if (obj.telemetry && typeof obj.telemetry === 'object') {
        for (const key of keys) {
          if (obj.telemetry[key] !== undefined && obj.telemetry[key] !== null) {
            return obj.telemetry[key];
          }
        }
      }
      if (obj.telemetria_completa && typeof obj.telemetria_completa === 'object') {
        for (const key of keys) {
          if (obj.telemetria_completa[key] !== undefined && obj.telemetria_completa[key] !== null) {
            return obj.telemetria_completa[key];
          }
        }
      }
      return fallback;
    };

    setFormData(prev => {
      const newData = { ...prev };
      
      const pos = getMappedValue(brEntry, ["posicao", "position_finish", "finishPosition"], undefined);
      if (pos !== undefined && pos !== null) newData.racePosition = String(pos);

      const tcVal = getMappedValue(brEntry, ["ct", "controle_tracao_manual"], undefined);
      if (tcVal !== undefined && tcVal !== null) newData.tractionControl = String(tcVal);

      const mapVal = getMappedValue(brEntry, ["mapeamento", "fuelMap", "mapa_combustivel"], undefined);
      if (mapVal !== undefined && mapVal !== null) newData.carMap = String(mapVal);

      const datVal = getMappedValue(brEntry, ["data", "date"], undefined);
      if (datVal && typeof datVal === 'string' && datVal.includes('/')) {
         const parts = datVal.split('/');
         if (parts.length === 3) {
            const [d, m, y] = parts;
            newData.runDate = `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
         }
      } else if (datVal && typeof datVal === 'string' && datVal.includes('-')) {
         newData.runDate = datVal;
      }

      const cliVal = getMappedValue(brEntry, ["clima", "weather"], undefined);
      if (cliVal && cliVal.trim() !== '') {
          if (cliVal.toLowerCase() === 'sol' || cliVal.toLowerCase() === 'clear') {
              newData.weather = 'Clear';
          } else if (cliVal.toLowerCase() === 'nublado' || cliVal.toLowerCase() === 'cloudy') {
              newData.weather = 'Cloudy';
          } else if (cliVal.toLowerCase() === 'chuva leve' || cliVal.toLowerCase() === 'light rain') {
              newData.weather = 'Light Rain';
          } else if (cliVal.toLowerCase() === 'chuva forte' || cliVal.toLowerCase() === 'heavy rain') {
              newData.weather = 'Heavy Rain';
          } else {
              newData.weather = cliVal;
          }
      }

      const transVal = getMappedValue(brEntry, ["transmissao", "transmission"], undefined);
      if (transVal && transVal.trim() !== '') {
          if (transVal.toLowerCase() === 'manual') newData.transmission = 'Manual';
          else if (transVal.toLowerCase() === 'automática' || transVal.toLowerCase() === 'automatic_transmission' || transVal.toLowerCase() === 'automatic') newData.transmission = 'Automatic';
          else newData.transmission = transVal;
      }

      const pitVal = getMappedValue(brEntry, ["pits", "pitStops", "numeroParadas"], undefined);
      if (pitVal !== undefined && pitVal !== null) newData.pitStops = String(pitVal);

      const voltasVal = getMappedValue(brEntry, ["voltas", "laps", "voltasCompletadas"], undefined);
      if (voltasVal !== undefined && voltasVal !== null) newData.laps = String(voltasVal);

      const driverVal = getMappedValue(brEntry, ["driver", "piloto"], undefined);
      if (driverVal && driverVal.trim() !== '') newData.pilot_name = driverVal;

      const melLapVal = getMappedValue(brEntry, ["melhor_volta", "melhorVolta", "bestLap"], undefined);
      if (melLapVal && melLapVal !== '--') newData.lapTime = maskMinutes(String(melLapVal));

      const ttVal = getMappedValue(brEntry, ["tempo_total", "tempoTotalCorrida", "totalTime"], undefined);
      if (ttVal && ttVal !== '--') newData.totalTime = maskHours(String(ttVal));

      const brandVal = getMappedValue(brEntry, ["marca", "brand"], undefined);
      if (brandVal && brandVal.trim() !== '') newData.carBrand = brandVal;

      const carNameVal = getMappedValue(brEntry, ["carro", "car", "carName"], undefined);
      if (carNameVal && carNameVal.trim() !== '') newData.carName = carNameVal;

      const setupVal = getMappedValue(brEntry, ["pneus_configuracao", "carSetup"], undefined);
      if (setupVal && setupVal.trim() !== '') newData.carSetup = setupVal;

      const evVal = getMappedValue(brEntry, ["evidence_image"], undefined);
      if (evVal && evVal.trim() !== '') newData.evidence_image = evVal;

      const tcValCompleta = getMappedValue(brEntry, ["telemetria_completa", "telemetry", "rawTelemetry"], undefined);
      if (tcValCompleta) newData.telemetria_completa = tcValCompleta;

      const velFinalVal = getMappedValue(brEntry, ["velocidade_final"], undefined);
      if (velFinalVal && velFinalVal.trim() !== '') {
          newData.velocidade_final = velFinalVal;
      } else {
          const tSpeed = getMappedValue(brEntry, ["velocidade"], undefined);
          if (tSpeed !== undefined && tSpeed !== null) {
              newData.velocidade_final = `${tSpeed} km/h`;
          } else if (newData.telemetria_completa && newData.telemetria_completa.velocidade) {
              newData.velocidade_final = `${newData.telemetria_completa.velocidade} km/h`;
          } else if (telemetry && telemetry.speed_kmh) {
              newData.velocidade_final = `${Math.round(telemetry.speed_kmh)} km/h`;
          }
      }

      return newData;
    });
    
    setBridgeStatus('imported');
    alert('Dados importados do Bridge com sucesso.');
  };

  const handlePasteBridgeData = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        const entry = normalizeBridgeEntry(text);
        applyBridgeEntryToNewRecord(entry);
      } else {
        const text = prompt('Cole aqui os dados do JSON copiados do Bridge:');
        if (text) {
          const entry = normalizeBridgeEntry(text);
          applyBridgeEntryToNewRecord(entry);
        }
      }
    } catch(err) {
      const text = prompt('O navegador bloqueou a área de transferência. Cole aqui os dados do JSON:');
      if (text) {
        const entry = normalizeBridgeEntry(text);
        applyBridgeEntryToNewRecord(entry);
      }
    }
  };

  const handleImportLastBridgeData = () => {
    let dataStr = null;
    if ((window as any).__gt7MobileEntry) {
       applyBridgeEntryToNewRecord((window as any).__gt7MobileEntry);
       return;
    }
    
    try {
      dataStr = localStorage.getItem('gt7LastMobileEntry');
    } catch(e) {}
    
    if (dataStr) {
      applyBridgeEntryToNewRecord(normalizeBridgeEntry(dataStr));
    } else {
      setBridgeStatus('error');
      alert('Nenhum dado recente do APK Bridge foi encontrado no seu dispositivo.');
    }
  };

  // AI-powered dynamic car image preview state
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewSource, setPreviewSource] = useState<'Database' | 'AI Search' | 'Searching' | 'None'>('None');
  const [previewError, setPreviewError] = useState(false);

  useEffect(() => {
    const trimmed = formData.carName.trim();
    if (!trimmed || trimmed.length < 3) {
      setPreviewUrl(null);
      setPreviewSource('None');
      setPreviewError(false);
      return;
    }

    // 1. Try local database matching first
    const localMatch = findCarByName(trimmed);
    if (localMatch) {
      const src = getMatchedThumbnailSrc(trimmed);
      if (src && !src.endsWith('placeholder.webp')) {
        setPreviewUrl(src);
        setPreviewSource('Database');
        setPreviewError(false);
        return;
      }
    }

    // 2. Otherwise fall back to debounced AI Image Search proxy
    setPreviewSource('Searching');
    setPreviewError(false);

    const timer = setTimeout(async () => {
      try {
        const response = await fetch(`/api/search-car-image?carName=${encodeURIComponent(trimmed)}`);
        if (!response.ok) {
          throw new Error('Failed to fetch AI car image search results');
        }
        const data = await response.json();
        if (data.imageUrl) {
          setPreviewUrl(data.imageUrl);
          setPreviewSource('AI Search');
        } else {
          setPreviewUrl(null);
          setPreviewSource('None');
        }
      } catch (err) {
        console.error("AI image search failed:", err);
        setPreviewUrl(null);
        setPreviewSource('None');
        setPreviewError(true);
      }
    }, 700);

    return () => clearTimeout(timer);
  }, [formData.carName]);

  const handlePreviewError = () => {
    // Self-healing fallback: if local database image fails to load (e.g. 404),
    // automatically trigger server-side AI web image search.
    if (previewSource === 'Database') {
      const trimmed = formData.carName.trim();
      setPreviewSource('Searching');
      fetch(`/api/search-car-image?carName=${encodeURIComponent(trimmed)}`)
        .then(res => res.json())
        .then(data => {
          if (data.imageUrl) {
            setPreviewUrl(data.imageUrl);
            setPreviewSource('AI Search');
          } else {
            setPreviewUrl(null);
            setPreviewSource('None');
          }
        })
        .catch(err => {
          console.error("Fallback AI image search failed:", err);
          setPreviewUrl(null);
          setPreviewSource('None');
          setPreviewError(true);
        });
    } else {
      setPreviewError(true);
    }
  };

  useEffect(() => {
    setSavedThumbs(getCachedThumbs());
    return subscribeToThumbs(() => {
      setSavedThumbs(getCachedThumbs());
    });
  }, []);

  const carMatchQuery = formData.carName.trim().toLowerCase();
  const matchingCars = useMemo(() => {
    if (!carMatchQuery) return [];
    
    const searchWords = carMatchQuery.replace(/['"()]/g, '').split(/[\s_\-%/]+/).filter(Boolean);
    
    return (suggestions?.carNames || [])
      .filter(name => {
         const dbName = name.toLowerCase();
         if (dbName.includes(carMatchQuery)) return true;
         
         const dbWords = dbName.replace(/['"()]/g, '').split(/[\s_\-%/]+/).filter(Boolean);
         return searchWords.length > 0 && searchWords.every(sw => dbWords.some(dw => dw.includes(sw) || sw.includes(dw)));
      })
      .slice(0, 10);
  }, [carMatchQuery, suggestions?.carNames]);

  const matchingCustomThumbs = useMemo(() => {
    if (!carMatchQuery) return [];
    
    const searchWords = carMatchQuery.replace(/['"()]/g, '').split(/[\s_\-%/]+/).filter(Boolean);
    
    return savedThumbs
      .filter(name => {
         const dbName = name.toLowerCase();
         if (dbName.includes(carMatchQuery)) return true;
         
         const dbWords = dbName.replace(/['"()]/g, '').split(/[\s_\-%/]+/).filter(Boolean);
         return searchWords.length > 0 && searchWords.every(sw => dbWords.some(dw => dw.includes(sw) || sw.includes(dw)));
      })
      .slice(0, 6);
  }, [carMatchQuery, savedThumbs]);

  const selectCar = (carName: string) => {
    setFormData(prev => ({ ...prev, carName }));
    setIsCarFocused(false);
    handleAutoIdentify(carName);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione uma imagem válida (PNG, JPG).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('A imagem é muito grande. O limite é 5MB.');
      return;
    }

    setIsUploadingImage(true);
    try {
      const publicUrl = await supabaseService.uploadEvidenceImage(file);
      setFormData(prev => ({ ...prev, evidence_image: publicUrl }));
    } catch (error: any) {
      console.error('Erro no upload:', error);
      alert('Erro ao enviar imagem: ' + (error.message || 'Erro desconhecido.'));
    } finally {
      setIsUploadingImage(false);
      if (fileInputRefEntry.current) fileInputRefEntry.current.value = '';
    }
  };

  useEffect(() => {
    if (!formData.pilot_name && userDisplayName) {
      setFormData(prev => ({ ...prev, pilot_name: userDisplayName }));
    }
  }, [userDisplayName, formData.pilot_name]);

  const handleAutoIdentify = async (name: string) => {
    if (!name || name.length < 3) return;
    
    // 1. Tentar banco local primeiro
    const localMatch = findCarByName(name);
    if (localMatch) {
      setFormData(prev => ({ ...prev, carBrand: localMatch.brand_name }));
      return;
    }

    // 2. Tentar IA
    setIsIdentifying(true);
    const identifiedBrand = await identifyCarBrand(name);
    if (identifiedBrand) {
      setFormData(prev => ({ ...prev, carBrand: identifiedBrand }));
    }
    setIsIdentifying(false);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-accent-blue/40 backdrop-blur-sm p-4"
    >
      <motion.div 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        exit={{ y: 100 }}
        className="bg-bg-card w-full max-w-md rounded-t-[32px] sm:rounded-[32px] overflow-hidden shadow-2xl flex flex-col max-h-[90vh] border border-accent-light"
      >
        <datalist id="brands-list">
          {suggestions.brands.map((b, idx) => <option key={`brand-${idx}-${b}`} value={b} />)}
        </datalist>
        <datalist id="cars-list">
          {suggestions.carNames.map((c, idx) => <option key={`car-${idx}-${c}`} value={c} />)}
        </datalist>
        <datalist id="setups-list">
          {suggestions.setups.map((s, idx) => <option key={`setup-${idx}-${s}`} value={s} />)}
        </datalist>

        <div className="px-6 py-6 border-b border-accent-light flex items-center justify-between">
          <h3 className="font-bold text-xl text-ink-primary">{entry ? t('edit_entry') : t('new_entry')}</h3>
          <div className="flex items-center gap-2">
            {entry && (
              <button 
                onClick={() => {
                  if (confirm(t('delete_entry_confirm'))) {
                    onDelete?.(entry.id);
                    onClose();
                  }
                }} 
                className="p-2 text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
                title={t('delete_entry')}
              >
                <Trash2 size={20} />
              </button>
            )}
            <button onClick={onClose} className="text-ink-secondary font-bold text-xs uppercase tracking-widest hover:text-ink-primary transition-colors ml-2">{t('cancel')}</button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="flex flex-col gap-2 bg-accent-blue/5 border border-accent-blue/20 rounded-[20px] p-3 text-center">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[9px] uppercase font-black tracking-widest text-accent-blue">Integração GT7 Bridge v1.4.2</span>
            </div>
            
            <button 
              type="button"
              onClick={() => {
                window.location.href = 'gt7bridge://open';
                setTimeout(() => alert('APK não abriu. Instale ou atualize o GT7 Online Mobile APK.'), 1500);
              }}
              className="w-full bg-accent-blue text-white hover:bg-accent-blue/80 font-bold text-[10px] uppercase tracking-widest py-2 px-3 rounded-[10px] transition-colors flex items-center justify-center gap-1 animate-none"
            >
              Abrir GT7 Online Mobile APK
            </button>
            
            <div className="grid grid-cols-3 gap-1.5">
              <button 
                type="button"
                onClick={handlePasteBridgeData}
                className="border border-accent-blue/30 text-accent-blue bg-white dark:bg-bg-cell hover:bg-accent-blue/10 font-bold text-[9px] uppercase tracking-tight py-2 px-1.5 rounded-[8px] transition-all flex items-center justify-center gap-1"
              >
                <Download size={11} /> Colar dados
              </button>
              <button 
                type="button"
                onClick={handleImportLastBridgeData}
                className="border border-accent-blue/30 text-accent-blue bg-white dark:bg-bg-cell hover:bg-accent-blue/10 font-bold text-[9px] uppercase tracking-tight py-2 px-1.5 rounded-[8px] transition-all flex items-center justify-center gap-1"
              >
                <Zap size={11} /> Importar dados
              </button>
              <button 
                type="button"
                onClick={handleClearPastedData}
                className="border border-red-500/30 text-red-500 bg-white dark:bg-bg-cell hover:bg-red-500/10 font-bold text-[9px] uppercase tracking-tight py-2 px-1.5 rounded-[8px] transition-all flex items-center justify-center gap-1"
              >
                <Trash2 size={11} /> Limpar
              </button>
            </div>

            <p className={`text-[10px] font-bold text-center mt-2 ${
              bridgeStatus === 'error' ? 'text-red-500' :
              bridgeStatus === 'imported' ? 'text-emerald-500' :
              bridgeStatus === 'connected' || bridgeStatus === 'pasted' ? 'text-accent-blue font-black' :
              'text-ink-secondary/60'
            }`}>
              {bridgeStatus === 'ready' ? 'Aguardando dados do Bridge Mobile' :
               bridgeStatus === 'connected' ? 'Bridge Mobile conectado' :
               bridgeStatus === 'pasted' ? 'Dados do Bridge colados' :
               bridgeStatus === 'imported' ? 'Novo Registro preenchido com dados do Bridge' :
               'Não foi possível importar os dados. Verifique o JSON copiado.'}
            </p>
          </div>

          <div className="space-y-1.5 focus-within:text-accent-blue transition-colors">
            <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('brand')}</label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input 
                  type="text" 
                  list="brands-list"
                  value={formData.carBrand}
                  onChange={e => setFormData({...formData, carBrand: e.target.value})}
                  placeholder="Ex: Porsche"
                  className="w-full bg-bg-cell border border-accent-light rounded-[20px] pl-4 pr-10 py-3 text-sm font-black focus:outline-none focus:border-accent-blue transition-colors"
                />
                {(() => {
                  const logoFile = resolveLogoLocal(formData.carName, formData.carBrand, logoOverrides, logosDatabase);
                  const logoUrl = getLogoUrl(logoFile);
                  if (!logoUrl) return null;

                  return (
                    <button 
                      type="button"
                      onClick={() => onEditLogo?.(formData.carBrand, formData.carName)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-bg-cell rounded-[12px] p-1 shadow-sm border border-accent-light/50 hover:border-accent-blue transition-colors group"
                      title="Mudar Logo"
                    >
                      <img 
                        src={logoUrl} 
                        alt="Logo" 
                        className="max-w-full max-h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-accent-blue/10 opacity-0 group-hover:opacity-100 rounded-lg flex items-center justify-center transition-opacity">
                        <Edit2 size={10} className="text-accent-blue" />
                      </div>
                    </button>
                  );
                })()}
              </div>
            </div>
          </div>
          <div className="space-y-1.5 focus-within:text-accent-blue transition-colors">
            <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('car')}</label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input 
                  type="text" 
                  value={formData.carName}
                  onChange={e => setFormData({...formData, carName: e.target.value})}
                  onFocus={() => setIsCarFocused(true)}
                  onBlur={() => {
                    // Small delay to allow onMouseDown event of suggestions to register first
                    setTimeout(() => {
                      setIsCarFocused(false);
                      handleAutoIdentify(formData.carName);
                    }, 250);
                  }}
                  placeholder="Ex: 911 GT3 RS"
                  className="w-full bg-bg-cell border border-accent-light rounded-[20px] px-4 py-3 text-sm font-black focus:outline-none focus:border-accent-blue transition-colors"
                />
                {isIdentifying && (
                  <div className="absolute right-2 top-1/2 -translate-y-1/2">
                    <div className="w-4 h-4 border-2 border-accent-blue border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
                {isCarFocused && (matchingCars.length > 0 || matchingCustomThumbs.length > 0) && (
                  <div className="absolute left-0 right-0 z-50 mt-1 max-h-72 overflow-y-auto bg-bg-card border border-accent-light rounded-2xl shadow-xl backdrop-blur-md divide-y divide-accent-light/40 flex flex-col">
                    {/* Section 1: Matching Custom Thumbnails */}
                    {matchingCustomThumbs.length > 0 && (
                      <div className="p-2 bg-bg-cell/40">
                        <div className="flex items-center gap-1 px-2 py-1 text-[9px] font-black uppercase tracking-widest text-accent-blue mb-1.5">
                          <ImageIcon size={10} />
                          {language === 'pt' ? 'Miniaturas Salvas Correspondentes' : 'Matching Saved Thumbnails'}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {matchingCustomThumbs.map((name, idx) => {
                            return (
                              <button
                                key={`${name}_${idx}`}
                                type="button"
                                onMouseDown={() => selectCar(name)}
                                className="bg-bg-card border border-accent-light/40 rounded-xl p-1.5 flex items-center gap-2 hover:border-accent-blue hover:shadow-sm text-left transition-all active:scale-[0.98] outline-none"
                              >
                                <div className="w-10 h-7 bg-bg-cell rounded-md overflow-hidden flex items-center justify-center p-0.5 shrink-0">
                                  <CarThumbnailImg 
                                    carName={name}
                                    className="w-full h-full object-contain mix-blend-multiply"
                                    onError={(e: any) => { e.currentTarget.src = SAFE_CAR_PLACEHOLDER; }}
                                  />
                                </div>
                                <span className="text-[10px] font-black text-ink-primary line-clamp-2 leading-none truncate flex-1 select-none">
                                  {name}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Section 2: Standard Database Suggestions */}
                    {matchingCars.length > 0 && (
                      <div className="flex flex-col divide-y divide-accent-light/30">
                        {matchingCustomThumbs.length > 0 && (
                          <div className="px-3 py-1 bg-bg-cell/20 text-[8px] font-bold uppercase tracking-wider text-ink-secondary/60">
                            {language === 'pt' ? 'Catálogo Geral GT7' : 'GT7 Car Catalog'}
                          </div>
                        )}
                        {matchingCars.map((carName, idx) => {
                          const localMatch = findCarByName(carName);
                          const brandName = localMatch?.brand_name || '';
                          const hasSavedThumb = savedThumbs.includes(carName);

                          return (
                            <button
                              key={`${carName}_${idx}`}
                              type="button"
                              onMouseDown={() => selectCar(carName)}
                              className="w-full text-left px-3 py-2.5 hover:bg-accent-blue/10 transition-all duration-150 flex items-center justify-between text-xs font-black text-ink-primary"
                            >
                              <div className="flex items-center gap-2 min-w-0 flex-1">
                                {hasSavedThumb && (
                                  <div className="w-6 h-4 bg-bg-cell rounded overflow-hidden flex items-center justify-center p-0.5 border border-accent-light/40 shrink-0">
                                    <CarThumbnailImg 
                                      carName={carName}
                                      className="w-full h-full object-contain mix-blend-multiply"
                                      onError={(e: any) => { e.currentTarget.src = SAFE_CAR_PLACEHOLDER; }}
                                    />
                                  </div>
                                )}
                                <span className="truncate min-w-0">{carName}</span>
                              </div>
                              {brandName && (
                                <span className="text-[9px] uppercase tracking-widest text-ink-secondary/60 bg-accent-light/10 px-1.5 py-0.5 rounded ml-2 shrink-0">
                                  {brandName}
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
              <button 
                
                className="p-3 bg-bg-cell border border-accent-light text-ink-primary hover:text-accent-blue rounded-[20px] transition-all shadow-sm active:scale-95 shrink-0"
                title="Pin Car"
              >
                <Save size={18} className="stroke-[2.5px]" />
              </button>
            </div>
          </div>

          {/* AI and Database-powered Responsive Car Image Preview */}
          {previewSource !== 'None' && (
            <div className="border border-accent-light bg-bg-cell/50 rounded-[24px] p-3 transition-all space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1 flex items-center gap-1">
                  <ImageIcon size={10} className="text-accent-blue" />
                  {language === 'pt' ? 'Visualização do Veículo' : 'Vehicle Visual Preview'}
                </span>
                
                {previewSource === 'Searching' ? (
                  <span className="text-[9px] px-2 py-0.5 rounded-full font-bold bg-accent-blue/10 text-accent-blue flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-accent-blue rounded-full animate-ping" />
                    {language === 'pt' ? 'Buscando via IA...' : 'Searching via AI...'}
                  </span>
                ) : (
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                    previewSource === 'Database' 
                      ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' 
                      : 'bg-accent-blue/10 text-accent-blue border border-accent-blue/20'
                  }`}>
                    {previewSource === 'Database' 
                      ? (language === 'pt' ? 'Banco de Dados' : 'Database Car') 
                      : (language === 'pt' ? 'Busca Web via IA' : 'AI Web Search')
                    }
                  </span>
                )}
              </div>

              {previewSource === 'Searching' ? (
                <div className="w-full h-32 bg-bg-cell rounded-2xl flex flex-col items-center justify-center border border-accent-light/40 space-y-2">
                  <div className="w-6 h-6 border-2 border-accent-blue border-t-transparent rounded-full animate-spin" />
                  <span className="text-[10px] font-bold text-ink-secondary">
                    {language === 'pt' ? 'Identificando e localizando imagem...' : 'Identifying and locating image...'}
                  </span>
                </div>
              ) : previewError || !previewUrl ? (
                <div className="w-full h-24 bg-bg-cell rounded-2xl flex flex-col items-center justify-center border border-accent-light/40 text-center px-4">
                  <span className="text-[10px] font-bold text-ink-secondary text-ink-secondary/50">
                    {language === 'pt' ? 'Nenhuma imagem disponível para visualização.' : 'No preview image available.'}
                  </span>
                </div>
              ) : (
                <div className="relative group overflow-hidden bg-bg-cell rounded-2xl border border-accent-light/40 flex flex-col items-center justify-center p-2 min-h-36">
                  <img 
                    src={previewUrl} 
                    alt={formData.carName}
                    onError={handlePreviewError}
                    className="max-h-36 w-full object-contain mix-blend-normal rounded-xl transition-transform group-hover:scale-102 duration-300"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Option to set this image as layout evidence */}
                  <div className="absolute bottom-2 right-2 left-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        setFormData(prev => ({ ...prev, evidence_image: previewUrl || undefined }));
                      }}
                      className={`text-[10px] font-black uppercase tracking-wider px-3 py-1.5 rounded-xl shadow-md border transition-all ${
                        formData.evidence_image === previewUrl
                          ? 'bg-emerald-500 border-emerald-600 text-white'
                          : 'bg-bg-card border-accent-light text-ink-primary hover:border-accent-blue hover:text-accent-blue bg-bg-cell'
                      }`}
                    >
                      {formData.evidence_image === previewUrl
                        ? (language === 'pt' ? '✓ Definido como Evidência' : '✓ Set as Evidence')
                        : (language === 'pt' ? 'Usar como Evidência' : 'Use as Evidence')
                      }
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="space-y-1.5 focus-within:text-accent-blue transition-colors">
            <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('tires_setup')}</label>
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <input 
                  type="text" 
                  list="setups-list"
                  value={formData.carSetup}
                  onChange={e => setFormData({...formData, carSetup: e.target.value})}
                  placeholder="Ex: Racing Soft"
                  className="w-full bg-bg-cell border border-accent-light rounded-[20px] px-4 py-3 text-sm font-black focus:outline-none focus:border-accent-blue transition-colors"
                />
              </div>
              <button 
                
                className="p-3 bg-bg-cell border border-accent-light text-ink-primary hover:text-accent-blue rounded-[20px] transition-all shadow-sm active:scale-95 shrink-0"
                title="Fixar Setup"
              >
                <Save size={18} className="stroke-[2.5px]" />
              </button>
              <button 
                onClick={() => {

                }}
                className="p-3 bg-bg-cell border border-accent-light text-ink-secondary hover:text-accent-blue rounded-[20px] transition-all shadow-sm active:scale-95 shrink-0"
                title="Carregar"
              >
                <Download size={18} />
              </button>
            </div>
          </div>

          {/* Quarta Linha: PP (Campo Dinâmico se existir) */}
          {(() => {
            const ppField = (layout.customFields || []).find(f => f.label.toUpperCase().trim() === 'PP');
            if (!ppField) return null;
            return (
              <div className="space-y-1.5 focus-within:text-accent-blue transition-colors">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">PP</label>
                <input 
                  type="text" 
                  value={formData.customFields?.[ppField.id] || ''}
                  onChange={e => setFormData({
                    ...formData, 
                    customFields: { ...formData.customFields, [ppField.id]: e.target.value }
                  })}
                  placeholder="Valor para PP"
                  className="w-full bg-bg-cell border border-accent-light rounded-[20px] px-4 py-3 text-sm font-black focus:outline-none focus:border-accent-blue transition-colors"
                />
              </div>
            );
          })()}

          <div className={`grid ${isTimeTrial ? 'grid-cols-2' : 'grid-cols-3'} gap-4`}>
            {!isTimeTrial && (
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('position')}</label>
                <div className="flex items-center gap-1.5">
                  <select 
                    value={formData.racePosition}
                    onChange={e => setFormData({...formData, racePosition: e.target.value})}
                    className="flex-1 bg-bg-cell border border-accent-light rounded-[20px] px-4 py-3 text-sm text-center font-black focus:border-accent-blue outline-none appearance-none cursor-pointer"
                  >
                    {Array.from({ length: 20 }, (_, i) => i + 1).map(num => (
                      <option key={num} value={num.toString()}>{num}</option>
                    ))}
                  </select>
                  {renderCopyButton(formData.racePosition, 'Posição')}
                </div>
              </div>
            )}
            <div className="space-y-1.5">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('tc')}</label>
              <div className="flex items-center gap-1.5">
                <select 
                  value={formData.tractionControl}
                  onChange={e => setFormData({...formData, tractionControl: e.target.value})}
                  className="flex-1 bg-bg-cell border border-accent-light rounded-[20px] px-4 py-3 text-sm text-center font-black focus:border-accent-blue outline-none appearance-none cursor-pointer"
                >
                  {Array.from({ length: 6 }, (_, i) => i).map(num => (
                    <option key={num} value={num.toString()}>{num}</option>
                  ))}
                </select>
                {renderCopyButton(formData.tractionControl, 'CT')}
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('map')}</label>
              <div className="flex items-center gap-1.5">
                <select 
                  value={formData.carMap}
                  onChange={e => setFormData({...formData, carMap: e.target.value})}
                  className="flex-1 bg-bg-cell border border-accent-light rounded-[20px] px-4 py-3 text-sm text-center font-black focus:border-accent-blue outline-none appearance-none cursor-pointer"
                >
                  {Array.from({ length: 6 }, (_, i) => i + 1).map(num => (
                    <option key={num} value={num.toString()}>{num}</option>
                  ))}
                </select>
                {renderCopyButton(formData.carMap, 'Mapeamento')}
              </div>
            </div>
          </div>

          {!isTimeTrial && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 border border-accent-light rounded-2xl p-1 bg-bg-cell">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-2 block mt-1">{t('best_lap')}</label>
                <div className="flex items-center px-1">
                  <input 
                    type="text" 
                    placeholder="--:--.--"
                    value={formData.lapTime}
                    onChange={e => setFormData({...formData, lapTime: maskMinutes(e.target.value)})}
                    className="w-full min-w-0 bg-transparent text-ink-primary py-3 text-sm sm:text-base font-mono font-black text-center outline-none transition-colors placeholder:text-ink-secondary/30"
                  />
                </div>
              </div>
              <div className="space-y-1.5 border border-accent-light rounded-2xl p-1 bg-bg-cell">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-2 block mt-1">{t('total_time')}</label>
                <div className="flex items-center px-1">
                  <input 
                    type="text" 
                    placeholder="--:--:--.---"
                    value={formData.totalTime}
                    onChange={e => {
                      manualTotalEdited.current = true;
                      setFormData({...formData, totalTime: maskHours(e.target.value)});
                    }}
                    className="w-full min-w-0 bg-transparent text-ink-primary py-3 text-sm sm:text-base font-mono font-black text-center outline-none transition-colors placeholder:text-ink-secondary/30"
                  />
                </div>
              </div>
            </div>
          )}

          {isTimeTrial && (
            <div className="space-y-1.5 border border-accent-light rounded-2xl p-1 bg-bg-cell">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-2 block mt-1">{t('time_trial')}</label>
              <div className="flex items-center px-2">
                <input 
                  type="text" 
                  placeholder="--:--:--.---"
                  value={formData.provaDeTempo}
                  onChange={e => setFormData({...formData, provaDeTempo: maskHours(e.target.value)})}
                  className="w-full min-w-0 bg-transparent text-ink-primary py-3 text-sm sm:text-base font-mono font-black text-center outline-none transition-colors placeholder:text-ink-secondary/30"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className={`space-y-1.5 ${isTimeTrial ? 'col-span-2' : ''}`}>
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('date')}</label>
              <div className="flex items-center gap-1.5">
                <input 
                  type="date" 
                  value={formData.runDate}
                  onChange={e => setFormData({...formData, runDate: e.target.value})}
                  className="flex-1 bg-bg-cell border border-accent-light rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors animate-none"
                />
                {(() => {
                  let dStr = formData.runDate || '';
                  if (dStr.includes('-')) {
                    const [y, m, d] = dStr.split('-');
                    dStr = `${d}/${m}/${y}`;
                  }
                  return renderCopyButton(dStr, 'Data');
                })()}
              </div>
            </div>
            {!isTimeTrial && (
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('weather')}</label>
                <div className="flex items-center gap-1.5">
                  <select 
                    value={formData.weather}
                    onChange={e => setFormData({...formData, weather: e.target.value})}
                    className="flex-1 bg-bg-cell border border-accent-light rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors outline-none cursor-pointer"
                  >
                    <option value="Clear">{t('weather_sun')}</option>
                    <option value="Cloudy">{t('weather_cloudy')}</option>
                    <option value="Light Rain">{t('weather_rain')}</option>
                    <option value="Heavy Rain">{t('weather_storm')}</option>
                  </select>
                  {(() => {
                    const mapClima: Record<string, string> = {
                       'Clear': 'Sol',
                       'Cloudy': 'Nublado',
                       'Light Rain': 'Chuva Leve',
                       'Heavy Rain': 'Chuva Forte'
                    };
                    return renderCopyButton(mapClima[formData.weather] || formData.weather, 'Clima');
                  })()}
                </div>
              </div>
            )}
            <div className="space-y-1.5">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('transmission')}</label>
              <div className="flex items-center gap-1.5">
                <select 
                  value={formData.transmission || 'Manual'}
                  onChange={e => setFormData({...formData, transmission: e.target.value})}
                  className="flex-1 bg-bg-cell border border-accent-light rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors outline-none cursor-pointer"
                >
                  <option value="Manual">{t('trans_manual')}</option>
                  <option value="Automatic">{t('trans_automatic')}</option>
                </select>
                {renderCopyButton(formData.transmission === 'Automatic' ? 'Automática' : 'Manual', 'Transmissão')}
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('peripheral')}</label>
              <div className="flex items-center gap-1.5">
                <select 
                  value={formData.peripheral || 'Controle'}
                  onChange={e => setFormData({...formData, peripheral: e.target.value})}
                  className="flex-1 bg-bg-cell border border-accent-light rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors outline-none cursor-pointer md:p-3"
                >
                  <option value="Controller">{t('peri_controller')}</option>
                  <option value="Wheel">{t('peri_wheel')}</option>
                </select>
                {(() => {
                  const copyVal = formData.peripheral === 'Wheel' ? 'Volante' : (formData.peripheral === 'Controller' || formData.peripheral === 'Controle' ? 'Controle' : formData.peripheral || 'Controle');
                  return renderCopyButton(copyVal, 'Periférico');
                })()}
              </div>
            </div>
            {!isTimeTrial && (
              <>
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('pits')}</label>
                  <div className="flex items-center gap-1.5">
                    <select 
                      value={formData.pitStops}
                      onChange={e => setFormData({...formData, pitStops: e.target.value})}
                      className="flex-1 bg-bg-cell border border-accent-light text-center rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors appearance-none cursor-pointer"
                    >
                      {Array.from({ length: 11 }, (_, i) => i).map(num => (
                        <option key={num} value={num.toString()}>{num}</option>
                      ))}
                    </select>
                    {renderCopyButton(formData.pitStops, 'Pits')}
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('laps')}</label>
                  <div className="flex items-center gap-1.5">
                    <select 
                      value={formData.laps}
                      onChange={e => setFormData({...formData, laps: e.target.value})}
                      className="flex-1 bg-bg-cell border border-accent-light text-center rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors appearance-none cursor-pointer"
                    >
                      {Array.from({ length: 30 }, (_, i) => i + 1).map(num => (
                        <option key={num} value={num.toString()}>{num}</option>
                      ))}
                    </select>
                    {renderCopyButton(formData.laps, 'Voltas')}
                  </div>
                </div>
              </>
            )}
            <div className={`space-y-1.5 ${isTimeTrial ? 'col-span-2' : ''}`}>
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">Driver</label>
              <div className="flex items-center gap-1.5">
                <input 
                  type="text"
                  value={formData.pilot_name || ''}
                  readOnly
                  placeholder="Driver Name"
                  className="flex-1 bg-bg-cell border border-accent-light opacity-50 cursor-not-allowed rounded-xl px-4 py-3 text-sm font-bold outline-none"
                />
                {renderCopyButton(formData.pilot_name || 'rAd', 'Driver')}
              </div>
            </div>

            {/* Nova linha: Velocidade Final */}
            <div className="space-y-1.5 col-span-2">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">Velocidade Final</label>
              <div className="flex items-center gap-1.5">
                <input 
                  type="text"
                  value={formData.velocidade_final || ''}
                  onChange={e => setFormData({...formData, velocidade_final: e.target.value})}
                  placeholder="Ex: 248 km/h"
                  className="flex-1 bg-bg-cell border border-accent-light rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors"
                />
                {renderCopyButton(formData.velocidade_final || '0 km/h', 'Velocidade Final')}
              </div>
            </div>
          </div>
          
          <div className="space-y-4 pt-2 border-t border-accent-light">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-accent-blue">Evidence (Image)</h4>
            <div className="space-y-2">
              <div className="relative group">
                <input 
                  type="text" 
                  placeholder="URL da Imagem da Tela" 
                  value={formData.evidence_image || ''}
                  onChange={e => setFormData({...formData, evidence_image: e.target.value})}
                  className="w-full bg-bg-cell border border-accent-light rounded-xl pl-4 pr-12 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors"
                />
                <button
                  type="button"
                  onClick={() => fileInputRefEntry.current?.click()}
                  disabled={isUploadingImage}
                  className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-all ${isUploadingImage ? 'bg-accent-blue/10 text-accent-blue' : 'hover:bg-bg-main text-ink-secondary hover:text-accent-blue'}`}
                  title="Enviar Imagem"
                >
                  {isUploadingImage ? (
                    <RefreshCcw size={18} className="animate-spin" />
                  ) : (
                    <UploadCloud size={18} />
                  )}
                </button>
                <input 
                  ref={fileInputRefEntry}
                  type="file" 
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
              <p className="text-[9px] text-ink-secondary px-2">Link direto para o screenshot no Discord, Imgur ou envie seu arquivo.</p>
            </div>
          </div>
          
          {(() => {
            const additionalFields = (layout.customFields || [])
              .filter(f => !['data', 'voltas', 'piloto', 'transmissão', 'pp'].includes(f.label.toLowerCase().trim()));
            
            if (additionalFields.length === 0) return null;

            return (
              <div className="space-y-4 pt-2 border-t border-accent-light">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-accent-blue">Campos Adicionais</h4>
                <div className="grid grid-cols-2 gap-4">
                  {additionalFields.map((field, fieldIdx) => (
                    <div key={`${field.id}-${fieldIdx}`} className="space-y-1.5">
                      <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{field.label}</label>
                      <input 
                        type="text" 
                        value={formData.customFields?.[field.id] || ''}
                        onChange={e => setFormData({
                          ...formData, 
                          customFields: { ...formData.customFields, [field.id]: e.target.value }
                        })}
                        placeholder={`Valor para ${field.label}`}
                        className="w-full bg-bg-cell border border-accent-light rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors"
                      />
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </div>

        <div className="p-6 bg-bg-app/50 border-t border-accent-light space-y-3">
          <button 
            type="button"
            onClick={copyAllFields}
            className="w-full bg-bg-cell text-accent-blue border border-accent-blue/40 hover:bg-accent-blue/10 font-black py-4 rounded-[24px] shadow-lg active:scale-[0.98] transition-all uppercase tracking-widest text-xs flex items-center justify-center gap-2"
          >
            <Copy size={13} className="stroke-[2.5]" />
            {copiedField === 'all_fields' ? 'Copiado!' : 'Copiar Tudo'}
          </button>

          <button 
            onClick={() => {
              // Save brand/car/setup to local storage
              const newConfig = { 
                carBrand: formData.carBrand, 
                carName: formData.carName, 
                carSetup: formData.carSetup 
              };
              onSave(formData);
            }}
            className="w-full bg-accent-blue text-white font-black py-5 rounded-[24px] shadow-xl active:scale-[0.98] transition-all uppercase tracking-widest text-xs border-b-4 border-black/20"
          >
            Save Entry
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function LayoutEditor({ layout, onSave, onClose }: { 
  layout: LayoutProfile; 
  onSave: (l: LayoutProfile) => void;
  onClose: () => void;
}) {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'visual' | 'fields'>('visual');
  const [fieldPromptOpen, setFieldPromptOpen] = useState(false);

  const fields = layout.fields && layout.fields.length > 0 ? layout.fields : getNormalizedFields(layout);

  const updateField = (id: string, partial: Partial<import('./types').FieldConfig>) => {
    const newFields = fields.map(f => f.id === id ? { ...f, ...partial } : f);
    onSave({ ...layout, fields: newFields });
  };

  const moveField = (index: number, direction: 'up' | 'down') => {
    const newFields = [...fields];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex >= 0 && targetIndex < newFields.length) {
      [newFields[index], newFields[targetIndex]] = [newFields[targetIndex], newFields[index]];
      onSave({ ...layout, fields: newFields });
    }
  };

  const addCustomField = (label: string) => {
    if (!label) return;
    const id = makeId();
    const newField: import('./types').FieldConfig = { id: `custom_${id}`, label, colSpan: 12, hidden: false, isCustom: true };
    onSave({ ...layout, fields: [...fields, newField], customFields: [...(layout.customFields || []), { id, label }] });
  };

  const removeCustomField = (id: string) => {
    const newFields = fields.filter(f => f.id !== id);
    onSave({ ...layout, fields: newFields, customFields: (layout.customFields || []).filter(f => f.id !== id) });
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-accent-blue/40 backdrop-blur-sm p-4"
    >
      <motion.div 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        exit={{ y: 100 }}
        className="bg-bg-card w-full max-w-md rounded-t-[32px] sm:rounded-[32px] overflow-hidden shadow-2xl flex flex-col max-h-[90vh] border border-accent-light"
      >
        <div className="px-6 py-6 border-b border-accent-light flex items-center justify-between">
          <h3 className="font-bold text-xl text-ink-primary">{t('card_designer')}</h3>
          <button onClick={onClose} className="p-2 -mr-2 rounded-full hover:bg-bg-app transition-colors text-ink-secondary">
            <Plus className="rotate-45" size={24} />
          </button>
        </div>

        <div className="flex border-b border-accent-light p-2 bg-bg-app/30">
          <div className="squircle-container flex-1 h-11">
            {(['visual', 'fields'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 squircle-tab ${
                  activeTab === tab ? 'squircle-tab-active' : 'squircle-tab-inactive'
                }`}
              >
                {tab === 'visual' ? t('style_and_size') : t('fields')}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          {activeTab === 'visual' && (
            <>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] uppercase font-black tracking-widest text-ink-secondary">{t('compact_mode')}</label>
                  <button 
                    onClick={() => onSave({...layout, compactMode: !layout.compactMode})}
                    className={`w-12 h-6 rounded-full relative transition-all shadow-inner ${layout.compactMode ? 'bg-accent-blue' : 'bg-accent-light'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-all ${layout.compactMode ? 'right-1' : 'left-1'}`} />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] uppercase font-black tracking-widest text-ink-secondary">{t('card_radius')}</label>
                  <span className="text-xs font-bold text-ink-primary">{layout.cardRadius}px</span>
                </div>
                <input 
                  type="range" min="0" max="40" value={layout.cardRadius} 
                  onChange={e => onSave({...layout, cardRadius: parseInt(e.target.value)})}
                  className="w-full h-1.5 bg-accent-light rounded-lg appearance-none cursor-pointer accent-accent-blue"
                />
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] uppercase font-black tracking-widest text-ink-secondary">{t('padding')}</label>
                  <span className="text-xs font-bold text-ink-primary">{layout.cardPadding}px</span>
                </div>
                <input 
                  type="range" min="8" max="32" value={layout.cardPadding} 
                  onChange={e => onSave({...layout, cardPadding: parseInt(e.target.value)})}
                  className="w-full h-1.5 bg-accent-light rounded-lg appearance-none cursor-pointer accent-accent-blue"
                />
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] uppercase font-black tracking-widest text-ink-secondary">{t('row_gap')}</label>
                  <span className="text-xs font-bold text-ink-primary">{layout.rowGap}px</span>
                </div>
                <input 
                  type="range" min="0" max="24" value={layout.rowGap} 
                  onChange={e => onSave({...layout, rowGap: parseInt(e.target.value)})}
                  className="w-full h-1.5 bg-accent-light rounded-lg appearance-none cursor-pointer accent-accent-blue"
                />
              </div>
            </>
          )}

          {activeTab === 'fields' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2">
                <h4 className="text-[10px] uppercase font-black tracking-widest text-ink-secondary">{t('field_layout')}</h4>
                <button 
                  onClick={() => setFieldPromptOpen(true)}
                  className="text-[9px] font-black uppercase tracking-wider text-white bg-accent-blue px-3 py-1.5 rounded-full shadow-sm active:scale-95 transition-all flex items-center gap-1"
                >
                  <Plus size={12}/> {t('custom_field')}
                </button>
              </div>

              <div className="space-y-2">
                {fields.map((field, index) => (
                  <div key={`${field.id}-${index}`} className={`flex flex-col gap-2 bg-bg-cell p-3 rounded-2xl border ${field.hidden ? 'border-red-500/20 opacity-50' : 'border-accent-light'} shadow-sm transition-opacity`}>
                    
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => updateField(field.id, { hidden: !field.hidden })}
                        className={`w-8 h-8 rounded-full flex shrink-0 items-center justify-center transition-colors ${field.hidden ? 'bg-red-100 text-red-500' : 'bg-accent-blue/10 text-accent-blue'}`}
                        title={field.hidden ? t('show_in_card') : t('hide_from_card')}
                      >
                        {field.hidden ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                      
                      <div className="flex-1 min-w-0">
                         {field.id === 'header' || field.id === 'actions' ? (
                            <p className="text-xs font-bold text-ink-primary truncate px-2">{field.label}</p>
                         ) : (
                            <input 
                              type="text" 
                              value={field.label}
                              onChange={(e) => updateField(field.id, { label: e.target.value })}
                              placeholder="Field Label"
                              className="w-full bg-transparent text-sm font-bold text-ink-primary focus:outline-none focus:border-b border-accent-blue/50 truncate px-2 py-0.5 placeholder:text-ink-secondary/30"
                            />
                         )}
                      </div>

                      <div className="flex flex-col border-l border-accent-light/50 pl-1 ml-1 shrink-0">
                        <button onClick={() => moveField(index, 'up')} className="p-1 px-1.5 text-ink-secondary/30 hover:text-ink-primary"><ChevronLeft className="rotate-90" size={14} /></button>
                        <button onClick={() => moveField(index, 'down')} className="p-1 px-1.5 text-ink-secondary/30 hover:text-ink-primary"><ChevronLeft className="-rotate-90" size={14} /></button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pl-10 pr-8">
                       <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary opacity-60">{t('size_label')}:</label>
                       <select 
                         value={field.colSpan} 
                         onChange={e => updateField(field.id, { colSpan: parseInt(e.target.value) })}
                         className="bg-bg-app border border-accent-light rounded-lg px-2 py-1 text-xs font-bold focus:outline-none focus:border-accent-blue"
                       >
                         <option value={2}>1/6</option>
                         <option value={3}>1/4</option>
                         <option value={4}>1/3</option>
                         <option value={6}>1/2</option>
                         <option value={8}>2/3</option>
                         <option value={9}>3/4</option>
                         <option value={10}>5/6</option>
                         <option value={12}>{t('full')}</option>
                       </select>

                       {field.isCustom && (
                         <button onClick={() => removeCustomField(field.id)} className="p-1.5 text-red-400 hover:text-red-500 rounded-md hover:bg-red-50 transition-colors ml-2" title="Delete Field">
                           <Trash2 size={12} />
                         </button>
                       )}
                    </div>

                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Field Prompt Modal */}
      <AnimatePresence>
        {fieldPromptOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-bg-card p-6 rounded-3xl shadow-2xl w-full max-w-[300px]"
            >
              <h3 className="font-bold text-ink-primary mb-4">{t('field_name')}</h3>
              <form onSubmit={(e) => {
                e.preventDefault();
                const input = new FormData(e.currentTarget).get('label') as string;
                addCustomField(input);
                setFieldPromptOpen(false);
              }}>
                <input 
                  name="label"
                  type="text" 
                  autoFocus
                  placeholder="e.g. Fuel"
                  className="w-full bg-bg-cell border border-accent-light rounded-2xl px-4 py-3 text-sm font-bold text-ink-primary focus:outline-none focus:border-accent-blue mb-4"
                />
                <div className="flex gap-2">
                  <button type="button" onClick={() => setFieldPromptOpen(false)} className="flex-1 py-3 text-xs font-bold text-ink-secondary hover:bg-bg-app rounded-xl">{t('cancel')}</button>
                  <button type="submit" className="flex-1 py-3 text-xs font-bold text-white bg-accent-blue rounded-xl shadow-md">{t('add')}</button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}


function LogoEditor({ brand, carName, currentLogo, logosDatabase, onAddLogos, onSave, onClose }: {
  brand: string;
  carName: string;
  currentLogo: string | null;
  logosDatabase?: LogoBrand[];
  onAddLogos?: (newLogos: LogoBrand[]) => void;
  onSave: (logoFile: string) => void;
  onClose: () => void;
}) {
  const { t } = useLanguage();
  const [logoFile, setLogoFile] = useState(currentLogo || '');
  const [isExplorerOpen, setIsExplorerOpen] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const base64 = await convertToWebP(file);
      setLogoFile(base64);
      setIsExplorerOpen(false);
    } catch (err) { console.error(err); }
  };

  const logoUrl = getLogoUrl(logoFile);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center bg-accent-blue/40 backdrop-blur-md p-4"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-bg-card w-full max-w-sm rounded-[40px] overflow-hidden shadow-2xl border border-accent-light"
      >
        <div className="p-8 space-y-6">
          <div className="flex items-center justify-between">
             <h3 className="text-xl font-black text-ink-primary italic uppercase">{t('edit_logo')}</h3>
             <button onClick={onClose} className="p-2 hover:bg-bg-app rounded-full text-ink-secondary"><X size={20} /></button>
          </div>

          <div className="flex flex-col items-center gap-6 py-2">
            <div className="relative group">
              <div className="w-24 h-24 bg-bg-cell rounded-[28px] flex items-center justify-center p-3 shadow-premium border border-accent-light/50 relative overflow-hidden">
                {logoUrl ? (
                  <img src={logoUrl} alt="Preview" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                ) : (
                  <Car size={32} className="text-ink-secondary opacity-10" />
                )}
              </div>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-accent-blue text-white rounded-full flex items-center justify-center shadow-lg border border-white">
                 <Edit2 size={12} />
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-[10px] font-black text-accent-blue uppercase tracking-[0.2em] mb-1">{brand}</div>
              <div className="text-lg font-bold text-ink-primary tracking-tight leading-none">{carName}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
             <button 
               type="button"
               onClick={() => setIsExplorerOpen(true)}
               className="p-4 bg-bg-cell border border-accent-light rounded-2xl flex flex-col items-center gap-2 hover:border-accent-blue transition-colors group"
             >
               <Library size={20} className="text-ink-secondary group-hover:text-accent-blue" />
               <span className="text-[9px] font-black uppercase tracking-widest text-ink-secondary group-hover:text-accent-blue">{t('explore')}</span>
             </button>
             <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
             <button 
               type="button"
               onClick={(e) => {
                 e.stopPropagation();
                 fileInputRef.current?.click();
               }}
               className="p-4 bg-bg-cell border border-accent-light rounded-2xl flex flex-col items-center gap-2 hover:border-accent-blue transition-colors group"
             >
               <Upload size={20} className="text-ink-secondary group-hover:text-accent-blue" />
               <span className="text-[9px] font-black uppercase tracking-widest text-ink-secondary group-hover:text-accent-blue">Upload</span>
             </button>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1 opacity-50">{t('logo_id_url')}</label>
              <div className="relative">
                <Settings className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary opacity-20" size={16} />
                <input 
                  type="text" 
                  value={logoFile.startsWith('data:image/') ? 'Imagem Carregada' : logoFile}
                  onChange={e => setLogoFile(e.target.value)}
                  placeholder="ID ou URL"
                  disabled={logoFile.startsWith('data:image/')}
                  className="w-full bg-bg-cell border border-accent-light rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors disabled:opacity-50"
                />
              </div>
              {logoFile.startsWith('data:image/') && (
                <button onClick={() => setLogoFile('')} className="w-full text-[8px] font-black uppercase tracking-widest text-red-500 mt-2">{t('remove_uploaded_image')}</button>
              )}
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button onClick={onClose} className="flex-1 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest text-ink-secondary hover:bg-bg-app">{t('cancel')}</button>
            <button onClick={() => onSave(logoFile)} className="flex-[2] py-4 bg-accent-blue text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-accent-blue/20 active:scale-95 transition-all">{t('confirm')}</button>
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {isExplorerOpen && (
          <LogoExplorer 
            logosDatabase={logosDatabase}
            onAddLogos={onAddLogos}
            onSelect={(file) => {
              setLogoFile(file);
              setIsExplorerOpen(false);
            }}
            onClose={() => {
              if (!logoFile) onClose(); 
              setIsExplorerOpen(false);
            }}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function AIAnalystModal({ entries, trackName, onClose }: { entries: Entry[], trackName: string, onClose: () => void }) {
  const { t, language } = useLanguage();
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const runAnalysis = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
        
        const entriesData = entries.map(e => ({
          car: `${e.carBrand} ${e.carName}`,
          lapTime: e.lapTime,
          weather: e.weather,
          transmission: e.transmission,
          track: trackName
        }));

        const prompt = language === 'pt' 
          ? `Analise o desempenho deste piloto na pista ${trackName}. 
            Aqui estão os tempos de volta e condições: ${JSON.stringify(entriesData)}.
            Dê 3 a 4 dicas curtas e práticas em uma lista de bullet points (Português) para ele melhorar, 
            comparando carros ou condições climáticas se possível. Seja encorajador e profissional.`
          : `Analyze this driver's performance at ${trackName}.
            Here are the lap times and conditions: ${JSON.stringify(entriesData)}.
            Provide 3 to 4 short, practical tips in a bullet point list (English) for them to improve,
            comparing cars or weather conditions if possible. Be encouraging and professional.`;

        const response = await ai.models.generateContent({
          model: "gemini-flash-latest",
          contents: [{ parts: [{ text: prompt }] }],
        });

        const text = response.text;
        if (!text) throw new Error(t('ai_empty_error'));
        
        setAnalysis(text);
      } catch (err: any) {
        console.error("AI Analysis error:", err);
        const errorMessage = err?.message || "";
        if (errorMessage.includes("API key")) {
          setError(t('ai_api_key_error'));
        } else if (errorMessage.includes("quota")) {
          setError(t('ai_quota_error'));
        } else {
          setError(t('ai_unavailable_error'));
        }
      } finally {
        setLoading(false);
      }
    };

    runAnalysis();
  }, [entries, trackName]);

  return (
    <motion.div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-bg-card w-full max-w-lg rounded-[32px] overflow-hidden border border-accent-light shadow-2xl flex flex-col max-h-[80vh]"
      >
        <div className="p-6 border-b border-accent-light flex items-center justify-between bg-accent-blue/5">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent-blue rounded-xl text-white shadow-lg shadow-accent-blue/20">
              <Sparkles size={20} />
            </div>
            <div>
              <h3 className="font-bold text-xl text-ink-primary">{t('ai_engineer_name')}</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-accent-blue">{t('performance_analysis')}</p>
            </div>
          </div>
          <button onClick={onClose}><X size={24} className="text-ink-secondary" /></button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-8">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 space-y-6">
              <div className="relative">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="w-16 h-16 border-4 border-accent-blue border-t-transparent rounded-full"
                />
                <Sparkles className="absolute inset-0 m-auto text-accent-blue animate-pulse" size={24} />
              </div>
              <p className="text-sm font-bold text-ink-secondary animate-pulse uppercase tracking-[0.2em]">{t('processing_telemetry')}</p>
            </div>
          ) : error ? (
            <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-2xl text-center space-y-4">
              <AlertCircle size={32} className="text-red-500 mx-auto" />
              <p className="text-sm font-bold text-red-500">{error}</p>
            </div>
          ) : (
            <div className="space-y-6 prose prose-invert max-w-none">
              <div className="bg-bg-cell rounded-2xl p-6 border border-accent-light/50 shadow-inner">
                <p className="text-ink-primary leading-relaxed text-sm whitespace-pre-wrap font-medium">
                  {analysis}
                </p>
              </div>
              
              <div className="flex items-center gap-4 p-4 border border-emerald-500/20 bg-emerald-500/5 rounded-2xl">
                 <CheckCircle2 size={20} className="text-emerald-500 shrink-0" />
                 <p className="text-[10px] font-bold text-emerald-600/70 leading-snug">
                   {t('ai_tips_generated_desc')}
                 </p>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 bg-bg-cell border-t border-accent-light">
          <button 
            onClick={onClose}
            className="w-full py-4 bg-accent-blue text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-opacity-90 transition-all shadow-xl shadow-accent-blue/20 active:scale-[0.98]"
          >
            {t('understood_captain')}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function LogoExplorer({ logosDatabase = [], onAddLogos, onSelect, onClose }: {
  logosDatabase?: LogoBrand[];
  onAddLogos?: (newLogos: LogoBrand[]) => void;
  onSelect: (logoFile: string) => void;
  onClose: () => void;
}) {
  const { t } = useLanguage();
  const [search, setSearch] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const singleFileInputRef = useRef<HTMLInputElement>(null);
  const staticBrands = useMemo(() => getAllBrands(), []);
  
  const allBrands = useMemo(() => {
    const customBrands = logosDatabase.map(cl => ({
      maker_id: cl.id,
      brand_name: cl.brand_name,
      logo_file: cl.logo_data || '',
      search_terms: [cl.brand_slug]
    }));
    return [...customBrands, ...staticBrands];
  }, [staticBrands, logosDatabase]);

  const filteredBrands = useMemo(() => {
    if (!search || !search.trim()) return allBrands;
    return allBrands
      .map(b => {
        let maxScore = getSmartSearchScore(search, b.brand_name || '');
        (b.search_terms || []).forEach(term => {
           maxScore = Math.max(maxScore, getSmartSearchScore(search, term || ''));
        });
        return { item: b, score: maxScore };
      })
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(x => x.item);
  }, [allBrands, search]);

  const handleBatchUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (!files.length || !onAddLogos) return;

    let newLogos: LogoBrand[] = [];

    for (const file of files) {
      try {
        const logoData = await convertToWebP(file);
        const brandName = file.name.split('.')[0].replace(/[-_]/g, ' '); 
        const brandSlug = brandName.toLowerCase().replace(/\s+/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, "");
        
        newLogos.push({
           id: crypto.randomUUID(),
           brand_name: brandName,
           brand_slug: brandSlug,
           logo_data: logoData,
           logo_type: 'webp',
           created_at: Date.now(),
           updated_at: Date.now()
        });
      } catch (err) { console.error(err); }
    }
    
    if (newLogos.length > 0) {
       onAddLogos(newLogos);
    }
    e.target.value = '';
  };

  const handleSingleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onAddLogos) return;

    try {
      const logoData = await convertToWebP(file);
      const brandName = file.name.split('.')[0].replace(/[-_]/g, ' ');
      const brandSlug = brandName.toLowerCase().replace(/\s+/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, "");
      
      onAddLogos([{
         id: crypto.randomUUID(),
         brand_name: brandName,
         brand_slug: brandSlug,
         logo_data: logoData,
         logo_type: 'webp',
         created_at: Date.now(),
         updated_at: Date.now()
      }]);
    } catch (err) { console.error(err); }
    e.target.value = '';
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xl"
    >
      <div className="absolute inset-0" onClick={onClose} />
      <motion.div 
        initial={{ y: 20, scale: 0.95 }}
        animate={{ y: 0, scale: 1 }}
        className="bg-bg-app w-full max-w-2xl h-[85vh] rounded-[48px] overflow-hidden shadow-2xl border border-white/10 flex flex-col relative z-10"
      >
        {/* Header */}
        <div className="p-8 pb-6 border-b border-accent-light space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-2xl font-black text-ink-primary tracking-tight italic uppercase">{t('logo_explorer')}</h4>
              <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('explore_upload_logos')}</p>
            </div>
            <div className="flex gap-2">
              {onAddLogos && (
                <button 
                  onClick={(e) => {
                 e.stopPropagation();
                 fileInputRef.current?.click();
               }} 
                  className="px-4 py-2 bg-accent-blue/10 text-accent-blue hover:bg-accent-blue/20 rounded-2xl transition-all flex items-center gap-2 font-black text-[10px] uppercase tracking-widest"
                >
                  <UploadCloud size={16} />
                  {t('batch_upload')}
                  <input 
                    type="file" 
                    multiple 
                    accept="image/*" 
                    ref={fileInputRef} 
                    onChange={handleBatchUpload} 
                    className="hidden" 
                  />
                </button>
              )}
              <button onClick={onClose} className="p-3 hover:bg-bg-card rounded-2xl transition-colors border border-accent-light">
                <X size={20} className="text-ink-secondary" />
              </button>
            </div>
          </div>

          <div className="relative group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-ink-secondary group-focus-within:text-accent-blue transition-colors" size={20} />
            <input 
              type="text" 
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={t('search_brand_placeholder')}
              className="w-full bg-white border border-accent-light rounded-3xl pl-14 pr-6 py-4 text-sm font-bold focus:outline-none focus:border-accent-blue focus:ring-4 focus:ring-accent-blue/5 transition-all shadow-sm"
            />
          </div>
        </div>

        {/* Grid Area */}
        <div className="flex-1 overflow-y-auto p-8 pt-4 custom-scrollbar">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {/* Upload Tile */}
            {onAddLogos && (
              <button 
                onClick={() => singleFileInputRef.current?.click()}
                className="aspect-square bg-white border-2 border-dashed border-accent-light hover:border-accent-blue hover:bg-accent-blue/5 rounded-[32px] flex flex-col items-center justify-center gap-3 transition-all group active:scale-95"
              >
                <div className="w-12 h-12 rounded-2xl bg-bg-app flex items-center justify-center text-ink-secondary group-hover:text-accent-blue group-hover:bg-white transition-all shadow-sm">
                  <Plus size={24} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-ink-secondary group-hover:text-accent-blue">
                  {t('upload_new')}
                </span>
                <input 
                  type="file" 
                  accept="image/*" 
                  ref={singleFileInputRef} 
                  onChange={handleSingleUpload} 
                  className="hidden" 
                />
              </button>
            )}

            {filteredBrands.map((brand, index) => (
              <button 
                key={`filtered-brand-${brand.maker_id || 'brand'}-${encodeURIComponent(brand.brand_name || '')}-${index}`}
                onClick={() => onSelect(brand.logo_file)}
                className="aspect-square bg-white rounded-[32px] border border-accent-light p-4 flex flex-col items-center justify-center gap-3 hover:border-accent-blue hover:shadow-xl hover:-translate-y-1 transition-all group active:scale-95"
              >
                <div className="flex-1 flex items-center justify-center w-full min-h-0">
                  {getLogoUrl(brand.logo_file) ? (
                    <img 
                      src={getLogoUrl(brand.logo_file)!} 
                      alt={brand.brand_name}
                      className="max-w-full max-h-full object-contain group-hover:scale-110 transition-transform"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <ImageIcon size={32} className="text-ink-secondary opacity-10" />
                  )}
                </div>
                <span className="text-[9px] font-black uppercase tracking-tight text-ink-secondary truncate w-full text-center px-2 group-hover:text-ink-primary transition-colors">
                  {brand.brand_name}
                </span>
              </button>
            ))}
          </div>

          {filteredBrands.length === 0 && (
             <div className="py-20 text-center space-y-4">
                <div className="w-20 h-20 bg-bg-card rounded-full flex items-center justify-center mx-auto text-ink-secondary/20">
                   <Search size={40} />
                </div>
                <p className="text-xs font-bold text-ink-secondary uppercase tracking-widest">{t('no_results_found')}</p>
             </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-6 bg-bg-app/50 border-t border-accent-light text-center">
           <p className="text-[8px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-40">
             {filteredBrands.length} {t('logos_available')}
           </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

function TrackEditModal({ track, currentLogo, currentBackground, onSave, onDelete, onClose, session, setShowAuthModal }: { 
  track: Track, 
  currentLogo?: string | null,
  currentBackground?: string | null,
  onSave: (id: string, name: string, location: string, newLogo?: string | null, newBackground?: string | null) => void, 
  onDelete: (id: string) => void,
  onClose: () => void,
  session: any,
  setShowAuthModal: (show: boolean) => void
}) {
  const { t, language } = useLanguage();
  const [name, setName] = useState(track.name || '');
  const [location, setLocation] = useState(track.location || '');
  const [logoData, setLogoData] = useState(currentLogo || '');
  const [backgroundData, setBackgroundData] = useState(currentBackground || '');
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const flag = getCountryFlag(location) || getCountryFlagFromTrack(track);

  const packData = useMemo(() => TRACK_PACK.find(t => t.id === track.packId || t.id === track.id), [track.id, track.packId]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const webp = await convertToWebP(file);
      setLogoData(webp);
    } catch (err) { console.error(err); }
  };

  const handleBgUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const webp = await convertToWebP(file);
      setBackgroundData(webp);
    } catch (err) { console.error(err); }
  };

  const handleDelete = () => {
    if (!session) {
      setShowAuthModal(true);
    } else {
      onDelete(track.id);
      onClose();
    }
  };

  return (
    <motion.div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <motion.div className="bg-bg-card w-full max-w-sm rounded-[32px] p-6 border border-accent-light shadow-2xl space-y-5 relative">
        <AnimatePresence mode="wait">
          {!showConfirmDelete ? (
            <motion.div
              key="edit-form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-5"
            >
              {packData && (
                <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
                  <svg viewBox={packData.svgViewBox} className="w-32 h-32 stroke-ink-primary fill-none stroke-[2]">
                    <path d={packData.svgVariants?.outline_thick || packData.svgPath} />
                  </svg>
                </div>
              )}

              <div className="flex items-center justify-between relative z-10">
                <h3 className="font-bold text-xl text-ink-primary">{t('edit_track')}</h3>
                <div className="flex items-center gap-4">
                  {packData && (
                    <div className="flex flex-col items-end">
                      <span className="text-[8px] font-black uppercase tracking-widest text-accent-blue">{packData.category}</span>
                      <span className="text-[8px] font-black uppercase tracking-widest text-ink-secondary">{packData.region}</span>
                    </div>
                  )}
                  <button 
                    onClick={() => setShowConfirmDelete(true)}
                    className="p-2 text-red-500/50 hover:text-red-500 hover:bg-red-500/10 rounded-full transition-all"
                    title={t('delete_track')}
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-6 py-2 relative z-10 w-full">
                {/* Logo Section */}
                <div className="flex flex-col items-center gap-1.5 flex-1">
                  <span className="text-[9px] uppercase font-black tracking-widest text-ink-secondary mb-1">Logo</span>
                  <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
                  <button 
                    onClick={(e) => {
                 e.stopPropagation();
                 fileInputRef.current?.click();
               }}
                    className="w-24 h-24 bg-bg-cell rounded-[18px] border border-accent-light flex flex-col items-center justify-center overflow-hidden hover:border-accent-blue transition-colors relative group shadow-sm bg-gradient-to-b from-bg-cell to-bg-app/50"
                  >
                    {logoData ? (
                      <>
                        <img src={logoData} alt="Logo" className="w-full h-full object-contain p-3" />
                        <div className="absolute inset-0 bg-accent-blue/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <ImageIcon size={24} className="text-white" />
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col items-center gap-1 opacity-50">
                        <ImageIcon size={24} />
                        <span className="text-[8px] uppercase font-black tracking-widest mt-1">Upload</span>
                      </div>
                    )}
                  </button>
                  {logoData && (
                    <button 
                      onClick={() => setLogoData('')} 
                      className="text-[9px] font-black text-red-400 uppercase tracking-widest hover:text-red-500 transition-colors mt-1"
                    >
                      Remover
                    </button>
                  )}
                </div>

                {/* Fundo Section */}
                <div className="flex flex-col items-center gap-1.5 flex-1">
                  <span className="text-[9px] uppercase font-black tracking-widest text-ink-secondary mb-1">Fundo</span>
                  <input type="file" ref={bgInputRef} onChange={handleBgUpload} accept="image/*" className="hidden" />
                  <button 
                    onClick={() => bgInputRef.current?.click()}
                    className="w-24 h-24 bg-bg-cell rounded-[18px] border border-accent-light flex flex-col items-center justify-center overflow-hidden hover:border-accent-blue transition-colors relative group shadow-sm bg-gradient-to-b from-bg-cell to-bg-app/50"
                  >
                    {backgroundData ? (
                      <>
                        <img src={backgroundData} alt="Fundo" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-accent-blue/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <ImageIcon size={24} className="text-white" />
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col items-center gap-1 opacity-50">
                        <ImageIcon size={24} />
                        <span className="text-[8px] uppercase font-black tracking-widest mt-1">Upload</span>
                      </div>
                    )}
                  </button>
                  {backgroundData && (
                    <button 
                      onClick={() => setBackgroundData('')} 
                      className="text-[9px] font-black text-red-400 uppercase tracking-widest hover:text-red-500 transition-colors mt-1"
                    >
                      Remover
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-4 relative z-10">
                <div className="space-y-1.5 focus-within:text-accent-blue transition-colors">
                  <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('track_name')}</label>
                  <input 
                    value={name} 
                    onChange={e => setName(e.target.value)} 
                    list="track-names-list"
                    className="w-full bg-bg-cell p-4 rounded-xl border border-accent-light text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors" 
                    placeholder="Ex: Monza"
                  />
                </div>

                <div className="space-y-1.5 focus-within:text-accent-blue transition-colors">
                  <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1">{t('location')}</label>
                  <div className="relative">
                    <input 
                      value={location} 
                      onChange={e => setLocation(e.target.value)} 
                      list="track-locations-list"
                      className="w-full bg-bg-cell p-4 rounded-xl border border-accent-light pr-14 text-sm font-bold focus:outline-none focus:border-accent-blue transition-colors" 
                      placeholder="Ex: Itália"
                    />
                    {flag && <span className="absolute right-4 top-1/2 -translate-y-1/2 text-2xl drop-shadow-md select-none">{flag}</span>}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-2 relative z-10">
                  <button 
                    onClick={onClose} 
                    className="flex-1 p-4 rounded-xl font-bold text-xs uppercase tracking-widest text-ink-secondary hover:bg-accent-light/20 transition-all font-black"
                  >
                    {t('cancel')}
                  </button>
                  <button 
                    onClick={() => onSave(track.id, name, location, logoData, backgroundData)} 
                    className="flex-1 bg-accent-blue text-white p-4 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg shadow-accent-blue/20 active:scale-[0.98] transition-all"
                  >
                    {t('save')}
                  </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="confirm-delete"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="py-4 space-y-6 text-center"
            >
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center text-red-500">
                  <Trash2 size={32} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-xl text-ink-primary">{t('delete_track')}?</h3>
                  <p className="text-xs text-ink-secondary leading-relaxed px-4">
                    {t('track_delete_permanently_desc').replace('{name}', track.name)}
                  </p>
                </div>
              </div>

              <div className="flex flex-col gap-2 pt-2">
                <button 
                  onClick={handleDelete}
                  className="w-full bg-red-500 text-white p-4 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg shadow-red-500/20 active:scale-[0.98] transition-all"
                >
                  Confirmar Exclusão
                </button>
                <button 
                  onClick={() => setShowConfirmDelete(false)} 
                  className="w-full p-4 rounded-xl font-bold text-xs uppercase tracking-widest text-ink-secondary hover:bg-accent-light/20 transition-all font-black"
                >
                  Voltar
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}

function TrackSelectorModal({ onAdd, onClose }: { onAdd: (name: string, location: string, id?: string) => void, onClose: () => void }) {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');

  const filteredPacks = useMemo(() => {
    if (!search || !search.trim()) return TRACK_PACK;

    return TRACK_PACK
      .map(t => {
        const scoreName = getSmartSearchScore(search, t.name || '');
        const scoreLocation = getSmartSearchScore(search, t.location || '');
        const maxScore = Math.max(scoreName, scoreLocation);
        return { item: t, score: maxScore };
      })
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(x => x.item);
  }, [search]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
    >
      <div className="absolute inset-0" onClick={onClose} />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-bg-card w-full max-w-4xl h-[90vh] rounded-[40px] flex flex-col border border-accent-light items-stretch shadow-2xl relative z-10"
      >
        
        {/* Header */}
        <div className="p-8 pb-6 flex items-center justify-between border-b border-accent-light/30">
          <div>
            <h3 className="font-black italic text-3xl uppercase tracking-tighter text-ink-primary leading-none">{t('track_selector')}</h3>
            <p className="text-[10px] font-black opacity-40 uppercase tracking-[0.3em] mt-1 text-ink-secondary">
              GT7 Ultra Track Pack V1.0
            </p>
          </div>
          <button 
            onClick={onClose} 
            className="p-3 bg-bg-cell border border-accent-light hover:bg-accent-blue/10 hover:border-accent-blue transition-all rounded-2xl text-ink-secondary hover:text-accent-blue shadow-sm"
          >
            <X size={24} />
          </button>
        </div>

        {/* Toolbar */}
        <div className="p-6 border-b border-accent-light/20 bg-bg-app/30">
          <div className="relative group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-ink-secondary opacity-30 group-focus-within:opacity-100 group-focus-within:text-accent-blue transition-all" size={20} />
            <input 
              type="text" 
              list="track-names-list"
              placeholder={t('search_track_placeholder')} 
              value={search} 
              onChange={e => setSearch(e.target.value)} 
              className="w-full bg-bg-cell h-14 pl-14 pr-6 rounded-2xl border border-accent-light focus:outline-none focus:border-accent-blue focus:ring-4 focus:ring-accent-blue/10 font-bold text-sm text-ink-primary placeholder:text-ink-secondary/30 transition-all shadow-sm"
            />
          </div>
        </div>

        {/* Track Grid */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar bg-bg-app/10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 p-2">
            {filteredPacks.map((track, trackIndex) => (
              <motion.div 
                layout
                key={`${track.id}-${trackIndex}`}
                onClick={() => onAdd(track.name, track.location, track.id)}
                className="group relative flex flex-col bg-bg-card rounded-[32px] border border-accent-light hover:border-accent-blue transition-all cursor-pointer shadow-sm hover:shadow-2xl hover:-translate-y-1"
              >
                {/* Content Section */}
                <div className="p-6 bg-bg-card">
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[8px] font-black uppercase tracking-widest bg-bg-cell text-ink-secondary px-2.5 py-1.5 rounded-xl border border-accent-light/50">
                        {track.category.replace(' Circuit', '')}
                      </span>
                      <span className="text-[8px] font-black uppercase tracking-widest bg-accent-blue/10 text-accent-blue px-2.5 py-1.5 rounded-xl border border-accent-blue/20">
                        {track.region}
                      </span>
                      {track.hudReady && (
                        <span className="text-[8px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-500 px-2.5 py-1.5 rounded-xl border border-emerald-500/20">
                          HUD READY
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="shrink-0 text-xl filter drop-shadow-sm mr-1">
                        {getCountryFlagFromTrack(track)}
                      </span>
                      <h4 className="font-bold text-lg text-ink-primary leading-tight flex-1">
                        {track.name}
                      </h4>
                    </div>
                    {track.location && (
                      <p className="text-[10px] font-bold text-ink-secondary uppercase tracking-widest opacity-40">{track.location}</p>
                    )}
                  </div>
                </div>

                {/* Hover Indicator */}
                <div className="absolute inset-0 bg-accent-blue/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              </motion.div>
            ))}
          </div>

          {filteredPacks.length === 0 && (
            <div className="py-32 text-center flex flex-col items-center justify-center opacity-30">
               <Trophy size={64} className="mb-6 text-ink-secondary" />
               <p className="font-black uppercase tracking-[0.2em] text-ink-secondary">{t('no_tracks_found')}</p>
            </div>
          )}
        </div>

        {/* Footer with Save Button */}
        <div className="p-6 md:p-8 bg-bg-card border-t border-accent-light">
           <button 
             onClick={onClose}
             className="w-full h-14 bg-accent-blue text-white rounded-2xl font-black uppercase italic tracking-widest text-xs hover:bg-accent-blue/90 active:scale-95 transition-all shadow-lg shadow-accent-blue/20 flex items-center justify-center gap-3"
           >
             <span>{t('save')}</span>
             <Check size={20} />
           </button>
        </div>

      </motion.div>
    </motion.div>
  );
}

function LogoBankTab({ logosDatabase, onAddLogos, onDeleteLogo, onUpdateName, onSaveAll }: any) {
  const { t } = useLanguage();
  const [search, setSearch] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFilesSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const promises = Array.from(files).map((file: File) => {
      return new Promise<{name: string, data: string}>(async (resolve, reject) => {
        try {
          const webp = await convertToWebP(file);
          resolve({
            name: file.name.split('.')[0].replace(/[-_]/g, ' '),
            data: webp
          });
        } catch (err) {
          reject(err);
        }
      });
    });

    Promise.all(promises).then(results => {
      onAddLogos(results);
    }).finally(() => {
      if (fileInputRef.current) fileInputRef.current.value = '';
    });
  };

  const startEditing = (logo: any) => {
    setEditingId(logo.id);
    setEditNameValue(logo.brand_name);
  };

  const saveEdit = () => {
    if (editingId && editNameValue.trim()) {
      onUpdateName(editingId, editNameValue.trim());
      setEditingId(null);
    }
  };

  const filtered = useMemo(() => {
    if (!logosDatabase) return [];
    if (!search || !search.trim()) return logosDatabase.filter(Boolean);

    return logosDatabase
      .map((l: any) => {
        if (!l) return null;
        const dbName = l.brand_name || '';
        if (!dbName) return null;
        const score = getSmartSearchScore(search, dbName);
        return { item: l, score };
      })
      .filter((x: any) => x !== null && x.score > 0)
      .sort((a: any, b: any) => b.score - a.score)
      .map((x: any) => x.item);
  }, [logosDatabase, search]);

  return (
    <div className="space-y-4">
       <div className="space-y-3">
          <div className="relative w-full">
             <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary" />
             <input 
               type="text" 
               placeholder="Buscar no banco..."
               value={search}
               onChange={(e) => setSearch(e.target.value)}
               className="w-full h-11 bg-bg-cell border border-accent-light rounded-2xl pl-11 pr-4 text-xs font-bold focus:outline-none focus:border-accent-blue transition-all"
             />
          </div>
          <div className="flex gap-2 justify-end">
            <input 
              type="file" 
              multiple 
              accept="image/*" 
              ref={fileInputRef} 
              onChange={handleFilesSelect} 
              className="hidden" 
            />
            <button 
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 sm:flex-initial h-11 px-4 bg-bg-app border border-accent-light text-ink-primary rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-[10px] hover:bg-bg-card transition-all"
            >
              <Upload size={16} />
              {t('add')}
            </button>
            <button 
              type="button"
              onClick={() => onSaveAll && onSaveAll()}
              className="flex-1 sm:flex-initial h-11 px-4 bg-accent-blue text-white rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-[10px] shadow-lg shadow-accent-blue/20 active:scale-95 transition-all"
            >
              <Save size={16} />
              {t('save_all')}
            </button>
          </div>
       </div>

       {logosDatabase.length === 0 && (
         <div className="py-12 text-center opacity-30 border-2 border-dashed border-accent-light rounded-2xl">
            <ImageIcon size={32} className="mx-auto mb-2" />
            <p className="text-[10px] font-black uppercase tracking-widest">Banco de Logos Vazio</p>
         </div>
       )}

       <div className="grid grid-cols-2 gap-2">
          {filtered.map((logo: any, index: number) => (
            <div key={`logo-${logo.id || 'db'}-${encodeURIComponent(logo.brand_name || '')}-${index}`} className="bg-bg-cell border border-accent-light rounded-2xl p-3 flex flex-col items-center gap-2 group relative">
               <div className="w-full aspect-square bg-bg-app rounded-xl overflow-hidden flex items-center justify-center p-2 relative group-hover:bg-bg-card transition-colors">
                  <img src={logo.logo_data} alt={logo.brand_name} className="max-w-full max-h-full object-contain" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                     <button 
                       onClick={() => startEditing(logo)}
                       className="p-2 bg-accent-blue text-white rounded-lg hover:scale-110 transition-transform"
                     >
                       <Edit2 size={16} />
                     </button>
                     <button 
                       onClick={() => onDeleteLogo(logo.id)}
                       className="p-2 bg-red-500 text-white rounded-lg hover:scale-110 transition-transform"
                     >
                       <Trash2 size={16} />
                     </button>
                  </div>
               </div>
               
               {editingId === logo.id ? (
                 <div className="w-full space-y-1">
                    <input 
                      autoFocus
                      type="text"
                      onClick={(e) => e.stopPropagation()}
                      className="w-full bg-bg-app border border-accent-blue text-[10px] font-bold p-1 rounded uppercase text-center"
                      value={editNameValue}
                      onChange={(e) => setEditNameValue(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && saveEdit()}
                      onBlur={saveEdit}
                    />
                 </div>
               ) : (
                 <p className="text-[10px] font-black uppercase tracking-tighter text-ink-primary truncate w-full text-center">{logo.brand_name}</p>
               )}
            </div>
          ))}
       </div>
    </div>
  );
}

function CarBankTab({ 
  carsDatabase = [], 
  onAddCars, 
  onDeleteCar, 
  onUpdateCarName, 
  onSaveAll, 
  onDeleteAll,
  isSyncing, 
  onOpenCarPreview,
  linkingForCarName,
  onSelectCarForLink
}: any) {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (linkingForCarName) {
      setSearch(linkingForCarName);
    }
  }, [linkingForCarName]);

  const handleFilesSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      const promises = Array.from(files).map((file: File) => {
        return new Promise<{name: string, data: string}>(async (resolve, reject) => {
          try {
            const webp = await convertToWebP(file);
            resolve({
              name: file.name.split('.')[0].replace(/[-_]/g, ' '),
              data: webp
            });
          } catch (err) {
            reject(err);
          }
        });
      });

      const results = await Promise.all(promises);
      await onAddCars(results);
    } catch (err) {
      console.error(err);
      alert('Erro no upload de carros.');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const startEditing = (car: any) => {
    setEditingId(car.id);
    setEditNameValue(car.brand_name);
  };

  const saveEdit = () => {
    if (editingId && editNameValue.trim()) {
      onUpdateCarName(editingId, editNameValue.trim());
      setEditingId(null);
    }
  };

  const filtered = useMemo(() => {
    if (!carsDatabase) return [];
    if (!search || !search.trim()) return carsDatabase.filter(Boolean);

    return carsDatabase
      .map((c: any) => {
        if (!c) return null;
        const dbName = c.brand_name || '';
        if (!dbName) return null;
        const score = getSmartSearchScore(search, dbName);
        return { item: c, score };
      })
      .filter((x: any) => x !== null && x.score > 0)
      .sort((a: any, b: any) => b.score - a.score)
      .map((x: any) => x.item);
  }, [carsDatabase, search]);

  return (
    <div className="space-y-4">
       {linkingForCarName && (
         <div className="bg-accent-blue/10 border border-accent-blue/20 p-3 rounded-2xl flex items-center justify-between animate-in fade-in slide-in-from-top-1 duration-150">
           <div className="flex items-center gap-2">
             <Link size={14} className="text-accent-blue animate-pulse" />
             <span className="text-[11px] font-bold text-ink-primary">
               {language === 'pt' ? `Vinculando imagem ao carro: ${linkingForCarName}` : `Linking image to: ${linkingForCarName}`}
             </span>
           </div>
           <button 
             onClick={(e) => {
               e.stopPropagation();
               onSelectCarForLink(null);
             }}
             className="text-[9px] font-black uppercase text-red-500 hover:text-red-600 tracking-wider"
           >
             {language === 'pt' ? "Limpar" : "Clear"}
           </button>
         </div>
       )}

        <div className="space-y-3">
           <div className="relative w-full">
               <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary" />
               <input 
                 type="text" 
                 placeholder="Buscar no banco..."
                 value={search}
                 onChange={(e) => setSearch(e.target.value)}
                 className="w-full h-11 bg-bg-cell border border-accent-light rounded-2xl pl-11 pr-4 text-xs font-bold focus:outline-none focus:border-accent-blue transition-all"
               />
           </div>
           <div className="flex gap-2 justify-end">
             <input 
               type="file" 
               multiple 
               accept="image/*" 
               ref={fileInputRef} 
               onChange={handleFilesSelect} 
               className="hidden" 
             />
             <button 
               type="button"
               disabled={isSyncing}
               onClick={(e) => {
                 e.stopPropagation();
                 fileInputRef.current?.click();
               }}
               className="flex-1 sm:flex-initial h-11 px-4 bg-bg-app border border-accent-light text-ink-primary rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-[10px] hover:bg-bg-card transition-all disabled:opacity-50"
             >
               <Upload size={16} />
               {isSyncing ? "..." : t('add')}
             </button>
             <button 
               type="button"
               disabled={isSyncing}
               onClick={(e) => {
                 e.stopPropagation();
                 onSaveAll && onSaveAll();
               }}
               className="flex-1 sm:flex-initial h-11 px-4 bg-accent-blue text-white rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-[10px] shadow-lg shadow-accent-blue/20 active:scale-95 transition-all disabled:opacity-50"
             >
               <Save size={16} />
               {isSyncing ? "..." : t('save_all')}
             </button>
             <button 
               type="button"
               disabled={isSyncing || (carsDatabase || []).length === 0}
               onClick={(e) => {
                 e.stopPropagation();
                 if (confirm('Excluir todos os carros do banco? Essa ação não pode ser desfeita.')) {
                   onDeleteAll && onDeleteAll();
                 }
               }}
               className="flex-1 sm:flex-initial h-11 px-4 bg-red-500 text-white rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-[10px] shadow-lg shadow-red-500/20 active:scale-95 transition-all disabled:opacity-50"
             >
               <Trash2 size={16} />
               Excluir todos
             </button>
           </div>
        </div>

       {carsDatabase.length === 0 && (
         <div className="py-12 text-center opacity-30 border-2 border-dashed border-accent-light rounded-2xl">
            <CarFront size={32} className="mx-auto mb-2 text-ink-secondary" />
            <p className="text-[10px] font-black uppercase tracking-widest">Banco de Carros Vazio</p>
         </div>
       )}

       <div className="grid grid-cols-2 gap-2">
          {filtered.map((car: any, index: number) => (
            <div 
              key={`car-${car.id || 'db'}-${encodeURIComponent(car.brand_name || '')}-${encodeURIComponent(car.car_name || '')}-${index}`} 
              onClick={() => onOpenCarPreview && onOpenCarPreview(car)} 
              className="bg-bg-cell border border-accent-light rounded-2xl p-3 flex flex-col items-center gap-2 group relative cursor-pointer"
            >
               <div className="w-full aspect-square bg-bg-app rounded-xl overflow-hidden flex items-center justify-center p-2 relative group-hover:bg-bg-card transition-colors">
                  <img src={car.logo_data} alt={car.brand_name} className="max-w-full max-h-full object-contain" />
                  
                  {linkingForCarName && (
                     <button
                       onClick={(e) => {
                         e.stopPropagation();
                         e.preventDefault();
                         onSelectCarForLink(car.logo_data);
                       }}
                       className="absolute bottom-2 right-2 p-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-[8.5px] font-extrabold uppercase shadow-md shadow-emerald-500/20 active:scale-95"
                       title={language === 'pt' ? "Vincular este carro" : "Link this car"}
                     >
                       <Check size={10} />
                       <span>{language === 'pt' ? "Vincular" : "Link"}</span>
                     </button>
                  )}

                  <div className="absolute top-1 right-1 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity flex gap-1" onClick={(e) => { e.stopPropagation(); e.preventDefault(); }}>
                     <button 
                       type="button"
                       onClick={(e) => {
                         e.stopPropagation();
                         e.preventDefault();
                         startEditing(car);
                       }}
                       className="p-2 bg-accent-blue text-white rounded-lg hover:scale-110 transition-transform"
                       title={language === 'pt' ? 'Editar carro' : 'Edit car'}
                     >
                       <Edit2 size={16} />
                     </button>
                     <button 
                       type="button"
                       onClick={(e) => {
                         e.stopPropagation();
                         e.preventDefault();
                         if (confirm(`Excluir "${car.brand_name}" do banco de carros?`)) {
                           onDeleteCar && onDeleteCar(car.id);
                         }
                       }}
                       className="p-2 bg-red-500 text-white rounded-lg hover:scale-110 transition-transform"
                       title={language === 'pt' ? 'Excluir carro' : 'Delete car'}
                     >
                       <Trash2 size={16} />
                     </button>
                  </div>
               </div>
               
               {editingId === car.id ? (
                 <div className="w-full space-y-1">
                    <input 
                      autoFocus
                      type="text"
                      onClick={(e) => e.stopPropagation()}
                      className="w-full bg-bg-app border border-accent-blue text-[10px] font-bold p-1 rounded uppercase text-center"
                      value={editNameValue}
                      onChange={(e) => setEditNameValue(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && saveEdit()}
                      onBlur={saveEdit}
                    />
                 </div>
               ) : (
                 <p className="text-[10px] font-black uppercase tracking-tighter text-ink-primary truncate w-full text-center">{car.brand_name}</p>
               )}
            </div>
          ))}
       </div>
    </div>
  );
}


function TrackBankTab({ 
  tracks = [], 
  onImportTrackPack, 
  onUpdateTrack, 
  onDeleteTrack 
}: any) {
  const { t } = useLanguage();
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="space-y-4">
       <div className="relative w-full">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary" />
          <input 
            type="text" 
            placeholder={t('search_track_placeholder')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-11 bg-bg-cell border border-accent-light rounded-2xl pl-11 pr-4 text-xs font-bold focus:outline-none focus:border-accent-blue transition-all"
          />
       </div>

       <div className="flex gap-2 justify-end">
          <button 
            type="button"
            onClick={onImportTrackPack}
            className="w-full h-11 px-4 bg-accent-blue/10 border border-accent-blue/30 text-accent-blue rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest text-[10px] hover:bg-accent-blue/20 transition-all"
          >
            <Upload size={16} />
            {t('import_pack')}
          </button>
       </div>

       <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
          {tracks
            .map((track: any) => ({
              item: track,
              score: Math.max(
                getSmartSearchScore(search, track.name || ''),
                getSmartSearchScore(search, track.location || '')
              )
            }))
            .filter((x: any) => (!search || !search.trim()) || x.score > 0)
            .sort((a: any, b: any) => {
              if (search && search.trim()) return b.score - a.score;
              return (a.item.name || '').localeCompare(b.item.name || '');
            })
            .map((x: any) => x.item)
            .map((track: any, index: number) => (
             <div key={`trackdb-${track.id || 'db'}-${encodeURIComponent(track.name || '')}-${index}`} className="bg-bg-cell border border-accent-light rounded-2xl p-4 flex items-center justify-between group transition-all">
                <div className="flex-1">
                  {editingId === track.id ? (
                    <div className="grid grid-cols-2 gap-2 pr-2">
                       <input 
                         autoFocus
                         className="bg-bg-card border border-accent-blue rounded-lg px-2 py-1 text-xs font-bold w-full"
                         value={track.name}
                         onChange={(e) => onUpdateTrack(track.id, { name: e.target.value })}
                       />
                       <input 
                         className="bg-bg-card border border-accent-blue rounded-lg px-2 py-1 text-xs font-bold w-full"
                         value={track.location}
                         onChange={(e) => onUpdateTrack(track.id, { location: e.target.value })}
                       />
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl filter drop-shadow-sm">{getCountryFlagFromTrack(track)}</span>
                        <p className="font-bold text-sm text-ink-primary">{track.name}</p>
                      </div>
                      <p className="text-[10px] font-bold text-ink-secondary uppercase tracking-widest mt-0.5 ml-8">{track.location || t('location_not_defined')}</p>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                   <label className="p-2 cursor-pointer hover:bg-accent-light text-ink-secondary rounded-xl transition-colors" title="Upload Background">
                     <Image size={16} />
                     <input type="file" className="hidden" accept="image/*" onChange={async (e) => {
                       const file = e.target.files?.[0];
                       if (file) {
                         try {
                           const webp = await convertToWebP(file);
                           onUpdateTrack(track.id, { customBackground: webp });
                         } catch (err) { console.error(err); }
                       }
                     }} />
                   </label>
                   <label className="p-2 cursor-pointer hover:bg-accent-light text-ink-secondary rounded-xl transition-colors" title="Upload Logo">
                     <ImageIcon size={16} />
                     <input type="file" className="hidden" accept="image/*" onChange={async (e) => {
                       const file = e.target.files?.[0];
                       if (file) {
                         try {
                           const webp = await convertToWebP(file);
                           onUpdateTrack(track.id, { customLogo: webp });
                         } catch (err) { console.error(err); }
                       }
                     }} />
                   </label>
                   <button 
                     onClick={() => setEditingId(editingId === track.id ? null : track.id)}
                     className={`p-2 rounded-xl transition-colors ${editingId === track.id ? 'bg-accent-blue text-white' : 'hover:bg-accent-light text-ink-secondary'}`}
                   >
                     {editingId === track.id ? <Check size={16} /> : <Edit2 size={16} />}
                   </button>
                   <button 
                     onClick={() => onDeleteTrack(track.id)}
                     className="p-2 hover:bg-red-500/10 text-red-400 rounded-xl transition-colors"
                   >
                     <Trash2 size={16} />
                   </button>
                </div>
             </div>
          ))}
       </div>
    </div>
  );
}


function AdminPanel({  
  onClose, 
  onSaveCloud, 
  onLoadCloud, 
  onDeduplicate,
  onScanOrphans,
  onRestoreTrash,
  onImportTrackPack,
  onUpdateTrack,
  onDeleteTrack,
  tracks,
  trashCount,
  isSyncing,
  syncError,
  onOpenPilotManager,
  logosDatabase,
  onAddLogos,
  onDeleteLogo,
  onUpdateName,
  onSaveAll,
  carsDatabase,
  onAddCars,
  onDeleteCar,
  onDeleteAllCars,
  onUpdateCarName,
  onOpenCarPreview,
  linkingForCarName,
  onSelectCarForLink,
  entries = [],
  suggestions,
  onRenameCar
}: any) {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'data' | 'drivers' | 'logos' | 'cars' | 'tracks' | 'car_names'>('cars');
  const [allProfiles, setAllProfiles] = useState<UserProfile[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [isDeletingUser, setIsDeletingUser] = useState(false);

  useEffect(() => {
    loadProfiles();
  }, []);

  const loadProfiles = async () => {
    setIsLoadingUsers(true);
    setLoadError(null);
    try {
      const data = await supabaseService.getAllProfilesAdmin();
      setAllProfiles(data);
    } catch (err: any) {
      console.error(err);
      setLoadError(err.message || 'Error loading profiles');
    } finally {
      setIsLoadingUsers(false);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Excluir este usuário definitivamente do Auth e remover os dados dele do app?')) return;
    
    setIsDeletingUser(true);
    try {
      await supabaseService.deleteProfile(userId);
      setAllProfiles(prev => prev.filter(p => p.id !== userId));
    } catch (err: any) {
      alert(err.message || 'Erro ao excluir usuário');
    } finally {
      setIsDeletingUser(false);
    }
  };

  const handleToggleBan = async (user: UserProfile) => {
    const newBanStatus = !user.is_banned;
    if (newBanStatus && !confirm(t('ban_confirm'))) return;
    
    try {
      await supabaseService.toggleBanProfile(user.id, newBanStatus);
      setAllProfiles(prev => prev.map(p => p.id === user.id ? { ...p, is_banned: newBanStatus } : p));
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar status de banimento');
    }
  };

  const filteredUsers = allProfiles.filter(p => {
    const name = (p.display_name || 'Piloto').toLowerCase();
    const psn = (p.psn_id || '').toLowerCase();
    const email = (p.email || '').toLowerCase();
    const q = userSearch.toLowerCase();
    return name.includes(q) || psn.includes(q) || email.includes(q);
  });

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-bg-card w-full max-w-md rounded-[32px] overflow-hidden flex flex-col border border-accent-light shadow-2xl max-h-[90vh]"
      >
        <div className="p-6 border-b border-accent-light flex items-center justify-between bg-accent-blue/5">
          <div className="flex items-center gap-2">
            <ShieldCheck size={24} className="text-accent-blue" />
            <div className="flex flex-col">
              <h3 className="font-bold text-xl text-ink-primary leading-tight">{t('administration')}</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-accent-blue/60">
                {activeTab === 'data' ? t('data_management') : activeTab === 'tracks' ? t('track_management') : activeTab === 'logos' ? 'LOGOS' : activeTab === 'cars' ? 'CARS' : t('driver_manager')}
              </p>
            </div>
          </div>
          <button onClick={onClose}><X size={24} className="text-ink-secondary" /></button>
        </div>

        {/* Tab Switcher */}
        <div className="px-4 pt-4">
          <div className="flex flex-col gap-1 bg-bg-cell rounded-[22px] p-1 border border-accent-light shadow-sm">
             <div className="grid grid-cols-4 gap-1">
               <button 
                 onClick={() => setActiveTab('logos')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'logos' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1">
                   <ImageIcon size={10} />
                   <span>Logos</span>
                 </div>
               </button>
               <button 
                 onClick={() => setActiveTab('tracks')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'tracks' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1">
                   <Globe size={10} />
                   <span>Pistas</span>
                 </div>
               </button>
               <button 
                 onClick={() => setActiveTab('cars')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'cars' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1">
                   <CarFront size={10} />
                   <span>Cars</span>
                 </div>
               </button>
               <button 
                 onClick={() => setActiveTab('car_names')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'car_names' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1">
                   <Car size={10} />
                   <span>{language === 'pt' ? 'Nomes' : 'Names'}</span>
                 </div>
               </button>
             </div>
             
             <div className="grid grid-cols-3 gap-1">
               <button 
                 onClick={() => setActiveTab('data')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'data' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1.5">
                   <Database size={10} />
                   <span>{t('data')}</span>
                 </div>
               </button>
               <button 
                 onClick={() => setActiveTab('drivers')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'drivers' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1.5">
                   <Users size={10} />
                   <span>{t('drivers')}</span>
                 </div>
               </button>
               <button 
                 onClick={() => setActiveTab('track_images')}
                 className={`py-1.5 rounded-[18px] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'track_images' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'}`}
               >
                 <div className="flex items-center justify-center gap-1.5">
                   <Image size={10} />
                   <span>Cenas</span>
                 </div>
               </button>
             </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {activeTab === 'cars' ? (
             <CarBankTab 
                carsDatabase={carsDatabase} 
                onAddCars={onAddCars} 
                onDeleteCar={onDeleteCar} 
                onUpdateCarName={onUpdateCarName}
                onSaveAll={onSaveAll}
                onDeleteAll={onDeleteAllCars}
                isSyncing={isSyncing}
                onOpenCarPreview={onOpenCarPreview}
                linkingForCarName={linkingForCarName}
                onSelectCarForLink={onSelectCarForLink}
             />
          ) : activeTab === 'car_names' ? (
              <CarNamesManagerTab 
                 entries={entries}
                 carsDatabase={carsDatabase}
                 suggestions={suggestions}
                 onRenameCar={onRenameCar}
                 isSyncing={isSyncing}
              />
          ) : activeTab === 'logos' ? (
             <LogoBankTab 
                logosDatabase={logosDatabase} 
                onAddLogos={onAddLogos} 
                onDeleteLogo={onDeleteLogo} 
                onUpdateName={onUpdateName}
                onSaveAll={onSaveAll}
             />
          ) : activeTab === 'tracks' ? (
             <TrackBankTab 
                tracks={tracks}
                onImportTrackPack={onImportTrackPack}
                onUpdateTrack={onUpdateTrack}
                onDeleteTrack={onDeleteTrack}
             />
          ) : activeTab === 'track_images' ? (
             <TrackImagesTab 
                tracks={tracks} 
                onUpdateTrack={onUpdateTrack}
             />
          ) : activeTab === 'data' ? (
            <>
              {syncError && (
                 <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl space-y-3">
                   <div className="flex items-center gap-2 text-red-500">
                     <AlertCircle size={18} />
                     <span className="text-[10px] font-black uppercase tracking-widest">{t('sync_error')}</span>
                   </div>
                   <p className="text-[11px] text-red-500 font-medium leading-relaxed whitespace-pre-wrap">
                     {syncError}
                   </p>

                   {syncError.includes('SUPABASE_SCHEMA.sql') && (
                     <button 
                       onClick={() => {
                         navigator.clipboard.writeText(supabaseSchemaRaw);
                         alert('SQL code copied to clipboard!\n\nPaste it into your Supabase SQL Editor and click RUN.');
                       }}
                       className="w-full py-2 bg-red-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20 active:scale-[0.98]"
                     >

                       COPY SCHEMA SQL
                     </button>
                   )}

                   <button 
                     onClick={onLoadCloud}
                     disabled={isSyncing}
                     className="w-full py-2 border border-red-500/30 text-red-500 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500/10 transition-colors disabled:opacity-50 active:scale-[0.98]"
                   >
                     {isSyncing ? t('attempting') : t('try_again')}
                   </button>
                 </div>
              )}

              {/* Cloud Sync Section */}
              <div className="space-y-3">
                 <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary ml-2">{t('cloud_sync')}</h4>
                 <div className="bg-bg-cell rounded-3xl p-1.5 border border-accent-light">
                    <button 
                      onClick={onSaveCloud} 
                      disabled={isSyncing} 
                      className="w-full text-left p-4 rounded-[22px] flex items-center gap-4 hover:bg-bg-card text-accent-blue font-bold text-sm transition-all active:scale-[0.98] disabled:opacity-50"
                    >
                      <UploadCloud size={20}/> {t('save_to_supabase')}
                    </button>
                    <div className="h-px bg-accent-light/30 mx-4" />
                    <button 
                      onClick={onLoadCloud} 
                      disabled={isSyncing} 
                      className="w-full text-left p-4 rounded-[22px] flex items-center gap-4 hover:bg-bg-card text-sm font-bold text-ink-primary transition-all active:scale-[0.98] disabled:opacity-50"
                    >
                      <CloudDownload size={20}/> {t('download_from_cloud')}
                    </button>
                 </div>
              </div>

              {/* External Database Section */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary ml-2">{t('data_management')}</h4>
                <div className="bg-bg-cell rounded-3xl p-1.5 border border-accent-light">
                    <button 
                      onClick={() => setActiveTab('tracks')} 
                      className="w-full text-left p-4 rounded-[22px] flex items-center gap-4 hover:bg-bg-card font-bold text-sm transition-all active:scale-[0.98] text-emerald-500"
                    >
                      <Globe size={20}/> {t('manage_tracks')} ({tracks.length})
                    </button>
                    <div className="h-px bg-accent-light/30 mx-4" />
                    <button 
                      onClick={onOpenPilotManager} 
                      className="w-full text-left p-4 rounded-[22px] flex items-center gap-4 hover:bg-bg-card font-bold text-sm transition-all active:scale-[0.98] text-accent-blue"
                    >
                      <Users size={20}/> {t('driver_manager')} (Full View)
                    </button>
                </div>
              </div>

              {/* Maintenance Tools */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary ml-2">{t('tools')}</h4>
                <div className="bg-bg-cell rounded-3xl p-5 border border-accent-light space-y-3">
                  <div className="flex items-center justify-between">
                     <div className="flex items-center gap-3 text-emerald-500">
                        <Zap size={20} />
                        <span className="text-xs font-black uppercase tracking-widest">{t('data_maintenance')}</span>
                     </div>
                  </div>
                  
                  <div className="space-y-2 pt-2 border-t border-accent-light/10">
                    <button 
                      onClick={onDeduplicate}
                      className="w-full text-left p-4 rounded-2xl flex items-center gap-3 hover:bg-bg-card bg-bg-card/30 border border-transparent hover:border-accent-light transition-all"
                    >
                      <RefreshCcw size={18} className="text-orange-500" />
                      <div>
                        <p className="font-bold text-xs uppercase tracking-wider">{t('remove_duplicates')}</p>
                        <p className="text-[9px] text-ink-secondary font-medium">{t('remove_duplicates_desc')}</p>
                      </div>
                    </button>
                    
                    <button 
                      onClick={() => {
                        const total = trashCount.tracks + trashCount.entries;
                        if (total === 0) {
                          alert(t('trash_empty'));
                          return;
                        }
                        if (confirm(t('restore_trash_confirm').replace('{tracks}', String(trashCount.tracks)).replace('{entries}', String(trashCount.entries)))) {
                          onRestoreTrash();
                        }
                      }}
                      className="w-full text-left p-4 rounded-2xl flex items-center gap-3 hover:bg-bg-card bg-bg-card/30 border border-transparent hover:border-accent-light transition-all"
                    >
                      <RotateCcw size={18} className="text-emerald-500" />
                      <div>
                        <p className="font-bold text-xs uppercase tracking-wider">{t('recover_trash')} ({trashCount.tracks + trashCount.entries})</p>
                        <p className="text-[9px] text-ink-secondary font-medium">{t('recover_trash_desc')}</p>
                      </div>
                    </button>
                    
                    <button 
                      onClick={onScanOrphans}
                      className="w-full text-left p-4 rounded-2xl flex items-center gap-3 hover:bg-bg-card bg-bg-card/30 border border-transparent hover:border-accent-light transition-all"
                    >
                      <Search size={18} className="text-accent-blue" />
                      <div>
                        <p className="font-bold text-xs uppercase tracking-wider">{t('scan_inconsistencies')}</p>
                        <p className="text-[9px] text-ink-secondary font-medium">{t('scan_inconsistencies_desc')}</p>
                      </div>
                    </button>

                    <button 
                      onClick={async () => {
                        if (confirm(t('recalculate_stats_confirm'))) {
                          try {
                            const count = await supabaseService.recalculateAllPilotStats();
                            alert(t('recalculate_stats_success').replace('{count}', String(count)));
                          } catch (err: any) {
                            alert('Error recalculating: ' + err.message);
                          }
                        }
                      }}
                      className="w-full text-left p-4 rounded-2xl flex items-center gap-3 hover:bg-bg-card bg-bg-card/30 border border-transparent hover:border-accent-light transition-all"
                    >
                      <BarChart size={18} className="text-accent-blue" />
                      <div>
                        <p className="font-bold text-xs uppercase tracking-wider">{t('recalculate_stats')}</p>
                        <p className="text-[9px] text-ink-secondary font-medium">{t('recalculate_stats_desc')}</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary" />
                <input 
                  type="text" 
                  placeholder={t('search_driver_placeholder')}
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full h-12 bg-bg-cell border border-accent-light rounded-2xl pl-12 pr-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:border-accent-blue transition-all"
                />
              </div>

              {loadError && (
                <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl">
                   <p className="text-[10px] text-red-500 font-bold uppercase tracking-widest flex items-center gap-2">
                     <AlertCircle size={14} /> {t('error_loading_drivers')}
                   </p>
                   <p className="text-[9px] text-red-500/70 mt-1">{loadError}</p>
                </div>
              )}

              {isLoadingUsers ? (
                <div className="py-20 flex flex-col items-center justify-center gap-4">
                   <div className="w-8 h-8 border-4 border-accent-blue/10 border-t-accent-blue rounded-full animate-spin" />
                   <p className="text-[9px] font-black uppercase tracking-[0.2em] text-ink-secondary animate-pulse">{t('syncing_cloud')}</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary ml-2">{t('registered_drivers')} ({filteredUsers.length})</h4>
                  <div className="space-y-2">
                    {filteredUsers.map((user, index) => (
                      <div key={`${user.id}-${index}`} className={`bg-bg-cell border rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center gap-4 sm:justify-between group transition-all ${user.is_banned ? 'border-red-500/30' : 'border-accent-light hover:border-accent-blue/30'}`}>
                         <div className="flex items-center gap-3 min-w-0 flex-1">
                            <div className="relative shrink-0">
                               <div className="w-10 h-10 rounded-xl overflow-hidden bg-bg-app border border-accent-light">
                                  {user.avatar_url ? (
                                    <img src={user.avatar_url} alt={user.display_name} className="w-full h-full object-cover" />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center text-ink-secondary/20">
                                      <User size={20} />
                                    </div>
                                  )}
                               </div>
                               {user.is_banned && (
                                 <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white flex items-center justify-center">
                                    <ShieldAlert size={8} className="text-white" />
                                 </div>
                               )}
                            </div>
                            <div className="min-w-0 flex-1">
                               <div className="flex items-center gap-2">
                                  <p className="text-xs font-black uppercase tracking-tight text-ink-primary leading-none truncate">{user.display_name}</p>
                                  {user.is_banned && (
                                    <span className="text-[7px] font-black bg-red-500 text-white px-1.5 py-0.5 rounded-full tracking-widest shrink-0">{t('banned')}</span>
                                  )}
                               </div>
                               <div className="flex flex-col gap-0.5 mt-1">
                                 <p className="text-[9px] font-bold text-accent-blue tracking-widest uppercase truncate">@{user.psn_id || 'GT_PILOT'}</p>
                                 <p className="text-[8px] font-bold text-ink-secondary/60 truncate">
                                   {user.email || 'sem email visível'}
                                 </p>
                                 <div className="flex items-center gap-2 mt-0.5 text-[8px] font-bold text-ink-secondary/50">
                                    <span className="flex items-center gap-0.5"><Trophy size={8} /> {user.total_wins || 0}</span>
                                    <span className="flex items-center gap-0.5"><Zap size={8} /> {user.total_races || 0}</span>
                                 </div>
                               </div>
                            </div>
                         </div>
                         <div className="flex items-center justify-end gap-2 shrink-0 sm:pl-3 sm:border-l border-accent-light/30 pt-3 sm:pt-0 border-t sm:border-t-0">
                            {user.is_admin && (
                               <div className="p-2 border border-accent-blue/20 bg-accent-blue/10 text-accent-blue rounded-xl" title="Admin">
                                  <ShieldCheck size={16} />
                               </div>
                            )}
                            <button 
                              onClick={() => handleToggleBan(user)}
                              className={`p-2 border rounded-xl transition-all ${user.is_banned ? 'bg-red-500 text-white shadow-lg border-red-500 shadow-red-500/20' : 'border-orange-500/20 bg-orange-500/5 hover:bg-orange-500/10 text-orange-400'}`}
                              title={user.is_banned ? t('unban_driver') : t('ban_driver')}
                            >
                              <ShieldAlert size={16} />
                            </button>
                            <button 
                              onClick={() => handleDeleteUser(user.id)}
                              className="p-2 border border-red-500/20 bg-red-500/5 hover:bg-red-500 hover:text-white text-red-500 rounded-xl transition-colors shadow-sm"
                              title={t('delete_profile')}
                            >
      
                            </button>
                         </div>
                      </div>
                    ))}
                    {filteredUsers.length === 0 && (
                      <div className="py-12 text-center opacity-30">
                        <Users size={32} className="mx-auto mb-2" />
                        <p className="text-[10px] font-black uppercase tracking-widest">{t('no_drivers_found')}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="p-6 bg-bg-cell border-t border-accent-light">
          <button 
            onClick={onClose}
            className="w-full h-12 bg-accent-blue text-white rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-accent-blue/90 active:scale-95 transition-all shadow-lg shadow-accent-blue/20"
          >
            {t('close_panel')}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function SettingsMenu({ 
  onClose, 
  onSaveCloud, 
  onLoadCloud, 
  onSignOut, 
  onImport, 
  onExport, 
  onCreateRestorePoint,
  onApplyRestorePoint,
  onLayoutEditor, 
  onDeduplicate,
  onScanOrphans,
  onClearTrash,
  onRestoreTrash,
  onRestoreTrash: onRestoreAction,
  trashCount,
  isSyncing, 
  syncError, 
  session,
  tracks
}: any) {
  const { t, language } = useLanguage();
  const [isUploading, setIsUploading] = useState(false);
  const [showDataTools, setShowDataTools] = useState(false);

  return (
    <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <motion.div className="bg-bg-card w-full max-w-sm rounded-[32px] overflow-hidden flex flex-col border border-accent-light shadow-2xl max-h-[90vh]">
        <div className="p-6 border-b border-accent-light flex items-center justify-between">
          <h3 className="font-bold text-xl text-ink-primary">{t('settings')}</h3>
          <button onClick={onClose}><X size={24} className="text-ink-secondary" /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
           {/* Section - Restore Point */}
           <div className="bg-bg-cell rounded-[24px] p-1.5 border border-accent-light shadow-sm">
             <button onClick={onCreateRestorePoint} className="w-full text-left p-4 rounded-[20px] flex items-center gap-4 hover:bg-bg-card text-ink-primary font-bold text-sm transition-all active:scale-[0.98] group">
               <div className="w-10 h-10 rounded-xl bg-accent-blue/5 flex items-center justify-center text-accent-blue group-hover:bg-accent-blue/10 transition-colors">
                 <Save size={20}/>
               </div>
               <span>{t('create_restore_point')}</span>
             </button>
             <div className="h-px bg-accent-light/30 mx-4" />
             <button onClick={onApplyRestorePoint} className="w-full text-left p-4 rounded-[20px] flex items-center gap-4 hover:bg-bg-card text-ink-primary font-bold text-sm transition-all active:scale-[0.98] group">
               <div className="w-10 h-10 rounded-xl bg-accent-blue/5 flex items-center justify-center text-accent-blue group-hover:bg-accent-blue/10 transition-colors">
                 <RefreshCw size={20}/>
               </div>
               <span>{t('apply_restore_point')}</span>
             </button>
           </div>
           <div className="bg-bg-cell rounded-[24px] p-1.5 border border-accent-light shadow-sm">
             <button onClick={() => onImport()} className="w-full text-left p-4 rounded-[20px] flex items-center gap-4 hover:bg-bg-card text-ink-primary font-bold text-sm transition-all active:scale-[0.98] group">
               <div className="w-10 h-10 rounded-xl bg-accent-blue/5 flex items-center justify-center text-accent-blue group-hover:bg-accent-blue/10 transition-colors">
                 <Upload size={20}/>
               </div>
               <span>{t('import_json')}</span>
             </button>
             <div className="h-px bg-accent-light/30 mx-4" />
             <button onClick={onExport} className="w-full text-left p-4 rounded-[20px] flex items-center gap-4 hover:bg-bg-card text-ink-primary font-bold text-sm transition-all active:scale-[0.98] group">
               <div className="w-10 h-10 rounded-xl bg-accent-blue/5 flex items-center justify-center text-accent-blue group-hover:bg-accent-blue/10 transition-colors">
                 <Download size={20}/>
               </div>
               <span>{t('export_json')}</span>
             </button>
           </div>

           {/* Section - Layout */}
           <div className="bg-bg-cell rounded-[24px] p-1.5 border border-accent-light shadow-sm">
             <button onClick={() => { onClose(); if(onLayoutEditor) onLayoutEditor(); }} className="w-full text-left p-4 rounded-[20px] flex items-center gap-4 hover:bg-bg-card text-ink-primary font-bold text-sm transition-all active:scale-[0.98] group">
               <div className="w-10 h-10 rounded-xl bg-bg-app flex items-center justify-center text-ink-secondary group-hover:text-accent-blue transition-colors">
                 <Layout size={20}/>
               </div>
               <span>{t('card_layout')}</span>
             </button>
           </div>

           <div className="pt-8">
             <button 
               onClick={() => { onSignOut(); onClose(); }} 
               className="w-full p-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-red-500/5 text-red-500 font-black uppercase tracking-[0.2em] text-[10px] transition-all border border-transparent hover:border-red-500/10"
             >
               <X size={16}/> 
               {t('sign_out')}
             </button>
           </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
