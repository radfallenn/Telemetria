import React, { useEffect, useState } from 'react';
import { X, Maximize, Minimize } from 'lucide-react';
import { LiveTelemetry } from './LiveTelemetry';

interface TelemetryFullscreenProps {
  onClose: () => void;
  t?: (key: string) => string;
}

export const TelemetryFullscreen: React.FC<TelemetryFullscreenProps> = ({ onClose }) => {
  const [realFullscreen, setRealFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setRealFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const toggleRealFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setRealFullscreen(true);
      } else {
        await document.exitFullscreen();
        setRealFullscreen(false);
      }
    } catch (e) {
      setRealFullscreen(!realFullscreen);
    }
  };

  return (
    <div className="fixed inset-0 z-[99999] w-screen h-screen overflow-y-auto bg-[#07090e] text-white flex flex-col font-sans select-none animate-fade-in p-4 sm:p-6 scrollbar-none">
      
      {/* Absolute Header with Exit/Fullscreen Controls */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/40 border border-white/5 backdrop-blur-md rounded-2xl mb-4 shrink-0">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <div>
            <h1 className="text-xs font-black tracking-widest text-[#5ca1ff] uppercase">GT7 HUD MODO FULLSCREEN</h1>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* HTML5 Native Fullscreen handler Button */}
          <button
            onClick={toggleRealFullscreen}
            className="p-1 px-2.5 bg-white/5 border border-white/10 hover:bg-white/10 text-zinc-300 hover:text-white active:scale-95 transition-all rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1"
            title={realFullscreen ? "Sair da Tela Cheia" : "Tela Cheia Real"}
          >
            {realFullscreen ? <Minimize size={11} /> : <Maximize size={11} />}
            <span>{realFullscreen ? "Janela" : "Janela Cheia"}</span>
          </button>

          {/* Sair Fullscreen Overlay Button */}
          <button
            onClick={onClose}
            className="flex items-center gap-1 p-1 px-2.5 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-rose-400 font-black uppercase text-[9px] tracking-wider active:scale-95 transition-colors rounded-lg hover:text-rose-300"
          >
            <X size={11} /> Sair do HUD
          </button>
        </div>
      </div>

      {/* Main unified Dashboard content */}
      <div className="flex-1 overflow-y-auto pr-1">
        <LiveTelemetry />
      </div>

    </div>
  );
};
