import React, { useState, useRef } from 'react';
import { Camera } from 'lucide-react';
import { UserProfile } from '../types';
import { supabaseService } from '../services/supabaseService';
import { useLanguage } from '../contexts/LanguageContext';

interface ProfileSetupOverlayProps {
  profile: UserProfile;
  onSave: (profileUpdate: Partial<UserProfile>) => Promise<void>;
}

export function ProfileSetupOverlay({ profile, onSave }: ProfileSetupOverlayProps) {
  const { t } = useLanguage();
  const [displayName, setDisplayName] = useState(() => {
    if (profile.display_name === 'Driver') return '';
    return profile.display_name || '';
  });
  const [avatarUrl, setAvatarUrl] = useState(profile.avatar_url || '');
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert(t('valid_image_error'));
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      alert(t('photo_size_error'));
      return;
    }

    setIsUploadingAvatar(true);
    try {
      const publicUrl = await supabaseService.uploadEvidenceImage(file);
      setAvatarUrl(publicUrl);
    } catch (err: any) {
      console.error('Error uploading avatar:', err);
      alert(t('upload_error'));
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || !avatarUrl.trim()) return;
    
    setIsSaving(true);
    try {
      await onSave({ display_name: displayName.trim(), avatar_url: avatarUrl.trim() });
    } catch (err) {
      console.error(err);
      alert(t('save_profile_error'));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg-app p-4">
      <div className="bg-bg-card rounded-[32px] border border-accent-light p-6 w-full max-w-sm shadow-2xl text-center">
        <h2 className="text-2xl font-black text-ink-primary mb-2">{t('welcome')}</h2>
        <p className="text-sm text-ink-secondary mb-6 leading-relaxed">
          {t('setup_profile_desc')}
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col items-center gap-4">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleAvatarUpload}
              accept="image/*"
              className="hidden"
            />
            <button
              type="button"
              disabled={isUploadingAvatar}
              onClick={() => fileInputRef.current?.click()}
              className={`relative w-24 h-24 rounded-full border-4 ${
                avatarUrl ? 'border-accent-blue' : 'border-accent-light border-dashed'
              } flex items-center justify-center overflow-hidden group hover:border-accent-blue transition-colors disabled:opacity-50`}
            >
              {avatarUrl ? (
                <div className="relative w-full h-full">
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera size={24} className="text-white" />
                  </div>
                </div>
              ) : (
                <div className="text-ink-secondary group-hover:text-accent-blue transition-colors flex flex-col items-center gap-1">
                  <Camera size={24} />
                  <span className="text-[10px] uppercase font-bold tracking-wider">{t('photo_label')}</span>
                </div>
              )}
              {isUploadingAvatar && (
                <div className="absolute inset-0 bg-bg-card/80 flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-accent-light border-t-accent-blue rounded-full animate-spin" />
                </div>
              )}
            </button>
          </div>

          <div className="space-y-1.5 text-left">
            <label className="text-[10px] font-black uppercase tracking-widest text-ink-secondary ml-1">
              {t('display_name').toUpperCase()}
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder={t('display_name_placeholder')}
              required
              className="w-full p-4 bg-bg-app border border-accent-light rounded-2xl text-base font-bold text-ink-primary focus:outline-none focus:border-accent-blue transition-colors"
            />
          </div>

          <div className="flex items-start gap-3 mt-4 p-3 bg-bg-cell rounded-2xl border border-accent-light text-left">
            <div className="mt-0.5">
              <input 
                type="checkbox" 
                id="consentCheck"
                required
                className="w-4 h-4 rounded border-accent-light text-accent-blue focus:ring-accent-blue focus:ring-offset-bg-card bg-bg-app"
              />
            </div>
            <label htmlFor="consentCheck" className="text-[10px] text-ink-secondary leading-snug cursor-pointer font-medium">
              {t('save') === 'Salvar' ? (
                <><strong>Termo de Consentimento:</strong> Compreendo que todo o conteúdo das corridas ficará visível para todos os cadastrados na aba Comunidade. Nenhum dado sensível ou pessoal será exposto.</>
              ) : (
                <><strong>Consent Terms:</strong> I understand that all race content will be visible to all registered users on the Community tab. No sensitive or personal data will be exposed.</>
              )}
            </label>
          </div>

          <button
            type="submit"
            disabled={isSaving || !displayName.trim() || !avatarUrl.trim()}
            className="w-full py-4 bg-accent-blue text-white rounded-2xl font-black uppercase tracking-widest text-xs transition-transform active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
            ) : (
              t('continue_button')
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
