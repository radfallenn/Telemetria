import React, { useState, useMemo } from 'react';
import { Search, Save, Check, ArrowRight, Car, AlertCircle, Info } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { Entry } from '../types';
import { CarThumbnailImg } from '../App';

interface CarNamesManagerTabProps {
  entries: Entry[];
  carsDatabase: any[];
  suggestions: { brands: string[]; carNames: string[]; setups: string[] };
  onRenameCar: (oldName: string, newName: string) => Promise<void>;
  isSyncing?: boolean;
}

export function CarNamesManagerTab({
  entries = [],
  carsDatabase = [],
  suggestions,
  onRenameCar,
  isSyncing = false
}: CarNamesManagerTabProps) {
  const { language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [editingNames, setEditingNames] = useState<Record<string, string>>({});
  const [savingStatus, setSavingStatus] = useState<Record<string, 'idle' | 'loading' | 'success' | 'error'>>({});

  // Extract unique car names from both laptimes (entries) and the custom cars database
  const uniqueCarNames = useMemo(() => {
    const names = new Set<string>();
    entries.forEach(e => {
      if (e.carName) names.add(e.carName.trim());
    });
    carsDatabase.forEach(c => {
      if (c.brand_name) names.add(c.brand_name.trim());
    });
    return Array.from(names).filter(Boolean).sort();
  }, [entries, carsDatabase]);

  // Handle renaming a car in the system
  const handleRename = async (oldName: string) => {
    const newName = (editingNames[oldName] || oldName).trim();
    if (!newName || newName === oldName) return;

    setSavingStatus(prev => ({ ...prev, [oldName]: 'loading' }));
    try {
      await onRenameCar(oldName, newName);
      setSavingStatus(prev => ({ ...prev, [oldName]: 'success' }));
      
      // Clean up local editing state matching this car
      setTimeout(() => {
        setSavingStatus(prev => {
          const next = { ...prev };
          delete next[oldName];
          return next;
        });
        setEditingNames(prev => {
          const next = { ...prev };
          delete next[oldName];
          return next;
        });
      }, 3000);
    } catch (err) {
      console.error('Error renaming car:', err);
      setSavingStatus(prev => ({ ...prev, [oldName]: 'error' }));
    }
  };

  // Find top matching suggestions from the static standard cars DB for standardizing
  const getPillSuggestions = (currentVal: string) => {
    if (!currentVal || currentVal.trim().length < 2) return [];
    const term = currentVal.toLowerCase();
    const allNames = suggestions?.carNames || [];
    
    return allNames
      .filter(name => {
        if (!name) return false;
        const nameLower = name.toLowerCase();
        return nameLower !== term && (nameLower.includes(term) || term.includes(nameLower));
      })
      .slice(0, 3);
  };

  // Filter unique car names based on user search
  const filteredCarNames = useMemo(() => {
    if (!searchQuery.trim()) return uniqueCarNames;
    const query = searchQuery.toLowerCase();
    return uniqueCarNames.filter(name => name.toLowerCase().includes(query));
  }, [uniqueCarNames, searchQuery]);

  return (
    <div className="space-y-4">
      {/* Informational Header */}
      <div className="bg-bg-cell border border-accent-light p-4 rounded-3xl flex items-start gap-3 shadow-sm">
        <Info className="text-accent-blue shrink-0 mt-0.5" size={18} />
        <div>
          <h4 className="font-black text-xs uppercase tracking-wider text-ink-primary">
            {language === 'pt' ? 'Padronizar Nomes dos Carros' : 'Standardize Car Names'}
          </h4>
          <p className="text-[10px] text-ink-secondary leading-relaxed mt-1">
            {language === 'pt' 
              ? 'Edite os nomes dos carros de forma rápida. Ao alterar e salvar o nome de um carro, todos os tempos associados a ele em sua planilha e suas imagens de capa serão atualizados automaticamente para o novo nome.'
              : 'Tidy up your timesheet easily. Renaming a car will instantly update all related laptimes and uploaded cover thumbnails to the new name across the whole application.'}
          </p>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative w-full">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary" />
        <input 
          type="text" 
          placeholder={language === 'pt' ? 'Buscar carros...' : 'Search cars...'}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-11 bg-bg-cell border border-accent-light rounded-2xl pl-11 pr-4 text-xs font-bold focus:outline-none focus:border-accent-blue transition-all placeholder:text-ink-secondary/50"
        />
      </div>

      {/* List Empty State */}
      {filteredCarNames.length === 0 && (
        <div className="py-12 text-center opacity-35 border-2 border-dashed border-accent-light rounded-2xl">
          <Car size={32} className="mx-auto mb-2 text-ink-secondary" />
          <p className="text-[10px] font-black uppercase tracking-widest">
            {language === 'pt' ? 'Nenhum carro encontrado' : 'No cars found'}
          </p>
        </div>
      )}

      {/* Car Grid / Edit Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto pr-1 scrollbar-thin">
        {filteredCarNames.map((carName) => {
          const currentEditVal = editingNames[carName] !== undefined ? editingNames[carName] : carName;
          const occurrenceCount = entries.filter(e => e.carName === carName).length;
          const status = savingStatus[carName] || 'idle';
          const pillSuggestions = getPillSuggestions(currentEditVal);

          return (
            <div 
              key={carName}
              className="bg-bg-cell border border-accent-light rounded-2xl p-3 flex flex-col gap-3 shadow-sm hover:border-accent-blue/30 transition-all group"
            >
              {/* Thumbnail Container */}
              <div className="relative w-full aspect-[2/1] bg-bg-app rounded-xl overflow-hidden border border-accent-light flex items-center justify-center">
                <CarThumbnailImg 
                  carName={carName}
                  className="w-full h-full object-cover group-hover:scale-105 group-hover:brightness-110 transition-all duration-500" 
                />
                
                {/* Occurrence count badge */}
                <span className="absolute top-2 right-2 px-2 py-0.5 bg-black/75 text-white border border-white/10 rounded-full font-black font-mono text-[9px] uppercase tracking-wider backdrop-blur-sm shadow">
                  {occurrenceCount} {language === 'pt' ? 'tempos' : 'laps'}
                </span>
              </div>

              {/* Editing Controls */}
              <div className="space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <label className="text-[8px] font-black uppercase tracking-widest text-ink-secondary opacity-60">
                    {language === 'pt' ? 'Nome do Carro' : 'Car Name'}
                  </label>
                  
                  {/* Text Input with suggestions support */}
                  <div className="relative mt-1">
                    <input 
                      type="text"
                      list={`db-suggest-${encodeURIComponent(carName)}`}
                      value={currentEditVal}
                      onChange={(e) => setEditingNames(prev => ({ ...prev, [carName]: e.target.value }))}
                      placeholder={language === 'pt' ? 'Escreva o nome completo...' : 'Write full name...'}
                      className="w-full h-9 bg-bg-app border border-accent-light rounded-xl px-3 text-[10px] font-bold focus:outline-none focus:border-accent-blue transition-all uppercase"
                    />
                    
                    {/* Native Datalist for overall suggestions */}
                    <datalist id={`db-suggest-${encodeURIComponent(carName)}`}>
                      {(suggestions?.carNames || []).slice(0, 15).map(name => (
                        <option value={name} key={name} />
                      ))}
                    </datalist>
                  </div>
                </div>

                {/* Database Matches (Pills) */}
                {pillSuggestions.length > 0 && (
                  <div className="pt-1.5 space-y-1">
                    <p className="text-[7.5px] font-black uppercase text-accent-blue tracking-wide opacity-80">
                      {language === 'pt' ? 'Sugestões do Banco:' : 'Database Matches:'}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {pillSuggestions.map(sug => (
                        <button
                          key={sug}
                          type="button"
                          onClick={() => setEditingNames(prev => ({ ...prev, [carName]: sug }))}
                          className="px-2 py-1 bg-accent-blue/10 border border-accent-blue/10 hover:border-accent-blue hover:bg-accent-blue/20 text-accent-blue text-[8.5px] font-bold rounded-lg transition-all text-left truncate max-w-full uppercase"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Save button and status indicator */}
                <div className="pt-2 flex justify-end">
                  {currentEditVal.trim() !== carName && (
                    <button
                      type="button"
                      disabled={isSyncing || status === 'loading'}
                      onClick={() => handleRename(carName)}
                      className={`h-8 px-4 rounded-xl flex items-center justify-center gap-1.5 text-[9px] font-black uppercase tracking-widest shadow-lg transition-all duration-300 ${
                        status === 'success' 
                          ? 'bg-emerald-500 text-white shadow-emerald-500/10' 
                          : status === 'error'
                          ? 'bg-red-500 text-white shadow-red-500/10'
                          : 'bg-accent-blue text-white shadow-accent-blue/10 hover:scale-[1.02] active:scale-[0.98]'
                      }`}
                    >
                      {status === 'loading' && <div className="w-3 h-3 border-2 border-white/35 border-t-white rounded-full animate-spin" />}
                      {status === 'success' && <Check size={12} />}
                      {status === 'error' && <AlertCircle size={12} />}
                      {status === 'idle' && <Save size={12} />}
                      <span>
                        {status === 'loading' && '...'}
                        {status === 'success' && (language === 'pt' ? 'Salvo!' : 'Renamed!')}
                        {status === 'error' && (language === 'pt' ? 'Erro' : 'Error')}
                        {status === 'idle' && (language === 'pt' ? 'Salvar' : 'Save')}
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
