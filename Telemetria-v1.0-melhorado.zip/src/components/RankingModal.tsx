import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trophy, User, Calendar, Car, Clock, Camera, Image as ImageIcon, MapPin } from 'lucide-react';
import { supabaseService } from '../services/supabaseService';
import { getBrandLogo } from '../services/gt7Database';
import { getLogoUrl } from '../lib/utils';
import { Entry, UserProfile, LogoBrand } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { PeripheralIcon } from './PeripheralIcon';
import { TRACK_PACK } from '../data/trackPack';

interface RankingModalProps {
  trackId: string;
  trackName: string;
  logoOverrides?: Record<string, string>;
  logosDatabase?: LogoBrand[];
  onClose: () => void;
  onOpenProfile?: (userId: string) => void;
}

const normalizeBrandNameHelper = (name: string) => 
  name.toLowerCase().replace(/\s+/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, "");

const getLogoFromLocalBank = (name: string, logosDatabase: LogoBrand[] = []) => {
  const slug = normalizeBrandNameHelper(name);
  const found = logosDatabase.find(l => l.brand_slug === slug);
  return found ? found.logo_data : null;
};

const resolveLogoLocal = (carName: string, carBrand: string, logoOverrides: Record<string, string> = {}, logosDatabase: LogoBrand[] = []) => {
  return logoOverrides[carName] || 
         logoOverrides[carBrand] || 
         getLogoFromLocalBank(carName, logosDatabase) || 
         getLogoFromLocalBank(carBrand, logosDatabase) || 
         getBrandLogo(carBrand);
};

const getReadableTrackName = (id: string) => {
  const found = TRACK_PACK.find(t => t.id === id);
  return found ? found.name : id;
};

export const RankingModal: React.FC<RankingModalProps> = ({ trackId, trackName, logoOverrides = {}, logosDatabase = [], onClose, onOpenProfile }) => {
  const { language, t } = useLanguage();
  const [rankings, setRankings] = useState<(Entry & { profiles: UserProfile | null })[]>([]);
  const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
  const [topSpeedRankings, setTopSpeedRankings] = useState<(Entry & { profiles: UserProfile | null })[]>([]);
  const [mode, setMode] = useState<'track' | 'global' | 'top_speed'>('track');
  const [loading, setLoading] = useState(true);
  const [selectedEntry, setSelectedEntry] = useState<(Entry & { profiles: UserProfile | null }) | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        if (mode === 'track') {
          const data = await supabaseService.getGlobalRankings(trackId);
          setRankings(data);
        } else if (mode === 'global') {
          const data = await supabaseService.getLeaderboard();
          setLeaderboard(data);
        } else if (mode === 'top_speed') {
          const data = await supabaseService.getTopSpeedRankings();
          setTopSpeedRankings(data);
        }
      } catch (error) {
        console.error('Error fetching rankings:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [trackId, mode]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-4xl bg-bg-app rounded-3xl overflow-hidden shadow-2xl border border-accent-light/30 flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative p-6 bg-accent-blue/5 border-b border-accent-light/30">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-accent-blue rounded-2xl shadow-lg shadow-accent-blue/20">
                <Trophy className="text-white" size={24} />
              </div>
              <div>
                <h2 className="text-xl font-black uppercase tracking-tighter text-ink-primary italic">{t('ranking_hub')}</h2>
                <p className="text-[10px] font-bold uppercase tracking-widest text-accent-blue opacity-80">
                  {mode === 'track' ? `${t('records')}: ${trackName}` : mode === 'global' ? t('top_community_drivers') : t('top_speed_leaderboard')}
                </p>
              </div>
            </div>

            {/* Tab Switcher */}
            <div className="flex bg-bg-cell p-1 rounded-2xl border border-accent-light gap-1">
              <button
                onClick={() => setMode('track')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  mode === 'track' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'
                }`}
              >
                {t('track')}
              </button>
              <button
                onClick={() => setMode('global')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  mode === 'global' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'
                }`}
              >
                {t('overall')}
              </button>
              <button
                onClick={() => setMode('top_speed')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  mode === 'top_speed' ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' : 'text-ink-secondary hover:bg-bg-app'
                }`}
              >
                {t('top_speed')}
              </button>
            </div>
          </div>
          
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 hover:bg-black/10 rounded-full transition-colors text-ink-primary"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-accent-light border-t-accent-blue rounded-full animate-spin mb-4" />
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-ink-secondary">{t('loading_leaderboard')}</p>
            </div>
          ) : mode === 'track' ? (
            // Existing Track Ranking Logic
            rankings.length === 0 ? (
              <div className="py-20 text-center opacity-40">
                <Trophy size={48} className="mx-auto mb-4 text-ink-secondary" />
                <p className="text-sm font-bold uppercase tracking-widest">{t('no_times_track')}</p>
              </div>
            ) : (
              <div className="grid gap-2">
                <div className="hidden md:grid grid-cols-12 gap-4 px-6 text-[10px] font-bold uppercase tracking-widest text-ink-secondary mb-2">
                  <div className="col-span-1">#</div>
                  <div className="col-span-4">{t('driver')}</div>
                  <div className="col-span-3">{t('car')}</div>
                  <div className="col-span-2 text-right">{t('best_lap')}</div>
                  <div className="col-span-2 text-right">{t('total_time')}</div>
                </div>
                
                {rankings.map((entry, index) => (
                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.03 }}
                    key={`${entry.id}-${index}`}
                    onClick={() => setSelectedEntry(entry)}
                    className={`grid grid-cols-12 gap-4 items-center p-4 rounded-2xl border transition-all cursor-pointer ${
                      index === 0 ? 'bg-yellow-500/5 border-yellow-500/30 shadow-lg shadow-yellow-500/5' :
                      index === 1 ? 'bg-slate-400/5 border-slate-400/30' :
                      index === 2 ? 'bg-orange-700/5 border-orange-700/30' :
                      'bg-bg-card border-accent-light hover:border-accent-blue/50'
                    }`}
                  >
                    <div className={`col-span-1 text-lg font-black italic ${
                      index === 0 ? 'text-yellow-500' :
                      index === 1 ? 'text-slate-400' :
                      index === 2 ? 'text-orange-700' :
                      'text-ink-secondary opacity-50'
                    }`}>
                      {index + 1}
                    </div>
                    
                    <div className="col-span-11 md:col-span-5 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-accent-blue/10 flex items-center justify-center overflow-hidden border-2 border-white/10 shrink-0">
                        {(() => {
                           const profileData = Array.isArray(entry.profiles) ? entry.profiles[0] : entry.profiles;
                           if (profileData?.avatar_url) {
                             return (
                               <img 
                                 src={profileData.avatar_url} 
                                 alt="" 
                                 className="w-full h-full object-cover"
                                 onError={(e) => {
                                   (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(profileData.display_name || entry.id)}&backgroundColor=b6e3f4,c0aede,d1d4f9`;
                                 }}
                               />
                             );
                           }
                           
                           // If no avatar_url, we just show initials
                           const displayName = entry.pilot_name && entry.pilot_name !== '-' 
                             ? entry.pilot_name 
                             : (profileData?.display_name || '?');
                             
                           return (
                             <span className="text-xs font-black text-accent-blue uppercase italic">
                               {displayName[0]}
                             </span>
                           );
                        })()}
                      </div>
                      <div className="min-w-0">
                        <p className="font-black text-sm text-ink-primary truncate">
                          {entry.pilot_name && entry.pilot_name !== '-' ? entry.pilot_name : ((Array.isArray(entry.profiles) ? entry.profiles[0] : entry.profiles)?.display_name || 'Guest Driver')}
                        </p>
                        <p className="text-[10px] font-bold text-accent-blue/70 uppercase">
                          @{(Array.isArray(entry.profiles) ? entry.profiles[0] : entry.profiles)?.psn_id || 'SEM_PSN'}
                        </p>
                      </div>
                    </div>

                    <div className="hidden md:block col-span-3 text-center">
                      <p className="text-[11px] font-black text-ink-primary italic truncate px-2">{entry.carBrand} {entry.carName}</p>
                      <p className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Carro</p>
                    </div>

                    <div className="hidden md:block col-span-1 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {entry.evidence_image && <Camera size={12} className="text-accent-blue opacity-50" />}
                        <p className={`text-sm font-black italic font-mono ${index === 0 ? 'text-yellow-500' : 'text-ink-primary'}`}>
                          {entry.lapTime}
                        </p>
                        <PeripheralIcon peripheral={entry.peripheral} size={10} className={`opacity-80 ${index === 0 ? 'text-yellow-500' : 'text-ink-secondary'}`} />
                      </div>
                      <p className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Tempo</p>
                    </div>

                    <div className="col-span-12 md:col-span-2 flex md:block items-center justify-between">
                       <div className="md:hidden flex gap-4 min-w-0 flex-1">
                          <div className="flex flex-col min-w-0 flex-1">
                             <span className="text-[10px] font-black text-ink-primary uppercase italic truncate">{entry.carBrand} {entry.carName}</span>
                             <span className="text-[6px] font-black uppercase text-ink-secondary">Carro</span>
                          </div>
                          <div className="flex flex-col items-end pr-3 shrink-0">
                             <div className="flex items-center gap-1">
                               {entry.evidence_image && <Camera size={10} className="text-accent-blue" />}
                               <span className={`text-sm font-black font-mono leading-none ${index === 0 ? 'text-yellow-500' : 'text-ink-primary'}`}>{entry.lapTime}</span>
                               <PeripheralIcon peripheral={entry.peripheral} size={10} className={`opacity-80 ${index === 0 ? 'text-yellow-500' : 'text-ink-secondary'}`} />
                             </div>
                             <span className="text-[6px] font-black uppercase text-ink-secondary mt-1">Tempo</span>
                          </div>
                       </div>
                       <div className="flex gap-1 justify-end shrink-0 md:mt-2">
                          <div className="px-2 py-0.5 bg-bg-app rounded text-[8px] font-black uppercase text-ink-secondary border border-accent-light">
                            DR {entry.profiles?.driver_rating || 'D'}
                          </div>
                          <div className="px-2 py-0.5 bg-bg-app rounded text-[8px] font-black uppercase text-ink-secondary border border-accent-light">
                            SR {entry.profiles?.safety_rating || 'E'}
                          </div>
                       </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )
          ) : mode === 'global' ? (
            // Global Pilot Leaderboard Logic
            leaderboard.length === 0 ? (
               <div className="py-20 text-center opacity-40">
                <User size={48} className="mx-auto mb-4 text-ink-secondary" />
                <p className="text-sm font-bold uppercase tracking-widest">No active drivers at the moment.</p>
              </div>
            ) : (
              <div className="grid gap-2">
                <div className="hidden md:grid grid-cols-12 gap-4 px-6 text-[10px] font-bold uppercase tracking-widest text-ink-secondary mb-2">
                  <div className="col-span-1">#</div>
                  <div className="col-span-5">Piloto</div>
                  <div className="col-span-2 text-center">Races</div>
                  <div className="col-span-2 text-center">Vitórias</div>
                  <div className="col-span-2 text-right">Rating</div>
                </div>

                {leaderboard.map((profile, index) => (
                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.03 }}
                    key={`${profile.id}-${index}`}
                    onClick={() => {
                      if (onOpenProfile) {
                        onOpenProfile(profile.id);
                        onClose();
                      }
                    }}
                    className={`grid grid-cols-12 gap-4 items-center p-4 rounded-2xl border transition-all cursor-pointer ${
                      index === 0 ? 'bg-yellow-500/5 border-yellow-500/30' :
                      index === 1 ? 'bg-slate-400/5 border-slate-400/30' :
                      index === 2 ? 'bg-orange-700/5 border-orange-700/30' :
                      'bg-bg-card border-accent-light hover:border-accent-blue/50'
                    }`}
                  >
                    <div className={`col-span-1 text-lg font-black italic ${
                      index === 0 ? 'text-yellow-500' :
                      index === 1 ? 'text-slate-400' :
                      index === 2 ? 'text-orange-700' :
                      'text-ink-secondary opacity-50'
                    }`}>
                      {index + 1}
                    </div>

                    <div className="col-span-11 md:col-span-5 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-accent-blue/10 flex items-center justify-center overflow-hidden border-2 border-white/10 shrink-0">
                        {profile.avatar_url ? (
                          <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-xs font-black text-accent-blue uppercase italic">
                            {(profile.display_name || '?')[0]}
                          </span>
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="font-black text-sm text-ink-primary truncate">
                          {profile.display_name}
                        </p>
                        <p className="text-[10px] font-bold text-accent-blue/70 uppercase">
                          @{profile.psn_id || 'sem_psn'}
                        </p>
                      </div>
                    </div>

                    <div className="hidden md:block col-span-2 text-center">
                      <p className="text-base font-black text-ink-primary italic">{profile.total_races || 0}</p>
                      <p className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Participations</p>
                    </div>

                    <div className="hidden md:block col-span-2 text-center">
                      <p className={`text-base font-black italic ${index === 0 ? 'text-yellow-500' : 'text-ink-primary'}`}>
                        {profile.total_wins || 0}
                      </p>
                      <p className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Overall P1</p>
                    </div>

                    <div className="col-span-12 md:col-span-2 flex md:block items-center justify-between">
                       <div className="md:hidden flex gap-4">
                          <div className="flex flex-col">
                             <span className="text-xs font-black text-ink-primary">{profile.total_races || 0}</span>
                             <span className="text-[6px] font-black uppercase text-ink-secondary">Tracks</span>
                          </div>
                          <div className="flex flex-col">
                             <span className="text-xs font-black text-ink-primary">{profile.total_wins || 0}</span>
                             <span className="text-[6px] font-black uppercase text-ink-secondary">Vitórias</span>
                          </div>
                       </div>
                       <div className="flex gap-1 justify-end">
                          <div className="px-2 py-0.5 bg-bg-app rounded text-[8px] font-black uppercase text-ink-secondary border border-accent-light">
                            DR {profile.driver_rating || 'D'}
                          </div>
                          <div className="px-2 py-0.5 bg-bg-app rounded text-[8px] font-black uppercase text-ink-secondary border border-accent-light">
                            SR {profile.safety_rating || 'E'}
                          </div>
                       </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )
          ) : (
            // Top Speed Ranking Logic
            topSpeedRankings.length === 0 ? (
              <div className="py-20 text-center opacity-40">
                <Trophy size={48} className="mx-auto mb-4 text-ink-secondary" />
                <p className="text-sm font-bold uppercase tracking-widest">Nenhum recorde de velocidade registrado.</p>
              </div>
            ) : (
              <div className="grid gap-2">
                <div className="hidden md:grid grid-cols-12 gap-4 px-6 text-[10px] font-bold uppercase tracking-widest text-ink-secondary mb-2">
                  <div className="col-span-1">#</div>
                  <div className="col-span-4">{t('driver')}</div>
                  <div className="col-span-3">{t('car')}</div>
                  <div className="col-span-2 text-center">{t('track')}</div>
                  <div className="col-span-2 text-right">{t('top_speed')}</div>
                </div>

                {topSpeedRankings.map((entry, index) => {
                  const displaySpeed = entry.velocidade_final || '0 km/h';
                  const profileData = Array.isArray(entry.profiles) ? entry.profiles[0] : entry.profiles;
                  return (
                    <motion.div
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: index * 0.03 }}
                      key={`${entry.id}-speed-${index}`}
                      onClick={() => setSelectedEntry(entry)}
                      className={`grid grid-cols-12 gap-4 items-center p-4 rounded-2xl border transition-all cursor-pointer ${
                        index === 0 ? 'bg-yellow-500/5 border-yellow-500/30' :
                        index === 1 ? 'bg-slate-400/5 border-slate-400/30' :
                        index === 2 ? 'bg-orange-700/5 border-orange-700/30' :
                        'bg-bg-card border-accent-light hover:border-accent-blue/50'
                      }`}
                    >
                      <div className={`col-span-1 text-lg font-black italic ${
                        index === 0 ? 'text-yellow-500' :
                        index === 1 ? 'text-slate-400' :
                        index === 2 ? 'text-orange-700' :
                        'text-ink-secondary opacity-50'
                      }`}>
                        {index + 1}
                      </div>

                      <div className="col-span-11 md:col-span-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-accent-blue/10 flex items-center justify-center overflow-hidden border-2 border-white/10 shrink-0">
                          {profileData?.avatar_url ? (
                            <img 
                              src={profileData.avatar_url} 
                              alt="" 
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(profileData.display_name || entry.id)}&backgroundColor=b6e3f4,c0aede,d1d4f9`;
                              }}
                            />
                          ) : (
                            <span className="text-xs font-black text-accent-blue uppercase italic">
                              {(entry.pilot_name && entry.pilot_name !== '-' ? entry.pilot_name : (profileData?.display_name || '?'))[0]}
                            </span>
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="font-black text-sm text-ink-primary truncate">
                            {entry.pilot_name && entry.pilot_name !== '-' ? entry.pilot_name : (profileData?.display_name || 'Guest Driver')}
                          </p>
                          <p className="text-[10px] font-bold text-accent-blue/70 uppercase">
                            @{profileData?.psn_id || 'SEM_PSN'}
                          </p>
                        </div>
                      </div>

                      <div className="hidden md:block col-span-3 text-left">
                        <p className="text-[11px] font-black text-ink-primary italic truncate pr-2">{entry.carBrand} {entry.carName}</p>
                        <p className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Carro</p>
                      </div>

                      <div className="hidden md:block col-span-2 text-center">
                        <p className="text-[10px] font-extrabold text-ink-primary truncate max-w-full px-1 justify-center items-center flex gap-1">
                          <MapPin size={10} className="text-zinc-500 inline shrink-0" />
                          <span className="truncate">{getReadableTrackName(entry.trackId)}</span>
                        </p>
                        <p className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Circuito</p>
                      </div>

                      <div className="col-span-12 md:col-span-2 flex md:block items-center justify-between">
                         <div className="md:hidden flex gap-4 min-w-0 flex-1">
                            <div className="flex flex-col min-w-0 flex-1 col-span-3">
                               <span className="text-[10px] font-black text-ink-primary uppercase italic truncate">{entry.carBrand} {entry.carName}</span>
                               <span className="text-[6px] font-black uppercase text-ink-secondary">Carro</span>
                            </div>
                            <div className="flex flex-col items-center">
                               <span className="text-[9px] font-extrabold text-ink-primary truncate max-w-[80px]">{getReadableTrackName(entry.trackId)}</span>
                               <span className="text-[6px] font-black uppercase text-ink-secondary">Circuito</span>
                            </div>
                         </div>
                         <div className="flex flex-col md:items-end items-center shrink-0 pr-1 select-text">
                            <span className="text-base font-black italic text-accent-blue font-mono">{displaySpeed}</span>
                            <span className="text-[7px] font-black uppercase text-ink-secondary opacity-40 italic tracking-widest">Velocidade</span>
                         </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )
          )}
        </div>

        {/* Evidence Detail Modal */}
        <AnimatePresence>
          {selectedEntry && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[110] bg-white flex items-center justify-center p-4 md:p-8"
            >
              <button 
                onClick={() => setSelectedEntry(null)}
                className="absolute top-6 right-6 z-[120] p-3 bg-bg-card hover:bg-accent-light rounded-full text-ink-primary transition-all shadow-lg border border-accent-light"
              >
                <X size={24} />
              </button>

              <div className={`w-full h-full flex flex-col md:flex-row gap-4 md:gap-8 max-w-6xl mx-auto overflow-hidden ${!selectedEntry.evidence_image ? 'justify-center items-center' : ''}`}>
                {/* Image Section - Only show if image exists */}
                {selectedEntry.evidence_image && (
                  <div className="flex-[3] rounded-[32px] overflow-hidden bg-bg-card border border-accent-light relative flex items-center justify-center shadow-premium">
                    <img 
                      src={selectedEntry.evidence_image} 
                      alt="Capture Evidence" 
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}

                {/* Info Section */}
                <div className={`${selectedEntry.evidence_image ? 'flex-[2]' : 'w-full max-w-md'} overflow-y-auto custom-scrollbar pr-2 py-3`}>
                  <div className="space-y-4">
                    {/* Brand/Car Header */}
                    <div className="bg-white rounded-[32px] p-6 shadow-premium border border-accent-light mb-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-bg-app border border-accent-light flex items-center justify-center p-2 shrink-0">
                          {(() => {
                            const logoFile = resolveLogoLocal(selectedEntry.carName, selectedEntry.carBrand, logoOverrides, logosDatabase);
                            const logoUrl = getLogoUrl(logoFile);
                            return logoUrl ? (
                              <img 
                                src={logoUrl} 
                                alt={selectedEntry.carBrand} 
                                className="max-w-full max-h-full object-contain"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <Car className="text-accent-blue" size={32} />
                            );
                          })()}
                        </div>
                        <div className="min-w-0">
                          {trackName && (
                            <div className="text-[7px] font-black text-accent-blue uppercase tracking-[0.2em] mb-1 opacity-60 leading-none">
                              {trackName}
                            </div>
                          )}
                          <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-60 leading-none mb-1">
                            {selectedEntry.carBrand}
                          </p>
                          <h3 className="text-xl font-black text-ink-primary leading-tight">
                            {selectedEntry.carName}
                          </h3>
                        </div>
                      </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-3 gap-2">
                      <StatBox label={t('position')} value={`${selectedEntry.racePosition}º ${t('place')}`} />
                      <StatBox label={t('setup')} value={selectedEntry.carSetup || '-'} />
                      <StatBox label={t('pits')} value={selectedEntry.pitStops} />
                      
                      <StatBox label={t('traction_control')} value={`Level ${selectedEntry.tractionControl}`} />
                      <StatBox label={t('map')} value={selectedEntry.carMap} />
                      <StatBox label={t('weather')} value={selectedEntry.weather} />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <StatBox label={t('lap')} value={selectedEntry.lapTime} highlight />
                      <StatBox label={t('total')} value={selectedEntry.totalTime || '-'} highlight />
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <StatBox label={t('date')} value={new Date(selectedEntry.runDate).toLocaleDateString()} />
                      <StatBox label={t('transmission')} value={selectedEntry.transmission || '-'} />
                      <StatBox label={t('laps')} value={selectedEntry.laps || '1'} />
                    </div>

                    <div className="bg-bg-cell rounded-[20px] p-3 border border-accent-light flex items-center justify-between">
                       <div>
                          <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary/60">{t('driver')}</p>
                          <p className="text-xs font-black text-ink-primary italic truncate max-w-[120px]">
                             {selectedEntry.pilot_name && selectedEntry.pilot_name !== '-' ? selectedEntry.pilot_name : (selectedEntry.profiles?.display_name || t('driver'))}
                          </p>
                       </div>
                       <div className="text-right">
                          <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary/60">{t('peripheral')}</p>
                          <p className="text-xs font-black text-ink-primary italic">{selectedEntry.peripheral || '-'}</p>
                       </div>
                    </div>

                     <div className="flex gap-2 pt-2">
                       {onOpenProfile && selectedEntry.profiles && (
                         <button 
                           onClick={() => {
                             onOpenProfile(selectedEntry.profiles!.id);
                             setSelectedEntry(null);
                             onClose();
                           }}
                           className="flex-1 py-4 bg-accent-blue text-white font-black uppercase tracking-widest rounded-2xl hover:bg-accent-blue/90 transition-all italic text-[10px] shadow-lg shadow-accent-blue/20"
                         >
                           {t('driver_profile')}
                         </button>
                       )}
                       <button 
                         onClick={() => setSelectedEntry(null)}
                         className="flex-1 py-4 bg-bg-card text-ink-primary font-black uppercase tracking-widest rounded-2xl border border-accent-light hover:bg-accent-light transition-all italic text-[10px] shadow-sm"
                       >
                         {t('back')}
                       </button>
                     </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};

function StatBox({ label, value, highlight = false }: { label: string, value: string, highlight?: boolean }) {
  return (
    <div className={`bg-bg-card rounded-[20px] p-3 shadow-premium border border-accent-light h-full flex flex-col justify-center ${highlight ? 'bg-accent-blue/5 border-accent-blue/20' : ''}`}>
      <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary/60 mb-0.5">{label}</p>
      <p className={`text-[11px] font-black text-ink-primary italic leading-tight ${highlight ? 'text-accent-blue font-mono text-sm' : ''}`}>{value}</p>
    </div>
  );
}
