import React, { useState, useEffect, useRef } from 'react';
import { useTelemetry } from '../contexts/TelemetryContext';
import {
  Settings, Info, Gauge, Zap, Search, Activity, Droplets, Map as MapIcon, 
  Timer, Flag, Power, Maximize, Minimize, Laptop, Trash2, Calendar, 
  ClipboardList, Check, AlertTriangle, ShieldCheck, HelpCircle, Navigation
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAllTelemetrySessions, deleteTelemetrySession, GT7TelemetrySession } from '../services/telemetryDB';

export const LiveTelemetry: React.FC = () => {
  const contextTelemetry = useTelemetry();
  const {
    telemetry, connectionState, pcLanIp, setPcLanIp,
    connectionMode, setConnectionMode,
    recordingEnabled, setRecordingEnabled,
    gt7Session, resetSession, finalizeRace, setTargetLaps,
    raspberryUrl, setRaspberryUrl
  } = contextTelemetry;

  // Tabs selection
  const [activeTab, setActiveTab] = useState<'telemetria' | 'todos_os_dados' | 'mapa' | 'sessoes'>('telemetria');

  // local PS5 IP management
  const [ps5Ip, setPs5Ip] = useState(() => {
    return localStorage.getItem('gt7Ps5Ip') || pcLanIp || '192.168.1.54';
  });

  useEffect(() => {
    localStorage.setItem('gt7Ps5Ip', ps5Ip);
    localStorage.setItem('gt7_bridge_pc_lan_ip', ps5Ip);
    if (pcLanIp !== ps5Ip) {
      setPcLanIp(ps5Ip);
    }
  }, [ps5Ip, pcLanIp, setPcLanIp]);

  // Collapsible sections
  const [isRawBridgeExpanded, setIsRawBridgeExpanded] = useState(false);
  const [isMapExpanded, setIsMapExpanded] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);

  // Sessions list
  const [savedSessions, setSavedSessions] = useState<GT7TelemetrySession[]>([]);
  useEffect(() => {
    if (activeTab === 'sessoes') {
      loadSessions();
    }
  }, [activeTab]);

  const loadSessions = () => {
    getAllTelemetrySessions()
      .then(sessions => {
        // Sort newest first
        const sorted = [...sessions].sort((a,b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        setSavedSessions(sorted);
      })
      .catch(console.error);
  };

  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Tem certeza que deseja excluir esta sessão salva?')) {
      await deleteTelemetrySession(sessionId);
      loadSessions();
    }
  };

  // Keep a running record of normalization values
  const lastValids = useRef({
    melhorVolta: '--',
    ultimaVolta: '--',
    voltaAtual: '--',
    tempoTotalCorrida: '--',
    velocidadeMaxima: 0,
    combustivel: null as number | null,
    combustivelPorcentagem: null as number | null,
    positionX: null as number | null,
    positionY: null as number | null,
    positionZ: null as number | null,
  });

  // Calculate speed and rpm values
  const currentSpeed = Math.round(telemetry?.speed_kmh || 0);
  const currentRpm = Math.round(telemetry?.rpm || 0);
  const currentGear = telemetry?.gear ?? 'N';

  // 1. Max Speed tracking
  if (currentSpeed > lastValids.current.velocidadeMaxima) {
    lastValids.current.velocidadeMaxima = currentSpeed;
  }
  const displayMaxSpeed = Math.max(lastValids.current.velocidadeMaxima, Math.round(gt7Session.maxSpeed || 0));

  // 2. Fuel normalization preserving previous valid value
  const fuelLiters = telemetry?.fuel !== null && telemetry?.fuel !== undefined && !isNaN(telemetry.fuel)
    ? telemetry.fuel 
    : lastValids.current.combustivel;
  if (fuelLiters !== null && fuelLiters !== undefined) {
    lastValids.current.combustivel = fuelLiters;
  }

  const fuelPercent = telemetry?.fuel_percent !== null && telemetry?.fuel_percent !== undefined && !isNaN(telemetry.fuel_percent)
    ? telemetry.fuel_percent 
    : lastValids.current.combustivelPorcentagem;
  if (fuelPercent !== null && fuelPercent !== undefined) {
    lastValids.current.combustivelPorcentagem = fuelPercent;
  }

  // 3. Loops and Laps
  const rawLaps = telemetry?.completed_laps || 0;
  const voltasCorrigidas = Math.max(0, rawLaps - 1);

  // 4. Lap Timings normalization
  const best_lap = (telemetry?.best_lap_text && telemetry.best_lap_text !== '--')
    ? telemetry.best_lap_text
    : (gt7Session.lastValidBestLap !== '--' ? gt7Session.lastValidBestLap : '--');
  if (best_lap !== '--') {
    lastValids.current.melhorVolta = best_lap;
  }

  const last_lap = (telemetry?.last_lap_text && telemetry.last_lap_text !== '--')
    ? telemetry.last_lap_text
    : (gt7Session.lastValidLastLap !== '--' ? gt7Session.lastValidLastLap : '--');
  if (last_lap !== '--') {
    lastValids.current.ultimaVolta = last_lap;
  }

  // 5. Total race duration
  const tempo_total = (gt7Session.frozenRaceTime && gt7Session.frozenRaceTime !== '--')
    ? gt7Session.frozenRaceTime
    : (telemetry?.total_race_time_text && telemetry.total_race_time_text !== '--' ? telemetry.total_race_time_text : '--');
  if (tempo_total !== '--') {
    lastValids.current.tempoTotalCorrida = tempo_total;
  }

  // 6. Coordinates normalization
  const currX = telemetry?.map?.car_position?.x;
  const currY = telemetry?.map?.car_position?.y;
  const currZ = telemetry?.map?.car_position?.z;

  const displayX = typeof currX === 'number' ? currX : lastValids.current.positionX;
  const displayY = typeof currY === 'number' ? currY : lastValids.current.positionY;
  const displayZ = typeof currZ === 'number' ? currZ : lastValids.current.positionZ;

  if (typeof currX === 'number') lastValids.current.positionX = currX;
  if (typeof currY === 'number') lastValids.current.positionY = currY;
  if (typeof currZ === 'number') lastValids.current.positionZ = currZ;

  // Status Diagnostics
  const getStatusColor = () => {
    switch (connectionState) {
      case 'connected': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'connecting': return 'text-amber-400 bg-amber-500/10 border-amber-500/20 animate-pulse';
      case 'waiting_valid_data': return 'text-orange-400 bg-orange-400/10 border-orange-400/20';
      case 'offline': return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      default: return 'text-zinc-500 bg-zinc-500/10 border-white/5';
    }
  };

  const getStatusText = () => {
    if (connectionMode === 'raspberry_bridge') {
      switch (connectionState) {
        case 'connected': return 'Conectado ao Raspberry';
        case 'connecting': return 'Conectando Raspberry...';
        case 'waiting_valid_data': return 'Aguardando Raspberry';
        case 'offline': return 'Raspberry Offline';
        default: return 'Inativo';
      }
    }
    switch (connectionState) {
      case 'connected': return 'Conectado ao PS5';
      case 'connecting': return 'Conectando ao PS5...';
      case 'waiting_valid_data': return 'Aguardando Telemetria';
      case 'offline': return 'Offline / Desconectado';
      default: return 'Inativo';
    }
  };

  // Extra packet variables if missing
  const lastTelemetryRefVal = telemetry && telemetry.lastTelemetry ? telemetry.lastTelemetry : null;
  const checkExtraValue = (p: string) => {
    if (lastTelemetryRefVal && lastTelemetryRefVal[p] !== undefined && lastTelemetryRefVal[p] !== null) {
      return lastTelemetryRefVal[p];
    }
    return '--';
  };

  // Auxiliary variables
  const waterTemp = checkExtraValue('water_temp') !== '--' ? `${checkExtraValue('water_temp')}ºC` : 
                    (checkExtraValue('engine_water_temp') !== '--' ? `${checkExtraValue('engine_water_temp')}ºC` : '--');
  const oilTemp = checkExtraValue('oil_temp') !== '--' ? `${checkExtraValue('oil_temp')}ºC` : 
                  (checkExtraValue('engine_oil_temp') !== '--' ? `${checkExtraValue('engine_oil_temp')}ºC` : '--');
  
  const rawTurbo = checkExtraValue('turbo_pressure') !== '--' ? Number(checkExtraValue('turbo_pressure')).toFixed(2) : 
                   (checkExtraValue('turbo') !== '--' ? Number(checkExtraValue('turbo')).toFixed(2) : '--');
  const turboDesc = rawTurbo !== '--' ? `${rawTurbo} bar` : '--';

  const yaw = checkExtraValue('rotacaoYaw') !== '--' ? Number(checkExtraValue('rotacaoYaw')).toFixed(1) : 
              (checkExtraValue('yaw') !== '--' ? Number(checkExtraValue('yaw')).toFixed(1) : '--');
  const pitch = checkExtraValue('rotacaoPitch') !== '--' ? Number(checkExtraValue('rotacaoPitch')).toFixed(1) : 
                (checkExtraValue('pitch') !== '--' ? Number(checkExtraValue('pitch')).toFixed(1) : '--');
  const roll = checkExtraValue('rotacaoRoll') !== '--' ? Number(checkExtraValue('rotacaoRoll')).toFixed(1) : 
               (checkExtraValue('roll') !== '--' ? Number(checkExtraValue('roll')).toFixed(1) : '--');

  // Vector velocity helper
  const vx = checkExtraValue('velocidadeVetorX') !== '--' ? Number(checkExtraValue('velocidadeVetorX')) : 
             (checkExtraValue('vx') !== '--' ? Number(checkExtraValue('vx')) : 0);
  const vy = checkExtraValue('velocidadeVetorY') !== '--' ? Number(checkExtraValue('velocidadeVetorY')) : 
             (checkExtraValue('vy') !== '--' ? Number(checkExtraValue('vy')) : 0);
  const vz = checkExtraValue('velocidadeVetorZ') !== '--' ? Number(checkExtraValue('velocidadeVetorZ')) : 
             (checkExtraValue('vz') !== '--' ? Number(checkExtraValue('vz')) : 0);
  const hasVector = vx !== 0 || vy !== 0 || vz !== 0;
  const vectorVelocity = hasVector ? `${Math.sqrt(vx * vx + vy * vy + vz * vz).toFixed(2)} m/s` : '--';

  // Reference elements mapped with IDs 1 to 45
  const referenceData = [
    { ref: 1, label: "Conectado", value: connectionState === 'connected' ? 'Sim' : 'Não', key: "connected", group: "Status do Bridge", source: "Status" },
    { ref: 2, label: "Decodificação válida", value: lastTelemetryRefVal?.decodeOk !== false ? 'Sim' : 'Não', key: "decodeOk", group: "Status do Bridge", source: "Packet" },
    { ref: 3, label: "Status da leitura", value: getStatusText(), key: "status", group: "Status do Bridge", source: "Diagnostics" },
    { ref: 4, label: "Última atualização", value: telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--', key: "updatedAt", group: "Status do Bridge", source: "Clock" },
    { ref: 5, label: "Versão do pacote", value: lastTelemetryRefVal?.packetVersion ? `v${lastTelemetryRefVal.packetVersion}` : 'v1.4', key: "packetVersion", group: "Status do Bridge", source: "Metadata" },
    { ref: 6, label: "Tamanho do pacote", value: lastTelemetryRefVal?.lastPacketSize ? `${lastTelemetryRefVal.lastPacketSize} bytes` : '376 bytes', key: "lastPacketSize", group: "Status do Bridge", source: "TCP/UDP" },
    { ref: 7, label: "Aviso / diagnóstico", value: telemetry?.connected ? 'Dados Fluindo normalmente' : 'Sem fluxo de dados', key: "warning", group: "Status do Bridge", source: "Flow Tracker" },
    { ref: 8, label: "Velocidade atual", value: `${currentSpeed} km/h`, key: "velocidade", group: "Dados ao Vivo do Carro", source: "Gauges" },
    { ref: 9, label: "Velocidade máxima", value: `${displayMaxSpeed} km/h`, key: "velocidadeMaxima", group: "Dados ao Vivo do Carro", source: "Session Records" },
    { ref: 10, label: "RPM", value: String(currentRpm), key: "rpm", group: "Dados ao Vivo do Carro", source: "Engine" },
    { ref: 11, label: "Marcha", value: currentGear, key: "marcha", group: "Dados ao Vivo do Carro", source: "Gears" },
    { ref: 12, label: "Marcha numérica", value: lastTelemetryRefVal?.gear_number !== undefined ? String(lastTelemetryRefVal.gear_number) : (currentGear === 'R' ? '-1' : currentGear === 'N' ? '0' : currentGear), key: "marchaNumero", group: "Dados ao Vivo do Carro", source: "Gears" },
    { ref: 13, label: "Acelerador", value: `${Math.round(telemetry?.throttle_percent || 0)}%`, key: "acelerador", group: "Dados ao Vivo do Carro", source: "Pedals" },
    { ref: 14, label: "Freio", value: `${Math.round(telemetry?.brake_percent || 0)}%`, key: "freio", group: "Dados ao Vivo do Carro", source: "Pedals" },
    { ref: 15, label: "Combustível", value: fuelLiters !== null ? `${fuelLiters.toFixed(1)} L` : '--', key: "combustivel", group: "Dados ao Vivo do Carro", source: "Fuel Tank" },
    { ref: 16, label: "Combustível porcentagem", value: fuelPercent !== null ? `${fuelPercent.toFixed(1)}%` : '--', key: "combustivelPorcentagem", group: "Dados ao Vivo do Carro", source: "Fuel Tank" },
    { ref: 17, label: "Capacidade do tanque", value: lastTelemetryRefVal?.fuel_capacity ? `${lastTelemetryRefVal.fuel_capacity} L` : '100.0 L', key: "fuelCapacity", group: "Dados ao Vivo do Carro", source: "Specs" },
    { ref: 18, label: "Melhor volta", value: best_lap, key: "melhorVolta", group: "Voltas e Tempo", source: "Timing Tower" },
    { ref: 19, label: "Última volta", value: last_lap, key: "ultimaVolta", group: "Voltas e Tempo", source: "Timing Tower" },
    { ref: 20, label: "Volta atual / parcial", value: telemetry?.last_lap_text ?? '--:--.--', key: "voltaAtual", group: "Voltas e Tempo", source: "Timing Tower" },
    { ref: 21, label: "Tempo total / prova", value: tempo_total, key: "tempoTotalCorrida", group: "Voltas e Tempo", source: "Timing Tower" },
    { ref: 22, label: "Tempo congelado", value: gt7Session.frozenRaceTime || '--', key: "tempoProvaCongelado", group: "Voltas e Tempo", source: "Race Flag" },
    { ref: 23, label: "Voltas brutas", value: String(rawLaps), key: "voltasCompletadas", group: "Voltas e Tempo", source: "Telemetry Engine" },
    { ref: 24, label: "Voltas corrigidas", value: String(voltasCorrigidas), key: "voltasCorrigidas", group: "Voltas e Tempo", source: "Correção de Volta" },
    { ref: 25, label: "Voltas da prova", value: gt7Session.targetLaps ? String(gt7Session.targetLaps) : 'Auto', key: "voltasAlvo", group: "Voltas e Tempo", source: "User Config" },
    { ref: 26, label: "Corrida finalizada", value: gt7Session.raceFinished ? 'Sim' : 'Não', key: "corridaFinalizada", group: "Voltas e Tempo", source: "Manual/Engine" },
    { ref: 27, label: "Paradas nos boxes", value: String(telemetry?.pit_stops_count || 0), key: "pits", group: "Voltas e Tempo", source: "Pitlane" },
    { ref: 28, label: "Coordenada X", value: displayX !== null ? displayX.toFixed(3) : '--', key: "position.x", group: "Posição e Mapa", source: "Coordinate Mapping" },
    { ref: 29, label: "Coordenada Y", value: displayY !== null ? displayY.toFixed(3) : '--', key: "position.y", group: "Posição e Mapa", source: "Coordinate Mapping" },
    { ref: 30, label: "Coordenada Z", value: displayZ !== null ? displayZ.toFixed(3) : '--', key: "position.z", group: "Posição e Mapa", source: "Coordinate Mapping" },
    { ref: 31, label: "Rastro do mapa", value: telemetry?.map?.path_points?.length ? `${telemetry.map.path_points.length} coords` : '--', key: "trackCoordinates", group: "Posição e Mapa", source: "Dynamic Map Trace" },
    { ref: 32, label: "Tipo de superfície", value: lastTelemetryRefVal?.surfaceType ?? 'Asfalto / Plain', key: "surfaceType", group: "Posição e Mapa", source: "Physics Engine" },
    { ref: 33, label: "Pista", value: telemetry?.map?.track_name ?? 'Detectando Autódromo...', key: "pista", group: "Sessão e Registro", source: "Autódromo Map" },
    { ref: 34, label: "Marca do carro", value: lastTelemetryRefVal?.marcaCarro || lastTelemetryRefVal?.brand || 'Sem Marca', key: "marcaCarro", group: "Sessão e Registro", source: "Gerege Inventory" },
    { ref: 35, label: "Modelo do carro", value: lastTelemetryRefVal?.modeloCarro || lastTelemetryRefVal?.carName || 'Sem Modelo', key: "modeloCarro", group: "Sessão e Registro", source: "Garage Inventory" },
    { ref: 36, label: "Posição", value: lastTelemetryRefVal?.posicao || '1º', key: "posicao", group: "Sessão e Registro", source: "HUD" },
    { ref: 37, label: "CT", value: telemetry?.traction_control !== null ? String(telemetry.traction_control) : '0', key: "ct", group: "Sessão e Registro", source: "Active Safety" },
    { ref: 38, label: "Mapeamento", value: lastTelemetryRefVal?.mapeamento || '1', key: "mapeamento", group: "Sessão e Registro", source: "HUD Fuel Map" },
    { ref: 39, label: "Data", value: new Date().toLocaleDateString(), key: "data", group: "Sessão e Registro", source: "Sistema" },
    { ref: 40, label: "Clima", value: lastTelemetryRefVal?.clima || 'Ensolarado', key: "clima", group: "Sessão e Registro", source: "Ambiente" },
    { ref: 41, label: "Transmissão", value: lastTelemetryRefVal?.transmissao || 'Manual', key: "transmissao", group: "Sessão e Registro", source: "Câmbio" },
    { ref: 42, label: "Periférico", value: lastTelemetryRefVal?.periferico || 'Volante FFB', key: "periferico", group: "Sessão e Registro", source: "Hardware Input" },
    { ref: 43, label: "Driver", value: lastTelemetryRefVal?.driver || 'Piloto Principal', key: "driver", group: "Sessão e Registro", source: "Perfil" },
    { ref: 44, label: "Velocidade final", value: `${displayMaxSpeed} km/h`, key: "velocidade_final", group: "Sessão e Registro", source: "Telemetry calculations" },
    { ref: 45, label: "Telemetria completa", value: '[Snapshot Normalizado]', key: "telemetria_completa", group: "Sessão e Registro", source: "System Schema" }
  ];

  return (
    <div className="w-full flex flex-col gap-4 bg-gradient-to-br from-[#0c0f17] to-[#05060a] border border-white/5 rounded-3xl p-4 sm:p-6 shadow-2xl text-white select-none relative overflow-hidden font-sans">
      
      {/* Decorative Neon Ring */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-br from-[#5ca1ff]/5 to-transparent rounded-full blur-3xl pointer-events-none -mr-40 -mt-4" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-[#10b981]/5 to-transparent rounded-full blur-3xl pointer-events-none -ml-40 -mb-42" />

      {/* TABS SELECTOR - GT Style */}
      <div className="flex border-b border-white/5 pb-3 justify-between items-center z-10 gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-4 bg-gradient-to-b from-[#5ca1ff] to-[#3b82f6] rounded-sm" />
          <h2 className="text-xs uppercase font-black tracking-widest text-[#5ca1ff]">Dashboard Telemetria</h2>
        </div>
        <div className="flex gap-1.5 items-center bg-black/40 p-1 rounded-xl border border-white/5 flex-wrap">
          <button
            onClick={() => setActiveTab('telemetria')}
            className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all duration-150 ${activeTab === 'telemetria' ? 'bg-[#5ca1ff] text-zinc-950 shadow-md shadow-[#5ca1ff]/20' : 'text-zinc-400 hover:text-white'}`}
          >
            HUD Telemetria
          </button>
          <button
            onClick={() => setActiveTab('todos_os_dados')}
            className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all duration-150 ${activeTab === 'todos_os_dados' ? 'bg-[#5ca1ff] text-zinc-950 shadow-md shadow-[#5ca1ff]/20' : 'text-zinc-400 hover:text-white'}`}
          >
            Todos os Dados
          </button>
          <button
            onClick={() => setActiveTab('mapa')}
            className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all duration-150 ${activeTab === 'mapa' ? 'bg-[#5ca1ff] text-zinc-950 shadow-md shadow-[#5ca1ff]/20' : 'text-zinc-400 hover:text-white'}`}
          >
            Visualizar Mapa
          </button>
          <button
            onClick={() => setActiveTab('sessoes')}
            className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all duration-150 ${activeTab === 'sessoes' ? 'bg-[#5ca1ff] text-zinc-950 shadow-md shadow-[#5ca1ff]/20' : 'text-zinc-400 hover:text-white'}`}
          >
            Sessões
          </button>
        </div>
      </div>

      {/* TAB 1: MAIN CONSOLE (TELEMETRIA) */}
      <AnimatePresence mode="wait">
        {activeTab === 'telemetria' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col gap-5 text-zinc-100 z-10"
          >
            {/* HERO PANEL: CONNECTION AND IP SETTINGS (hero_bridge_status) */}
            <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex flex-col gap-4 relative overflow-hidden shadow-inner">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                
                {/* Diagnostics */}
                <div className="flex items-center gap-3">
                  <div className={`py-1.5 px-3 rounded-lg border text-[9px] font-black uppercase tracking-wider flex items-center gap-2 ${getStatusColor()}`}>
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-inherit opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-current"></span>
                    </span>
                    {getStatusText()}
                  </div>
                  
                  {/* Miniature live banner */}
                  <div className="flex items-center gap-3.5 bg-black/60 py-1.5 px-3 rounded-xl border border-white/5 text-[9px] font-black tracking-widest uppercase font-mono">
                    <span className="text-zinc-500">Volante: <strong className="text-white">{currentSpeed} KM/H</strong></span>
                    <span className="text-zinc-500">RPM: <strong className="text-[#ffd35c]">{currentRpm}</strong></span>
                    <span className="text-zinc-500">M: <strong className="text-emerald-400">{currentGear}</strong></span>
                  </div>
                </div>

                {/* PS5 IP input (Always prefilled as requested) */}
                <div className="flex items-center gap-2 bg-black/60 p-1 px-2 rounded-xl border border-white/5 max-w-full sm:max-w-xs shrink-0 self-stretch sm:self-auto justify-between">
                  <span className="text-[8px] font-black uppercase text-zinc-500 tracking-wider">PS5 IP:</span>
                  <input
                    type="text"
                    value={ps5Ip}
                    onChange={(e) => setPs5Ip(e.target.value)}
                    placeholder="192.168.1.54"
                    className="bg-transparent border-none text-[10px] font-mono font-black text-[#ffd35c] focus:outline-none focus:ring-0 w-28 text-right px-1"
                  />
                </div>
              </div>

              {/* Origin / Mode Selector */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-black/35 p-3 rounded-2xl border border-white/5">
                <div className="flex flex-col gap-0.5">
                  <span className="text-[8.5px] font-black uppercase tracking-widest text-[#5ca1ff]">Fonte / Origem de Telemetria</span>
                  <p className="text-[9px] text-zinc-400">Escolha o modo de recepção dos dados do Gran Turismo 7.</p>
                </div>

                <div className="flex items-center gap-2 self-stretch sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setConnectionMode('auto')}
                    className={`flex-1 sm:flex-initial px-3.5 py-2 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all border ${
                      connectionMode !== 'raspberry_bridge'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-lg shadow-emerald-500/5'
                        : 'bg-zinc-800/10 border-white/5 text-zinc-400 hover:text-white'
                    }`}
                  >
                    📡 UDP Direto / Auto
                  </button>

                  <button
                    type="button"
                    onClick={() => setConnectionMode('raspberry_bridge')}
                    className={`flex-1 sm:flex-initial px-3.5 py-2 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all border ${
                      connectionMode === 'raspberry_bridge'
                        ? 'bg-[#5ca1ff]/10 border-[#5ca1ff]/30 text-[#5ca1ff] shadow-lg shadow-[#5ca1ff]/5'
                        : 'bg-zinc-800/10 border-white/5 text-zinc-400 hover:text-white'
                    }`}
                  >
                    🍓 Raspberry Bridge
                  </button>
                </div>
              </div>

              {connectionMode === 'raspberry_bridge' && (
                <div
                  className="bg-black/50 p-2.5 rounded-xl border border-[#5ca1ff]/10 flex flex-col sm:flex-row items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2 bg-black/40 p-1.5 px-3 rounded-lg border border-white/5 w-full sm:w-auto flex-1">
                    <span className="text-[8px] font-black uppercase text-zinc-500 tracking-wider whitespace-nowrap">Instância Raspberry:</span>
                    <input
                      type="text"
                      value={raspberryUrl}
                      onChange={(e) => setRaspberryUrl(e.target.value)}
                      placeholder="http://192.168.1.70:8787/api/fields"
                      className="bg-transparent border-none text-[10px] font-mono font-black text-[#5ca1ff] focus:outline-none focus:ring-0 flex-1 text-left px-1 min-w-0"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setConnectionMode('auto');
                      setTimeout(() => setConnectionMode('raspberry_bridge'), 100);
                    }}
                    className="w-full sm:w-auto px-4 py-2.5 bg-[#5ca1ff] hover:bg-[#5ca1ff]/90 text-zinc-950 font-black uppercase text-[9.5px] tracking-widest rounded-xl transition-all shadow-md shadow-[#5ca1ff]/15 flex items-center justify-center gap-1.5 active:scale-[0.98]"
                  >
                    🍓 Conectar Raspberry
                  </button>
                </div>
              )}

              {/* Dynamic summary information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-white/5 pt-4">
                <div className="text-[10px] text-zinc-400 space-y-1.5">
                  <div className="flex justify-between border-b border-white/5 pb-1 select-text">
                    <span>Sincronização:</span>
                    <span className="font-mono text-zinc-300">
                      {telemetry?.timestamp ? new Date(telemetry.timestamp).toLocaleTimeString() : '--'}
                    </span>
                  </div>
                  <div className="flex justify-between select-text">
                    <span>Pacote UDP:</span>
                    <span className="font-mono text-[#5ca1ff]">
                      {lastTelemetryRefVal?.packetVersion ? `v${lastTelemetryRefVal.packetVersion}` : 'v1.4'} ({lastTelemetryRefVal?.lastPacketSize || lastTelemetryRefVal?.packet_size || '368'} bytes)
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 shrink-0 flex-wrap">
                  {/* Actions Bar */}
                  <button
                    onClick={() => setRecordingEnabled(!recordingEnabled)}
                    className={`px-3 py-1.5 rounded-xl font-bold uppercase text-[9px] tracking-wider transition-all border ${recordingEnabled ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/15' : 'bg-zinc-800/20 border-white/5 text-zinc-400 hover:bg-zinc-800'}`}
                  >
                    {recordingEnabled ? '● GRAVANDO' : 'Gravar Sessão'}
                  </button>

                  <button
                    onClick={() => {
                      setShowSaveSuccess(true);
                      setTimeout(() => setShowSaveSuccess(false), 2000);
                    }}
                    className="px-3 py-1.5 bg-[#ffd35c]/10 border border-[#ffd35c]/10 hover:bg-[#ffd35c]/15 text-[#ffd35c] font-black uppercase text-[9px] tracking-wider rounded-xl active:scale-95 transition-all text-center relative"
                  >
                    💾 Salvar Sessão
                    {showSaveSuccess && (
                      <span className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-1 bg-emerald-500 text-white rounded text-[8px] font-bold animate-bounce z-50 whitespace-nowrap">Sessão Salva!</span>
                    )}
                  </button>

                  <button
                    onClick={() => window.dispatchEvent(new CustomEvent('gt7-trigger-fullscreen-hud'))}
                    className="px-3 py-1.5 bg-[#5ca1ff]/10 border border-[#5ca1ff]/15 hover:bg-[#5ca1ff]/20 text-[#5ca1ff] font-black uppercase text-[9px] tracking-wider rounded-xl transition-all flex items-center gap-1 shrink-0"
                  >
                    <Maximize size={10} /> Fullscreen HUD
                  </button>
                </div>
              </div>
            </div>

            {/* LIVE METRICS SECTION (live_metrics) - 2 columns grid on mobile */}
            <div className="space-y-3">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <span className="w-1 h-3 bg-[#5ca1ff] rounded-sm" /> Telemetria ao Vivo
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">Velocidade <Gauge size={10} /></span>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className="text-2xl font-black font-mono">{currentSpeed}</span>
                    <span className="text-[9px] text-zinc-500">km/h</span>
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">Velocidade Máxima <Flag size={10} /></span>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className="text-2xl font-black font-mono text-[#ffd35c]">{displayMaxSpeed}</span>
                    <span className="text-[9px] text-zinc-500">km/h</span>
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between font-mono">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">RPM <Zap size={10} /></span>
                  <div className="mt-1">
                    <span className="text-2xl font-black text-white">{currentRpm}</span>
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-[#10b981] tracking-wider flex items-center gap-1">Marcha <Settings size={10} /></span>
                  <div className="mt-1">
                    <span className="text-3xl font-black text-emerald-400 font-mono leading-none">{currentGear}</span>
                  </div>
                </div>

                {/* Throttle Bar */}
                <div className="col-span-2 p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-500 tracking-wider">
                    <span>Acelerador</span>
                    <span className="font-mono text-emerald-400">{Math.round(telemetry?.throttle_percent || 0)}%</span>
                  </div>
                  <div className="mt-2 h-2.5 w-full bg-zinc-800 rounded-full overflow-hidden p-0.5 border border-white/5">
                    <div className="h-full bg-emerald-500 rounded-full transition-all duration-75" style={{ width: `${Math.min(100, Math.max(0, telemetry?.throttle_percent || 0))}%` }} />
                  </div>
                </div>

                {/* Brake Bar */}
                <div className="col-span-2 p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-500 tracking-wider">
                    <span>Freio</span>
                    <span className="font-mono text-rose-500">{Math.round(telemetry?.brake_percent || 0)}%</span>
                  </div>
                  <div className="mt-2 h-2.5 w-full bg-zinc-800 rounded-full overflow-hidden p-0.5 border border-white/5">
                    <div className="h-full bg-rose-500 rounded-full transition-all duration-75" style={{ width: `${Math.min(100, Math.max(0, telemetry?.brake_percent || 0))}%` }} />
                  </div>
                </div>

                {/* Fuel Liter */}
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">Combustível <Power size={10} /></span>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className="text-xl font-black font-mono">
                      {fuelLiters !== null ? fuelLiters.toFixed(1) : '--'}
                    </span>
                    <span className="text-[9px] text-zinc-500">Liters</span>
                  </div>
                </div>

                {/* Fuel Percent */}
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">Combustível Porcentagem <Power size={10} /></span>
                  <div className="mt-1 flex items-baseline gap-1">
                    <span className="text-xl font-black font-mono text-cyan-400">
                      {fuelPercent !== null ? fuelPercent.toFixed(1) : '--'}
                    </span>
                    <span className="text-[9px] text-zinc-500">%</span>
                  </div>
                </div>

                {/* Water Temp */}
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">Temperatura da Água <Laptop size={10} /></span>
                  <div className="mt-1 text-xl font-black font-mono text-cyan-300">
                    {waterTemp}
                  </div>
                </div>

                {/* Oil Temp */}
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider flex items-center gap-1">Temperatura do Óleo <Laptop size={10} /></span>
                  <div className="mt-1 text-xl font-black font-mono text-amber-500">
                    {oilTemp}
                  </div>
                </div>
              </div>
            </div>

            {/* SECTIONS: LAP AND SESSION (lap_and_session) */}
            <div className="space-y-3">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <span className="w-1 h-3 bg-emerald-500 rounded-sm" /> Voltas e Resultados
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Melhor Volta</span>
                  <div className="mt-1 text-lg font-black font-mono text-[#a78bfa]">
                    {best_lap}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Última Volta</span>
                  <div className="mt-1 text-lg font-black font-mono text-zinc-200">
                    {last_lap}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Tempo Total</span>
                  <div className="mt-1 text-lg font-black font-mono text-cyan-400">
                    {tempo_total}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Voltas Brutas</span>
                  <div className="mt-1 text-lg font-black font-mono">
                    {rawLaps}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-[#5ca1ff] tracking-wider">Voltas Corrigidas</span>
                  <div className="mt-1 text-lg font-black font-mono text-[#5ca1ff]">
                    {voltasCorrigidas}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Volta Alvo</span>
                  <input
                    type="number"
                    value={gt7Session.targetLaps || ''}
                    onChange={(e) => setTargetLaps(parseInt(e.target.value) || 0)}
                    placeholder="Auto"
                    className="w-full bg-black/60 border border-white/10 rounded-xl p-1 text-[11px] font-mono font-black text-center text-white focus:border-[#5ca1ff]/80 outline-none mt-1 h-7 placeholder:text-zinc-700"
                  />
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Estado da Corrida</span>
                  <div className="mt-1 text-[10px] font-bold">
                    {gt7Session.raceFinished ? (
                      <span className="text-emerald-400 uppercase">🏁 Finalizada</span>
                    ) : (
                      <span className="text-[#5ca1ff] uppercase">⏱ Em Andamento</span>
                    )}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Paradas Boxes</span>
                  <div className="mt-1 text-lg font-black font-mono">
                    {telemetry?.pit_stops_count || 0}
                  </div>
                </div>
              </div>
            </div>

            {/* ENGINE AND DYNAMICS (engine_and_vehicle) */}
            <div className="space-y-3">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <span className="w-1 h-3 bg-purple-500 rounded-sm" /> Motor & Dinâmica do Veículo
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Pressão do Turbo</span>
                  <div className="mt-1 text-base font-black font-mono text-purple-400">
                    {turboDesc}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Vetores Velocidade</span>
                  <div className="mt-1 text-base font-black font-mono text-emerald-400">
                    {vectorVelocity}
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Rotações Roll/Pitch</span>
                  <div className="mt-1 text-[11px] font-mono leading-tight">
                    <div>Pitch: {pitch}°</div>
                    <div>Roll: {roll}°</div>
                  </div>
                </div>

                <div className="p-3 bg-black/40 border border-white/5 rounded-2xl">
                  <span className="text-[8px] uppercase font-black text-zinc-500 tracking-wider">Vetor Yaw</span>
                  <div className="mt-1 text-base font-black font-mono text-amber-500">
                    {yaw !== '--' ? `${yaw}°/s` : '--'}
                  </div>
                </div>
              </div>
            </div>

            {/* COLLAPSIBLE TRACK MAP AND COORDS */}
            <div className="space-y-2">
              <button
                onClick={() => setIsMapExpanded(!isMapExpanded)}
                className="w-full text-left flex justify-between items-center py-2 px-3 bg-black/20 border border-white/5 rounded-xl hover:bg-black/30 transition-all"
              >
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-[#a78bfa]">
                  <MapIcon size={12} /> Coordenadas e Mapa do Circuito
                </div>
                <span className="text-[9px] font-black uppercase text-zinc-500">
                  {isMapExpanded ? 'Recolher Coordenadas ▲' : 'Expandir Coordenadas ▼'}
                </span>
              </button>

              <AnimatePresence>
                {isMapExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden space-y-2"
                  >
                    <div className="p-4 bg-[#10141f]/40 border border-white/5 rounded-2xl flex flex-col sm:flex-row gap-4 items-center justify-between shadow-2xl">
                      <div className="text-[10px] font-mono text-zinc-400 space-y-1 self-stretch w-full sm:w-auto">
                        <div className="flex justify-between border-b border-white/5 pb-1">
                          <span>Posição X:</span>
                          <span className="text-white">{displayX !== null ? displayX.toFixed(4) : '--'}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-1">
                          <span>Posição Y:</span>
                          <span className="text-white">{displayY !== null ? displayY.toFixed(4) : '--'}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-1">
                          <span>Posição Z:</span>
                          <span className="text-white">{displayZ !== null ? displayZ.toFixed(4) : '--'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Superfície:</span>
                          <span className="text-emerald-400 capitalize">{lastTelemetryRefVal?.surfaceType || 'Asfalto'}</span>
                        </div>
                      </div>

                      {/* Map trajectory inline preview */}
                      <div className="w-full sm:w-48 h-28 relative bg-[#07090e]/80 rounded-xl border border-white/5 flex items-center justify-center overflow-hidden">
                        {telemetry?.map?.path_points?.length ? (
                          <>
                            {(() => {
                              const points = telemetry.map.path_points;
                              const minX = Math.min(...points.map(p => p.x));
                              const maxX = Math.max(...points.map(p => p.x));
                              const minY = Math.min(...points.map(p => p.y));
                              const maxY = Math.max(...points.map(p => p.y));
                              
                              const rangeX = maxX - minX || 1;
                              const rangeY = maxY - minY || 1;
                              const pMinX = minX - rangeX * 0.15;
                              const pMaxX = maxX + rangeX * 0.15;
                              const pMinY = minY - rangeY * 0.15;
                              const pMaxY = maxY + rangeY * 0.15;
                              
                              const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

                              return (
                                <svg 
                                  viewBox={`${pMinX} ${pMinY} ${pMaxX - pMinX} ${pMaxY - pMinY}`} 
                                  className="absolute inset-0 w-full h-full opacity-60 stroke-[#5ca1ff] fill-none"
                                  style={{ strokeWidth: (pMaxX - pMinX) * 0.015 }}
                                  preserveAspectRatio="xMidYMid meet"
                                >
                                  <path d={pathData} strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              );
                            })()}
                            <div className="absolute w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                          </>
                        ) : (
                          <div className="text-zinc-600 text-[8px] uppercase tracking-wider font-bold">Sem Traçado</div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* COLLAPSIBLE COHESIVE DIAGNOSTICS BRIDGE PANEL (raw_bridge_panel) */}
            <div className="space-y-2 border-t border-white/5 pt-4">
              <button
                onClick={() => setIsRawBridgeExpanded(!isRawBridgeExpanded)}
                className="w-full text-left flex justify-between items-center py-2 px-3 bg-zinc-900 border border-white/5 rounded-2xl hover:bg-zinc-800 transition-all"
              >
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-[#ffd35c]">
                  <ClipboardList size={12} /> {isRawBridgeExpanded ? 'Recolher detalhes do Bridge' : 'Mostrar detalhes do Bridge'}
                </div>
                <span className="text-[12px] font-bold text-[#ffd35c]">
                  {isRawBridgeExpanded ? '▲' : '▼'}
                </span>
              </button>

              <AnimatePresence>
                {isRawBridgeExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-black/60 p-4 border border-white/5 rounded-2xl shadow-inner space-y-4">
                      
                      <div className="text-[10px] text-zinc-500 font-bold select-text leading-relaxed">
                        Status: <strong className="text-emerald-400">gt7.online aberto</strong>. Bridge de rede local ativo. Listagem completa e numerada com índices fixos garantindo compatibilidade.
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[350px] overflow-y-auto pr-1 scrollbar-thin">
                        {referenceData.map((item, index) => (
                          <div 
                            key={`${item.ref}-${index}`}
                            className="flex items-center justify-between p-2 bg-zinc-950 border border-white/5 rounded-xl hover:border-white/10 transition-all text-[9.5px]"
                          >
                            <div className="flex items-center gap-1.5 truncate">
                              <span className="font-mono text-[8px] font-black text-zinc-600 bg-white/5 px-1.5 py-0.5 rounded">
                                {String(item.ref).padStart(2, '0')}
                              </span>
                              <span className="font-semibold text-zinc-400 truncate">{item.label}</span>
                            </div>
                            <div className="flex items-center gap-1 shrink-0 font-mono">
                              <span className="text-white font-black bg-[#5ca1ff]/5 px-2 py-0.5 border border-[#5ca1ff]/10 rounded text-[9px]">
                                {item.value}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* TAB 2: TODOS OS DADOS PANEL (todos_os_dados) */}
        {activeTab === 'todos_os_dados' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col gap-4 text-zinc-200 z-10"
          >
            {/* Headers info */}
            <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex flex-col gap-1 select-text">
              <h4 className="text-xs uppercase font-black tracking-widest text-[#5ca1ff] flex items-center gap-2">
                <ShieldCheck size={14} className="text-[#10b981]" /> Todos os Dados da Telemetria (Grupo)
              </h4>
              <p className="text-[10px] text-zinc-400">Exibição de todos os dados organizados em grupos para auditoria completa e análise detalhada do bridge.</p>
            </div>

            {/* List groupings */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {["Status do Bridge", "Dados ao Vivo do Carro", "Voltas e Tempo", "Motor e Dinâmica", "Posição e Mapa", "Sessão e Registro"].map((groupName) => {
                const groupItems = referenceData.filter(i => i.group === groupName || (groupName === "Motor e Dinâmica" && i.group === "Motor e Dinâmica"));
                
                // Fetch dynamic items for Motor e Dinâmica which are not inside referenced elements
                const isMotor = groupName === "Motor e Dinâmica";
                const isPosicao = groupName === "Posição e Mapa";

                return (
                  <div key={groupName} className="p-4 bg-black/30 border border-white/5 rounded-2xl space-y-2">
                    <h5 className="text-[10px] uppercase font-black tracking-widest text-[#ffd35c] border-b border-white/5 pb-1 flex items-center gap-1.5">
                      <span className="w-1.5 h-3 bg-[#ffd35c] rounded-sm" />
                      {groupName}
                    </h5>

                    <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
                      {isMotor && (
                        <>
                          <div className="flex justify-between items-center py-1.5 px-2 bg-black/40 border border-white/5 rounded-xl text-[9.5px]">
                            <span className="text-zinc-400 font-medium">Temperatura Água</span>
                            <span className="font-mono text-cyan-300 font-bold">{waterTemp}</span>
                          </div>
                          <div className="flex justify-between items-center py-1.5 px-2 bg-black/40 border border-white/5 rounded-xl text-[9.5px]">
                            <span className="text-zinc-400 font-medium">Temperatura Óleo</span>
                            <span className="font-mono text-amber-500 font-bold">{oilTemp}</span>
                          </div>
                          <div className="flex justify-between items-center py-1.5 px-2 bg-black/40 border border-white/5 rounded-xl text-[9.5px]">
                            <span className="text-zinc-400 font-medium">Turbo Pressão</span>
                            <span className="font-mono text-purple-400 font-bold">{turboDesc}</span>
                          </div>
                          <div className="flex justify-between items-center py-1.5 px-2 bg-black/40 border border-white/5 rounded-xl text-[9.5px]">
                            <span className="text-zinc-400 font-medium">Vetor Velocidade</span>
                            <span className="font-mono text-emerald-400 font-bold">{vectorVelocity}</span>
                          </div>
                        </>
                      )}

                      {groupItems.map((item, index) => (
                        <div 
                          key={`${item.ref}-${index}`}
                          className="flex justify-between items-center py-1.5 px-2 bg-black/40 border border-white/5 rounded-xl text-[9.5px]"
                        >
                          <span className="text-zinc-400 font-medium">{item.label}</span>
                          <span className="font-mono text-white font-bold">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* TAB 3: CIRCUITO MAP VIEW (mapa) */}
        {activeTab === 'mapa' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col gap-4 text-zinc-200 z-10"
          >
            <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex justify-between items-center select-text">
              <div>
                <h4 className="text-xs uppercase font-black tracking-widest text-[#a78bfa] flex items-center gap-2">
                  <Navigation size={14} className="text-[#a78bfa] animate-pulse" /> Traçado e Vetor de Trajetória
                </h4>
                <p className="text-[10px] text-zinc-400">Coordenadas tridimensionais lidas em tempo real transmitidas via rede.</p>
              </div>
              {telemetry?.map?.track_name && (
                <span className="text-[9px] font-black uppercase tracking-widest bg-[#a78bfa]/10 border border-[#a78bfa]/20 px-3 py-1 rounded-full text-[#c084fc]">
                  📍 {telemetry.map.track_name}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Telemetry coordinate list */}
              <div className="p-4 bg-black/30 border border-white/5 rounded-2xl space-y-2 select-text font-mono text-[10px]">
                <h5 className="text-[9px] uppercase font-black tracking-widest text-zinc-500 border-b border-white/5 pb-1 select-none">Métricas de Coordenadas</h5>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span>Posição X:</span>
                  <span className="text-[#5ca1ff] font-bold">{displayX !== null ? displayX.toFixed(5) : '--'}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span>Posição Y:</span>
                  <span className="text-[#5ca1ff] font-bold">{displayY !== null ? displayY.toFixed(5) : '--'}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span>Posição Z:</span>
                  <span className="text-[#5ca1ff] font-bold">{displayZ !== null ? displayZ.toFixed(5) : '--'}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span>Superfície:</span>
                  <span className="text-white capitalize">{lastTelemetryRefVal?.surfaceType || 'Asfalto / Plain'}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span>Ângulo de Direção:</span>
                  <span className="text-[#ffd35c]">{telemetry?.map?.heading !== undefined && telemetry?.map?.heading !== null ? `${telemetry.map.heading.toFixed(1)}°` : '--'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Pontos no Vetor:</span>
                  <span className="text-zinc-400">{telemetry?.map?.path_points?.length || 0}</span>
                </div>
              </div>

              {/* Big Map Canvas Frame */}
              <div className="col-span-2 p-4 bg-black/60 border border-white/5 rounded-2xl min-h-[300px] flex items-center justify-center relative overflow-hidden">
                {telemetry?.map?.car_position?.x !== null && typeof telemetry?.map?.car_position?.x === 'number' ? (
                  <>
                    <div className="w-full h-full relative z-0 flex items-center justify-center">
                      {telemetry.map.path_points && telemetry.map.path_points.length > 2 && (() => {
                        const points = telemetry.map.path_points;
                        const minX = Math.min(...points.map(p => p.x));
                        const maxX = Math.max(...points.map(p => p.x));
                        const minY = Math.min(...points.map(p => p.y));
                        const maxY = Math.max(...points.map(p => p.y));
                        
                        const rangeX = maxX - minX || 1;
                        const rangeY = maxY - minY || 1;
                        const pMinX = minX - rangeX * 0.12;
                        const pMaxX = maxX + rangeX * 0.12;
                        const pMinY = minY - rangeY * 0.12;
                        const pMaxY = maxY + rangeY * 0.12;
                        
                        const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

                        return (
                          <svg 
                            viewBox={`${pMinX} ${pMinY} ${pMaxX - pMinX} ${pMaxY - pMinY}`} 
                            className="absolute inset-x-0 w-full h-full opacity-70 stroke-[#5ca1ff] fill-none"
                            style={{ strokeWidth: (pMaxX - pMinX) * 0.012 }}
                            preserveAspectRatio="xMidYMid meet"
                          >
                            <path d={pathData} strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        );
                      })()}

                      {/* Moving Car Dot indicator */}
                      <div className="relative">
                        <div className="animate-ping w-4.5 h-4.5 bg-[#ffd35c] rounded-full opacity-75 absolute -left-2.5 -top-2.5" />
                        <div className="w-4.5 h-4.5 bg-[#ffd35c] rounded-full relative z-10 flex items-center justify-center -left-2.5 -top-2.5 border-2 border-white">
                          <div className="w-1 h-3 bg-zinc-900 rounded-full" style={{ transform: `rotate(${telemetry.map.heading || 0}deg)` }} />
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center p-6 space-y-3 select-none">
                    <MapIcon size={36} className="mx-auto text-zinc-650 animate-bounce" />
                    <p className="text-xs font-black text-zinc-500 uppercase tracking-widest leading-relaxed">Aguardando coordenadas e traçado do PS5</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {/* TAB 4: SAVED HISTORY RECORDS (sessoes) */}
        {activeTab === 'sessoes' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col gap-4 text-zinc-200 z-10"
          >
            <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex justify-between items-center select-text">
              <div>
                <h4 className="text-xs uppercase font-black tracking-widest text-[#10b981] flex items-center gap-2">
                  <ClipboardList size={14} className="text-[#10b981]" /> Sessões de Telemetria Salvas
                </h4>
                <p className="text-[10px] text-zinc-400">Histórico de sessões de pista arquivadas localmente neste navegador.</p>
              </div>
              <button
                onClick={loadSessions}
                className="px-2.5 py-1 text-[8px] font-black uppercase tracking-widest bg-zinc-800 border border-white/5 rounded hover:bg-zinc-700 hover:text-white transition-all"
              >
                Atualizar Lista
              </button>
            </div>

            {savedSessions.length === 0 ? (
              <div className="py-16 text-center select-none bg-black/20 rounded-2xl border border-white/5 p-6">
                <Search size={36} className="mx-auto text-zinc-650 mb-3" />
                <h5 className="text-[10px] uppercase font-black tracking-widest text-zinc-500 mb-1">Nenhuma sessão gravada</h5>
                <p className="text-[9px] text-zinc-600 max-w-xs mx-auto">Ative "Gravar telemetria" nas opções e salve seus tempos de pista no banco local.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-8">
                {savedSessions.map((session, index) => (
                  <div
                    key={`${session.session_id}-${index}`}
                    className="p-4 bg-black/45 border border-white/5 rounded-2xl relative shadow-md hover:border-white/10 transition-all flex flex-col justify-between gap-4"
                  >
                    <div className="flex justify-between items-start select-text">
                      <div className="min-w-0">
                        <span className="text-[8px] uppercase font-black text-zinc-500 block mb-0.5">Sessão / Track</span>
                        <h4 className="text-xs font-black text-white truncate max-w-xs">{session.track_name || 'Circuito Desconhecido'}</h4>
                        <p className="text-[9px] font-mono text-zinc-400 mt-1 flex items-center gap-1">
                          <Calendar size={10} className="text-zinc-550" /> {new Date(session.created_at).toLocaleString()}
                        </p>
                      </div>

                      <button
                        onClick={(e) => handleDeleteSession(session.session_id, e)}
                        className="p-1 px-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 rounded border border-rose-500/20 active:scale-95 transition-all"
                        title="Excluir Sessão"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>

                    <div className="grid grid-cols-3 gap-2 border-t border-white/5 pt-3 text-[10px] font-mono">
                      <div>
                        <div className="text-[7.5px] uppercase font-black text-zinc-500">Melhor Volta</div>
                        <div className="text-[#a78bfa] font-black mt-0.5">{session.best_lap_text || '--:--.--'}</div>
                      </div>
                      <div>
                        <div className="text-[7.5px] uppercase font-black text-zinc-500">Voltas</div>
                        <div className="text-white font-black mt-0.5">{session.completed_laps || 0} laps</div>
                      </div>
                      <div>
                        <div className="text-[7.5px] uppercase font-black text-zinc-500">Max V</div>
                        <div className="text-[#ffd35c] font-black mt-0.5">{Math.round(session.max_speed_kmh || 0)} km/h</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* DISCREET BOTTOM ADVISORY BANNER */}
      <div className="mt-2 p-3 bg-white/5 border border-white/5 rounded-xl text-zinc-500 text-[9.5px] leading-relaxed flex items-start gap-2.5 z-10 select-text">
        <Info size={13} className="text-[#5ca1ff] shrink-0 mt-0.5" />
        <p>
          O painel de <strong>Sincronização Telemetria v1.4.12</strong> mantém decodificação em tempo real via UDP. Todos os cálculos matematicamente derivados, como voltas corrigidas, velocidade máxima e preservação dinâmica de tempos de volta, são salvos automaticamente no banco de dados local.
        </p>
      </div>

    </div>
  );
};
