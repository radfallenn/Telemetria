import React from 'react';
import { motion } from 'motion/react';
import { X } from 'lucide-react';
import { PublicProfileView } from './PublicProfileView';
import { LogoBrand } from '../types';

interface PublicProfileModalProps {
  userId: string;
  logoOverrides?: Record<string, string>;
  logosDatabase?: LogoBrand[];
  onClose: () => void;
}

export const PublicProfileModal: React.FC<PublicProfileModalProps> = ({ userId, logoOverrides = {}, logosDatabase = [], onClose }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[120] flex items-center justify-center p-4 lg:p-6 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 20 }}
        className="w-full max-w-4xl bg-bg-app rounded-[40px] shadow-2xl border border-accent-light flex flex-col max-h-[90vh] relative rgb-border-effect"
        onClick={e => e.stopPropagation()}
      >
         <button 
           onClick={onClose}
           className="absolute top-6 right-6 z-10 p-2 rounded-xl text-ink-secondary hover:text-ink-primary bg-white/10 hover:bg-white/20 transition-all backdrop-blur-md border border-white/10"
         >
           <X size={20} />
         </button>
         
         <div className="flex-1 overflow-y-auto scrollbar-hide">
           <PublicProfileView userId={userId} logoOverrides={logoOverrides} logosDatabase={logosDatabase} />
         </div>
      </motion.div>
    </motion.div>
  );
};
