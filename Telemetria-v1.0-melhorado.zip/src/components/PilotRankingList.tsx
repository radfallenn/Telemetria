import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Trophy, 
  User, 
  ShieldCheck, 
  Medal,
  Calendar,
  Activity,
  History,
  Star,
  Search,
  Filter
} from 'lucide-react';
import { UserProfile } from '../types';
import { supabaseService } from '../services/supabaseService';
import { formatDistanceToNow } from 'date-fns';
import { enUS, ptBR } from 'date-fns/locale';
import { useLanguage } from '../contexts/LanguageContext';

interface PilotRankingListProps {
  onSelectPilot: (userId: string) => void;
}

export function PilotRankingList({ onSelectPilot }: PilotRankingListProps) {
  const { language, t } = useLanguage();
  const [pilots, setPilots] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'wins' | 'races' | 'recent'>('wins');

  useEffect(() => {
    fetchRanking();
  }, []);

  const fetchRanking = async () => {
    setIsLoading(true);
    try {
      const data = await supabaseService.getAllPublicProfiles();
      setPilots(data);
    } catch (error) {
      console.error('Error fetching ranking:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const sortedPilots = [...pilots]
    .filter(p => 
      p.display_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.psn_id || '').toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'wins') return (b.total_wins || 0) - (a.total_wins || 0);
      if (sortBy === 'races') return (b.total_races || 0) - (a.total_races || 0);
      if (sortBy === 'recent') {
        const dateA = a.last_online ? new Date(a.last_online).getTime() : 0;
        const dateB = b.last_online ? new Date(b.last_online).getTime() : 0;
        return dateB - dateA;
      }
      return 0;
    });

  const getPilotRank = (idx: number) => {
    if (idx === 0) return { color: 'text-yellow-500', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' };
    if (idx === 1) return { color: 'text-slate-400', bg: 'bg-slate-400/10', border: 'border-slate-400/20' };
    if (idx === 2) return { color: 'text-amber-700', bg: 'bg-amber-700/10', border: 'border-amber-700/20' };
    return { color: 'text-ink-secondary', bg: 'bg-bg-app', border: 'border-accent-light' };
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary/40" size={18} />
          <input 
            type="text"
            placeholder={t('search')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-bg-card border border-accent-light rounded-2xl pl-12 pr-4 py-3 text-sm font-bold focus:outline-none focus:border-accent-blue transition-all"
          />
        </div>
        
        <div className="flex gap-2 w-full sm:w-auto">
          {[
            { id: 'wins', label: t('wins'), icon: Trophy },
            { id: 'races', label: t('tracks'), icon: Activity },
            { id: 'recent', label: t('online'), icon: Star }
          ].map((btn) => (
            <button
              key={btn.id}
              onClick={() => setSortBy(btn.id as any)}
              className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                sortBy === btn.id 
                  ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' 
                  : 'bg-bg-card border border-accent-light text-ink-secondary hover:border-accent-blue/30'
              }`}
            >
              <btn.icon size={14} />
              <span className="hidden sm:inline">{btn.label}</span>
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-4">
          <div className="w-12 h-12 border-4 border-accent-blue/20 border-t-accent-blue rounded-full animate-spin" />
          <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary animate-pulse">{t('syncing_ranking')}</p>
        </div>
      ) : sortedPilots.length === 0 ? (
        <div className="py-20 text-center">
          <Trophy size={60} className="mx-auto text-ink-secondary/10 mb-4" />
          <p className="text-sm font-bold text-ink-secondary uppercase tracking-widest">{t('no_drivers_ranking')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {sortedPilots.map((pilot, idx) => {
            const rankStyles = getPilotRank(idx);
            return (
              <motion.div
                key={`${pilot.id}-${idx}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                onClick={() => onSelectPilot(pilot.id)}
                className={`group relative bg-bg-card border ${rankStyles.border} rounded-[32px] p-5 sm:p-6 cursor-pointer hover:border-accent-blue transition-all flex flex-col sm:flex-row items-center sm:items-start gap-6 rgb-border-effect`}
              >
                {/* Ranking Badge */}
                <div className={`absolute top-0 left-0 px-4 py-2 ${rankStyles.bg} rounded-br-[20px] flex items-center gap-2 border-b border-r ${rankStyles.border}`}>
                  <span className={`text-base italic font-black ${rankStyles.color}`}>{idx + 1}</span>
                  {idx < 3 && <Medal size={14} className={rankStyles.color} />}
                </div>

                {/* Left Side: Avatar and Identity */}
                <div className="flex items-center gap-5 pt-8 sm:pt-0">
                  <div className="relative">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-[32px] overflow-hidden border-2 border-accent-light group-hover:border-accent-blue transition-colors shadow-2xl bg-bg-app">
                      {pilot.avatar_url ? (
                        <img src={pilot.avatar_url} alt={pilot.display_name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-ink-secondary/20">
                          <User size={40} />
                        </div>
                      )}
                    </div>
                    {pilot.is_admin && (
                       <div className="absolute -bottom-1 -right-1 p-1.5 bg-accent-blue text-white rounded-2xl shadow-xl border-2 border-bg-card">
                         <ShieldCheck size={14} />
                       </div>
                    )}
                  </div>

                  <div className="min-w-0">
                    <h3 className="text-xl font-black uppercase tracking-tight text-ink-primary leading-tight">
                      {pilot.display_name}
                    </h3>
                    <p className="text-xs font-black text-accent-blue tracking-widest uppercase opacity-70">
                      @{pilot.psn_id || 'GT_PILOT'}
                    </p>
                    <div className="flex gap-2 mt-3">
                       <div className="px-3 py-1 bg-bg-app rounded-xl text-[10px] font-black uppercase text-ink-secondary border border-accent-light shadow-sm">
                         DR {pilot.driver_rating || 'D'}
                       </div>
                       <div className="px-3 py-1 bg-bg-app rounded-xl text-[10px] font-black uppercase text-ink-secondary border border-accent-light shadow-sm">
                         SR {pilot.safety_rating || 'S'}
                       </div>
                    </div>
                  </div>
                </div>

                {/* Right Side: Stats */}
                <div className="flex-1 w-full flex items-center justify-around sm:justify-end gap-4 sm:gap-12 py-4 sm:py-0 border-t sm:border-t-0 border-accent-light/50">
                  <div className="text-center group-hover:scale-110 transition-transform">
                    <p className="text-2xl font-black text-ink-primary leading-none uppercase">{pilot.total_races || 0}</p>
                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-40 mt-1">{t('tracks')}</p>
                  </div>
                  
                  <div className="w-px h-10 bg-accent-light/30 hidden sm:block" />

                  <div className="text-center group-hover:scale-110 transition-transform">
                    <p className="text-2xl font-black text-yellow-500 leading-none uppercase">{pilot.total_wins || 0}</p>
                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-ink-secondary opacity-40 mt-1 text-yellow-500/60">{t('wins')}</p>
                  </div>

                  <div className="hidden xl:flex flex-col items-end gap-1 min-w-[120px]">
                    <div className="flex items-center gap-2 text-ink-secondary opacity-40">
                       <History size={12} />
                       <span className="text-[9px] font-black uppercase tracking-widest">{t('activity')}</span>
                    </div>
                    <p className="text-[10px] font-black text-ink-primary uppercase tracking-tighter">
                      {pilot.last_online 
                        ? formatDistanceToNow(new Date(pilot.last_online), { addSuffix: true, locale: language === 'pt' ? ptBR : enUS })
                        : t('no_activity')}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
