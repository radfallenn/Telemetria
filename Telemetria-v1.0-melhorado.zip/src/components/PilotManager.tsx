import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Search, 
  User, 
  ShieldCheck, 
  ChevronRight, 
  X,
  Activity,
  History,
  Trophy,
  Filter,
  BarChart3,
  Calendar,
  MessageSquare,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { UserProfile } from '../types';
import { supabaseService } from '../services/supabaseService';
import { formatDistanceToNow } from 'date-fns';
import { enUS, ptBR } from 'date-fns/locale';
import { useLanguage } from '../contexts/LanguageContext';

interface PilotManagerProps {
  onSelectUser: (userId: string) => void;
  onClose: () => void;
  isAdmin?: boolean;
}

export function PilotManager({ onSelectUser, onClose, isAdmin }: PilotManagerProps) {
  const { language, t } = useLanguage();
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'online' | 'new'>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    setIsLoading(true);
    try {
      const data = await supabaseService.getAllProfilesAdmin();
      setProfiles(data);
    } catch (error) {
      console.error('Error fetching profiles:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const isOnline = (lastOnline?: string) => {
    if (!lastOnline) return false;
    const lastDate = new Date(lastOnline);
    const now = new Date();
    // Consider online if active in the last 5 minutes
    return now.getTime() - lastDate.getTime() < 5 * 60 * 1000;
  };

  const filteredProfiles = profiles.filter(p => {
    const matchesSearch = 
      p.display_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.psn_id || '').toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filter === 'online') return matchesSearch && isOnline(p.last_online);
    if (filter === 'new') {
      const createdDate = p.created_at ? new Date(p.created_at) : new Date(0);
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      return matchesSearch && createdDate > oneWeekAgo;
    }
    
    return matchesSearch;
  });

  const onlineCount = profiles.filter(p => isOnline(p.last_online)).length;

  const handleDeleteProfile = async (e: React.MouseEvent, userId: string) => {
    e.stopPropagation();
    if (!isAdmin) return;
    
    setDeletingId(userId);
  };

  const confirmDelete = async () => {
    if (!deletingId) return;
    setIsDeleting(true);
    try {
      await supabaseService.deleteProfile(deletingId);
      setProfiles(prev => prev.filter(p => p.id !== deletingId));
      setDeletingId(null);
    } catch (error: any) {
      alert(error.message || 'Error deleting profile');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[110] flex items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-bg-card w-full max-w-6xl h-full sm:h-[90vh] sm:rounded-[32px] overflow-hidden border border-accent-light shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="p-6 border-b border-accent-light flex items-center justify-between bg-gradient-to-r from-bg-card to-bg-app/50 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Users size={120} />
          </div>
          
          <div className="flex items-center gap-4 relative z-10">
            <div className="p-3 bg-accent-blue/10 rounded-2xl text-accent-blue shadow-inner">
              <Users size={24} />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-ink-primary">{t('driver_manager')}</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-60">
                   {profiles.length} {t('registered_drivers')}
                </span>
                <span className="w-1 h-1 bg-ink-secondary/30 rounded-full" />
                <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-green-500">
                  <Activity size={10} className="animate-pulse" />
                  {onlineCount} {t('now')}
                </span>
              </div>
            </div>
          </div>
          
          <button 
            onClick={onClose}
            className="p-2 hover:bg-bg-app rounded-full text-ink-secondary transition-colors relative z-10"
          >
            <X size={24} />
          </button>
        </div>

        {/* Dashboard Controls */}
        <div className="p-6 bg-bg-app/30 border-b border-accent-light flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary/40" size={18} />
            <input 
              type="text"
              placeholder={t('search_driver_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-bg-cell border border-accent-light rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-accent-blue transition-all shadow-sm"
            />
          </div>
          
          <div className="flex gap-2">
            {[
              { id: 'all', label: t('all'), icon: Users },
              { id: 'online', label: t('online'), icon: Activity },
              { id: 'new', label: t('new'), icon: Calendar }
            ].map((btn) => (
              <button
                key={btn.id}
                onClick={() => setFilter(btn.id as any)}
                className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  filter === btn.id 
                    ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20' 
                    : 'bg-bg-cell border border-accent-light text-ink-secondary hover:border-accent-blue/30'
                }`}
              >
                <btn.icon size={14} />
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 scrollbar-hide bg-bg-app/10">
          {isLoading ? (
            <div className="h-full flex flex-col items-center justify-center gap-4">
              <div className="w-12 h-12 border-4 border-accent-blue/20 border-t-accent-blue rounded-full animate-spin" />
              <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary animate-pulse">{t('syncing_drivers')}</p>
            </div>
          ) : filteredProfiles.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-12">
               <div className="p-8 bg-bg-cell rounded-[40px] text-ink-secondary/10 mb-6 border border-accent-light shadow-inner">
                  <Users size={80} />
               </div>
               <h3 className="text-xl font-black uppercase tracking-tight text-ink-primary">{t('no_drivers_found')}</h3>
               <p className="text-xs font-bold text-ink-secondary opacity-60 uppercase mt-2 max-w-xs">
                 {t('adjust_filters_desc')}
               </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProfiles.map((pilot, idx) => (
                <motion.div
                  key={`${pilot.id}-${idx}`}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.03 }}
                  onClick={() => onSelectUser(pilot.id)}
                  className="group relative bg-bg-cell border border-accent-light rounded-[32px] p-6 cursor-pointer hover:border-accent-blue/50 hover:shadow-2xl transition-all overflow-hidden"
                >
                  {/* Status Indicator */}
                  {isOnline(pilot.last_online) && (
                    <div className="absolute top-4 right-4 flex items-center gap-1.5 px-2.5 py-1 bg-green-500/10 rounded-full border border-green-500/20">
                       <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                       <span className="text-[8px] font-black uppercase text-green-500 tracking-widest">{t('active')}</span>
                    </div>
                  )}

                  <div className="flex items-center gap-5">
                    <div className="relative">
                      <div className="w-20 h-20 rounded-[24px] overflow-hidden border-2 border-accent-light group-hover:border-accent-blue transition-colors shadow-lg bg-bg-app">
                        {pilot.avatar_url ? (
                          <img src={pilot.avatar_url} alt={pilot.display_name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-ink-secondary/20">
                            <User size={40} />
                          </div>
                        )}
                      </div>
                      {pilot.is_admin && (
                         <div className="absolute -bottom-1 -right-1 p-1.5 bg-accent-blue text-white rounded-xl shadow-xl border-2 border-bg-cell">
                           <ShieldCheck size={12} />
                         </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-black uppercase tracking-tight text-ink-primary truncate leading-tight">
                        {pilot.display_name}
                      </h3>
                      <p className="text-[10px] font-black text-accent-blue truncate mt-0.5 tracking-widest">
                        @{pilot.psn_id || 'GT_PILOT'}
                      </p>
                      <div className="flex gap-1.5 mt-3">
                         <div className="px-2 py-1 bg-bg-app rounded-lg text-[9px] font-black uppercase text-ink-secondary border border-accent-light">
                           DR {pilot.driver_rating || 'D'}
                         </div>
                         <div className="px-2 py-1 bg-bg-app rounded-lg text-[9px] font-black uppercase text-ink-secondary border border-accent-light">
                           SR {pilot.safety_rating || 'S'}
                         </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-between gap-4">
                     <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2 text-ink-secondary">
                          <History size={12} className="opacity-40" />
                          <span className="text-[9px] font-black uppercase tracking-widest opacity-60">{t('last_seen')}</span>
                        </div>
                        <p className="text-[10px] font-black text-ink-primary uppercase tracking-tighter">
                          {pilot.last_online 
                            ? formatDistanceToNow(new Date(pilot.last_online), { addSuffix: true, locale: language === 'pt' ? ptBR : enUS })
                            : t('offline_a_long_time')}
                        </p>
                     </div>
                     
                     <div className="flex items-center gap-2">
                        <div className="flex flex-col items-center px-4 py-2 bg-bg-app rounded-2xl border border-accent-light">
                           <span className="text-sm font-black text-ink-primary">{pilot.total_wins || 0}</span>
                           <Trophy size={10} className="text-yellow-500 mt-0.5" />
                        </div>
                     </div>
                  </div>

                  {/* Hover Action */}
                  <div className="absolute bottom-4 right-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                    {isAdmin && (
                      <button 
                        onClick={(e) => handleDeleteProfile(e, pilot.id)}
                        className="p-3 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all shadow-xl"
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                    <div className="p-3 bg-accent-blue text-white rounded-2xl shadow-xl">
                       <ChevronRight size={18} />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        <AnimatePresence>
          {deletingId && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-bg-card max-w-sm w-full p-8 rounded-[32px] border border-red-500/20 shadow-2xl space-y-6"
              >
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="p-4 bg-red-500/10 text-red-500 rounded-full">
                    <AlertTriangle size={32} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black uppercase tracking-tight text-ink-primary">{t('delete_driver_confirm')}</h3>
                    <p className="text-xs font-bold text-ink-secondary opacity-60 uppercase mt-2">
                       {t('delete_driver_desc')}
                    </p>
                  </div>
                </div>

                <div className="flex gap-3 mt-4">
                  <button 
                    onClick={() => setDeletingId(null)}
                    className="flex-1 px-4 py-4 rounded-2xl bg-bg-cell border border-accent-light text-ink-secondary text-[10px] font-black uppercase tracking-widest hover:bg-bg-app transition-colors"
                  >
                    {t('cancel')}
                  </button>
                  <button 
                    onClick={confirmDelete}
                    disabled={isDeleting}
                    className="flex-1 px-4 py-4 rounded-2xl bg-red-500 text-white text-[10px] font-black uppercase tracking-widest hover:bg-red-600 transition-all flex items-center justify-center gap-2"
                  >
                    {isDeleting ? (
                       <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                         <Trash2 size={14} />
                         {t('yes_delete')}
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer Stats */}
        <div className="p-6 bg-bg-cell border-t border-accent-light grid grid-cols-2 sm:grid-cols-4 gap-4">            <div className="flex items-center gap-3">
              <div className="p-2 bg-accent-blue/5 rounded-xl text-accent-blue"><Users size={16} /></div>
              <div>
                <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('registered_drivers')}</p>
                <p className="text-xs font-black text-ink-primary uppercase">{profiles.length}</p>
              </div>
           </div>
           <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/5 rounded-xl text-green-500"><Activity size={16} /></div>
              <div>
                <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('online')}</p>
                <p className="text-xs font-black text-ink-primary uppercase">{onlineCount}</p>
              </div>
           </div>
           <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/5 rounded-xl text-purple-500"><BarChart3 size={16} /></div>
              <div>
                <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('activity')}</p>
                <p className="text-xs font-black text-ink-primary uppercase">{t('highLines')}</p>
              </div>
           </div>

           <div className="flex items-center gap-3">
              <div className="p-2 bg-accent-blue/5 rounded-xl text-accent-blue"><MessageSquare size={16} /></div>
              <div>
                <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary opacity-50">Community</p>
                <p className="text-xs font-black text-ink-primary uppercase">GT Trace</p>
              </div>
           </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
