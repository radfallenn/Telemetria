import React, { useEffect, useRef } from 'react';

export function CarAudioFX() {
  const audioCtxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    // Try to initialize audio context
    const initAudio = () => {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }
    };

    // Play a race car pass-by sound
    const playPassBySound = () => {
      if (!audioCtxRef.current) return;
      if (audioCtxRef.current.state === 'suspended') return; // Can't play if suspended

      const ctx = audioCtxRef.current;
      const t = ctx.currentTime;
      const duration = 0.8 + Math.random() * 0.8; // 0.8s to 1.6s

      // Base engine sound using oscillators
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc2.type = 'square';

      // Noise for wind/road texture
      const bufferSize = ctx.sampleRate * duration;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1; 
      }
      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;

      // Doppler effect (pitch shift) for engine
      const startFreq = 300 + Math.random() * 300; // 300-600Hz
      const endFreq = 80 + Math.random() * 60; // 80-140Hz

      osc1.frequency.setValueAtTime(startFreq, t);
      osc1.frequency.exponentialRampToValueAtTime(startFreq * 1.1, t + duration * 0.4); 
      osc1.frequency.exponentialRampToValueAtTime(endFreq, t + duration * 0.5);
      osc1.frequency.exponentialRampToValueAtTime(endFreq * 0.9, t + duration);

      osc2.frequency.setValueAtTime(startFreq * 0.5, t);
      osc2.frequency.exponentialRampToValueAtTime(startFreq * 0.55, t + duration * 0.4);
      osc2.frequency.exponentialRampToValueAtTime(endFreq * 0.5, t + duration * 0.5);
      osc2.frequency.exponentialRampToValueAtTime(endFreq * 0.45, t + duration);

      // Filter settings for car engine/wind sound
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2000, t);
      filter.frequency.linearRampToValueAtTime(400, t + duration); // Dull as it gets further
      
      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'bandpass';
      noiseFilter.frequency.setValueAtTime(startFreq * 2, t);
      noiseFilter.frequency.exponentialRampToValueAtTime(endFreq * 2, t + duration * 0.5);

      // Volume envelope (fade in out quickly)
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.001, t);
      masterGain.gain.exponentialRampToValueAtTime(0.4, t + duration * 0.4);
      masterGain.gain.exponentialRampToValueAtTime(0.001, t + duration);

      const oscGain = ctx.createGain();
      oscGain.gain.value = 0.5;

      const noiseGain = ctx.createGain();
      noiseGain.gain.value = 0.5;

      // Simple stereo panning (left to right or right to left)
      const panner = ctx.createStereoPanner();
      const panDirection = Math.random() > 0.5 ? 1 : -1;
      panner.pan.setValueAtTime(-panDirection, t);
      panner.pan.linearRampToValueAtTime(panDirection, t + duration);

      // Connect nodes
      osc1.connect(oscGain);
      osc2.connect(oscGain);
      oscGain.connect(filter);
      
      noiseSource.connect(noiseFilter);
      noiseFilter.connect(noiseGain);

      filter.connect(masterGain);
      noiseGain.connect(masterGain);
      
      masterGain.connect(panner);
      panner.connect(ctx.destination);

      osc1.start(t);
      osc2.start(t);
      noiseSource.start(t);

      osc1.stop(t + duration);
      osc2.stop(t + duration);
      noiseSource.stop(t + duration);
    };

    // Initialize on first click on document to unlock audio if needed
    const unlockAudio = () => {
      initAudio();
      document.removeEventListener('click', unlockAudio);
      document.removeEventListener('touchstart', unlockAudio);
      document.removeEventListener('keydown', unlockAudio);
      playPassBySound(); // Play one immediately on interaction
    };
    
    document.addEventListener('click', unlockAudio);
    document.addEventListener('touchstart', unlockAudio);
    document.addEventListener('keydown', unlockAudio);
    
    // Attempt init immediately (for browsers that allow it or if already unlocked)
    try {
      initAudio();
    } catch(e) {}

    let timeoutId: NodeJS.Timeout;
    
    const scheduleNextPass = () => {
      playPassBySound();
      const nextInterval = 600 + Math.random() * 2000;
      timeoutId = setTimeout(scheduleNextPass, nextInterval);
    };
    
    // Start loop
    scheduleNextPass();

    return () => {
      clearTimeout(timeoutId);
      document.removeEventListener('click', unlockAudio);
      document.removeEventListener('touchstart', unlockAudio);
      document.removeEventListener('keydown', unlockAudio);
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  return null;
}
