import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, Sparkles, AlertCircle, ThumbsUp, Send, CheckCircle2, 
  Activity, Zap, Lightbulb, Clock, Check, Plus, MessageSquare, Flame
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface RoadmapItem {
  id: string;
  titleEn: string;
  titlePt: string;
  descEn: string;
  descPt: string;
  status: 'completed' | 'in_development' | 'planned';
  votes: number;
  isUserAdded?: boolean;
  version?: string;
  category: string;
}

const DEFAULT_ROADMAP_ITEMS: RoadmapItem[] = [
  {
    id: 'comp_1',
    titleEn: 'Raspberry Bridge Mode v1.5.0',
    titlePt: 'Modo Raspberry Bridge v1.5.0',
    descEn: 'Allows using a Raspberry/CasaOS instance as a telemetry bridge to stream GT7 data directly to mobiles.',
    descPt: 'Permite usar uma instância Raspberry/CasaOS como bridge de telemetria para transmitir dados do GT7 diretamente.',
    status: 'completed',
    votes: 412,
    version: 'v1.5.0',
    category: 'Connectivity'
  },
  {
    id: 'comp_2',
    titleEn: 'Database Performance Engine & Indexes',
    titlePt: 'Otimização de Banco de Dados & Índices',
    descEn: 'Avoids heavy full-table scans with dedicated physical indexes, preventing database query timeout errors.',
    descPt: 'Evita varreduras pesadas do tipo full-table scan com índices físicos dedicados, prevenindo erros de timeout.',
    status: 'completed',
    votes: 356,
    version: 'v1.4.9',
    category: 'Database'
  },
  {
    id: 'comp_3',
    titleEn: 'Automated Corrections for Lap Times',
    titlePt: 'Correções Automáticas de Tempos de Volta',
    descEn: 'Substitutes calculated totals automatically unless manually overridden to keep stats and sums precise.',
    descPt: 'Preenche os totais calculados automaticamente, exceto se editados de forma manual, garantindo precisão.',
    status: 'completed',
    votes: 219,
    version: 'v1.4.9',
    category: 'UX'
  },
  {
    id: 'comp_4',
    titleEn: 'Chunked Data Uploader',
    titlePt: 'Uploader de Dados Fracionado',
    descEn: 'Saves tracks and entries with sequential chunked batches of 50 to prevent connection interruptions.',
    descPt: 'Salva pistas e registros em blocos sequenciais pequenos (chunks) de 50 para prevenir timeouts de rede.',
    status: 'completed',
    votes: 184,
    version: 'v1.4.9',
    category: 'Database'
  },
  {
    id: 'dev_1',
    titleEn: 'Interactive Pace & Laps Charts',
    titlePt: 'Gráficos de Ritmo e Evolução de Voltas',
    descEn: 'Visual graph charts using D3/Recharts comparing individual lap timeline progression within race sessions.',
    descPt: 'Gráfico visual usando D3/Recharts comparando a evolução e consistência de tempos nas sessões de corrida.',
    status: 'in_development',
    votes: 894,
    category: 'Data Analysis'
  },
  {
    id: 'dev_2',
    titleEn: 'Multiplayer Real-time Split Dashboard',
    titlePt: 'Modo Corrida Multiplayer Split Screen',
    descEn: 'Interactive split timeline allowing pilots to compare raw active live streams side-by-side.',
    descPt: 'Painel dividido interativo permitindo que pilotos comparem telemetria e posições ao vivo lado a lado.',
    status: 'in_development',
    votes: 752,
    category: 'Multiplayer'
  },
  {
    id: 'dev_3',
    titleEn: 'Dynamic Weather & Tire Alerts',
    titlePt: 'Alertas Dinâmicos de Clima e Pneus',
    descEn: 'Real-time tire degradation and track surface analysis alerts triggered automatically before optimal thresholds.',
    descPt: 'Calculadora e alertas de desgaste de pneu em tempo real acionados antes de passar do limite recomendado.',
    status: 'in_development',
    votes: 620,
    category: 'Telemetry Alerts'
  },
  {
    id: 'plan_1',
    titleEn: 'Discord Webhook Connection',
    titlePt: 'Integração de Webhook com Discord',
    descEn: 'Trigger instant notifications containing best lap updates and records to community server boards.',
    descPt: 'Dispare notificações instantâneas com novos recordes de pista de volta mais rápida diretamente para o Discord.',
    status: 'planned',
    votes: 491,
    category: 'Social'
  },
  {
    id: 'plan_2',
    titleEn: 'Carbon Card Studio Editor Preset Bank',
    titlePt: 'Banco de Temas Personalizados no Card Designer',
    descEn: 'Import, share, and select visual layouts for layout telemetry boxes through a customizable theme deck.',
    descPt: 'Importe, crie e compartilhe temas e esquemas visuais com a comunidade para o designer de cartões.',
    status: 'planned',
    votes: 382,
    category: 'UI/UX'
  },
  {
    id: 'plan_3',
    titleEn: 'Telemetry Spreadsheet Export (.CSV)',
    titlePt: 'Exportação de Planilhas CSV Completas',
    descEn: 'Allow full bulk extraction of races lap schedules into Excel spreadsheets for extreme sim-racing telemetry analysis.',
    descPt: 'Permite extrair planilhas cheias de cronogramas de voltas em formato CSV para análise de engenharia de corrida.',
    status: 'planned',
    votes: 275,
    category: 'Data Analysis'
  }
];

export const RoadmapView: React.FC = () => {
  const { language } = useLanguage();
  const isPt = language === 'pt';

  const [items, setItems] = useState<RoadmapItem[]>(() => {
    try {
      const saved = localStorage.getItem('gt7_roadmap_data');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
    return DEFAULT_ROADMAP_ITEMS;
  });

  const [votedIds, setVotedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('gt7_roadmap_voted');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState('Sugestão');
  const [activeFilter, setActiveFilter] = useState<'all' | 'completed' | 'in_development' | 'planned'>('all');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    localStorage.setItem('gt7_roadmap_data', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem('gt7_roadmap_voted', JSON.stringify(votedIds));
  }, [votedIds]);

  const handleVote = (itemId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (votedIds.includes(itemId)) {
      // Unvote
      setItems(prev => prev.map(item => {
        if (item.id === itemId) {
          return { ...item, votes: Math.max(0, item.votes - 1) };
        }
        return item;
      }));
      setVotedIds(prev => prev.filter(id => id !== itemId));
    } else {
      // Vote
      setItems(prev => prev.map(item => {
        if (item.id === itemId) {
          return { ...item, votes: item.votes + 1 };
        }
        return item;
      }));
      setVotedIds(prev => [...prev, itemId]);
    }
  };

  const handleSubmitSuggestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    const newItem: RoadmapItem = {
      id: `custom_${Date.now()}`,
      titleEn: newTitle,
      titlePt: newTitle,
      descEn: newDesc,
      descPt: newDesc,
      status: 'planned',
      votes: 1,
      isUserAdded: true,
      category: newCategory
    };

    setItems(prev => [newItem, ...prev]);
    setVotedIds(prev => [...prev, newItem.id]);
    setNewTitle('');
    setNewDesc('');
    setNewCategory('Sugestão');

    setSuccessMsg(isPt ? 'Ideia recebida e votada! 💡' : 'Idea received & upvoted! 💡');
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  const filteredItems = items
    .filter(item => activeFilter === 'all' || item.status === activeFilter)
    .sort((a, b) => {
      // Rank by status: in_development first, then planned, then completed (unless they want standard order)
      // Among same status, sort by vote count descending
      if (a.status !== b.status) {
        const orderMap = { in_development: 0, planned: 1, completed: 2 };
        return orderMap[a.status] - orderMap[b.status];
      }
      return b.votes - a.votes;
    });

  return (
    <div className="space-y-8" id="roadmap_hub">
      {/* Visual Roadmap Banner */}
      <div className="bg-bg-card rounded-[40px] p-8 border border-accent-light shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden group">
        <div className="flex items-center gap-6 relative z-10">
          <div className="p-5 bg-accent-blue rounded-[28px] text-white relative z-10 shadow-2xl group-hover:scale-105 transition-transform">
            <Sparkles size={32} className="animate-pulse" />
          </div>
          <div className="relative z-10">
            <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-ink-primary leading-none">
              {isPt ? 'MELHORIAS FUTURAS' : 'FUTURE IMPROVEMENTS'}
            </h2>
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-ink-secondary mt-3 opacity-60">
              {isPt ? 'Central de Sugestões & Roadmap' : 'Roadmap & Suggestions board'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 relative z-10 self-stretch md:self-auto">
          {(['all', 'in_development', 'planned', 'completed'] as const).map(f => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1.5 sm:py-2 rounded-[14px] text-[8.5px] sm:text-[9.5px] font-black uppercase tracking-wider transition-all duration-200 border ${
                activeFilter === f 
                  ? 'bg-ink-primary text-bg-app border-transparent shadow' 
                  : 'bg-black/10 dark:bg-white/5 text-ink-secondary border-accent-light hover:text-ink-primary'
              }`}
            >
              {f === 'all' ? (isPt ? 'TUDO' : 'ALL') :
               f === 'completed' ? (isPt ? 'CONCLUÍDAS' : 'COMPLETED') :
               f === 'in_development' ? (isPt ? 'DESENVOLVIMENTO' : 'IN PROGRESS') :
               (isPt ? 'PLANEJADAS' : 'PLANNED')}
            </button>
          ))}
        </div>

        {/* Abstract Background Decoration */}
        <div className="absolute top-0 right-0 p-12 opacity-[0.03] rotate-12 group-hover:rotate-45 transition-all duration-1000 select-none pointer-events-none">
          <Trophy size={180} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Feature Submission Board */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-bg-card rounded-[32px] p-6 border border-accent-light shadow-sm flex flex-col gap-5">
            <div className="flex flex-col gap-1">
              <span className="text-[9px] font-black uppercase tracking-widest text-accent-blue">
                {isPt ? 'COOPERE COM O PROJETO' : 'COLLABORATE WITH THE PROJECT'}
              </span>
              <h3 className="text-base font-black uppercase tracking-wider text-ink-primary">
                {isPt ? 'Sugerir Novo Recurso' : 'Suggest New Feature'}
              </h3>
              <p className="text-[10px] text-ink-secondary leading-normal mt-1">
                {isPt 
                  ? 'Envie sua ideia de melhoria para a telemetria ou gerenciador. A comunidade pode votar para dar visibilidade!' 
                  : 'Submit your ideas to improve safety or user performance. Drivers can upvote to prioritize!'}
              </p>
            </div>

            <form onSubmit={handleSubmitSuggestion} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[8.5px] font-black uppercase tracking-wider text-ink-secondary">
                  {isPt ? 'Título da Melhoria' : 'Enhancement Title'}
                </label>
                <input 
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder={isPt ? 'Ex: Gráfico de consistência...' : 'Ex: Fuel management box...'}
                  className="w-full text-xs font-black bg-black/10 dark:bg-white/5 border border-accent-light rounded-[14px] p-3 focus:outline-none focus:ring-1 focus:ring-accent-blue focus:border-transparent text-ink-primary placeholder:opacity-50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[8.5px] font-black uppercase tracking-wider text-ink-secondary">
                  {isPt ? 'Descrição Detalhada' : 'Detailed Description'}
                </label>
                <textarea 
                  required
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder={isPt ? 'Como esse recurso ajudará você a bater o recorde da pista?...' : 'Why does this trigger your GT7 racer performance?...'}
                  className="w-full text-xs font-medium bg-black/10 dark:bg-white/5 border border-accent-light rounded-[14px] p-3 focus:outline-none focus:ring-1 focus:ring-accent-blue focus:border-transparent text-ink-primary resize-none placeholder:opacity-50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[8.5px] font-black uppercase tracking-wider text-ink-secondary">
                  {isPt ? 'Categoria' : 'Category'}
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full text-xs font-black bg-black/10 dark:bg-white/5 border border-accent-light rounded-[14px] p-3 appearance-none focus:outline-none text-ink-primary cursor-pointer hover:bg-black/15 transition-colors"
                >
                  <option value={isPt ? 'Telemetria' : 'Telemetry'}>{isPt ? 'Telemetria / Widgets' : 'Telemetry / Widgets'}</option>
                  <option value={isPt ? 'Visual / Layout' : 'Visual / Layout'}>{isPt ? 'Visual / Layouts' : 'Visual / Layouts'}</option>
                  <option value={isPt ? 'Banco de Dados' : 'Database'}>{isPt ? 'Banco de Dados (DB)' : 'Database'}</option>
                  <option value={isPt ? 'Conectividade' : 'Connectivity'}>{isPt ? 'Conectividade & APK' : 'Connectivity & APK'}</option>
                  <option value={isPt ? 'Geral' : 'General'}>{isPt ? 'Geral / Outros' : 'General / Others'}</option>
                </select>
              </div>

              <AnimatePresence>
                {successMsg && (
                  <motion.div 
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-[10px] font-black uppercase text-center tracking-widest flex items-center justify-center gap-1.5"
                  >
                    <Check size={13} className="stroke-[3]" />
                    {successMsg}
                  </motion.div>
                )}
              </AnimatePresence>

              <button
                type="submit"
                className="w-full py-3 bg-accent-blue hover:bg-accent-blue/90 text-white hover:text-white font-black text-[10px] tracking-widest uppercase rounded-[16px] transition-all flex items-center justify-center gap-2 shadow-lg shadow-accent-blue/20 active:scale-[0.98]"
              >
                <Send size={12} />
                {isPt ? 'Enviar & Votar Ideia' : 'Submit & Support'}
              </button>
            </form>
          </div>

          {/* Quick Notice Card */}
          <div className="bg-[#12151c]/70 border border-white/[0.06] rounded-[24px] p-5 flex items-start gap-3">
            <AlertCircle className="text-accent-blue shrink-0 mt-0.5" size={16} />
            <div className="space-y-0.5">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-white">
                {isPt ? 'Código Open-Source' : 'Open-Source Project'}
              </h4>
              <p className="text-[9.5px] leading-relaxed text-zinc-400">
                {isPt 
                  ? 'A telemetria do GT7 Bridge é um sistema livre. Se você sabe programar, pode propor uma pull request para integrar estes itens!' 
                  : 'This bridge is custom made. Pull requests are welcomed to speed up integration of these community requests.'}
              </p>
            </div>
          </div>
        </div>

        {/* Right Columns: Interactive Board Grid */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-xs font-black uppercase tracking-widest text-ink-secondary flex items-center gap-2">
              <Activity size={12} className="text-accent-blue animate-pulse" />
              {isPt ? 'Fila do Desenvolvimento Ativa' : 'Active Feature Backlog'}
            </h3>
            <span className="text-[9px] font-mono font-bold text-zinc-500">
              {filteredItems.length} {filteredItems.length === 1 ? (isPt ? 'item' : 'item') : (isPt ? 'itens' : 'items')}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item, index) => {
                const isVoted = votedIds.includes(item.id);
                
                // Color badges depending on states
                let statusBadge = '';
                let statusText = '';
                if (item.status === 'completed') {
                  statusBadge = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
                  statusText = isPt ? 'Concluído' : 'Completed';
                } else if (item.status === 'in_development') {
                  statusBadge = 'bg-amber-500/10 text-amber-400 border-amber-500/20';
                  statusText = isPt ? 'Em Desenvolvimento' : 'In Progress';
                } else {
                  statusBadge = 'bg-accent-blue/10 text-accent-blue border-accent-blue/20';
                  statusText = isPt ? 'Planejado' : 'Planned';
                }

                return (
                  <motion.div
                    key={item.id}
                    layoutId={`roadmap-item-${item.id}`}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.25, delay: Math.min(3, index) * 0.05 }}
                    className="p-5 bg-bg-card rounded-[24px] border border-accent-light shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-accent-light-hover group hover:-translate-y-0.5 transition-all relative overflow-hidden"
                  >
                    <div className="space-y-2 flex-1">
                      {/* Flex header */}
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-black/10 dark:bg-white/5 border border-accent-light text-ink-secondary">
                          {item.category}
                        </span>

                        <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full border ${statusBadge}`}>
                          {item.version ? `v${item.version}` : statusText}
                        </span>

                        {item.votes > 300 && (
                          <span className="text-[8px] font-black tracking-widest px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-0.5 animate-pulse">
                            <Flame size={9} className="fill-current" />
                            {isPt ? 'ALTA DEMANDA' : 'POPULAR'}
                          </span>
                        )}

                        {item.isUserAdded && (
                          <span className="text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-white/5">
                            {isPt ? 'Você Sugeriu' : 'Your Idea'}
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-black uppercase tracking-wide text-ink-primary group-hover:text-accent-blue transition-colors">
                        {isPt ? item.titlePt : item.titleEn}
                      </h4>

                      <p className="text-[11px] leading-relaxed text-ink-secondary opacity-80 max-w-2xl font-medium">
                        {isPt ? item.descPt : item.descEn}
                      </p>
                    </div>

                    {/* Voting engine right button block */}
                    <div className="flex items-center gap-3 shrink-0 self-end md:self-auto border-t border-accent-light/30 md:border-t-0 pt-3 md:pt-0">
                      <button
                        type="button"
                        onClick={(e) => handleVote(item.id, e)}
                        className={`px-4 py-2.5 rounded-[18px] text-[10px] font-black tracking-wider uppercase transition-all flex items-center gap-2 border select-none ${
                          isVoted
                            ? 'bg-emerald-500 text-white border-transparent shadow shadow-emerald-500/20 scale-[1.03]'
                            : 'bg-black/10 dark:bg-white/5 border-accent-light text-ink-secondary hover:text-ink-primary hover:bg-black/20 dark:hover:bg-white/10 active:scale-95'
                        }`}
                      >
                        <ThumbsUp size={11} className={isVoted ? 'fill-current animate-bounce' : ''} />
                        <span>{item.votes}</span>
                        {item.status !== 'completed' && (
                          <span className="text-[7px] font-bold opacity-60">
                            {isPt ? (isVoted ? 'APOIADO' : 'APOIAR') : (isVoted ? 'SUPPORTED' : 'SUPPORT')}
                          </span>
                        )}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </div>

      </div>
    </div>
  );
};
