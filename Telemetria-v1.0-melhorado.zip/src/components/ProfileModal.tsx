import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  User, 
  Camera, 
  Save, 
  ShieldCheck, 
  Trophy, 
  Flag, 
  Car,
  Pencil,
  LogOut,
  ChevronRight,
  ShieldAlert,
  Globe
} from 'lucide-react';
import { UserProfile as UserProfileType, DriverRating, SafetyRating, Entry as EntryType } from '../types';
import { supabaseService } from '../services/supabaseService';
import { supabase } from '../lib/supabase';
import { useLanguage } from '../contexts/LanguageContext';

interface ProfileModalProps {
  profile: UserProfileType | null;
  entries: EntryType[];
  onSave: (profile: Partial<UserProfileType>) => void;
  onClose: () => void;
  canClaimAdmin?: boolean;
}

const DRIVER_RATINGS: DriverRating[] = ['D', 'C', 'B', 'A', 'A+', 'S'];
const SAFETY_RATINGS: SafetyRating[] = ['E', 'D', 'C', 'B', 'A', 'S'];

export function ProfileModal({ profile, entries, onSave, onClose, canClaimAdmin }: ProfileModalProps) {
  const { language, t } = useLanguage();
  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [psnId, setPsnId] = useState(profile?.psn_id || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [driverRating, setDriverRating] = useState<DriverRating>(profile?.driver_rating || 'D');
  const [safetyRating, setSafetyRating] = useState<SafetyRating>(profile?.safety_rating || 'E');
  
  // Calculate stats directly from entries instead of using profile fields
  const calculatedTotalRaces = entries.length;
  const calculatedTotalWins = entries.filter(e => {
    const pos = e.racePosition?.toString().toLowerCase().trim();
    return pos === '1' || pos === '1º' || pos === '1°' || pos === '1st' || pos === '1 lugar' || pos === '1º lugar';
  }).length;
  
  const [avatarUrl, setAvatarUrl] = useState(profile?.avatar_url || '');
  const [isPublic, setIsPublic] = useState(profile?.is_public || false);
  const [showResults, setShowResults] = useState(profile?.show_results ?? true);
  const [showRanking, setShowRanking] = useState(profile?.show_ranking ?? true);
  const [showStats, setShowStats] = useState(profile?.show_stats ?? true);
  const [showPhoto, setShowPhoto] = useState(profile?.show_photo ?? true);
  const [showBio, setShowBio] = useState(profile?.show_bio ?? true);
  const [showPublicConfirm, setShowPublicConfirm] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [adminExists, setAdminExists] = useState<boolean | null>(null);
  const [isAdmin, setIsAdmin] = useState(profile?.is_admin || false);

  useEffect(() => {
    async function checkAdmin() {
      if (isAdmin) {
        setAdminExists(true);
        return;
      }
      const { count } = await supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('is_admin', true);
      setAdminExists(count ? count > 0 : false);
    }
    checkAdmin();
  }, [isAdmin]);

  const handleClaimAdmin = async () => {
    if (!profile) return;
    setIsSaving(true);
    try {
      const { error } = await supabase.from('profiles').update({ is_admin: true }).eq('id', profile.id);
      if (error) throw error;
      setIsAdmin(true);
      setAdminExists(true);
      await onSave({ is_admin: true });
    } catch (err) {
      console.error('Failed to claim admin', err);
      alert(language === 'pt' ? 'Não foi possível se tornar admin. Talvez já exista um.' : 'Could not become admin. Maybe one already exists.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert(language === 'pt' ? 'Por favor, selecione uma imagem válida.' : 'Please select a valid image.');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      alert(language === 'pt' ? 'O avatar deve ter no máximo 2MB.' : 'Avatar must be at most 2MB.');
      return;
    }

    setIsUploadingAvatar(true);
    try {
      const publicUrl = await supabaseService.uploadEvidenceImage(file);
      setAvatarUrl(publicUrl);
    } catch (error: any) {
      console.error('Erro no upload do avatar:', error);
      alert((language === 'pt' ? 'Erro ao enviar avatar: ' : 'Error uploading avatar: ') + (error.message || (language === 'pt' ? 'Erro desconhecido.' : 'Unknown error.')));
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const updatedProfile: Partial<UserProfileType> = {
        display_name: displayName,
        psn_id: psnId,
        bio: bio,
        driver_rating: driverRating,
        safety_rating: safetyRating,
        total_races: calculatedTotalRaces,
        total_wins: calculatedTotalWins,
        avatar_url: avatarUrl,
        is_public: isPublic,
        show_results: showResults,
        show_ranking: showRanking,
        show_stats: showStats,
        show_photo: showPhoto,
        show_bio: showBio
      };
      await onSave(updatedProfile);
    } catch (error) {
      console.error('Failed to save profile:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const winRate = calculatedTotalRaces > 0 ? ((calculatedTotalWins / calculatedTotalRaces) * 100).toFixed(1) : 0;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-bg-card w-full max-w-lg rounded-[32px] overflow-hidden border border-accent-light shadow-2xl flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-6 border-b border-accent-light flex items-center justify-between bg-gradient-to-r from-bg-card to-bg-app/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent-blue/10 rounded-xl text-accent-blue">
              <User size={20} />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight text-ink-primary">{t('driver_profile')}</h2>
              <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('synced_gt')}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-bg-app rounded-full text-ink-secondary transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8 scrollbar-hide">
          {/* Avatar & Basic Info */}
          <div className="flex flex-col items-center gap-6">
            <div className="relative group">
              <div className="w-32 h-32 rounded-3xl overflow-hidden border-2 border-accent-light bg-bg-cell shadow-xl group-hover:border-accent-blue transition-colors">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-ink-secondary/20">
                    <User size={64} />
                  </div>
                )}
              </div>
              <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploadingAvatar}
                className="absolute bottom-[-8px] right-[-8px] p-3 bg-accent-blue text-white rounded-2xl shadow-lg hover:scale-110 active:scale-95 transition-all disabled:opacity-50"
              >
                {isUploadingAvatar ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Camera size={18} />
                )}
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleAvatarUpload} 
                accept="image/*" 
                className="hidden" 
              />
            </div>
            
            <div className="w-full space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[8px] font-black uppercase tracking-widest text-ink-secondary ml-1">{t('display_name')}</label>
                  <input 
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    className="w-full bg-bg-cell border border-accent-light rounded-xl p-3 text-sm font-bold focus:border-accent-blue focus:outline-none transition-colors"
                    placeholder={t('your_name_placeholder')}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[8px] font-black uppercase tracking-widest text-ink-secondary ml-1">{t('psn_id_label')}</label>
                  <input 
                    value={psnId}
                    onChange={e => setPsnId(e.target.value)}
                    className="w-full bg-bg-cell border border-accent-light rounded-xl p-3 text-sm font-bold focus:border-accent-blue focus:outline-none transition-colors"
                    placeholder="e.g., Senna_1960"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-[8px] font-black uppercase tracking-widest text-ink-secondary ml-1">{t('bio_slogan')}</label>
                <textarea 
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  className="w-full bg-bg-cell border border-accent-light rounded-xl p-3 text-sm font-bold focus:border-accent-blue focus:outline-none transition-colors min-h-[80px] resize-none"
                  placeholder={t('tell_us_career')}
                />
              </div>
            </div>
          </div>

          {/* Ratings */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-widest text-ink-secondary ml-1 flex items-center gap-2">
              <ShieldCheck size={12} className="text-accent-blue" />
              {t('official_ratings')}
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-bg-cell p-4 rounded-2xl border border-accent-light">
                <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary mb-3">{t('driver_rating_label')}</p>
                <div className="flex gap-1">
                  {DRIVER_RATINGS.map(r => (
                    <button
                      key={r}
                      onClick={() => setDriverRating(r)}
                      className={`flex-1 h-8 rounded-lg text-[10px] font-black transition-all ${
                        driverRating === r 
                          ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20 scale-110 z-10' 
                          : 'bg-bg-card text-ink-secondary border border-accent-light opacity-50 hover:opacity-100'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              <div className="bg-bg-cell p-4 rounded-2xl border border-accent-light">
                <p className="text-[8px] font-black uppercase tracking-widest text-ink-secondary mb-3">{t('safety_rating_label')}</p>
                <div className="flex gap-1">
                  {SAFETY_RATINGS.map(r => (
                    <button
                      key={r}
                      onClick={() => setSafetyRating(r)}
                      className={`flex-1 h-8 rounded-lg text-[10px] font-black transition-all ${
                        safetyRating === r 
                          ? 'bg-accent-blue text-white shadow-lg shadow-accent-blue/20 scale-110 z-10' 
                          : 'bg-bg-card text-ink-secondary border border-accent-light opacity-50 hover:opacity-100'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="space-y-4">
            <label className="text-[10px] font-black uppercase tracking-widest text-ink-secondary ml-1 flex items-center gap-2">
              <Trophy size={12} className="text-yellow-500" />
              {t('career_statistics')}
            </label>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-bg-cell p-4 rounded-2xl border border-accent-light flex flex-col items-center justify-center text-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-1 opacity-20"><Flag size={24} /></div>
                <span className="text-xl font-black text-ink-primary z-10">{calculatedTotalRaces}</span>
                <span className="text-[7px] font-black uppercase tracking-widest text-ink-secondary z-10">{t('races_via_app')}</span>
              </div>
              <div className="bg-bg-cell p-4 rounded-2xl border border-accent-light flex flex-col items-center justify-center text-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-1 opacity-20"><Trophy size={24} /></div>
                <span className="text-xl font-black text-ink-primary z-10">{calculatedTotalWins}</span>
                <span className="text-[7px] font-black uppercase tracking-widest text-ink-secondary z-10">{t('wins_via_app')}</span>
              </div>
              <div className="bg-bg-cell p-4 rounded-2xl border border-accent-light flex flex-col items-center justify-center text-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-1 opacity-20"><ShieldCheck size={24} /></div>
                <span className="text-xl font-black text-ink-primary z-10">{winRate}%</span>
                <span className="text-[7px] font-black uppercase tracking-widest text-ink-secondary z-10">{t('win_rate')}</span>
              </div>
            </div>
          </div>

          {/* Admin section */}
          <div className="pt-4 border-t border-accent-light space-y-3">
            {isAdmin ? (
               <div className="p-4 rounded-2xl bg-accent-blue/10 border border-accent-blue/20 flex flex-col items-center justify-center text-center">
                 <ShieldAlert size={24} className="text-accent-blue mb-2" />
                 <h4 className="text-xs font-black text-accent-blue uppercase tracking-tight">{t('administrator')}</h4>
                 <p className="text-[10px] font-bold text-ink-secondary opacity-80 mt-1 uppercase">{t('only_admin_desc')}</p>
               </div>
            ) : (adminExists === false && canClaimAdmin) ? (
              <button 
                onClick={handleClaimAdmin}
                className="w-full p-4 rounded-2xl bg-accent-blue/5 hover:bg-accent-blue/10 text-accent-blue border border-accent-blue/20 flex flex-col items-center justify-center gap-2 group transition-all"
              >
                <div className="flex items-center gap-2">
                  <ShieldAlert size={18} />
                  <span className="text-xs font-black uppercase tracking-widest">{t('become_administrator')}</span>
                </div>
                <span className="text-[9px] font-bold opacity-70 uppercase tracking-tight">{t('first_to_click_desc')}</span>
              </button>
            ) : null}
            
            <button 
              onClick={() => supabase.auth.signOut()}
              className="w-full p-4 rounded-2xl bg-red-500/5 hover:bg-red-500/10 text-red-500 border border-red-500/10 flex items-center justify-between group transition-all"
            >
               <div className="flex items-center gap-3">
                 <LogOut size={20} />
                 <span className="text-xs font-black uppercase tracking-widest">{t('sign_out')}</span>
               </div>
               <ChevronRight size={16} className="opacity-30 group-hover:translate-x-1 transition-transform" />
             </button>
           </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-bg-cell border-t border-accent-light">
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="w-full bg-accent-blue text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-accent-blue/20 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {isSaving ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Save size={18} />
                {t('save_profile')}
              </>
            )}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
