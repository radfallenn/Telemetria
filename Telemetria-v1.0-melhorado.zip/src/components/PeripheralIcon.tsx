import React from 'react';
import { Gamepad2 } from 'lucide-react';

export function PeripheralIcon({ peripheral, size = 12, className = '' }: { peripheral?: string | null, size?: number, className?: string }) {
  if (!peripheral) return null;
  const lower = peripheral.toLowerCase();
  
  if (lower.includes('control')) {
    return <Gamepad2 size={size} className={className} />;
  }
  
  if (lower.includes('wheel') || lower.includes('volante')) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 14c-1.5 0-2.5-1-2.5-1l-3.5 2"/>
        <path d="M12 14c1.5 0 2.5-1 2.5-1l3.5 2"/>
        <path d="M12 14v8"/>
        <path d="M4 10h16"/>
        <circle cx="12" cy="12" r="2"/>
      </svg>
    );
  }
  
  return null;
}
