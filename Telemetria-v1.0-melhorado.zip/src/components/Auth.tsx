import React, { useState } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { motion, AnimatePresence } from 'motion/react';
import { User, Lock, LogIn, UserPlus, Info, CheckCircle2, ChevronRight, AlertCircle, Eye, EyeOff, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { supabaseService } from '../services/supabaseService';

export function Auth({ onAuthSuccess, onOfflineMode, onClose }: { onAuthSuccess: () => void, onOfflineMode?: () => void, onClose?: () => void }) {
  const { t, language } = useLanguage();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [consent, setConsent] = useState(false);
  const [message, setMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const formatEmail = (val: string) => {
    if (val.includes('@')) return val;
    return `${val.trim().toLowerCase().replace(/[^a-z0-9_]/g, '')}@gtrace.app`;
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    
    if (!isSupabaseConfigured) {
      setMessage({ type: 'error', text: t('supabase_not_configured') });
      setLoading(false);
      return;
    }

    if (isSignUp && !consent) {
      setMessage({ type: 'error', text: language === 'pt' ? 'Você deve aceitar os termos de consentimento para criar uma conta.' : 'You must accept the consent terms to create an account.' });
      setLoading(false);
      return;
    }

    const email = formatEmail(identifier);

    try {
      if (isSignUp) {
        const emailLower = email.toLowerCase();
        if (emailLower !== 'rad.endbringer@gmail.com') {
          setMessage({
            type: 'error',
            text: language === 'pt' 
              ? 'A criação de novas contas foi desativada no momento. Apenas o administrador possui permissão.' 
              : 'New account registrations have been disabled. Only the administrator is allowed.'
          });
          setLoading(false);
          return;
        }

        const { error, data } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
        
        // After signup we set up initial profile visibility and display_name
        if (data.session) {
          if (!identifier.includes('@')) {
            await supabaseService.saveProfile({ display_name: identifier.trim(), is_public: true });
          }
          onAuthSuccess();
        } else {
          // Attempt silent sign-in
          const { error: signInError, data: signInData } = await supabase.auth.signInWithPassword({
            email,
            password,
          });

          if (!signInError && signInData.session) {
            if (!identifier.includes('@')) {
               await supabaseService.saveProfile({ display_name: identifier.trim(), is_public: true });
            }
            onAuthSuccess();
          } else {
            console.error('Auto login after signup failed:', signInError);
            const errMsg = signInError?.message?.toLowerCase() || '';
            
            if (errMsg.includes('invalid login') || errMsg.includes('invalid credentials')) {
              setMessage({
                type: 'error',
                text: t('invalid_credentials')
              });
              setIsSignUp(false);
            } else if (errMsg.includes('email not confirmed')) {
              setMessage({
                type: 'error',
                text: t('email_not_confirmed')
              });
            } else {
              setMessage({
                type: 'error',
                text: `${t('account_created_login_failed')} (${signInError?.message || 'Unknown error'}).`
              });
            }
          }
        }
      } else {
        const { data: signInData, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;

        // Check if the current user is admin in 'profiles'
        if (signInData.user) {
          const { data: profile, error: profileErr } = await supabase
            .from('profiles')
            .select('is_admin')
            .eq('id', signInData.user.id)
            .single();

          if (profileErr || !profile || profile.is_admin !== true) {
            // Sign out immediately
            await supabase.auth.signOut();
            setMessage({
              type: 'error',
              text: language === 'pt'
                ? 'Novos logins estão bloqueados temporariamente, exceto para o administrador.'
                : 'Logins are temporarily restricted to administrators only.'
            });
            setLoading(false);
            return;
          }
        }

        onAuthSuccess();
      }
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.toLowerCase().includes('fetch')) {
        setMessage({ 
          type: 'error', 
          text: t('fetch_error')
        });
      } else {
        setMessage({ 
          type: 'error', 
          text: msg.includes('disabled') 
            ? t('email_disabled_error')
            : msg || t('auth_error')
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg-app p-4 overflow-hidden relative">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none select-none overflow-hidden">
        <h1 className="text-[20vw] font-black leading-none -rotate-12 translate-x-[-10%] translate-y-[20%]">GT7</h1>
        <h1 className="text-[15vw] font-black leading-none -rotate-12 translate-x-[40%] translate-y-[-10%]">TRACKS</h1>
      </div>

      <AnimatePresence mode="wait">
          <motion.div 
            key="auth-form"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            className="w-full max-w-sm bg-bg-card p-8 rounded-[40px] shadow-2xl border border-accent-light relative z-10"
          >
            {onClose && (
              <button 
                onClick={onClose}
                className="absolute top-4 right-4 p-2 text-ink-secondary hover:text-ink-primary transition-colors"
                aria-label="Close"
              >
                <X size={20} />
              </button>
            )}
            <div className="mb-10 text-center">
              <div className="inline-flex p-3 bg-accent-blue/10 rounded-2xl text-accent-blue mb-4">
                {isSignUp ? <UserPlus size={28} /> : <LogIn size={28} />}
              </div>
              <h1 className="font-black text-2xl text-ink-primary uppercase tracking-tight">
                {isSignUp ? t('create_driver_account') : t('paddock_access')}
              </h1>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-ink-secondary mt-1 opacity-50">
                {t('paddock_desc')}
              </p>
            </div>

            {message && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className={`mb-6 p-4 rounded-2xl flex gap-3 items-start border ${
                  message.type === 'error' ? 'bg-red-500/5 border-red-500/20 text-red-500' : 'bg-emerald-500/5 border-emerald-500/20 text-emerald-500'
                }`}
              >
                {message.type === 'error' ? <AlertCircle size={18} className="shrink-0" /> : <CheckCircle2 size={18} className="shrink-0" />}
                <p className="text-[11px] font-bold leading-tight">{message.text}</p>
              </motion.div>
            )}

            <form onSubmit={handleAuth} className="space-y-5">
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1 flex items-center gap-1.5">
                  <User size={10} /> {isSignUp ? 'Nick' : 'Nick ou E-mail'}
                </label>
                <input
                  type={isSignUp ? "text" : "text"}
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full bg-bg-cell border border-accent-light rounded-2xl px-5 py-4 text-sm font-bold focus:outline-none focus:border-accent-blue transition-all"
                  placeholder={isSignUp ? "Seu Nickname" : "Nickname ou E-mail"}
                  required
                />
              </div>
              
              <div className="space-y-1.5">
                <label className="text-[9px] uppercase font-black tracking-widest text-ink-secondary ml-1 flex items-center gap-1.5">
                  <Lock size={10} /> {t('password_label')}
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-bg-cell border border-accent-light rounded-2xl px-5 py-4 text-sm font-bold focus:outline-none focus:border-accent-blue transition-all"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-secondary hover:text-accent-blue transition-colors focus:outline-none"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {isSignUp && (
                <div className="flex items-start gap-3 mt-4 p-3 bg-bg-cell rounded-2xl border border-accent-light">
                  <div className="mt-0.5">
                    <input 
                      type="checkbox" 
                      id="consentCheck"
                      checked={consent}
                      onChange={(e) => setConsent(e.target.checked)}
                      className="w-4 h-4 rounded border-accent-light text-accent-blue focus:ring-accent-blue focus:ring-offset-bg-card bg-bg-app"
                    />
                  </div>
                  <label htmlFor="consentCheck" className="text-[10px] text-ink-secondary leading-snug cursor-pointer font-medium">
                    {language === 'pt' ? (
                      <><strong>Termo de Consentimento:</strong> Compreendo que todo o conteúdo das corridas ficará visível para todos os cadastrados na aba Comunidade. Nenhum dado sensível ou pessoal será exposto.</>
                    ) : (
                      <><strong>Consent Terms:</strong> I understand that all race content will be visible to all registered users on the Community tab. No sensitive or personal data will be exposed.</>
                    )}
                  </label>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-6 bg-accent-blue text-white font-black py-5 rounded-2xl shadow-lg shadow-accent-blue/20 active:scale-[0.98] transition-all uppercase tracking-[0.2em] text-[10px] disabled:opacity-50 flex items-center justify-center gap-2 group"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    {isSignUp ? t('confirm_registration') : t('sign_in')}
                    <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-8 flex flex-col items-center gap-4">
              <button 
                onClick={() => {
                  setIsSignUp(!isSignUp);
                  setMessage(null);
                }}
                className="text-[10px] font-black text-ink-secondary hover:text-accent-blue transition-colors uppercase tracking-widest"
              >
                {isSignUp ? t('already_have_account') : t('no_account_signup')}
              </button>
              
              <div className="flex items-center gap-1.5 opacity-30 mt-2 text-center">
                <Info size={12} className="shrink-0" />
                <span className="text-[8px] font-bold uppercase tracking-tighter">{t('encrypted_data_desc')}</span>
              </div>
            </div>
          </motion.div>
      </AnimatePresence>
    </div>
  );
}
