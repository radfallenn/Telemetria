import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Search, 
  ArrowRight, 
  Trophy, 
  Flag, 
  Globe,
  User,
  ShieldCheck,
  ChevronRight,
  Filter,
  X
} from 'lucide-react';
import { UserProfile } from '../types';
import { supabaseService } from '../services/supabaseService';
import { useLanguage } from '../contexts/LanguageContext';

interface UserHubProps {
  onSelectUser: (userId: string) => void;
  onClose: () => void;
}

export function UserHub({ onSelectUser, onClose }: UserHubProps) {
  const { t } = useLanguage();
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async (query?: string) => {
    setIsLoading(true);
    try {
      const data = await supabaseService.getPublicHubProfiles(query);
      setProfiles(data);
    } catch (error) {
      console.error('Error in Hub:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchProfiles(searchQuery);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-bg-card w-full max-w-5xl h-full sm:h-[90vh] sm:rounded-[32px] border border-accent-light shadow-2xl flex flex-col rgb-border-effect"
      >
        {/* Header */}
        <div className="p-6 border-b border-accent-light flex items-center justify-between bg-gradient-to-r from-bg-card to-bg-app/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent-blue/10 rounded-xl text-accent-blue">
              <Users size={20} />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight text-ink-primary">{t('drivers_hub')}</h2>
              <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('discover_follow_community')}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-bg-app rounded-full text-ink-secondary transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search & Filters */}
        <div className="p-6 bg-bg-app/30 border-b border-accent-light">
          <form onSubmit={handleSearch} className="flex gap-3">
             <div className="flex-1 relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-secondary/50 group-focus-within:text-accent-blue transition-colors" size={18} />
                <input 
                  type="text"
                  placeholder={t('search_hub_placeholder')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-bg-cell border border-accent-light rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:outline-none focus:border-accent-blue transition-all"
                />
             </div>
             <button 
               type="submit"
               className="px-6 bg-accent-blue text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-lg shadow-accent-blue/20"
              >
                {t('search')}
              </button>
          </form>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 scrollbar-hide">
          {isLoading ? (
            <div className="h-full flex items-center justify-center">
              <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 border-4 border-accent-blue/20 border-t-accent-blue rounded-full animate-spin" />
                <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary">{t('syncing_cloud')}</p>
              </div>
            </div>
          ) : profiles.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 space-y-4">
               <div className="p-6 bg-bg-app rounded-full text-ink-secondary/20">
                  <Search size={64} />
               </div>
               <div>
                  <h3 className="text-xl font-black uppercase tracking-tight text-ink-primary">{t('no_drivers_found')}</h3>
                  <p className="text-sm font-bold text-ink-secondary opacity-60 uppercase mt-2">{t('try_searching_terms')}</p>
               </div>
               <button 
                 onClick={() => fetchProfiles()}
                 className="text-accent-blue font-black text-xs uppercase tracking-widest"
               >
                 {t('see_all_drivers')}
               </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {profiles.map((profile, index) => (
                <motion.div
                  key={`${profile.id || 'profile'}-${index}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => onSelectUser(profile.id)}
                  className="group relative bg-bg-cell border border-accent-light rounded-3xl p-6 cursor-pointer hover:border-accent-blue/50 hover:shadow-2xl hover:shadow-accent-blue/5 transition-all rgb-border-effect"
                >
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-accent-light group-hover:border-accent-blue transition-all">
                        {profile.avatar_url ? (
                          <img src={profile.avatar_url} alt={profile.display_name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-bg-app text-ink-secondary/30">
                            <User size={32} />
                          </div>
                        )}
                      </div>
                      <div className="absolute -bottom-1 -right-1 p-1 bg-accent-blue text-white rounded-lg shadow-lg">
                        <ShieldCheck size={10} />
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-black uppercase tracking-tight text-ink-primary truncate">
                        {profile.display_name}
                      </h3>
                      <p className="text-[10px] font-bold text-accent-blue truncate">
                        @{profile.psn_id || 'no_psn'}
                      </p>
                      <div className="flex gap-1 mt-2">
                         <div className="px-2 py-0.5 bg-bg-app rounded text-[8px] font-black uppercase text-ink-secondary">
                           DR {profile.driver_rating || 'D'}
                         </div>
                         <div className="px-2 py-0.5 bg-bg-app rounded text-[8px] font-black uppercase text-ink-secondary">
                           SR {profile.safety_rating || 'E'}
                         </div>
                      </div>
                    </div>
                  </div>

                  {profile.bio && (
                    <p className="mt-4 text-[10px] font-bold text-ink-secondary line-clamp-2 uppercase leading-relaxed opacity-60">
                      {profile.bio}
                    </p>
                  )}

                  <div className="mt-6 pt-4 border-t border-accent-light/50 flex items-center justify-between">
                    <div className="flex gap-4">
                      <>
                           <div className="flex flex-col">
                              <span className="text-[14px] font-black text-ink-primary">{profile.total_races || 0}</span>
                              <span className="text-[6px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('races')}</span>
                           </div>
                           <div className="flex flex-col">
                              <span className="text-[14px] font-black text-ink-primary">{profile.total_wins || 0}</span>
                              <span className="text-[6px] font-black uppercase tracking-widest text-ink-secondary opacity-50">{t('wins')}</span>
                           </div>
                         </>
                    </div>
                    <div className="p-2 bg-bg-app rounded-xl text-ink-secondary group-hover:bg-accent-blue group-hover:text-white transition-all">
                      <ChevronRight size={16} />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-bg-cell border-t border-accent-light flex items-center justify-center">
            <p className="text-[9px] font-black uppercase tracking-widest text-ink-secondary opacity-40">
              {t('showing_public_only')} {profiles.length > 0 && `• ${profiles.length} ${t('active_drivers_count')}`}
            </p>
        </div>
      </motion.div>
    </motion.div>
  );
}
