import React, { useRef, useState } from 'react';
import { Upload, ImageIcon, CheckCircle, XCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { convertToWebP } from '../lib/imageUtils';
import { getTrackSlug } from '../App';
import { Track } from '../types';

interface TrackImagesTabProps {
  tracks: Track[];
  onUpdateTrack: (id: string, updates: any) => Promise<void>;
}

export function TrackImagesTab({ tracks, onUpdateTrack }: TrackImagesTabProps) {
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logs, setLogs] = useState<{name: string, status: 'success' | 'error' | 'loading' | 'unmatched', message: string}[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const normalizeName = (name: string) => {
    return name.toLowerCase().replace(/[-_]/g, ' ').trim();
  };

  const handleFilesSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessing(true);
    const newLogs: typeof logs = [];
    setLogs([]);

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const rawFileName = file.name.split('.')[0];
        const normalizedInput = normalizeName(rawFileName);
        
        // Find matching track
        const matchedTrack = tracks.find(t => {
            const trackNorm = normalizeName(t.name);
            const slug = getTrackSlug(t).replace(/_/g, ' ');
            return trackNorm === normalizedInput || slug === normalizedInput || trackNorm.includes(normalizedInput) || normalizedInput.includes(trackNorm);
        });

        if (!matchedTrack) {
            newLogs.push({ name: rawFileName, status: 'unmatched', message: 'Nenhuma pista correspondente encontrada.' });
            setLogs([...newLogs]);
            continue;
        }

        try {
            newLogs.push({ name: rawFileName, status: 'loading', message: `Processando ${matchedTrack.name}...` });
            setLogs([...newLogs]);
            
            const webpData = await convertToWebP(file);
            await onUpdateTrack(matchedTrack.id, { customBackground: webpData });
            
            const logIdx = newLogs.findIndex(l => l.name === rawFileName);
            if(logIdx !== -1) {
               newLogs[logIdx] = { name: rawFileName, status: 'success', message: `Background de ${matchedTrack.name} atualizado.` };
               setLogs([...newLogs]);
            }
        } catch (err) {
            const logIdx = newLogs.findIndex(l => l.name === rawFileName);
            if(logIdx !== -1) {
               newLogs[logIdx] = { name: rawFileName, status: 'error', message: `Erro: ${(err as Error).message}` };
               setLogs([...newLogs]);
            }
        }
    }

    setIsProcessing(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-4">
      <div className="bg-bg-cell rounded-[24px] p-6 border border-accent-light flex flex-col items-center justify-center text-center space-y-4 shadow-sm">
        <div className="w-16 h-16 rounded-2xl bg-accent-blue/10 flex items-center justify-center text-accent-blue">
            <ImageIcon size={32} />
        </div>
        <div>
            <h4 className="font-bold text-ink-primary text-base">Salvar em Massa (Cenas / Fundos)</h4>
            <p className="text-[11px] text-ink-secondary mt-1 max-w-sm">
            Selecione várias imagens. O nome do arquivo será usado para tentar encontrar a pista correspondente (ex: "Sardegna Road Track.jpg").
            </p>
        </div>
        <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFilesSelect} 
            accept="image/*" 
            multiple 
            className="hidden" 
        />
        <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessing}
            className={`w-full max-w-xs p-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg ${isProcessing ? 'bg-accent-light/50 text-ink-secondary cursor-not-allowed' : 'bg-accent-blue text-white shadow-accent-blue/20 hover:scale-[1.02] active:scale-[0.98]'}`}
        >
            {isProcessing ? (
                <span className="animate-pulse">Processando...</span>
            ) : (
                <>
                    <Upload size={16} /> 
                    <span>Selecionar Imagens</span>
                </>
            )}
        </button>
      </div>

      {logs.length > 0 && (
          <div className="bg-bg-card rounded-[22px] border border-accent-light p-4 space-y-2">
              <h5 className="text-[10px] font-black uppercase tracking-widest text-ink-secondary ml-1 mb-3">Logs de Processamento</h5>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
                  {logs.map((log, idx) => (
                      <div key={idx} className="flex items-start gap-3 bg-bg-cell p-3 rounded-xl border border-accent-light/50">
                          {log.status === 'success' && <CheckCircle size={16} className="text-success mt-0.5" />}
                          {log.status === 'error' && <XCircle size={16} className="text-red-500 mt-0.5" />}
                          {log.status === 'unmatched' && <XCircle size={16} className="text-orange-400 mt-0.5" />}
                          {log.status === 'loading' && <Upload size={16} className="text-accent-blue animate-bounce mt-0.5" />}
                          <div className="flex flex-col flex-1 min-w-0">
                              <span className="text-xs font-bold text-ink-primary truncate">{log.name}</span>
                              <span className={`text-[10px] uppercase font-bold tracking-wider mt-0.5 ${log.status === 'success' ? 'text-success/70' : log.status === 'error' ? 'text-red-400' : log.status === 'unmatched' ? 'text-orange-400/80' : 'text-accent-blue/70'}`}>
                                  {log.message}
                              </span>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}
    </div>
  );
}
