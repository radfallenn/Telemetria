import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trophy, MapPin, Car, Camera, User, Image as ImageIcon, Clock, ChevronLeft } from 'lucide-react';
import { supabaseService } from '../services/supabaseService';
import { getBrandLogo } from '../services/gt7Database';
import { getLogoUrl } from '../lib/utils';
import { INITIAL_TRACKS } from '../constants';
import { Entry, UserProfile, LogoBrand } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { PeripheralIcon } from './PeripheralIcon';

interface PublicProfileViewProps {
  userId: string;
  logoOverrides?: Record<string, string>;
  logosDatabase?: LogoBrand[];
}

const normalizeBrandNameHelper = (name: string) => 
  name.toLowerCase().replace(/\s+/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, "");

const getLogoFromLocalBank = (name: string, logosDatabase: LogoBrand[] = []) => {
  const slug = normalizeBrandNameHelper(name);
  const found = logosDatabase.find(l => l.brand_slug === slug);
  return found ? found.logo_data : null;
};

const resolveLogoLocal = (carName: string, carBrand: string, logoOverrides: Record<string, string> = {}, logosDatabase: LogoBrand[] = []) => {
  return logoOverrides[carName] || 
         logoOverrides[carBrand] || 
         getLogoFromLocalBank(carName, logosDatabase) || 
         getLogoFromLocalBank(carBrand, logosDatabase) || 
         getBrandLogo(carBrand);
};

export const PublicProfileView: React.FC<PublicProfileViewProps> = ({ userId, logoOverrides = {}, logosDatabase = [] }) => {
  const { language, t } = useLanguage();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEntry, setSelectedEntry] = useState<Entry | null>(null);
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null);

  const groupedEntries = useMemo(() => {
    const groups: Record<string, { track: any, entries: Entry[] }> = {};
    entries.forEach(entry => {
      let track = (entry as any).tracks;
      
      // Fallback para pistas iniciais se não encontrada no banco do usuário
      if (!track && entry.trackId) {
        track = INITIAL_TRACKS.find(t => String(t.id).toLowerCase() === String(entry.trackId).toLowerCase());
      }

      const trackId = track?.id || entry.trackId || 'unknown';
      if (!groups[trackId]) {
        groups[trackId] = { track, entries: [] };
      }
      groups[trackId].entries.push(entry);
    });
    return Object.values(groups).sort((a, b) => 
      (a.track?.name || '').localeCompare(b.track?.name || '')
    );
  }, [entries]);

  const currentTrackEntries = useMemo(() => {
    if (!selectedTrackId) return [];
    return entries.filter(e => {
       let track = (e as any).tracks;
       if (!track && e.trackId) {
         track = INITIAL_TRACKS.find(t => String(t.id).toLowerCase() === String(e.trackId).toLowerCase());
       }
       const id = track?.id || e.trackId || 'unknown';
       return id === selectedTrackId;
    });
  }, [entries, selectedTrackId]);

  const selectedTrackName = useMemo(() => {
    if (!selectedTrackId) return '';
    const group = groupedEntries.find(g => g.track?.id === selectedTrackId);
    return group?.track?.name || t('unknown_circuit');
  }, [groupedEntries, selectedTrackId]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const prof = await supabaseService.getPublicProfile(userId);
        setProfile(prof);

        if (prof) {
          const data = await supabaseService.getPublicEntries(userId);
          setEntries(data as any);
        }
      } catch (error) {
        console.error('Error fetching public profile:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [userId]);

  if (loading) {
    return (
      <div className="py-20 flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-4 border-accent-light border-t-accent-blue animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-12 text-center">
        <User size={48} className="mx-auto mb-4 text-ink-secondary/30" />
        <h3 className="text-xl font-bold text-ink-primary mb-2">{t('profile_unavailable')}</h3>
        <p className="text-sm font-medium text-ink-secondary mb-6">{t('profile_unavailable_desc')}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col relative">
         {/* Profile Header */}
         <div className="p-6 bg-accent-blue/5 border-b border-accent-light/30 flex flex-col sm:flex-row items-center gap-6">
            <div className="w-20 h-20 rounded-full bg-bg-card border-4 border-accent-light/50 flex items-center justify-center overflow-hidden shrink-0 shadow-sm">
               {profile.avatar_url ? (
                 <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
               ) : (
                 <User size={32} className="text-ink-secondary" />
               )}
            </div>
            <div className="text-center sm:text-left flex-1">
               <h2 className="text-2xl font-black uppercase tracking-tighter text-ink-primary">{profile.display_name}</h2>
               {profile.psn_id && (
                 <p className="font-bold text-accent-blue text-xs uppercase tracking-widest mt-0.5">PSN: {profile.psn_id}</p>
               )}
               {profile.bio && (
                 <p className="text-[9px] font-bold text-ink-secondary uppercase mt-2 max-w-md italic opacity-60 leading-relaxed line-clamp-2">{profile.bio}</p>
               )}
               <div className="flex items-center justify-center sm:justify-start gap-4 mt-3">
                 {profile.driver_rating && (
                   <span className="px-2.5 py-1 bg-bg-app rounded-lg text-[10px] font-black uppercase tracking-wider text-ink-primary border border-accent-light/50">
                     DR: {profile.driver_rating}
                   </span>
                 )}
                 {profile.safety_rating && (
                   <span className="px-2.5 py-1 bg-bg-app rounded-lg text-[10px] font-black uppercase tracking-wider text-ink-primary border border-accent-light/50">
                     SR: {profile.safety_rating}
                   </span>
                 )}
               </div>
            </div>
         </div>

         {/* Entries / Tracks Section */}
         <div className="p-6 bg-bg-app">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold uppercase tracking-wider text-ink-secondary text-[10px]">
                {selectedTrackId ? `${t('times_at')} ${selectedTrackName}` : `${t('tracks_ridden')} (${groupedEntries.length})`}
              </h3>
              {selectedTrackId && (
                <button 
                  onClick={() => setSelectedTrackId(null)}
                  className="text-[9px] font-black uppercase text-accent-blue tracking-widest hover:underline"
                >
                  {t('back_to_tracks')}
                </button>
              )}
            </div>
            
            {entries.length === 0 ? (
              <div className="py-12 px-6 text-center border-2 border-dashed border-accent-light/50 rounded-3xl flex flex-col items-center gap-4">
                <div className="p-4 bg-accent-blue/5 rounded-full text-accent-blue">
                   <Clock size={32} />
                </div>
                <div>
                  <p className="text-sm font-black text-ink-primary uppercase italic mb-1">{t('no_times_recorded')}</p>
                  <p className="text-[10px] font-bold text-ink-secondary uppercase leading-relaxed max-w-xs mx-auto">
                    {t('no_times_desc')}
                  </p>
                </div>
              </div>
            ) : !selectedTrackId ? (
              /* Tracks View */
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-2">
                {groupedEntries.map(({ track, entries: trackEntries }, index) => {
                  const trackKey = track?.id || trackEntries[0]?.trackId || `track_${index}`;
                  return (
                    <button 
                      key={`${trackKey}-${index}`} 
                      onClick={() => setSelectedTrackId(trackKey)}
                      className="p-4 rounded-2xl bg-bg-cell border border-accent-light flex items-center justify-between hover:border-accent-blue transition-all text-left shadow-sm group rgb-border-effect"
                    >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <MapPin size={10} className="text-accent-blue" />
                        <span className="text-[9px] font-black uppercase tracking-[0.15em] text-accent-blue/60">
                          {track?.location || 'World'}
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-ink-primary truncate">
                        {track?.name || t('unknown_circuit')}
                      </h4>
                      <p className="text-[10px] font-bold text-ink-secondary opacity-60 uppercase mt-1">
                        {trackEntries.length} {trackEntries.length === 1 ? t('record_count') : t('records_count')}
                      </p>
                    </div>
                    <div className="p-2 rounded-xl bg-accent-blue/5 text-accent-blue group-hover:bg-accent-blue group-hover:text-white transition-all">
                       <ChevronLeft className="rotate-180" size={14} />
                    </div>
                  </button>
                );
                })}
              </div>
            ) : (
              /* Entries View for Selected Track */
              <div className="grid gap-3">
                {currentTrackEntries.map((entry, entryIndex) => (
                  <div 
                    key={`${entry.id}-${entryIndex}`} 
                    onClick={() => setSelectedEntry(entry)}
                    className="p-4 rounded-2xl bg-bg-cell border border-accent-light flex flex-col sm:flex-row items-center justify-between gap-4 cursor-pointer hover:border-accent-blue/50 transition-all shadow-sm"
                  >
                     <div className="min-w-0 flex-1">
                       <h4 className="font-bold text-sm text-ink-primary truncate">
                         {entry.carBrand} {entry.carName}
                       </h4>
                       <p className="text-[10px] uppercase font-bold text-ink-secondary mt-1 tracking-wider opacity-60">
                         {t('date')}: {new Date(entry.runDate).toLocaleDateString()}
                       </p>
                       <div className="flex items-center gap-2 mt-2">
                         <span className="px-1.5 py-0.5 bg-accent-blue/10 text-accent-blue text-[8px] font-black uppercase rounded">
                           {entry.carSetup}
                         </span>
                         {entry.weather && (
                           <span className="text-[8px] font-bold text-ink-secondary opacity-60 uppercase">
                             {t('weather')}: {entry.weather}
                           </span>
                         )}
                       </div>
                     </div>
                     <div className="text-right whitespace-nowrap">
                       <div className="text-2xl font-black italic text-accent-blue font-mono flex items-center justify-end gap-2">
                         {entry.lapTime}
                         <PeripheralIcon peripheral={entry.peripheral} size={20} className="opacity-80 pb-1" />
                       </div>
                       {entry.evidence_image && (
                         <div className="flex items-center gap-1 justify-end text-[10px] font-bold text-accent-blue/60 mt-1 uppercase">
                           <Camera size={12} /> {t('evidence')}
                         </div>
                       )}
                     </div>
                  </div>
                ))}
              </div>
            )}
         </div>

         {/* Entry Detail Overlay */}
         <AnimatePresence>
           {selectedEntry && (
             <motion.div
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               exit={{ opacity: 0, scale: 0.95 }}
               className="fixed inset-0 z-[110] bg-black/90 flex flex-col p-4 sm:p-8"
             >
                <div className="w-full max-w-5xl mx-auto flex flex-col h-full bg-bg-app rounded-[40px] overflow-hidden border border-white/10 shadow-2xl relative">
                   <div className="p-6 flex items-center justify-between border-b border-accent-light/30 bg-bg-card">
                    <h3 className="text-xl font-black text-ink-primary italic uppercase">{t('lap_details')}</h3>
                    <button onClick={() => setSelectedEntry(null)} className="p-2 rounded-full border border-accent-light text-ink-secondary hover:text-ink-primary transition-colors">
                      <X size={24} />
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto p-6 bg-bg-app scrollbar-hide">
                    <div className="flex flex-col lg:flex-row gap-8">
                      {/* Evidence Image */}
                      <div className="flex-1 rounded-[32px] overflow-hidden bg-black/5 border border-accent-light flex items-center justify-center min-h-[300px]">
                        {selectedEntry.evidence_image ? (
                          <img src={selectedEntry.evidence_image} alt="" className="w-full h-full object-contain" />
                        ) : (
                          <div className="text-center opacity-10">
                            <ImageIcon size={64} className="mx-auto mb-4 text-ink-primary" />
                            <p className="text-lg font-black uppercase tracking-widest text-ink-primary italic">{t('no_evidence')}</p>
                          </div>
                        )}
                      </div>

                      {/* Stats */}
                      <div className="w-full lg:w-96 shrink-0 space-y-4">
                         <div className="bg-bg-card rounded-[32px] p-6 shadow-xl border border-accent-light">
                            <div className="flex items-center gap-4">
                               <div className="w-16 h-16 rounded-2xl bg-bg-app border border-accent-light flex items-center justify-center p-2 shrink-0">
                                 {(() => {
                                   const logoFile = resolveLogoLocal(selectedEntry.carName, selectedEntry.carBrand, logoOverrides, logosDatabase);
                                   const logoUrl = getLogoUrl(logoFile);
                                   return logoUrl ? (
                                     <img 
                                       src={logoUrl} 
                                       alt={selectedEntry.carBrand} 
                                       className="max-w-full max-h-full object-contain"
                                       referrerPolicy="no-referrer"
                                     />
                                   ) : (
                                     <Car className="text-accent-blue" size={32} />
                                   );
                                 })()}
                               </div>
                               <div className="min-w-0">
                                 {(selectedEntry as any).tracks?.name && (
                                   <div className="text-[7px] font-black text-accent-blue uppercase tracking-[0.2em] mb-1 opacity-60 leading-none">
                                     {(selectedEntry as any).tracks.name}
                                   </div>
                                 )}
                                 <p className="text-[10px] font-black uppercase tracking-widest text-ink-secondary/60 leading-none mb-1">
                                    {selectedEntry.carBrand}
                                 </p>
                                 <h4 className="text-xl font-black text-ink-primary leading-tight">
                                    {selectedEntry.carName}
                                 </h4>
                               </div>
                            </div>
                         </div>

                         <div className="grid grid-cols-2 gap-2">
                            <StatBox label={t('position')} value={`${selectedEntry.racePosition} ${t('place')}`} />
                            <StatBox label={t('laps')} value={selectedEntry.laps || '1'} />
                         </div>

                         <div className="grid grid-cols-2 gap-2">
                            <StatBox label={t('fastest_lap')} value={selectedEntry.lapTime} highlight />
                            <StatBox label={t('total')} value={selectedEntry.totalTime || '-'} highlight />
                         </div>

                         <div className="grid grid-cols-3 gap-2">
                            <StatBox label={t('pits')} value={selectedEntry.pitStops} />
                            <StatBox label={t('setup')} value={selectedEntry.carSetup || '-'} />
                            <StatBox label={t('traction_control')} value={`TC:${selectedEntry.tractionControl}`} />
                         </div>

                         <div className="grid grid-cols-2 gap-2">
                            <StatBox label={t('weather')} value={selectedEntry.weather} />
                            <StatBox label={t('transmission')} value={selectedEntry.transmission || '-'} />
                         </div>

                         <div className="bg-bg-card rounded-[24px] p-4 border border-accent-light shadow-sm">
                            <p className="text-[9px] font-black uppercase tracking-widest text-ink-secondary/50 mb-0.5">{t('driver')}</p>
                            <p className="text-sm font-black text-ink-primary italic">{selectedEntry.pilot_name || profile.display_name}</p>
                         </div>

                         <button 
                           onClick={() => setSelectedEntry(null)}
                           className="w-full py-5 bg-accent-blue text-white font-black uppercase tracking-widest rounded-[32px] shadow-lg shadow-accent-blue/20 mt-4 active:scale-95 transition-all"
                         >
                           Close Details
                         </button>
                      </div>
                    </div>
                  </div>
                </div>
             </motion.div>
           )}
         </AnimatePresence>
    </div>
  );
};

function StatBox({ label, value, highlight = false }: { label: string, value: string, highlight?: boolean }) {
  return (
    <div className={`bg-bg-cell rounded-[24px] p-4 border border-accent-light shadow-sm ${highlight ? 'bg-accent-blue/5 border-accent-blue/20' : ''}`}>
      <p className="text-[9px] font-black uppercase tracking-widest text-ink-secondary/50 mb-0.5">{label}</p>
      <p className={`text-xs font-black text-ink-primary italic truncate ${highlight ? 'text-accent-blue font-mono' : ''}`}>{value}</p>
    </div>
  );
}
