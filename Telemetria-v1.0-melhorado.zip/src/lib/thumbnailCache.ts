import { useState, useEffect } from 'react';
import { getAllLocalThumbnails } from './thumbnailDb';
import { getAllGlobalThumbnailMetadata } from '../services/firebaseService';

let backendThumbs: string[] = [];
const firebaseThumbsMap: Record<string, string> = {}; // normalizedName -> downloadUrl
const firebaseOriginalNames: Record<string, string> = {}; // normalizedName -> originalName
const listeners = new Set<() => void>();
const loadingListeners = new Set<(loading: boolean) => void>();
let isLoadingCache = false;
let channel: BroadcastChannel | null = null;
try {
  if (typeof BroadcastChannel !== 'undefined') {
    channel = new BroadcastChannel('thumbnail_updates');
    channel.onmessage = (event) => {
      if (event.data === 'refresh') {
        refreshThumbsCache();
      }
    };
  }
} catch (e) {
  console.warn('BroadcastChannel not available, updates will not be synchronized across tabs.');
}

export function subscribeToThumbs(listener: () => void) {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

export function subscribeToLoading(listener: (loading: boolean) => void) {
  loadingListeners.add(listener);
  listener(isLoadingCache);
  return () => { loadingListeners.delete(listener); };
}

function notify() {
  listeners.forEach(l => l());
}

function notifyLoading(loading: boolean) {
  isLoadingCache = loading;
  loadingListeners.forEach(l => l(loading));
}

export function getCachedThumbs() {
  return backendThumbs;
}

export function triggerThumbnailUpdate() {
  channel?.postMessage('refresh');
  notify();
}

export function setCachedThumbs(newThumbs: string[]) {
  backendThumbs = Array.from(new Set(newThumbs));
  notify();
}

/**
 * Syncs memory cache with both backend `/api/list-car-thumbnails` and local indexedDB entries
 */
export async function refreshThumbsCache() {
  if (isLoadingCache) return backendThumbs;
  
  notifyLoading(true);
  try {
    // 1. Fetch from Firestore (with timeout)
    const firestorePromise = getAllGlobalThumbnailMetadata().then(fbThumbs => {
      Object.entries(fbThumbs).forEach(([name, url]) => {
        const normalized = normalizeNameForMatching(name);
        firebaseThumbsMap[normalized] = url;
        firebaseOriginalNames[normalized] = name;
      });
    }).catch(e => console.warn("Firestore fetch error:", e));

    // 2. Fetch from local server (with timeout)
    const serverPromise = fetch('/api/list-car-thumbnails').then(async res => {
      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.names)) {
          return data.names;
        }
      }
      return [] as string[];
    }).catch(e => {
      console.warn("Server list fetch error:", e);
      return [] as string[];
    });

    // Wait for basic data but don't hang if one is slow
    const [_, serverNames] = await Promise.all([
      firestorePromise,
      serverPromise
    ]);
    
    const namesFromServer = serverNames || [];

    // 3. Merging with LocalDB
    let localNames: string[] = [];
    try {
      const localDbItems = await getAllLocalThumbnails();
      localNames = localDbItems.map(item => item.carName);
    } catch (e) {}
    
    // Use original names from firebase if available to preserve casing in list
    const fbNames = Object.values(firebaseOriginalNames);
    const uniq = Array.from(new Set([...localNames, ...namesFromServer, ...fbNames]));
    setCachedThumbs(uniq);
    return uniq;
  } catch (err) {
    console.warn("Failed to refresh thumbs cache, trying local only:", err);
    try {
      const localDbItems = await getAllLocalThumbnails();
      const localNames = localDbItems.map(item => item.carName);
      const fbNames = Object.values(firebaseOriginalNames);
      const uniq = Array.from(new Set([...localNames, ...fbNames]));
      setCachedThumbs(uniq);
      return uniq;
    } catch (fallbackErr) {
      console.error("Local DB fetch fallback failed:", fallbackErr);
    }
  } finally {
    notifyLoading(false);
  }
  
  return backendThumbs;
}

/**
 * Normalizes filenames and car names to lower-case alpha-numerics
 * for flawless cross-case/cross-space matching.
 */
export function normalizeNameForMatching(name: string): string {
  if (!name) return "";
  let decoded = name;
  try {
    decoded = decodeURIComponent(name);
  } catch (e) {}
  
  return decoded
    .toLowerCase()
    .replace(/[\s_\-%]/g, '') // remove spaces, underscores, line/dash chars, and percents
    .replace(/['"()]/g, '');  // remove quotes, apostrophes, and brackets
}

/**
 * Resolves a carName to a matching file found on the backend filesystem.
 */
export function getMatchedFilename(carName: string): string | null {
  if (!carName) return null;
  const searchNormalized = normalizeNameForMatching(carName);
  
  // 1. First path: exact normalized match
  for (const name of backendThumbs) {
    if (normalizeNameForMatching(name) === searchNormalized) {
      return name;
    }
  }
  
  return null;
}

import { listCarAssets, subscribeToCarAssets, CarAsset } from '../services/carAssetService';

let carAssetsMap: Record<string, string> = {};

listCarAssets().then(assets => {
  assets.forEach(a => carAssetsMap[normalizeNameForMatching(a.car_name)] = a.image_url);
}).catch(() => {});

subscribeToCarAssets((assets) => {
  const newMap: Record<string, string> = {};
  assets.forEach(a => newMap[normalizeNameForMatching(a.car_name)] = a.image_url);
  carAssetsMap = newMap;
  listeners.forEach(l => l());
});

/**
 * Returns the final URL for a car thumbnail
 */
export function getMatchedThumbnailSrc(carName: string): string {
  const normalized = normalizeNameForMatching(carName);
  
  // 0. Supabase car_assets URL check
  if (carAssetsMap[normalized]) {
    return carAssetsMap[normalized];
  }

  // 1. Direct Firebase URL check
  if (firebaseThumbsMap[normalized]) {
    return firebaseThumbsMap[normalized];
  }

  // 2. Check filename matches in assets/backend
  const matched = getMatchedFilename(carName);
  const finalName = matched || carName;
  return `/assets/cars/${encodeURIComponent(finalName)}.webp`;
}

/**
 * Elegant hook to cleanly sub to thumbnail cache updates in any React functional component.
 */
export function useCarThumbnail(carName: string) {
  const [src, setSrc] = useState(() => getMatchedThumbnailSrc(carName));

  useEffect(() => {
    setSrc(getMatchedThumbnailSrc(carName));
    
    // Subscribe to changes in thumbnails (Firebase, Local, or car_assets)
    return subscribeToThumbs(() => {
        setSrc(getMatchedThumbnailSrc(carName));
    });
  }, [carName]);

  return src;
}

/**
 * Hook to get the full list of available thumbnails
 */
export function useAllThumbnails() {
  const [thumbs, setThumbs] = useState(getCachedThumbs());

  useEffect(() => {
    setThumbs(getCachedThumbs());
    return subscribeToThumbs(() => {
      setThumbs(getCachedThumbs());
    });
  }, []);

  return thumbs;
}

/**
 * Hook to track loading state of the thumbnail cache
 */
export function useThumbsLoading() {
  const [loading, setLoading] = useState(isLoadingCache);
  useEffect(() => {
    return subscribeToLoading(setLoading);
  }, []);
  return loading;
}
