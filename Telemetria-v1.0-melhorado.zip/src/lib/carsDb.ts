import { db, auth, isFirebaseConfigured, ensureFirebaseAuth } from '../services/firebaseService';
import { collection, doc, setDoc, getDoc, getDocs, deleteDoc, query, onSnapshot, where, writeBatch } from 'firebase/firestore';
import { Car } from '../types';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

export interface CustomCar extends Omit<Car, 'insertionCount' | 'thumbnail_file' | 'image_file' | 'image_url' | 'thumbnail_url'> {
  custom_id: string;
  creator_uid: string;
  created_at: number;
}

export interface CarPageItem {
  id: string;
  brand_name: string;
  brand_slug: string;
  logo_data: string;
  logo_type: string;
  created_at: number;
  updated_at: number;
  creator_uid?: string;
}

/**
 * Save a custom car page item (cars database item) to the Firestore "cars_page" collection.
 */
export async function saveCarPageItemToFirestore(item: CarPageItem): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const docRef = doc(db, 'cars_page', item.id);
    await setDoc(docRef, {
      ...item,
      creator_uid: auth.currentUser.uid,
      updated_at: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `cars_page/${item.id}`, auth.currentUser);
  }
}

/**
 * Delete a custom car page item from the Firestore "cars_page" collection.
 */
export async function deleteCarPageItemFromFirestore(id: string): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const docRef = doc(db, 'cars_page', id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `cars_page/${id}`, auth.currentUser);
  }
}

/**
 * Subscribe to the "cars_page" collection to receive updates reactively.
 */
export function subscribeToCarPage(onUpdate: (items: CarPageItem[]) => void) {
  if (!isFirebaseConfigured) return () => {};
  
  const collRef = collection(db, 'cars_page');
  const unsubscribe = onSnapshot(collRef, (snapshot) => {
    const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CarPageItem));
    // Sort chronologically by creation date
    items.sort((a, b) => (a.created_at || 0) - (b.created_at || 0));
    onUpdate(items);
  }, (error) => {
    console.error('Error in onSnapshot for cars_page:', error);
  });
  
  return unsubscribe;
}


/**
 * Save a custom car to the Firestore "carros" database.
 */
export async function saveCustomCarToFirestore(car: CustomCar): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const docRef = doc(db, 'carros', car.custom_id);
    await setDoc(docRef, { ...car, updated_at: Date.now() });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `carros/${car.custom_id}`, auth.currentUser);
  }
}

/**
 * Save multiple custom cars to the Firestore "carros" database in a batch.
 */
export async function saveCustomCarsBatchToFirestore(cars: CustomCar[]): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const batch = writeBatch(db);
    for (const car of cars) {
      const docRef = doc(db, 'carros', car.custom_id);
      batch.set(docRef, { ...car, updated_at: Date.now() });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'carros/batch', auth.currentUser);
  }
}

/**
 * Get all custom cars from the Firestore "carros" database globally.
 */
export async function getAllCustomCarsFromFirestore(): Promise<CustomCar[]> {
  if (!isFirebaseConfigured) return [];
  try {
    const collRef = collection(db, 'carros');
    const snapshot = await getDocs(collRef);
    return snapshot.docs.map(doc => doc.data() as CustomCar);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, `carros`, auth.currentUser);
    return [];
  }
}

/**
 * Delete a custom car from the Firestore "carros" database.
 */
export async function deleteCustomCarFromFirestore(customId: string): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const docRef = doc(db, 'carros', customId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `carros/${customId}`, auth.currentUser);
  }
}

/**
 * Subscribe to the custom cars collection to update the UI reactively
 */
export function subscribeToCustomCars(onUpdate: (cars: CustomCar[]) => void) {
  if (!isFirebaseConfigured) return () => {};
  
  const collRef = collection(db, 'carros');
  const unsubscribe = onSnapshot(collRef, (snapshot) => {
    const cars = snapshot.docs.map(doc => doc.data() as CustomCar);
    onUpdate(cars);
  }, (error) => {
    console.error('Error in onSnapshot for carros:', error);
  });
  
  return unsubscribe;
}
