import { supabase, isSupabaseConfigured } from './supabase';

export async function saveThumbnailSupabase(carName: string, base64: string): Promise<void> {
  if (!isSupabaseConfigured) return;
  const { error } = await supabase
    .from('thumbnails')
    .upsert({ car_name: carName, base64: base64 });
  if (error) console.error("Error saving thumbnail to Supabase:", error);
}

export async function getThumbnailSupabase(carName: string): Promise<string | null> {
  if (!isSupabaseConfigured) return null;
  const { data, error } = await supabase
    .from('thumbnails')
    .select('base64')
    .eq('car_name', carName)
    .single();
  if (error) {
    console.error("Error fetching thumbnail from Supabase:", error);
    return null;
  }
  return data?.base64 || null;
}

export async function getAllThumbnailsSupabase(): Promise<{ carName: string; base64: string }[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase
    .from('thumbnails')
    .select('car_name, base64');
  if (error) {
    console.error("Error fetching all thumbnails from Supabase:", error);
    return [];
  }
  return data?.map(d => ({ carName: d.car_name, base64: d.base64 })) || [];
}

export async function deleteThumbnailSupabase(carName: string): Promise<void> {
  if (!isSupabaseConfigured) return;
  const { error } = await supabase
    .from('thumbnails')
    .delete()
    .eq('car_name', carName);
  if (error) console.error("Error deleting thumbnail from Supabase:", error);
}

export async function clearAllThumbnailsSupabase(): Promise<void> {
  if (!isSupabaseConfigured) return;
  const { error } = await supabase
    .from('thumbnails')
    .delete()
    .neq('car_name', 'non-existent'); // Hack to delete all
  if (error) console.error("Error clearing thumbnails from Supabase:", error);
}
