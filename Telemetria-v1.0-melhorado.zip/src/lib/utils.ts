/**
 * Helper para construir a URL do logo
 */
export const getLogoUrl = (logoFile: string | null) => {
  if (!logoFile) return null;
  if (logoFile.startsWith('data:image/') || logoFile.startsWith('http')) return logoFile;
  return `https://www.gran-turismo.com/gtsport/decal/${logoFile}`;
};

/**
 * Formata a data para o padrão Br
 */
export const formatDateBr = (dateStr: string) => {
  if (!dateStr || !dateStr.includes('-')) return dateStr;
  const [year, month, day] = dateStr.split('-');
  return `${day}/${month}/${year}`;
};

/**
 * Smart search algorithm that returns a relevance score.
 * > 0 means a match. Higher is better.
 */
export function getSmartSearchScore(query: string, text: string): number {
  if (!query || !query.trim()) return 1; // Empty query matches all with low score
  if (!text) return 0;

  const q = query.trim().toLowerCase();
  const t = text.trim().toLowerCase();

  // Exact matches
  if (t === q) return 100;
  if (t.startsWith(q)) return 80;

  // Substring matches
  const idx = t.indexOf(q);
  if (idx !== -1) {
    // If it starts at a word boundary, give it a higher score
    if (idx === 0 || /[\s_\-%/]/.test(t[idx - 1])) {
      return 60;
    }
    return 50;
  }

  // Word-based matching (order agnostic)
  const qWords = q.replace(/['"()\[\]]/g, '').split(/[\s_\-%/]+/).filter(Boolean);
  const tWords = t.replace(/['"()\[\]]/g, '').split(/[\s_\-%/]+/).filter(Boolean);

  if (qWords.length === 0) return 1;

  let allMatch = true;
  let wordScore = 0;

  for (const qw of qWords) {
    let matchedWord = false;
    for (const tw of tWords) {
      if (tw === qw) {
        wordScore += 10;
        matchedWord = true;
        break;
      } else if (tw.startsWith(qw)) {
        wordScore += 5;
        matchedWord = true;
        break;
      } else if (tw.includes(qw)) {
        wordScore += 2;
        matchedWord = true;
        break;
      }
    }
    if (!matchedWord) {
      allMatch = false;
      break;
    }
  }

  if (allMatch) return 40 + wordScore;

  // Fallback: concatenated string check
  const qJoined = qWords.join('');
  const tJoined = tWords.join('');
  if (tJoined.includes(qJoined)) return 30;

  return 0;
}
