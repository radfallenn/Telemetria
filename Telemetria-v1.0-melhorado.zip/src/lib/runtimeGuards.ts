
export function initRuntimeGuards() {
  if (typeof window !== 'undefined') {
    window.addEventListener('error', (event) => {
      if (!event.message) return;
      console.warn('Global error caught:', event.message);
    });

    window.addEventListener('unhandledrejection', (event) => {
      const reason = event.reason;
      if (!reason) return;
      
      const msg = typeof reason === 'object' && reason !== null ? (reason.message || '') : String(reason);
      
      // Filter out typical network abort errors, browser extensions, or common background noise
      if (
        msg.includes('AbortError') || 
        msg.toLowerCase().includes('cancel') || 
        msg.toLowerCase().includes('listener') ||
        msg.includes('Failed to fetch') ||
        msg.toLowerCase().includes('permissions')
      ) {
        return;
      }
      
      console.warn('Unhandled rejection caught:', reason);
    });
  }
}
