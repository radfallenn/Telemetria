export const safeLocalStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.warn(`LocalStorage.getItem blocked: ${key}`);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn(`LocalStorage.setItem blocked: ${key}`);
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn(`LocalStorage.removeItem blocked: ${key}`);
    }
  },
  clear: (): void => {
    try {
      localStorage.clear();
    } catch (e) {
      console.warn('LocalStorage.clear blocked');
    }
  },
};

export const safeSessionStorage = {
  getItem: (key: string): string | null => {
    try {
      return sessionStorage.getItem(key);
    } catch (e) {
      console.warn(`SessionStorage.getItem blocked: ${key}`);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      sessionStorage.setItem(key, value);
    } catch (e) {
      console.warn(`SessionStorage.setItem blocked: ${key}`);
    }
  },
  removeItem: (key: string): void => {
    try {
      sessionStorage.removeItem(key);
    } catch (e) {
      console.warn(`SessionStorage.removeItem blocked: ${key}`);
    }
  },
  clear: (): void => {
    try {
      sessionStorage.clear();
    } catch (e) {
      console.warn('SessionStorage.clear blocked');
    }
  },
};
