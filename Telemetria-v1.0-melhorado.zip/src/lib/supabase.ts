import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-key',
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
      // Using custom lock helper to completely bypass navigator.locks API and avoid "lock stole" errors
      // @ts-ignore
      lock: async (name: string, acquireTimeout: number, fn: () => Promise<any>) => fn(),
      // Backward compatibility
      // @ts-ignore
      lockAcquirer: async (key: string, fn: () => Promise<any>) => fn(),
    }
  }
);

export const isSupabaseConfigured = !!(supabaseUrl && !supabaseUrl.includes('placeholder'));
