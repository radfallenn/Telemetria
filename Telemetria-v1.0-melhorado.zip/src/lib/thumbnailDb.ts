// Simple, direct client-side storage for GT7 custom car thumbnails using IndexedDB
// This allows saving the thumbnails directly in the browser's database,
// absolutely ensuring full offline-friendly, zero-external storage capability!

let dbInstance: IDBDatabase | null = null;

export function initDB(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open("GT7ThumbnailsLocalDB", 2);

    request.onupgradeneeded = (e) => {
      const db = request.result;
      if (!db.objectStoreNames.contains("thumbnails")) {
        db.createObjectStore("thumbnails", { keyPath: "carName" });
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

/**
 * Saves a thumbnail representation to browser IndexedDB
 */
export async function saveThumbnailLocal(carName: string, base64: string): Promise<void> {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("thumbnails", "readwrite");
      const store = tx.objectStore("thumbnails");
      
      // Clean up base64 prefix if needed, but keeping it as-is is safer for data urls
      store.put({ carName, base64 });

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error("Failed to write to local IndexedDB store:", err);
  }
}

/**
 * Retrieves a single custom thumbnail's base64 representation
 */
export async function getThumbnailLocal(carName: string): Promise<string | null> {
  try {
    const db = await initDB();
    return new Promise((resolve) => {
      const tx = db.transaction("thumbnails", "readonly");
      const store = tx.objectStore("thumbnails");
      const request = store.get(carName);

      request.onsuccess = () => {
        if (request.result) {
          resolve(request.result.base64);
        } else {
          resolve(null);
        }
      };

      request.onerror = () => resolve(null);
    });
  } catch (err) {
    console.error("Failed to read from local IndexedDB store:", err);
    return null;
  }
}

/**
 * Retrieves all stored car names and their corresponding base64 representations
 */
export async function getAllLocalThumbnails(): Promise<{ carName: string; base64: string }[]> {
  try {
    const db = await initDB();
    return new Promise((resolve) => {
      const tx = db.transaction("thumbnails", "readonly");
      const store = tx.objectStore("thumbnails");
      const request = store.getAll();

      request.onsuccess = () => {
        resolve(request.result || []);
      };

      request.onerror = () => resolve([]);
    });
  } catch (err) {
    console.error("Failed to read all from local IndexedDB store:", err);
    return [];
  }
}

/**
 * Deletes a stored thumbnail from the local database
 */
export async function deleteThumbnailLocal(carName: string): Promise<void> {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("thumbnails", "readwrite");
      const store = tx.objectStore("thumbnails");
      store.delete(carName);

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error("Failed to delete from local IndexedDB store:", err);
  }
}

/**
 * Deletes all stored thumbnails from the local database
 */
export async function clearAllThumbnailsLocal(): Promise<void> {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("thumbnails", "readwrite");
      const store = tx.objectStore("thumbnails");
      store.clear();

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error("Failed to clear all from local IndexedDB store:", err);
  }
}
