import { db, auth, isFirebaseConfigured, ensureFirebaseAuth } from '../services/firebaseService';
import { collection, doc, setDoc, deleteDoc, onSnapshot, getDocs, writeBatch } from 'firebase/firestore';
import { Track, Entry } from '../types';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

/**
 * Save a custom track to Firestore "tracks" collection.
 */
export async function saveTrackToFirestore(track: Track): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  try {
    const docRef = doc(db, 'tracks', track.id);
    await setDoc(docRef, {
      ...track,
      creator_uid: auth.currentUser?.uid || 'anonymous',
      updated_at: Date.now()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `tracks/${track.id}`, auth.currentUser);
  }
}

/**
 * Delete a track from Firestore "tracks" collection.
 */
export async function deleteTrackFromFirestore(id: string): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  try {
    const docRef = doc(db, 'tracks', id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `tracks/${id}`, auth.currentUser);
  }
}

/**
 * Subscribe to the "tracks" collection.
 */
export function subscribeToTracks(onUpdate: (tracks: Track[]) => void) {
  if (!isFirebaseConfigured) return () => {};
  
  const collRef = collection(db, 'tracks');
  const unsubscribe = onSnapshot(collRef, (snapshot) => {
    const tracks = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        name: data.name,
        location: data.location || '',
        packId: data.packId || '',
        is_public: data.is_public ?? true
      } as Track;
    });
    onUpdate(tracks);
  }, (error) => {
    console.error('Error in onSnapshot for tracks:', error);
  });
  
  return unsubscribe;
}

/**
 * Save a single telemetry/lap entry to Firestore "entries" collection.
 */
export async function saveEntryToFirestore(entry: Entry): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  try {
    const docRef = doc(db, 'entries', entry.id);
    await setDoc(docRef, {
      ...entry,
      creator_uid: auth.currentUser?.uid || 'anonymous',
      updated_at: Date.now()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `entries/${entry.id}`, auth.currentUser);
  }
}

/**
 * Delete an entry from Firestore.
 */
export async function deleteEntryFromFirestore(id: string): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  try {
    const docRef = doc(db, 'entries', id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `entries/${id}`, auth.currentUser);
  }
}

/**
 * Subscribe to the "entries" collection.
 */
export function subscribeToEntries(onUpdate: (entries: Entry[]) => void) {
  if (!isFirebaseConfigured) return () => {};
  
  const collRef = collection(db, 'entries');
  const unsubscribe = onSnapshot(collRef, (snapshot) => {
    const entries = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        trackId: data.trackId,
        carBrand: data.carBrand,
        carName: data.carName,
        carSetup: data.carSetup || '',
        racePosition: data.racePosition || '',
        tractionControl: data.tractionControl || '',
        carMap: data.carMap || '',
        pitStops: data.pitStops || '',
        runDate: data.runDate || '',
        weather: data.weather || '',
        lapTime: data.lapTime,
        totalTime: data.totalTime || '',
        provaDeTempo: data.provaDeTempo || '',
        avgLapTime: data.avgLapTime || '',
        laps: data.laps || '',
        pilot_name: data.pilot_name || '',
        transmission: data.transmission || 'Automatic',
        peripheral: data.peripheral || 'Controller',
        customFields: data.customFields || {},
        evidence_image: data.evidence_image || '',
        is_public: data.is_public ?? true,
        user_id: data.user_id || ''
      } as Entry;
    });
    onUpdate(entries);
  }, (error) => {
    console.error('Error in onSnapshot for entries:', error);
  });
  
  return unsubscribe;
}
