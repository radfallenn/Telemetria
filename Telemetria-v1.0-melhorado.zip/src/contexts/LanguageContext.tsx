import React, { createContext, useContext, useState, useEffect } from 'react';
import { safeLocalStorage } from '../lib/safeBrowserStorage';

type Language = 'en' | 'pt';

interface Translations {
  [key: string]: {
    en: string;
    pt: string;
  };
}

const translations: Translations = {
  // Common
  save: { en: 'Save', pt: 'Salvar' },
  cancel: { en: 'Cancel', pt: 'Cancelar' },
  delete: { en: 'Delete', pt: 'Excluir' },
  edit: { en: 'Edit', pt: 'Editar' },
  confirm: { en: 'Confirm', pt: 'Confirmar' },
  back: { en: 'Back', pt: 'Voltar' },
  search: { en: 'Search', pt: 'Buscar' },
  all: { en: 'ALL', pt: 'TUDO' },
  close: { en: 'Close', pt: 'Fechar' },
  active: { en: 'Active', pt: 'Ativo' },
  now: { en: 'now', pt: 'agora' },
  highLines: { en: 'High', pt: 'Alta' },
  exit: { en: 'Exit', pt: 'Sair' },
  add: { en: 'Add', pt: 'Adicionar' },

  // Header & Hub
  ranking_central: { en: 'Ranking Central', pt: 'Central de Rankings' },
  community_top_drivers: { en: 'Community Top Drivers', pt: 'Top Pilotos da Comunidade' },
  driver_manager: { en: 'Driver Manager', pt: 'Gerenciador de Pilotos' },
  sign_out: { en: 'Sign Out', pt: 'Encerrar Sessão' },
  exit_app: { en: 'Exit App?', pt: 'Sair do App?' },
  exit_app_desc: { en: 'Are you sure you want to exit GTrace?', pt: 'Tem certeza que deseja sair do GTrace?' },
  
  // Navigation
  my_tracks: { en: 'My Tracks', pt: 'Minhas Pistas' },
  global_ranking: { en: 'Ranking', pt: 'Ranking' },
  recent: { en: 'Recent', pt: 'Recentes' },
  all_tracks: { en: 'All Tracks', pt: 'Todas as Pistas' },
  community_tracks: { en: 'Community', pt: 'Comunidade' },
  
  // Track Actions
  new_track: { en: 'New Track', pt: 'Nova Pista' },
  search_tracks: { en: 'Search tracks...', pt: 'Buscar pistas...' },
  sort_by_records: { en: 'Sort by records', pt: 'Ordenar por registros' },
  sort_alphabetical: { en: 'Sort alphabetical', pt: 'Ordem alfabética' },
  add_best: { en: 'Add Record', pt: 'Novo Registro' },
  card_view: { en: 'Card View', pt: 'Vista em Card' },
  list_view: { en: 'List View', pt: 'Vista em Lista' },
  create_restore_point: { en: 'Create Restore Point', pt: 'Criar Ponto de Restauração' },
  apply_restore_point: { en: 'Apply Restore Point', pt: 'Restaurar do Ponto' },
  restore_point_success: { en: 'Restore Point (Full) created successfully!', pt: 'Ponto de Restauração (Completo) criado com sucesso!' },
  restore_point_light_success: { en: 'Restore Point (Light) created. Browser storage limit reached, saved only tracks and entries (no custom images).', pt: 'Ponto de Restauração (Reduzido) criado. O limite de armazenamento do seu navegador foi atingido, então salvamos apenas as pistas e registros (sem imagens customizadas de carros/logos).' },
  restore_point_applied: { en: 'Restore point applied successfully!', pt: 'Ponto de restauração aplicado com sucesso!' },
  restore_point_error: { en: 'Critical error creating restore point. Try clearing browser cache or removing old records.', pt: 'Erro crítico ao criar ponto de restauração. Tente limpar o cache do navegador ou remover registros antigos.' },
  registered_drivers: { en: 'Registered Drivers', pt: 'Pilotos Cadastrados' },
  syncing_drivers: { en: 'Syncing Drivers...', pt: 'Sincronizando Pilotos...' },
  last_seen: { en: 'Last seen:', pt: 'Visto por último:' },
  delete_driver_confirm: { en: 'Delete Driver?', pt: 'Excluir Piloto?' },
  delete_driver_desc: { en: "This action is irreversible and will permanently remove this driver's profile from the system.", pt: 'Esta ação é irreversível e removerá permanentemente o perfil deste piloto do sistema.' },
  syncing_ranking: { en: 'Syncing Ranking...', pt: 'Sincronizando Ranking...' },
  no_drivers_ranking: { en: 'No drivers found in the ranking.', pt: 'Nenhum piloto encontrado no ranking.' },
  no_activity: { en: 'No activity', pt: 'Sem atividade' },
  wins: { en: 'Wins', pt: 'Vitórias' },
  tracks: { en: 'Tracks', pt: 'Pistas' },
  activity: { en: 'Activity', pt: 'Atividade' },

  // Profile Modal
  driver_profile: { en: 'Driver Profile', pt: 'Perfil do Piloto' },
  synced_with_gt: { en: 'Synced with gran-turismo.com', pt: 'Sincronizado com gran-turismo.com' },
  display_name: { en: 'Display Name', pt: 'Nome de Exibição' },
  psn_id_label: { en: 'PSN ID', pt: 'PSN ID' },
  bio_slogan: { en: 'Bio / Slogan', pt: 'Bio / Slogan' },
  tell_us_career: { en: 'Tell us a bit about your career...', pt: 'Conte-nos um pouco sobre sua carreira...' },
  official_ratings: { en: 'Official Ratings', pt: 'Classificações Oficiais' },
  driver_rating_label: { en: 'Driver Rating (DR)', pt: 'Classificação de Piloto (DR)' },
  safety_rating_label: { en: 'Safety Rating (SR)', pt: 'Classificação de Segurança (SR)' },
  profile_privacy: { en: 'Profile Privacy', pt: 'Privacidade do Perfil' },
  public_profile_enabled: { en: 'Public Profile Enabled', pt: 'Perfil Público Ativado' },
  private_profile: { en: 'Private Profile', pt: 'Perfil Privado' },
  public_profile_desc: { en: 'By enabling Public Profile, your allowed info below will be visible to the community.', pt: 'Ao ativar o Perfil Público, suas informações permitidas abaixo ficarão visíveis para a comunidade.' },
  private_profile_desc: { en: 'Your information is private. Nothing from your profile will be shared.', pt: 'Suas informações são privadas. Nada do seu perfil será compartilhado.' },
  show_times_records: { en: 'Show Times and Records', pt: 'Mostrar Tempos e Registros' },
  appear_global_ranking: { en: 'Appear in Global Ranking', pt: 'Aparecer no Ranking Global' },
  show_statistics: { en: 'Show Statistics', pt: 'Mostrar Estatísticas' },
  show_profile_photo: { en: 'Show Profile Photo', pt: 'Mostrar Foto de Perfil' },
  show_bio_slogan: { en: 'Show Bio / Slogan', pt: 'Mostrar Bio / Slogan' },
  confirm_public_profile: { en: 'Confirm Public Profile?', pt: 'Confirmar Perfil Público?' },
  confirm_public_desc: { en: 'By making your profile public, your PSN ID, Avatar, Bio and all your times will be shared with the community. Do you want to proceed?', pt: 'Ao tornar seu perfil público, seu PSN ID, Avatar, Bio e todos os seus tempos serão compartilhados com a comunidade. Deseja prosseguir?' },
  yes_make_public: { en: 'Yes, make public', pt: 'Sim, tornar público' },
  career_statistics: { en: 'Career Statistics', pt: 'Estatísticas de Carreira' },
  races_via_app: { en: 'Races via App', pt: 'Corridas via App' },
  wins_via_app: { en: 'Wins via App', pt: 'Vitórias via App' },
  win_rate: { en: 'Win Rate', pt: 'Taxa de Vitória' },
  administrator: { en: 'Administrator', pt: 'Administrador' },
  only_admin_desc: { en: 'You are the only administrator of this system.', pt: 'Você é o único administrador deste sistema.' },
  become_admin: { en: 'Become Administrator', pt: 'Tornar-se Administrador' },
  become_admin_desc: { en: 'The first to click will be the only system admin!', pt: 'O primeiro a clicar será o único admin do sistema!' },
  save_profile: { en: 'Save Profile', pt: 'Salvar Perfil' },
  your_name_placeholder: { en: 'Your name', pt: 'Seu nome' },

  // Ranking
  ranking_hub: { en: 'Ranking Hub', pt: 'Central de Ranking' },
  track_records: { en: 'Track Records', pt: 'Recordes da Pista' },
  top_community_drivers: { en: 'Top Community Drivers', pt: 'Melhores Pilotos da Comunidade' },
  track: { en: 'Track', pt: 'Pista' },
  overall: { en: 'Overall', pt: 'Geral' },
  top_speed: { en: 'Top Speed', pt: 'Velocidade' },
  top_speed_leaderboard: { en: 'Top Speed Rankings (Fastest Cars)', pt: 'Pilotos mais Velozes (Velocidade Final)' },
  loading_leaderboard: { en: 'Loading Leaderboard...', pt: 'Carregando Leaderboard...' },
  no_times_track: { en: 'No times recorded for this track.', pt: 'Nenhum tempo gravado nesta pista.' },
  best_lap: { en: 'Best Lap', pt: 'Melhor Volta' },
  total_time: { en: 'Total Time', pt: 'Tempo Total' },
  driver: { en: 'Driver', pt: 'Piloto' },
  car: { en: 'Car', pt: 'Carro' },
  participations: { en: 'Participations', pt: 'Participações' },
  overall_p1: { en: 'Overall P1', pt: 'Vitórias Totais' },
  capture_evidence: { en: 'Capture Evidence', pt: 'Evidência de Captura' },
  setup: { en: 'Setup', pt: 'Setup' },
  pits: { en: 'Pits', pt: 'Pits' },
  traction_control: { en: 'TC', pt: 'Controle de Tração' },
  map: { en: 'Map', pt: 'Mapeamento' },
  weather: { en: 'Weather', pt: 'Clima' },
  lap: { en: 'Lap', pt: 'Volta' },
  total: { en: 'Total', pt: 'Total' },
  transmission: { en: 'Transmission', pt: 'Transmissão' },
  peripheral: { en: 'Peripheral', pt: 'Periférico' },
  place: { en: 'Place', pt: 'Lugar' },
  no_active_drivers: { en: 'No active drivers at the moment.', pt: 'Nenhum piloto ativo no momento.' },
  guest_driver: { en: 'Guest Driver', pt: 'Piloto Convidado' },
  search_driver_ranking_placeholder: { en: 'Search driver...', pt: 'Buscar piloto...' },
  search_driver_placeholder: { en: 'Search by driver or PSN ID...', pt: 'Buscar por piloto ou PSN ID...' },
  no_drivers_found: { en: 'No drivers found', pt: 'Nenhum piloto encontrado' },
  
  // Public Profile View
  profile_unavailable: { en: 'Profile Unavailable', pt: 'Perfil Indisponível' },
  profile_unavailable_desc: { en: 'This profile was not found or is private.', pt: 'Este perfil não foi encontrado ou é privado.' },
  times_recorded: { en: 'Times recorded', pt: 'Tempos registrados' },
  no_times_recorded: { en: 'No times recorded', pt: 'Nenhum tempo registrado' },
  no_times_desc: { en: 'This driver does not have time records on this account yet.', pt: 'Este piloto ainda não possui registros de tempo nesta conta.' },
  back_to_tracks: { en: 'Back to Tracks', pt: 'Voltar para Pistas' },
  lap_details: { en: 'Lap Details', pt: 'Detalhes da Volta' },
  no_evidence: { en: 'No Evidence', pt: 'Sem Prova' },
  position: { en: 'Position', pt: 'Posição' },
  laps: { en: 'Laps', pt: 'Voltas' },
  fastest_lap: { en: 'Fastest Lap', pt: 'Volta Rápida' },
  tc: { en: 'TC', pt: 'CT' },
  times_at: { en: 'Times at:', pt: 'Tempos em:' },
  tracks_ridden: { en: 'Tracks Ridden', pt: 'Pistas Percorridas' },
  date: { en: 'Date', pt: 'Data' },
  close_details: { en: 'Close Details', pt: 'Fechar Detalhes' },
  unknown_circuit: { en: 'Unknown Circuit', pt: 'Circuito Desconhecido' },
  records_count: { en: 'Records', pt: 'Registros' },
  record_count: { en: 'Record', pt: 'Registro' },
  evidence: { en: 'Evidence', pt: 'Evidência' },
  
  // User Hub
  drivers_hub: { en: 'Drivers Hub', pt: 'Central de Pilotos' },
  discover_follow_community: { en: 'Discover and follow the GT community', pt: 'Descubra e acompanhe a comunidade GT' },
  search_hub_placeholder: { en: 'Search by name, PSN ID or bio...', pt: 'Buscar por nome, PSN ID ou bio...' },
  syncing_cloud: { en: 'Syncing with the cloud...', pt: 'Sincronizando com a nuvem...' },
  try_searching_terms: { en: 'Try searching for different terms or check profile privacy.', pt: 'Tente pesquisar termos diferentes ou verifique a privacidade do perfil.' },
  see_all_drivers: { en: 'See all drivers', pt: 'Ver todos os pilotos' },
  showing_public_only: { en: 'Showing only profiles marked as public', pt: 'Mostrando apenas perfis marcados como público' },
  active_drivers_count: { en: 'active drivers', pt: 'pilotos ativos' },
  races: { en: 'Races', pt: 'Corridas' },

  // Auth
  create_driver_account: { en: 'Create Driver Account', pt: 'Criar Conta de Piloto' },
  paddock_access: { en: 'Paddock Access', pt: 'Acesso ao Paddock' },
  paddock_desc: { en: 'GT7 Telemetry Manager', pt: 'Gerenciador de Telemetria GT7' },
  email_label: { en: 'Email', pt: 'Email' },
  password_label: { en: 'Password', pt: 'Senha' },
  confirm_registration: { en: 'Confirm Registration', pt: 'Confirmar Cadastro' },
  already_have_account: { en: 'Already have an account? LOGIN', pt: 'Já tem uma conta? LOGIN' },
  no_account_signup: { en: 'No account? SIGN UP', pt: 'Sem conta? CADASTRE-SE' },
  encrypted_data_desc: { en: 'Encrypted data via Supabase Cloud', pt: 'Dados criptografados via Supabase Cloud' },
  invalid_credentials: { en: 'This email is already registered. Please try to LOG IN with your password.', pt: 'Este e-mail já está cadastrado. Por favor, tente fazer LOGIN com sua senha.' },
  email_not_confirmed: { en: 'This email has been registered but not confirmed. Check your inbox or try a new email.', pt: 'Este e-mail foi cadastrado mas não confirmado. Verifique sua caixa de entrada ou tente um novo e-mail.' },
  supabase_not_configured: { en: 'Supabase not configured. Add real keys in project settings to use cloud sync.', pt: 'Supabase não configurado. Adicione as chaves reais nas configurações do projeto para usar a sincronização em nuvem.' },
  auth_error: { en: 'Error during authentication.', pt: 'Erro durante a autenticação.' },
  fetch_error: { en: 'Error: Browser blocked the connection (Failed to fetch).', pt: 'Erro: O navegador bloqueou a conexão (Falha ao buscar).' },
  email_disabled_error: { en: 'Error: Email login/signup is disabled in your Supabase.', pt: 'Erro: Login/cadastro por e-mail está desativado no seu Supabase.' },
  account_created_login_failed: { en: 'Account created, but login failed', pt: 'Conta criada, mas o login falhou' },

  // Profile Setup
  welcome: { en: 'Welcome!', pt: 'Bem-vindo!' },
  setup_profile_desc: { en: 'Before we start, we need a name and a photo for your profile.', pt: 'Antes de começarmos, precisamos de um nome e uma foto para o seu perfil.' },
  photo_label: { en: 'Photo', pt: 'Foto' },
  continue_button: { en: 'Continue', pt: 'Continuar' },
  valid_image_error: { en: 'Please select a valid image.', pt: 'Por favor, selecione uma imagem válida.' },
  photo_size_error: { en: 'The photo must be at most 2MB.', pt: 'A foto deve ter no máximo 2MB.' },
  upload_error: { en: 'Error uploading image.', pt: 'Erro ao enviar imagem.' },
  save_profile_error: { en: 'Error saving profile.', pt: 'Erro ao salvar perfil.' },
  display_name_placeholder: { en: 'Your name', pt: 'Seu nome' },

  // App General
  no_records: { en: 'No records', pt: 'Sem registros' },
  no_time_trial: { en: 'No Time Trial', pt: 'Sem Prova de Tempo' },
  time_trial_ranking: { en: 'Time Trial Ranking', pt: 'Ranking de Prova de Tempo' },
  best_laps_recorded: { en: 'Best laps recorded', pt: 'Melhores voltas registradas' },
  adjust_filters_desc: { en: 'Try adjusting your filters or search terms to find what you\'re looking for.', pt: 'Tente ajustar seus filtros ou termos de pesquisa para encontrar o que procura.' },
  clear: { en: 'Clear', pt: 'Limpar' },
  yes_delete: { en: 'Yes, Delete', pt: 'Sim, Excluir' },
  offline_a_long_time: { en: 'A long time ago', pt: 'Há muito tempo' },
  online: { en: 'Online', pt: 'Online' },

  // Admin & Settings
  administration: { en: 'Administration', pt: 'Administração' },
  track_management: { en: 'Track Management', pt: 'Gerenciamento de Pistas' },
  import_pack: { en: 'Import Pack', pt: 'Importar Pacote' },
  search_track_placeholder: { en: 'Search track or country...', pt: 'Buscar pista ou país...' },
  location_not_defined: { en: 'Location not defined', pt: 'Localização não definida' },
  sync_error: { en: 'Sync Error', pt: 'Erro de Sincronização' },
  attempting: { en: 'Attempting...', pt: 'Tentando...' },
  try_again: { en: 'Try Again', pt: 'Tentar Novamente' },
  cloud_sync: { en: 'Cloud Sync', pt: 'Sincronização na Nuvem' },
  save_to_supabase: { en: 'Save to Supabase', pt: 'Salvar no Supabase' },
  download_from_cloud: { en: 'Download from Cloud', pt: 'Baixar da Nuvem' },
  data_management: { en: 'Data Management', pt: 'Gerenciamento de Dados' },
  manage_tracks: { en: 'Manage Tracks', pt: 'Gerenciar Pistas' },
  tools: { en: 'Tools', pt: 'Ferramentas' },
  data_maintenance: { en: 'Data Maintenance', pt: 'Manutenção de Dados' },
  remove_duplicates: { en: 'Remove Duplicates', pt: 'Remover Duplicados' },
  remove_duplicates_desc: { en: 'Deep cleaning of orphan entries.', pt: 'Limpeza profunda de registros órfãos.' },
  recover_trash: { en: 'Recover Trash', pt: 'Recuperar Lixo' },
  trash_empty: { en: 'Trash empty.', pt: 'Lixeira vazia.' },
  restore_trash_confirm: { en: 'Restore {tracks} tracks and {entries} entries recently deleted?', pt: 'Restaurar {tracks} pistas e {entries} registros excluídos recentemente?' },
  recover_trash_desc: { en: 'Recover items deleted in the current session.', pt: 'Recuperar itens excluídos na sessão atual.' },
  scan_inconsistencies: { en: 'Scan Inconsistencies', pt: 'Escanear Inconsistências' },
  scan_inconsistencies_desc: { en: 'Verifies reference integrity.', pt: 'Verifica integridade das referências.' },
  recalculate_stats: { en: 'Recalculate Stats', pt: 'Recalcular Estatísticas' },
  recalculate_stats_confirm: { en: 'Recalcalculate win and track statistics for ALL drivers? This may take a few seconds.', pt: 'Recalcular estatísticas de vitórias e pistas para TODOS os pilotos? Isso pode levar alguns segundos.' },
  recalculate_stats_success: { en: 'Success! Stats for {count} drivers updated.', pt: 'Sucesso! Estatísticas de {count} pilotos atualizadas.' },
  recalculate_stats_desc: { en: 'Synchronizes global wins and participations.', pt: 'Sincroniza vitórias e participações globais.' },
  close_panel: { en: 'Close Panel', pt: 'Fechar Painel' },
  settings: { en: 'Settings', pt: 'Configurações' },
  import_json: { en: 'Import JSON', pt: 'Importar JSON' },
  export_json: { en: 'Export JSON', pt: 'Exportar JSON' },
  card_layout: { en: 'Card Layout', pt: 'Layout do Card' },

  // Entry Card & Form
  designer_active: { en: 'Designer Active', pt: 'Designer Ativo' },
  edit_entry: { en: 'Edit Entry', pt: 'Editar Registro' },
  new_entry: { en: 'New Entry', pt: 'Novo Registro' },
  delete_entry_confirm: { en: 'Are you sure you want to delete this entry?', pt: 'Tem certeza que deseja excluir este registro?' },
  delete_entry: { en: 'Delete Entry', pt: 'Excluir Registro' },
  brand: { en: 'Brand', pt: 'Marca' },
  tires_setup: { en: 'Tires / Setup', pt: 'Pneus / Configuração' },
  change_logo: { en: 'Change Logo', pt: 'Mudar Logo' },
  pin_car: { en: 'Pin Car', pt: 'Fixar Carro' },
  private: { en: 'Private', pt: 'Privado' },
  public: { en: 'Public', pt: 'Público' },
  level: { en: 'Level', pt: 'Nível' },
  place_st: { en: 'st Place', pt: 'º Lugar' },
  place_nd: { en: 'nd Place', pt: 'º Lugar' },
  place_rd: { en: 'rd Place', pt: 'º Lugar' },
  place_th: { en: 'th Place', pt: 'º Lugar' },

  // AI & Modals
  ai_engineer_name: { en: 'AI Racing Engineer', pt: 'Engenheiro de Corrida IA' },
  performance_analysis: { en: 'Performance Analysis', pt: 'Análise de Performance' },
  data: { en: 'Data', pt: 'Dados' },
  drivers: { en: 'Drivers', pt: 'Pilotos' },
  delete_profile: { en: 'Delete Profile', pt: 'Excluir Perfil' },
  error_loading_drivers: { en: 'Error Loading Drivers', pt: 'Erro ao Carregar Pilotos' },
  ban_driver: { en: 'Ban Driver', pt: 'Banir Piloto' },
  unban_driver: { en: 'Unban Driver', pt: 'Desbanir Piloto' },
  banned: { en: 'BANNED', pt: 'BANIDO' },
  ban_confirm: { en: 'Are you sure you want to ban this driver? They will no longer appear in rankings.', pt: 'Tem certeza que deseja banir este piloto? Ele não aparecerá mais nos rankings.' },
  processing_telemetry: { en: 'Processing Telemetry...', pt: 'Processando Telemetria...' },
  ai_tips_generated_desc: { en: 'Tips generated based on your current database of times and weather conditions.', pt: 'Dicas geradas com base na sua base de dados atual de tempos e condições climáticas.' },
  understood_captain: { en: 'Understood, Captain', pt: 'Entendido, Capitão' },
  logo_explorer: { en: 'Logo Explorer', pt: 'Explorador de Logos' },
  search_brand_placeholder: { en: 'Search brand...', pt: 'Buscar marca...' },
  edit_track: { en: 'Edit Track', pt: 'Editar Pista' },
  track_name: { en: 'Track Name', pt: 'Nome da Pista' },
  location: { en: 'Location', pt: 'Localização' },
  track_logo: { en: 'Track Logo', pt: 'Logo da Pista' },
  sync_with_community: { en: 'Sync with Community', pt: 'Sincronizar com Comunidade' },
  pack_info: { en: 'Pack Info', pt: 'Informações do Pacote' },
  official_pack: { en: 'Official Track Pack', pt: 'Pacote Oficial de Pistas' },
  delete_track: { en: 'Delete Track', pt: 'Excluir Pista' },
  delete_track_confirm: { en: 'Are you sure? This will delete the track and ALL associated entries.', pt: 'Tem certeza? Isso excluirá a pista e TODOS os registros associados.' },
  track_delete_permanently_desc: { en: 'This will permanently delete the track {name} and all recorded times on it.', pt: 'Isso excluirá permanentemente a pista {name} e todos os tempos registrados nela.' },
  track_selector: { en: 'Track Selector', pt: 'Seletor de Pistas' },
  no_tracks_found: { en: 'No tracks found', pt: 'Nenhuma pista encontrada' },
  card_designer: { en: 'Card Designer', pt: 'Designer do Card' },
  style_and_size: { en: 'Style & Size', pt: 'Estilo e Tamanho' },
  compact_mode: { en: 'Compact Mode', pt: 'Modo Compacto' },
  card_radius: { en: 'Card Radius', pt: 'Arredondamento' },
  padding: { en: 'Padding', pt: 'Espaçamento' },
  row_gap: { en: 'Row Gap', pt: 'Espaço entre Linhas' },
  field_layout: { en: 'Field Layout', pt: 'Layout dos Campos' },
  custom_field: { en: 'Custom', pt: 'Personalizado' },
  show_in_card: { en: 'Show in Card', pt: 'Mostrar no Card' },
  hide_from_card: { en: 'Hide from Card', pt: 'Esconder do Card' },
  field_label: { en: 'Field Label', pt: 'Rótulo do Campo' },
  field_name: { en: 'Field Name', pt: 'Nome do Campo' },
  size_label: { en: 'Size', pt: 'Tamanho' },
  edit_logo: { en: 'Edit Logo', pt: 'Editar Logotipo' },
  brand_customization: { en: 'Brand Customization', pt: 'Customização da Marca' },
  explore: { en: 'Explore', pt: 'Explorar' },
  logo_id_url: { en: 'Logo ID or URL', pt: 'ID ou URL do Logotipo' },
  remove_uploaded_image: { en: 'Remove Uploaded Image', pt: 'Remover Imagem Carregada' },
  logo_instructions: { en: 'You can use an ingame ID, external URL or upload a file.', pt: 'Você pode usar um ID do jogo, uma URL externa ou fazer upload de um arquivo.' },
  explore_upload_logos: { en: 'Explore or upload custom logos', pt: 'Explore ou envie logos personalizados' },
  batch_upload: { en: 'Batch Upload', pt: 'Upload em Lote' },
  upload_new: { en: 'Upload New', pt: 'Novo Logo' },
  no_results_found: { en: 'No results found', pt: 'Nenhum resultado encontrado' },
  logos_available: { en: 'logos available', pt: 'logos disponíveis' },
  save_all: { en: 'Save All', pt: 'Salvar Tudo' },
  delete_all: { en: 'Delete All', pt: 'Excluir Tudo' },
  full: { en: 'Full', pt: 'Cheio' },
  remove_logo: { en: 'Remove Logo', pt: 'Remover Logotipo' },
  ai_api_key_error: { en: 'Invalid or not found API key. Check your settings.', pt: 'Chave de API inválida ou não encontrada. Verifique suas configurações.' },
  ai_quota_error: { en: 'AI usage limit reached. Try again later.', pt: 'Limite de uso da IA atingido. Tente novamente mais tarde.' },
  ai_unavailable_error: { en: 'AI server is temporarily unavailable. Check your settings.', pt: 'O servidor de IA está temporariamente indisponível. Verifique suas configurações.' },
  ai_empty_error: { en: 'Empty response from AI', pt: 'Resposta vazia da IA' },

  // Weather Values
  weather_sun: { en: 'Sun', pt: 'Sol' },
  weather_cloudy: { en: 'Cloudy', pt: 'Nublado' },
  weather_rain: { en: 'Rain', pt: 'Chuva' },
  weather_storm: { en: 'Storm', pt: 'Tempestade' },

  // Transmission Values
  trans_automatic: { en: 'Automatic', pt: 'Automática' },
  trans_manual: { en: 'Manual', pt: 'Manual' },

  // Peripheral Values
  peri_controller: { en: 'Controller', pt: 'Controle' },
  peri_wheel: { en: 'Steering Wheel', pt: 'Volante' },

  // Track View
  records: { en: 'RECORDS', pt: 'REGISTROS' },
  time_trial: { en: 'TIME TRIAL', pt: 'PROVA DE TEMPO' },
  default_setup: { en: 'Default', pt: 'Padrão' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = safeLocalStorage.getItem('gtrace_lang');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    safeLocalStorage.setItem('gtrace_lang', language);
  }, [language]);

  const t = (key: string) => {
    if (!translations[key]) {
      // console.warn(`Translation key not found: ${key}`);
      return key;
    }
    return translations[key][language];
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
