import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { saveTelemetrySession, saveTelemetrySample, GT7TelemetrySession, GT7TelemetrySample, saveTelemetryMapPoint, GT7TelemetryMapPoint } from '../services/telemetryDB';

export interface TelemetryData {
  session_id: string;
  timestamp: string;
  source: string;
  connected: boolean;
  speed_kmh: number;
  rpm: number;
  gear: string | number;
  throttle_percent: number;
  brake_percent: number;
  fuel: number | null;
  fuel_percent: number | null;
  best_lap_ms: number | null;
  best_lap_text: string | null;
  last_lap_ms: number | null;
  last_lap_text: string | null;
  total_race_time_ms: number;
  total_race_time_text: string | null;
  completed_laps: number;
  rain_intensity: number | null;
  traction_control: number | string | null;
  pit_stops_count: number;
  map: {
    track_id: string | null;
    track_name: string | null;
    car_position: { x: number | null; y: number | null; z: number | null };
    heading: number | null;
    lap_progress_percent: number | null;
    path_points?: { x: number; y: number }[];
  };
}

export type ConnectionState = 'offline' | 'connecting' | 'connected' | 'blocked' | 'waiting_valid_data';

export type ConnectionMode = 'auto' | 'pc_bridge' | 'mobile_apk_bridge' | 'mobile_apk_push' | 'manual' | 'raspberry_bridge';

// Declare GT7AndroidBridge interface
declare global {
  interface Window {
    GT7AndroidBridge?: {
      getFields: () => string;
      getStatus: () => string;
      getMap: () => string;
    };
    GT7_BRIDGE_MODE?: string;
    __gt7MobileBridgeActive?: boolean;
    __gt7MobileTelemetrySource?: string;
    __gt7MobileTelemetry?: any;
    __gt7LastTelemetry?: any;
  }
}

export interface GT7SessionState {
  sessionActive: boolean;
  raceStarted: boolean;
  raceFinished: boolean;
  maxSpeed: number;
  frozenRaceTime: string;
  frozenRaceTimeMs: number;
  lastValidRaceTime: string;
  lastValidRaceTimeMs: number;
  lastValidBestLap: string;
  lastValidLastLap: string;
  lastValidPits: number;
  correctedLaps: number;
  lastValidFuel: number | null;
  lastValidFuelPercent: number | null;
  lastValidPosition: { x: number | null; y: number | null; z: number | null };
  targetLaps: number;
  isBestLapStale: boolean;
  isLastLapStale: boolean;
  isRaceTimeStale: boolean;
  isPitsStale: boolean;
  isLapsStale: boolean;
  isFuelStale: boolean;
  isMaxSpeedStale: boolean;
  isPositionStale: boolean;
  lastTelemetry: any;
}

interface TelemetryContextType {
  telemetry: TelemetryData | null;
  connectionState: ConnectionState;
  pcLanIp: string;
  setPcLanIp: (ip: string) => void;
  connectionMode: ConnectionMode;
  setConnectionMode: (mode: ConnectionMode) => void;
  manualApiUrl: string;
  setManualApiUrl: (url: string) => void;
  manualWsUrl: string;
  setManualWsUrl: (url: string) => void;
  raspberryUrl: string;
  setRaspberryUrl: (url: string) => void;
  recordingEnabled: boolean;
  setRecordingEnabled: (enabled: boolean) => void;
  gt7Session: GT7SessionState;
  resetSession: () => void;
  finalizeRace: () => void;
  setTargetLaps: (laps: number) => void;
}

const TelemetryContext = createContext<TelemetryContextType | undefined>(undefined);

const getDefaultTelemetry = (): TelemetryData => ({
  session_id: '',
  timestamp: new Date().toISOString(),
  source: 'pc_bridge',
  connected: false,
  speed_kmh: 0,
  rpm: 0,
  gear: 'N',
  throttle_percent: 0,
  brake_percent: 0,
  fuel: null,
  fuel_percent: null,
  best_lap_ms: null,
  best_lap_text: null,
  last_lap_ms: null,
  last_lap_text: null,
  total_race_time_ms: 0,
  total_race_time_text: null,
  completed_laps: 0,
  rain_intensity: null,
  traction_control: null,
  pit_stops_count: 0,
  map: {
    track_id: null,
    track_name: null,
    car_position: { x: null, y: null, z: null },
    heading: null,
    lap_progress_percent: null,
  }
});

const getAliasValue = (payload: any, aliases: string[]) => {
  if (!payload || typeof payload !== 'object') return null;
  for (const alias of aliases) {
    if (payload[alias] !== undefined && payload[alias] !== null) {
      return payload[alias];
    }
  }
  return null;
};

const ALIASES = {
  speed_kmh: ['speed_kmh', 'speed', 'car_speed', 'velocity', 'velocity_kmh', 'velocidade', 'speedKmh'],
  rpm: ['rpm', 'engine_rpm', 'current_rpm', 'RPM', 'engineRpm'],
  gear: ['gear', 'current_gear', 'marcha', 'currentGear', 'gearLabel'],
  throttle_percent: ['throttle_percent', 'throttle', 'accelerator', 'accelerator_percent', 'gas', 'acelerador', 'throttlePercent'],
  brake_percent: ['brake_percent', 'brake', 'brake_pedal', 'freio', 'brakePercent'],
  fuel: ['fuel', 'fuel_percent', 'fuel_liters', 'fuel_capacity', 'current_fuel', 'combustivel', 'combustível', 'fuelLevel', 'fuel_level', 'fuelLiters'],
  fuel_percent: ['combustivelPorcentagem', 'fuelPercent'],
  best_lap_ms: ['best_lap_ms', 'bestLapMs', 'best_lap', 'bestLap', 'melhorVolta', 'bestLapTime'],
  last_lap_ms: ['last_lap_ms', 'lastLapMs', 'last_lap', 'lastLap', 'ultimaVolta', 'ultima_volta', 'lastLapTime', 'last_lap_time'],
  total_race_time_ms: ['total_race_time_ms', 'race_time_ms', 'totalTimeMs', 'total_time', 'tempoTotalCorrida', 'raceTime', 'race_time', 'totalRaceTime'],
  completed_laps: ['completed_laps', 'lap_count', 'lapCount', 'current_lap_completed', 'laps_completed', 'voltasCompletadas', 'completedLaps', 'lap', 'currentLap'],
  rain_intensity: ['rain_intensity', 'rain', 'rain_percent', 'surface_water', 'water_on_track', 'chuva', 'rainLevel', 'rain_level', 'wetness', 'trackWetness'],
  traction_control: ['traction_control', 'tcs', 'tcs_level', 'tc', 'controleTracao', 'tractionControl'],
  pit_stops_count: ['pit_stops_count', 'pitStops', 'pit_count', 'numeroParadas', 'pit_stops', 'stops'],
};

export function normalizeTelemetry(raw: any): any {
  let data = raw;
  if (!raw) return {};
  if (typeof raw === 'string') {
    try {
      const match = raw.match(/\{[\s\S]*schema["\s:]+["'](gt7_entry_v1_4_2|gt7_entry_v1_4_1|gt7_entry_v1)["'][\s\S]*\}/) || raw.match(/\{[\s\S]*\}/);
      if (match) {
        data = JSON.parse(match[0]);
      } else {
        data = JSON.parse(raw);
      }
    } catch(e) {
      return {};
    }
  }
  if (!data || typeof data !== 'object') return {};

  const speed = Number(getAliasValue(data, ALIASES.speed_kmh)) || 0;
  let rpm = Number(getAliasValue(data, ALIASES.rpm)) || 0;
  if (isNaN(rpm) || !isFinite(rpm) || rpm < 0 || rpm > 30000) {
    rpm = 0;
  }
  const gearRaw = getAliasValue(data, ALIASES.gear);
  const gear = (gearRaw === 0 || gearRaw === '0' || !gearRaw) ? 'N' : gearRaw;
  const throttle = Number(getAliasValue(data, ALIASES.throttle_percent)) || 0;
  const brake = Number(getAliasValue(data, ALIASES.brake_percent)) || 0;
  const fuel = getAliasValue(data, ALIASES.fuel) !== null ? Number(getAliasValue(data, ALIASES.fuel)) : null;
  const best_lap_ms = getAliasValue(data, ALIASES.best_lap_ms);
  const last_lap_ms = getAliasValue(data, ALIASES.last_lap_ms);
  const total_race_time_ms = Number(getAliasValue(data, ALIASES.total_race_time_ms)) || 0;
  const completed_laps = Number(getAliasValue(data, ALIASES.completed_laps)) || 0;
  const pit_stops_count = getAliasValue(data, ALIASES.pit_stops_count) !== null ? Number(getAliasValue(data, ALIASES.pit_stops_count)) : null;
  const raceFinished = data.raceFinished ?? data.corridaFinalizada ?? data.race_finished ?? false;

  return {
    velocidade: speed,
    speed_kmh: speed,
    rpm,
    gear,
    throttle_percent: throttle,
    brake_percent: brake,
    fuel,
    best_lap_ms,
    best_lap_text: (best_lap_ms && best_lap_ms > 0) ? new Date(best_lap_ms).toISOString().substr(14, 9) : null,
    last_lap_ms,
    last_lap_text: (last_lap_ms && last_lap_ms > 0) ? new Date(last_lap_ms).toISOString().substr(14, 9) : null,
    total_race_time_ms,
    total_race_time_text: total_race_time_ms > 0 ? new Date(Math.max(0, total_race_time_ms)).toISOString().substr(11, 12) : null,
    completed_laps,
    pit_stops_count,
    raceFinished
  };
}

export const TelemetryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [telemetry, setTelemetry] = useState<TelemetryData>(getDefaultTelemetry());
  const [connectionState, setConnectionState] = useState<ConnectionState>('offline');
  
  const [pcLanIp, setPcLanIp] = useState(() => localStorage.getItem('gt7Ps5Ip') || localStorage.getItem('gt7_bridge_pc_lan_ip') || '192.168.1.54');
  const [connectionMode, setConnectionMode] = useState<ConnectionMode>(
    () => (localStorage.getItem('gt7.telemetry.connectionMode') as ConnectionMode) || 'auto'
  );
  const [manualApiUrl, setManualApiUrl] = useState(() => localStorage.getItem('gt7.telemetry.manualApiUrl') || '');
  const [manualWsUrl, setManualWsUrl] = useState(() => localStorage.getItem('gt7.telemetry.manualWsUrl') || '');
  const [raspberryUrl, setRaspberryUrl] = useState(() => localStorage.getItem('gt7.telemetry.raspberryUrl') || 'http://192.168.1.70:8787/api/fields');
  const [recordingEnabled, setRecordingEnabled] = useState(() => localStorage.getItem('gt7_recording_enabled') !== 'false');

  const [gt7Session, setGt7Session] = useState<GT7SessionState>(() => {
    try {
      const saved = localStorage.getItem('gt7_current_session_state');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
    return {
      sessionActive: false,
      raceStarted: false,
      raceFinished: false,
      maxSpeed: 0,
      frozenRaceTime: '--',
      frozenRaceTimeMs: 0,
      lastValidRaceTime: '--',
      lastValidRaceTimeMs: 0,
      lastValidBestLap: '--',
      lastValidLastLap: '--',
      lastValidPits: 0,
      correctedLaps: 0,
      lastValidFuel: null,
      lastValidFuelPercent: null,
      lastValidPosition: { x: null, y: null, z: null },
      targetLaps: 0,
      isBestLapStale: false,
      isLastLapStale: false,
      isRaceTimeStale: false,
      isPitsStale: false,
      isLapsStale: false,
      isFuelStale: false,
      isMaxSpeedStale: false,
      isPositionStale: false,
      lastTelemetry: {}
    };
  });

  const lowSpeedTicksRef = useRef<number>(0);

  const resetSession = () => {
    const fresh: GT7SessionState = {
      sessionActive: false,
      raceStarted: false,
      raceFinished: false,
      maxSpeed: 0,
      frozenRaceTime: '--',
      frozenRaceTimeMs: 0,
      lastValidRaceTime: '--',
      lastValidRaceTimeMs: 0,
      lastValidBestLap: '--',
      lastValidLastLap: '--',
      lastValidPits: 0,
      correctedLaps: 0,
      lastValidFuel: null,
      lastValidFuelPercent: null,
      lastValidPosition: { x: null, y: null, z: null },
      targetLaps: 0,
      isBestLapStale: false,
      isLastLapStale: false,
      isRaceTimeStale: false,
      isPitsStale: false,
      isLapsStale: false,
      isFuelStale: false,
      isMaxSpeedStale: false,
      isPositionStale: false,
      lastTelemetry: {}
    };
    setGt7Session(fresh);
    lowSpeedTicksRef.current = 0;
    try {
      localStorage.setItem('gt7_current_session_state', JSON.stringify(fresh));
    } catch (e) {}
  };

  const finalizeRace = () => {
    setGt7Session(prev => {
      const curTimeText = prev.lastTelemetry?.total_race_time_text || prev.lastValidRaceTime;
      const next: GT7SessionState = {
        ...prev,
        raceFinished: true,
        frozenRaceTime: curTimeText !== '--' ? curTimeText : prev.frozenRaceTime
      };
      try {
        localStorage.setItem('gt7_current_session_state', JSON.stringify(next));
      } catch (e) {}
      return next;
    });
  };

  const setTargetLaps = (laps: number) => {
    setGt7Session(prev => {
      const next: GT7SessionState = {
        ...prev,
        targetLaps: laps
      };
      try {
        localStorage.setItem('gt7_current_session_state', JSON.stringify(next));
      } catch (e) {}
      return next;
    });
  };

  const updateRaceState = (normRaw: any) => {
    setGt7Session(prev => {
      let isNewSession = false;
      const curTime = normRaw.total_race_time_ms || 0;
      const prevTime = prev.lastTelemetry?.total_race_time_ms || 0;

      // Start new session / reset if time goes backwards drastically (ex: restarts race or enters lobby)
      if (curTime < 2000 && prevTime > 5000) {
        isNewSession = true;
      }
      // Or if previous was finished and we are starting a brand new timer
      if (prev.raceFinished && curTime > 0 && curTime < 5000 && (normRaw.completed_laps || 0) === 0) {
        isNewSession = true;
      }

      const active = isNewSession ? true : (prev.sessionActive || curTime > 0);
      const raceStarted = isNewSession ? false : (prev.raceStarted || curTime > 0);

      // Best Lap parsing and formatting safely with last valid logic
      let bestLapStr = prev.lastValidBestLap;
      let isBestLapStale = prev.isBestLapStale;
      if (normRaw.best_lap_text && normRaw.best_lap_text !== '--' && normRaw.best_lap_text !== '00:00.000' && normRaw.best_lap_text !== '0:00.000') {
        bestLapStr = normRaw.best_lap_text;
        isBestLapStale = false;
      } else if (normRaw.best_lap_ms && normRaw.best_lap_ms > 0) {
        bestLapStr = new Date(normRaw.best_lap_ms).toISOString().substr(14, 9);
        isBestLapStale = false;
      } else if (bestLapStr === '--') {
        isBestLapStale = false;
      } else {
        isBestLapStale = true;
      }

      // Last Lap parsing and formatting safely with last valid logic
      let lastLapStr = prev.lastValidLastLap;
      let isLastLapStale = prev.isLastLapStale;
      if (normRaw.last_lap_text && normRaw.last_lap_text !== '--' && normRaw.last_lap_text !== '00:00.000' && normRaw.last_lap_text !== '0:00.000') {
        lastLapStr = normRaw.last_lap_text;
        isLastLapStale = false;
      } else if (normRaw.last_lap_ms && normRaw.last_lap_ms > 0) {
        lastLapStr = new Date(normRaw.last_lap_ms).toISOString().substr(14, 9);
        isLastLapStale = false;
      } else if (lastLapStr === '--') {
        isLastLapStale = false;
      } else {
        isLastLapStale = true;
      }

      // Pit count with last valid logic
      let pits = prev.lastValidPits;
      let isPitsStale = prev.isPitsStale;
      if (normRaw.pit_stops_count !== null && normRaw.pit_stops_count !== undefined && !isNaN(normRaw.pit_stops_count)) {
        pits = normRaw.pit_stops_count;
        isPitsStale = false;
      } else {
        isPitsStale = true;
      }

      // Max speed with last valid logic
      const currentSpeed = normRaw.velocidade ?? normRaw.speed_kmh ?? 0;
      const maxSpeed = isNewSession ? currentSpeed : Math.max(prev.maxSpeed, currentSpeed);
      const isMaxSpeedStale = currentSpeed === 0 && maxSpeed > 0;

      // Laps corrected
      const rawLaps = normRaw.completed_laps || 0;
      const correctedLaps = Math.max(0, rawLaps - 1);
      const isLapsStale = normRaw.completed_laps === null || normRaw.completed_laps === undefined || isNaN(normRaw.completed_laps);

      // Fuel with last valid logic
      let lastValidFuel = prev.lastValidFuel;
      let lastValidFuelPercent = prev.lastValidFuelPercent;
      let isFuelStale = prev.isFuelStale;
      if (normRaw.fuel !== null && normRaw.fuel !== undefined && !isNaN(normRaw.fuel)) {
        lastValidFuel = normRaw.fuel;
        isFuelStale = false;
      }
      if (normRaw.fuel_percent !== null && normRaw.fuel_percent !== undefined && !isNaN(normRaw.fuel_percent)) {
        lastValidFuelPercent = normRaw.fuel_percent;
        isFuelStale = false;
      }
      if (normRaw.fuel === null && normRaw.fuel_percent === null) {
        isFuelStale = true;
      }

      // Position with last valid logic
      let lastValidPosition = prev.lastValidPosition;
      let isPositionStale = prev.isPositionStale;
      if (normRaw.map && normRaw.map.car_position && normRaw.map.car_position.x !== null) {
        lastValidPosition = normRaw.map.car_position;
        isPositionStale = false;
      } else {
        isPositionStale = true;
      }

      // Race finished freeze setup / fallback / priority detection
      let raceFinished = isNewSession ? false : prev.raceFinished;

      // Priority 1: telemetry.raceFinished or corridaFinalizada is true
      const rawFinished = normRaw.raceFinished || normRaw.corridaFinalizada || false;

      // Priority 2: targetLaps configuration hits
      const targetLaps = prev.targetLaps || 0;
      const hitTargetLaps = targetLaps > 0 && correctedLaps >= targetLaps;

      // Fallback Priority 3 logic
      let fallbackTriggered = false;
      if (!isNewSession && !raceFinished) {
        const prevLaps = prev.lastTelemetry?.completed_laps || 0;
        const timeStopped = Math.abs(curTime - prevTime) < 100;
        const lapsStopped = rawLaps === prevLaps;
        const currentThrottle = normRaw.throttle_percent ?? 0;

        if (rawLaps >= prevLaps && currentSpeed < 20 && currentThrottle === 0) {
          lowSpeedTicksRef.current += 1;
          // ~4 seconds is 8 ticks since update interval is 500ms (2Hz)
          if (lowSpeedTicksRef.current >= 8 && (rawLaps > prevLaps || (timeStopped && lapsStopped))) {
            fallbackTriggered = true;
          }
        } else {
          lowSpeedTicksRef.current = 0;
        }
      }

      if (!raceFinished) {
        if (rawFinished || hitTargetLaps || fallbackTriggered) {
          raceFinished = true;
        }
      } else if (isNewSession) {
        lowSpeedTicksRef.current = 0;
      }

      // Race time with last valid logic
      let lastValidRaceTime = prev.lastValidRaceTime;
      let lastValidRaceTimeMs = prev.lastValidRaceTimeMs;
      let isRaceTimeStale = prev.isRaceTimeStale;
      if (normRaw.total_race_time_text && normRaw.total_race_time_text !== '--' && normRaw.total_race_time_text !== '00:00:00.000') {
        lastValidRaceTime = normRaw.total_race_time_text;
        lastValidRaceTimeMs = normRaw.total_race_time_ms || 0;
        isRaceTimeStale = false;
      } else if (normRaw.total_race_time_ms && normRaw.total_race_time_ms > 0) {
        lastValidRaceTime = new Date(normRaw.total_race_time_ms).toISOString().substr(11, 12);
        lastValidRaceTimeMs = normRaw.total_race_time_ms;
        isRaceTimeStale = false;
      } else {
        isRaceTimeStale = true;
      }

      // Frozen race time rules
      let frozenTime = prev.frozenRaceTime;
      if (isNewSession) {
        frozenTime = '--';
      } else if (!prev.raceFinished && raceFinished) {
        frozenTime = lastValidRaceTime;
      } else if (!raceFinished) {
        frozenTime = lastValidRaceTime;
      }

      const nextSessionState: GT7SessionState = {
        sessionActive: active,
        raceStarted,
        raceFinished,
        maxSpeed,
        frozenRaceTime: frozenTime,
        frozenRaceTimeMs: raceFinished ? (prev.frozenRaceTimeMs || lastValidRaceTimeMs) : 0,
        lastValidRaceTime,
        lastValidRaceTimeMs,
        lastValidBestLap: bestLapStr,
        lastValidLastLap: lastLapStr,
        lastValidPits: pits,
        correctedLaps,
        lastValidFuel,
        lastValidFuelPercent,
        lastValidPosition,
        targetLaps,
        isBestLapStale,
        isLastLapStale,
        isRaceTimeStale,
        isPitsStale,
        isLapsStale,
        isFuelStale,
        isMaxSpeedStale,
        isPositionStale,
        lastTelemetry: normRaw
      };

      try {
        localStorage.setItem('gt7_current_session_state', JSON.stringify(nextSessionState));
      } catch (e) {}

      return nextSessionState;
    });
  };

  useEffect(() => {
    const isMobileApk = () => window.GT7_BRIDGE_MODE === 'mobile-apk' || typeof window.GT7AndroidBridge !== 'undefined' || window.__gt7MobileBridgeActive;
    if (isMobileApk()) {
        if (connectionMode !== 'mobile_apk_bridge' && connectionMode !== 'mobile_apk_push' && connectionMode !== 'auto') {
           setConnectionMode('mobile_apk_push');
        }
    }
    
    const handler = () => {
        if (connectionMode !== 'mobile_apk_bridge' && connectionMode !== 'mobile_apk_push' && connectionMode !== 'auto') {
           setConnectionMode('mobile_apk_push');
        }
    };
    window.addEventListener('gt7-bridge-mobile-ready', handler);
    return () => window.removeEventListener('gt7-bridge-mobile-ready', handler);
  }, [connectionMode]);

  useEffect(() => {
    const handlePushEvent = (event: any) => {
        // We received data from direct push
        if (event.detail) {
           handleIncomingData(event.detail, 'mobile_apk_push');
           window.__gt7MobileBridgeActive = true;
           window.__gt7MobileTelemetry = event.detail;
           window.__gt7LastTelemetry = event.detail;
           try {
             localStorage.setItem('gt7LastMobileTelemetry', JSON.stringify(event.detail));
           } catch(e) {}
           
           if (connectionMode === 'auto' || connectionMode === 'mobile_apk_bridge') {
               setConnectionMode('mobile_apk_push');
           }
        }
    };

    window.addEventListener('gt7-mobile-telemetry', handlePushEvent);
    window.addEventListener('gt7-telemetry', handlePushEvent);
    window.addEventListener('gt7-telemetry-update', handlePushEvent);

    return () => {
       window.removeEventListener('gt7-mobile-telemetry', handlePushEvent);
       window.removeEventListener('gt7-telemetry', handlePushEvent);
       window.removeEventListener('gt7-telemetry-update', handlePushEvent);
    };
  }, [connectionMode]);

  const wsRef = useRef<WebSocket | null>(null);
  const pollIntervalRef = useRef<number | null>(null);
  const sessionDataRef = useRef<GT7TelemetrySession | null>(null);
  const lastSampleTimeRef = useRef<number>(0);
  const currentTelemetryRef = useRef<TelemetryData>(getDefaultTelemetry());

  useEffect(() => {
    localStorage.setItem('gt7_bridge_pc_lan_ip', pcLanIp);
    localStorage.setItem('gt7Ps5Ip', pcLanIp);
  }, [pcLanIp]);

  useEffect(() => {
    localStorage.setItem('gt7.telemetry.connectionMode', connectionMode);
  }, [connectionMode]);

  useEffect(() => {
    localStorage.setItem('gt7.telemetry.manualApiUrl', manualApiUrl);
  }, [manualApiUrl]);

  useEffect(() => {
    localStorage.setItem('gt7.telemetry.manualWsUrl', manualWsUrl);
  }, [manualWsUrl]);

  useEffect(() => {
    localStorage.setItem('gt7.telemetry.raspberryUrl', raspberryUrl);
  }, [raspberryUrl]);

  useEffect(() => {
    localStorage.setItem('gt7_recording_enabled', recordingEnabled.toString());
  }, [recordingEnabled]);

  const generateSessionId = () => crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2);

  const handleIncomingData = (rawPayload: any, url: string) => {
    let isValidData = true;
    if (rawPayload.decodeOk === false || rawPayload.decryptOk === false || rawPayload.status === 'aguardando_dados_validos' || rawPayload.status === 'erro') {
      isValidData = false;
    }

    if (!isValidData) {
      setConnectionState('waiting_valid_data');
      return;
    }

    setConnectionState('connected');
    const nowMs = Date.now();

    const normData = normalizeTelemetry(rawPayload);
    updateRaceState(normData);
    const speed = Number(getAliasValue(rawPayload, ALIASES.speed_kmh)) || 0;
    
    let rpm = Number(getAliasValue(rawPayload, ALIASES.rpm));
    if (isNaN(rpm) || !isFinite(rpm) || rpm < 0 || rpm > 30000) {
        rpm = currentTelemetryRef.current.rpm; // Keep last valid
    }

    let gearRaw = getAliasValue(rawPayload, ALIASES.gear);
    let gear = (gearRaw === 0 || gearRaw === '0' || !gearRaw) ? 'N' : gearRaw;
    
    let throttle = Number(getAliasValue(rawPayload, ALIASES.throttle_percent)) || 0;
    if (throttle > 100) throttle = (throttle / 255) * 100;
    
    let brake = Number(getAliasValue(rawPayload, ALIASES.brake_percent)) || 0;
    if (brake > 100) brake = (brake / 255) * 100;
    const fuel = getAliasValue(rawPayload, ALIASES.fuel) !== null ? Number(getAliasValue(rawPayload, ALIASES.fuel)) : null;
    const fuelPercent = getAliasValue(rawPayload, ALIASES.fuel_percent) !== null ? Number(getAliasValue(rawPayload, ALIASES.fuel_percent)) : null;
    const bestLapMs = getAliasValue(rawPayload, ALIASES.best_lap_ms) !== null ? Number(getAliasValue(rawPayload, ALIASES.best_lap_ms)) : null;
    const lastLapMs = getAliasValue(rawPayload, ALIASES.last_lap_ms) !== null ? Number(getAliasValue(rawPayload, ALIASES.last_lap_ms)) : null;
    const totalRaceTimeMs = Number(getAliasValue(rawPayload, ALIASES.total_race_time_ms)) || 0;
    
    let completedLaps = Number(getAliasValue(rawPayload, ALIASES.completed_laps)) || 0;
    if (completedLaps > 10000 || completedLaps < 0) completedLaps = currentTelemetryRef.current.completed_laps;

    const rain = getAliasValue(rawPayload, ALIASES.rain_intensity) !== null ? Number(getAliasValue(rawPayload, ALIASES.rain_intensity)) : null;
    const tc = getAliasValue(rawPayload, ALIASES.traction_control);
    const pitStops = Number(getAliasValue(rawPayload, ALIASES.pit_stops_count)) || 0;
    
    let position = { x: null, y: null, z: null };
    let mapRaw = rawPayload.map || rawPayload.track_map || rawPayload.position_xyz || rawPayload.car_position || rawPayload.position;
    if (!mapRaw && rawPayload.x !== undefined && rawPayload.y !== undefined) mapRaw = rawPayload;
    if (mapRaw && typeof mapRaw === 'object') {
       position = {
          x: mapRaw.x ?? mapRaw.posX ?? mapRaw.positionX ?? null,
          y: mapRaw.y ?? mapRaw.posY ?? mapRaw.positionY ?? null,
          z: mapRaw.z ?? mapRaw.posZ ?? mapRaw.positionZ ?? null
       };
    }

    let path_points = currentTelemetryRef.current.map.path_points || [];
    if (typeof position.x === 'number' && typeof position.y === 'number') {
        const lastPt = path_points[path_points.length - 1];
        if (!lastPt || Math.abs(lastPt.x - position.x) > 5 || Math.abs(lastPt.y - position.y) > 5) {
           path_points = [...path_points, {x: position.x, y: position.y}];
           if (path_points.length > 1500) path_points = path_points.slice(path_points.length - 1500);
        }
    }

    let detectedSource = connectionMode;
    if (connectionMode === 'auto') {
      if (url.includes('127.0.0.1')) detectedSource = 'mobile_apk_bridge';
      else if (url.includes('localhost') || pcLanIp && url.includes(pcLanIp)) detectedSource = 'pc_bridge';
      else detectedSource = 'manual';
    }

    const tData: TelemetryData = {
      session_id: sessionDataRef.current?.session_id || '',
      timestamp: new Date().toISOString(),
      source: detectedSource,
      connected: true,
      speed_kmh: speed,
      rpm: rpm,
      gear: gear,
      throttle_percent: throttle,
      brake_percent: brake,
      fuel: fuel,
      fuel_percent: fuelPercent,
      best_lap_ms: bestLapMs,
      best_lap_text: bestLapMs ? new Date(bestLapMs).toISOString().substr(14, 9) : null,
      last_lap_ms: lastLapMs,
      last_lap_text: lastLapMs ? new Date(lastLapMs).toISOString().substr(14, 9) : null,
      total_race_time_ms: totalRaceTimeMs,
      total_race_time_text: new Date(Math.max(0, totalRaceTimeMs)).toISOString().substr(11, 12),
      completed_laps: completedLaps,
      rain_intensity: rain,
      traction_control: tc,
      pit_stops_count: pitStops,
      map: {
        track_id: rawPayload.track_id || null,
        track_name: rawPayload.track_name || null,
        car_position: position,
        heading: rawPayload.heading || null,
        lap_progress_percent: rawPayload.lap_progress_percent || null,
        path_points: path_points
      }
    };
    
    currentTelemetryRef.current = tData;
    setTelemetry(tData);

    if (recordingEnabled) {
      if (!sessionDataRef.current) {
        if ((speed > 1 || rpm > 1000) && (!sessionDataRef.current || (sessionDataRef.current as any)._initSpeedMs === undefined)) {
            // Wait 2 secs logic simplified: if we have speed > 1, create session
            const newSessionId = generateSessionId();
            tData.session_id = newSessionId;
            sessionDataRef.current = {
                session_id: newSessionId,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
                source: detectedSource,
                pc_bridge_url: url,
                track_name: tData.map.track_name,
                car_name: rawPayload.car_name || null,
                started_at: new Date().toISOString(),
                ended_at: null,
                status: 'recording',
                best_lap_ms: bestLapMs,
                best_lap_text: tData.best_lap_text,
                total_race_time_ms: totalRaceTimeMs,
                total_race_time_text: tData.total_race_time_text || '',
                completed_laps: completedLaps,
                max_speed_kmh: speed,
                max_rpm: rpm,
                min_fuel: fuel,
                max_rain_intensity: rain,
                traction_control_last: tc,
                pit_stops_count: pitStops,
                notes: null
            };
        }
      }

      if (sessionDataRef.current && (nowMs - lastSampleTimeRef.current >= 500)) { // 2Hz -> 500ms
        lastSampleTimeRef.current = nowMs;
        const sample: GT7TelemetrySample = {
            sample_id: generateSessionId(),
            session_id: sessionDataRef.current.session_id,
            timestamp: tData.timestamp,
            speed_kmh: speed,
            rpm: rpm,
            gear: gear,
            throttle_percent: throttle,
            brake_percent: brake,
            fuel: fuel,
            fuel_percent: fuelPercent,
            rain_intensity: rain,
            traction_control: tc,
            completed_laps: completedLaps,
            total_race_time_ms: totalRaceTimeMs,
            position_x: position.x,
            position_y: position.y,
            position_z: position.z,
            heading: tData.map.heading,
            lap_progress_percent: tData.map.lap_progress_percent,
            decodeOk: rawPayload.decodeOk,
            packetVersion: rawPayload.packetVersion || null
        };
        saveTelemetrySample(sample).catch(console.error);

        // Update session stats
        sessionDataRef.current.max_speed_kmh = Math.max(sessionDataRef.current.max_speed_kmh, speed);
        sessionDataRef.current.max_rpm = Math.max(sessionDataRef.current.max_rpm, rpm);
        if (fuel !== null) {
            sessionDataRef.current.min_fuel = sessionDataRef.current.min_fuel === null ? fuel : Math.min(sessionDataRef.current.min_fuel, fuel);
        }
        if (rain !== null) {
            sessionDataRef.current.max_rain_intensity = sessionDataRef.current.max_rain_intensity === null ? rain : Math.max(sessionDataRef.current.max_rain_intensity, rain);
        }
        sessionDataRef.current.updated_at = new Date().toISOString();
        if (!gt7Session.raceFinished) {
            sessionDataRef.current.total_race_time_ms = totalRaceTimeMs;
            sessionDataRef.current.total_race_time_text = tData.total_race_time_text || '';
        } else if (gt7Session.frozenRaceTime && gt7Session.frozenRaceTime !== '--') {
            sessionDataRef.current.total_race_time_text = gt7Session.frozenRaceTime;
        }
        sessionDataRef.current.completed_laps = Math.max(0, completedLaps - 1);
        sessionDataRef.current.best_lap_ms = bestLapMs;
        sessionDataRef.current.best_lap_text = gt7Session.lastValidBestLap !== '--' ? gt7Session.lastValidBestLap : tData.best_lap_text;
        
        // Save Map Point if x/y numbers
        if (typeof position.x === 'number' && typeof position.y === 'number') {
            const pt: GT7TelemetryMapPoint = {
                point_id: generateSessionId(),
                session_id: sessionDataRef.current.session_id,
                timestamp: tData.timestamp,
                lap_number: completedLaps + 1,
                x: position.x,
                y: position.y,
                z: position.z,
                speed_kmh: speed,
                brake_percent: brake,
                throttle_percent: throttle,
                rain_intensity: rain
            };
            saveTelemetryMapPoint(pt).catch(console.error);
        }

        saveTelemetrySession(sessionDataRef.current).catch(console.error);
      }
    } else if (sessionDataRef.current) {
        // user turned off recording, end session immediately
        sessionDataRef.current.status = 'finished';
        sessionDataRef.current.ended_at = new Date().toISOString();
        saveTelemetrySession(sessionDataRef.current).catch(console.error);
        sessionDataRef.current = null;
    }
  };

  useEffect(() => {
    let urlsToTry: string[] = [];
    if (connectionMode === 'mobile_apk_bridge') {
      urlsToTry.push('ws://127.0.0.1:8787/ws');
    } else if (connectionMode === 'pc_bridge') {
      urlsToTry.push('ws://localhost:8787/ws');
      if (pcLanIp) urlsToTry.push(`ws://${pcLanIp}:8787/ws`);
    } else if (connectionMode === 'manual') {
      if (manualWsUrl) urlsToTry.push(manualWsUrl);
    } else if (connectionMode === 'raspberry_bridge') {
      let rWs = 'ws://192.168.1.70:8787';
      if (raspberryUrl) {
        try {
          const u = new URL(raspberryUrl);
          rWs = `ws://${u.host}`;
        } catch (e) {}
      }
      urlsToTry.push(rWs);
      urlsToTry.push(`${rWs}/ws`);
    } else {
      // auto
      urlsToTry.push('ws://127.0.0.1:8787/ws');
      urlsToTry.push('ws://localhost:8787/ws');
      const lastWorkingWs = localStorage.getItem('gt7.telemetry.lastWorkingWsUrl');
      if (lastWorkingWs) urlsToTry.push(lastWorkingWs);
      if (pcLanIp) urlsToTry.push(`ws://${pcLanIp}:8787/ws`);
      if (manualWsUrl) urlsToTry.push(manualWsUrl);
    }

    let isUnmounted = false;
    let urlIndex = 0;
    let activeTimeouts: any[] = [];

    const connectWS = () => {
      if (isUnmounted || urlIndex >= urlsToTry.length) {
         if (urlIndex > 0) setConnectionState('offline');
         startPolling();
         return;
       }
      const url = urlsToTry[urlIndex];
      setConnectionState('connecting');
      try {
        const ws = new WebSocket(url);
        ws.onopen = () => {
          if (isUnmounted) { ws.close(); return; }
          setConnectionState('connected');
        };
        ws.onmessage = (event) => {
          if (isUnmounted) return;
          try {
            const data = JSON.parse(event.data);
            handleIncomingData(data, url);
            localStorage.setItem('gt7.telemetry.lastWorkingWsUrl', url);
          } catch(e) {}
        };
        ws.onerror = (e) => {
          if (window.location.protocol === 'https:') {
              setConnectionState('blocked');
          }
        };
        ws.onclose = () => {
          wsRef.current = null;
          if (!isUnmounted) {
            urlIndex++;
            const tId = setTimeout(connectWS, 1000); // Try next URL or retry after 1s
            activeTimeouts.push(tId);
          }
        };
        wsRef.current = ws;
      } catch (err) {
        urlIndex++;
        const tId = setTimeout(connectWS, 500);
        activeTimeouts.push(tId);
      }
    };

    const startPolling = () => {
        if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
        
        let noDataCounter = 0;

        let pollUrls: string[] = [];

        if (connectionMode === 'mobile_apk_bridge') {
          pollUrls.push('http://127.0.0.1:8787/api/fields');
        } else if (connectionMode === 'pc_bridge') {
          pollUrls.push('http://localhost:8787/api/fields');
          if (pcLanIp) pollUrls.push(`http://${pcLanIp}:8787/api/fields`);
        } else if (connectionMode === 'manual') {
          if (manualApiUrl) pollUrls.push(manualApiUrl);
        } else if (connectionMode === 'raspberry_bridge') {
          if (raspberryUrl) pollUrls.push(raspberryUrl);
        } else {
          // auto
          pollUrls.push('http://127.0.0.1:8787/api/fields');
          pollUrls.push('http://localhost:8787/api/fields');
          const lastWorkingApi = localStorage.getItem('gt7.telemetry.lastWorkingApiUrl');
          if (lastWorkingApi) pollUrls.push(lastWorkingApi);
          if (pcLanIp) pollUrls.push(`http://${pcLanIp}:8787/api/fields`);
          if (manualApiUrl) pollUrls.push(manualApiUrl);
          
          // Fallback legacy URLs
          pollUrls.push('http://127.0.0.1:8787/api/telemetry');
          pollUrls.push('http://localhost:8787/api/telemetry');
          if (pcLanIp) pollUrls.push(`http://${pcLanIp}:8787/api/telemetry`);
        }
        
        // Remove duplicates and empty
        pollUrls = Array.from(new Set(pollUrls.filter(Boolean)));
        
        if (pollUrls.length === 0) return;
        
        let pIndex = 0;
        
        pollIntervalRef.current = window.setInterval(async () => {
           if (isUnmounted || wsRef.current?.readyState === WebSocket.OPEN) return;
           
           try {
               if (window.__gt7MobileTelemetry && (connectionMode === 'mobile_apk_push' || connectionMode === 'auto')) {
                   if ((window as any).__last_gt7MobileTelemetry !== window.__gt7MobileTelemetry) {
                       (window as any).__last_gt7MobileTelemetry = window.__gt7MobileTelemetry;
                       handleIncomingData(window.__gt7MobileTelemetry, 'mobile_apk_push');
                       noDataCounter = 0;
                   }
                   return;
               }

               if (window.__gt7LastTelemetry && (connectionMode === 'mobile_apk_push' || connectionMode === 'auto')) {
                   if ((window as any).__last_gt7LastTelemetry !== window.__gt7LastTelemetry) {
                       (window as any).__last_gt7LastTelemetry = window.__gt7LastTelemetry;
                       handleIncomingData(window.__gt7LastTelemetry, 'mobile_apk_push');
                       noDataCounter = 0;
                   }
                   return;
               }

               if ((connectionMode === 'mobile_apk_bridge' || connectionMode === 'mobile_apk_push' || connectionMode === 'auto') && window.GT7AndroidBridge) {
                   const jsonStr = window.GT7AndroidBridge.getFields();
                   if (jsonStr) {
                       const data = JSON.parse(jsonStr);
                       handleIncomingData(data, 'GT7AndroidBridge');
                       noDataCounter = 0;
                       return;
                   }
               }
           } catch (e) {
               console.warn("Error reading from GT7AndroidBridge", e);
           }
           
           if (pollUrls.length === 0) return;
           
           try {
             if (pIndex >= pollUrls.length) pIndex = 0;
             const url = pollUrls[pIndex];
             const res = await fetch(url);
             if (res.ok) {
                 const data = await res.json();
                 handleIncomingData(data, url);
                 localStorage.setItem('gt7.telemetry.lastWorkingApiUrl', url);
                 pIndex = pollUrls.indexOf(url); // stick to working url
                 noDataCounter = 0;
             } else {
                 pIndex++;
                 noDataCounter++;
             }
           } catch {
             pIndex++;
             noDataCounter++;
           }
           
           if (noDataCounter > 120 && sessionDataRef.current) { // 120 * 500ms = 60s
              sessionDataRef.current.status = 'finished';
              sessionDataRef.current.ended_at = new Date().toISOString();
              saveTelemetrySession(sessionDataRef.current).catch(console.error);
              sessionDataRef.current = null;
           }
        }, 500);
    };

    connectWS();

    return () => {
      isUnmounted = true;
      activeTimeouts.forEach(tId => clearTimeout(tId));
      if (wsRef.current) wsRef.current.close();
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [connectionMode, pcLanIp, recordingEnabled, raspberryUrl]);

  return (
    <TelemetryContext.Provider value={{ 
      telemetry, connectionState, pcLanIp, setPcLanIp, 
      connectionMode, setConnectionMode, 
      manualApiUrl, setManualApiUrl,
      manualWsUrl, setManualWsUrl,
      raspberryUrl, setRaspberryUrl,
      recordingEnabled, setRecordingEnabled,
      gt7Session, resetSession,
      finalizeRace, setTargetLaps
    }}>
      {children}
    </TelemetryContext.Provider>
  );
};

export const useTelemetry = () => {
  const context = useContext(TelemetryContext);
  if (!context) throw new Error('useTelemetry must be used within a TelemetryProvider');
  return context;
};
