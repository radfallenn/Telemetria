import { Car, Brand } from '../types';
import { GT7_V2_DATA } from '../data/gt7V2Dataset';
import { GT7_V3_DATA } from '../data/gt7V3Dataset';
import { GT7_V4_DATA } from '../data/gt7V4Dataset';

export const transformV4Data = (): { cars: Car[], brands: Brand[], tracks: any[] } => {
  const cars: Car[] = GT7_V4_DATA.search_ready.cars.map((c: any) => ({
    car_id: `v4-${c.id}`,
    car_slug: c.search_compact[0] || c.model.toLowerCase().replace(/\s+/g, '-'),
    brand_slug: c.maker.toLowerCase().replace(/\s+/g, '-'),
    brand_name: c.maker,
    car_name: c.model,
    full_display_name: c.display_name,
    year: c.year?.toString() || null,
    group_code: null,
    category: c.tags.includes('Gr.3') ? 'Gr.3' : c.tags.includes('Gr.4') ? 'Gr.4' : 'Road Car',
    type: c.body_style || 'Road Car',
    model_label: c.model,
    image_file: '',
    image_url: null,
    thumbnail_file: `${c.id}.webp`,
    thumbnail_url: `assets/cars/${c.id}.webp`,
    search_aliases: [...c.search_terms, ...c.aliases],
    insertionCount: 0
  }));

  const brandsMap = new Map<string, Brand>();
  cars.forEach(c => {
    if (!brandsMap.has(c.brand_name)) {
      brandsMap.set(c.brand_name, {
        maker_id: `v4-brand-${c.brand_slug}`,
        brand_slug: c.brand_slug,
        brand_name: c.brand_name,
        country_id: '',
        logo_file: '',
        logo_url: null,
        search_terms: [c.brand_name]
      });
    }
  });

  return { 
    cars, 
    brands: Array.from(brandsMap.values()),
    tracks: GT7_V4_DATA.search_ready.tracks
  };
};

export const transformV3Data = (): { cars: Car[], brands: Brand[] } => {
  // Extract cars from models_by_maker for consistency
  const cars: Car[] = Object.entries(GT7_V3_DATA.autocomplete.models_by_maker).flatMap(([maker, models]) => 
    models.map((model: string, index: number) => ({
      car_id: `v3-${maker}-${index}`,
      car_slug: model.toLowerCase().replace(/\s+/g, '-'),
      brand_slug: maker.toLowerCase().replace(/\s+/g, '-'),
      brand_name: maker,
      car_name: model,
      full_display_name: `${maker} ${model}`,
      year: model.match(/\d{2,4}$/)?.[0] || null,
      group_code: null,
      category: 'Road Car',
      type: 'Road Car',
      model_label: model,
      image_file: '',
      image_url: null,
      thumbnail_file: '',
      thumbnail_url: null,
      search_aliases: [maker, model],
      insertionCount: 0
    }))
  );

  const brands: Brand[] = GT7_V3_DATA.autocomplete.makers.map((m, index) => ({
    maker_id: `v3-brand-${index}`, 
    brand_slug: m.toLowerCase().replace(/\s+/g, '-'),
    brand_name: m,
    country_id: '', 
    logo_file: '',
    logo_url: null,
    search_terms: [m]
  }));

  return { cars, brands };
};

export const transformV2Data = (): { cars: Car[], brands: Brand[] } => {
  // Extract cars from the models_by_maker structure to build Car objects
  const cars: Car[] = Object.entries(GT7_V2_DATA.autocomplete.models_by_maker).flatMap(([maker, models]) => 
    models.map((model: string, index: number) => ({
      car_id: `${maker}-${index}`,
      car_slug: model.toLowerCase().replace(/\s+/g, '-'),
      brand_slug: maker.toLowerCase().replace(/\s+/g, '-'),
      brand_name: maker,
      car_name: model,
      full_display_name: `${maker} ${model}`,
      year: model.match(/\d{2,4}$/)?.[0] || null,
      group_code: null,
      category: 'Road Car',
      type: 'Road Car',
      model_label: model,
      image_file: '',
      image_url: null,
      thumbnail_file: '',
      thumbnail_url: null,
      search_aliases: [maker, model],
      insertionCount: 0
    }))
  );

  const brands: Brand[] = GT7_V2_DATA.autocomplete.makers.map((m, index) => ({
    maker_id: String(index), 
    brand_slug: m.toLowerCase().replace(/\s+/g, '-'),
    brand_name: m,
    country_id: '', 
    logo_file: '',
    logo_url: null,
    search_terms: [m]
  }));

  return { cars, brands };
};
