export async function identifyCarBrand(carName: string): Promise<string | null> {
  if (!carName || carName.length < 3) return null;

  try {
    const response = await fetch(`/api/identify-brand?carName=${encodeURIComponent(carName)}`);
    if (!response.ok) {
      throw new Error(`Failed to identify car brand: ${response.statusText}`);
    }
    const result = await response.json();
    if (result.brand && result.brand !== "Unknown") {
      return result.brand;
    }
    return null;
  } catch (error) {
    console.error("Error identifying car brand:", error);
    return null;
  }
}
