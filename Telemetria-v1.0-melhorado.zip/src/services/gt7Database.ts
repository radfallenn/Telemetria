import { Car, Brand } from '../types';
import { transformV4Data } from './dataTransformer';

// Estado interno do banco processado
let processedCars: Car[] = [];
let processedBrands: Brand[] = [];
let processedTracks: any[] = [];
let localCustomCars: Car[] = [];

/**
 * Normaliza e processa os dados brutos.
 */
export const initializeGT7Database = (): void => {
  const { cars, brands, tracks } = transformV4Data();
  processedCars = cars;
  processedBrands = brands;
  processedTracks = tracks;
  processedCars.sort((a, b) => b.insertionCount - a.insertionCount);
};

export const addCustomCarsToDatabase = (customCars: any[]): void => {
  localCustomCars = customCars.map(c => ({
    ...c,
    insertionCount: 0,
    image_file: '',
    image_url: null,
    thumbnail_file: '',
    thumbnail_url: null
  }));
};

initializeGT7Database();

export const getAllCars = (): Car[] => [...localCustomCars, ...processedCars];

export const getAllBrands = (): Brand[] => processedBrands;

export const getAllTracks = (): any[] => processedTracks;

export const getBrandLogo = (brandName: string): string | null => {
  const brand = processedBrands.find(b => 
    b.brand_name.toLowerCase() === brandName.toLowerCase() ||
    b.search_terms.some(term => term.toLowerCase() === brandName.toLowerCase())
  );
  return (brand && brand.logo_file) ? brand.logo_file : null;
};

export const getCarsByBrand = (brandName: string): Car[] => {
  return [...localCustomCars, ...processedCars].filter(c => c.brand_name.toLowerCase() === brandName.toLowerCase());
};

// --- Funções de Busca ---

export const searchCars = (query: string): Car[] => {
  const normalizedQuery = query.toLowerCase();
  return [...localCustomCars, ...processedCars].filter(c => 
    c.full_display_name.toLowerCase().includes(normalizedQuery) ||
    (c.search_aliases && c.search_aliases.some(alias => alias.toLowerCase().includes(normalizedQuery)))
  );
};

export const searchTracks = (query: string): any[] => {
  const normalizedQuery = query.toLowerCase();
  return processedTracks.filter(t => 
    t.name.toLowerCase().includes(normalizedQuery) ||
    (t.aliases && t.aliases.some((alias: string) => alias.toLowerCase().includes(normalizedQuery)))
  );
};

export const findCarByName = (name: string): Car | null => {
  const normalizedName = name.toLowerCase();
  return [...localCustomCars, ...processedCars].find(c => 
    c.car_name.toLowerCase() === normalizedName ||
    c.full_display_name.toLowerCase() === normalizedName ||
    (c.search_aliases && c.search_aliases.some(alias => alias.toLowerCase() === normalizedName))
  ) || null;
};

// --- Função para incrementar inserções ---
export const incrementCarInsertion = (carId: string): void => {
  const car = processedCars.find(c => c.car_id === carId);
  if (car) {
    car.insertionCount += 1;
    // Reordena após atualização
    processedCars.sort((a, b) => b.insertionCount - a.insertionCount);
  }
};
