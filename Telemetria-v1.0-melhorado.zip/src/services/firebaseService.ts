import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, collection, getDocs, getDocFromServer } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL, uploadString } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

// Initialize Firebase app safely
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const isFirebaseConfigured = !!firebaseConfig.projectId;
export const auth = getAuth(app);
export const storage = getStorage(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Reduce retry time to prevent long hangs when permissions or network are invalid
// Default is 10 minutes, we'll set it to 10 seconds to allow faster fallbacks
if (isFirebaseConfigured) {
  // In Firebase v9+ Modular SDK, these are properties on the storage instance
  (storage as any).maxUploadRetryTime = 10000;
  (storage as any).maxOperationRetryTime = 10000;
}

let authPromise: Promise<any> | null = null;
export async function ensureFirebaseAuth() {
  if (!isFirebaseConfigured) return;
  if (auth.currentUser) return;
  if (!authPromise) {
    authPromise = signInAnonymously(auth).catch(err => {
      console.warn("Firebase Anonymous Auth failed to initialize:", err.message);
      // Suppress throw to allow gracefully failing storage uploads instead of crashing early
      return null;
    });
  }
  await authPromise;
}

// Keep the background init but wrap it in the promise
if (isFirebaseConfigured) {
  ensureFirebaseAuth().catch(() => {});
}

/**
 * Saves a thumbnail metadata to Firestore
 */
export async function saveThumbnailMetadataToFirestore(carName: string, thumbnailUrl: string): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const docRef = doc(db, 'users', auth.currentUser.uid, 'thumbnails', carName);
    await setDoc(docRef, { carName, thumbnailUrl, updatedAt: Date.now() });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser?.uid}/thumbnails/${carName}`, auth.currentUser);
  }
}

/**
 * Gets a thumbnail metadata from Firestore
 */
export async function getThumbnailMetadataFromFirestore(carName: string): Promise<string | null> {
  if (!isFirebaseConfigured) return null;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return null;
  try {
    const docRef = doc(db, 'users', auth.currentUser.uid, 'thumbnails', carName);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data().thumbnailUrl;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}/thumbnails/${carName}`, auth.currentUser);
  }
  return null;
}

/**
 * Saves a global thumbnail metadata to Firestore
 */
export async function saveGlobalThumbnailMetadata(carName: string, thumbnailUrl: string): Promise<void> {
  if (!isFirebaseConfigured) return;
  await ensureFirebaseAuth();
  if (!auth.currentUser) return;
  try {
    const docRef = doc(db, 'thumbnails', carName);
    await setDoc(docRef, { carName, thumbnailUrl, updatedAt: Date.now(), creator_uid: auth.currentUser.uid });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `thumbnails/${carName}`, auth.currentUser);
  }
}

/**
 * Gets all global thumbnail metadata from Firestore
 */
export async function getAllGlobalThumbnailMetadata(): Promise<Record<string, string>> {
  if (!isFirebaseConfigured) return {};
  try {
    const collRef = collection(db, 'thumbnails');
    const snapshot = await getDocs(collRef);
    const results: Record<string, string> = {};
    snapshot.docs.forEach(doc => {
      const data = doc.data();
      results[data.carName] = data.thumbnailUrl;
    });
    return results;
  } catch (error) {
    console.error('Error getting global thumbnails:', error);
    return {};
  }
}

/**
 * Uploads a File or Blob to Firebase Storage and returns its public download URL
 */
export async function uploadFileToFirebase(file: File | Blob, storagePath: string): Promise<string> {
  if (!isFirebaseConfigured) {
    throw new Error('Firebase is not configured. Check firebase-applet-config.json');
  }
  await ensureFirebaseAuth();
  if (!auth.currentUser) {
    throw new Error('Storage upload blocked: No authenticated user. Falling back to local storage.');
  }
  try {
    const fileRef = ref(storage, storagePath);
    const snapshot = await uploadBytes(fileRef, file);
    const downloadUrl = await getDownloadURL(snapshot.ref);
    return downloadUrl;
  } catch (error) {
    console.warn('Error uploading file to Firebase Storage (fallback will be used):', error);
    throw error;
  }
}

/**
 * Uploads a Base64 string/Data URL to Firebase Storage and returns its public download URL
 */
export async function uploadBase64ToFirebase(base64Data: string, storagePath: string): Promise<string> {
  if (!isFirebaseConfigured) {
    throw new Error('Firebase is not configured. Check firebase-applet-config.json');
  }
  await ensureFirebaseAuth();
  if (!auth.currentUser) {
    throw new Error('Storage upload blocked: No authenticated user. Falling back to local storage.');
  }
  try {
    const fileRef = ref(storage, storagePath);
    // Determine format if base64Data is a complete Data URL (e.g. data:image/png;base64,...)
    let uploadFormat: 'data_url' | 'base64' = 'base64';
    let dataToUpload = base64Data;
    
    if (base64Data.startsWith('data:')) {
      uploadFormat = 'data_url';
    }
    
    const snapshot = await uploadString(fileRef, dataToUpload, uploadFormat);
    const downloadUrl = await getDownloadURL(snapshot.ref);
    return downloadUrl;
  } catch (error) {
    console.warn('Error uploading base64 to Firebase Storage (fallback will be used):', error);
    throw error;
  }
}



/**
 * Uploads a car thumbnail directly to Firebase Storage and registers it in Firestore.
 * This replaces local IndexedDB-only writing with persistent cloud storage.
 * @param carName - The exact or customized name of the car.
 * @param image - The underlying File, Blob, or Data URL base64 string representing the thumbnail image.
 * @returns A promise resolving to the public download URL.
 */
export async function uploadThumbnailDirectly(carName: string, image: File | Blob | string): Promise<string> {
  if (!isFirebaseConfigured) {
    throw new Error('Firebase is not configured.');
  }

  const fileExt = image instanceof File ? (image.name.split('.').pop() || 'webp') : 'webp';
  const storagePath = `car_thumbnails/${encodeURIComponent(carName)}_${Date.now()}.${fileExt}`;
  
  try {
    let downloadUrl = '';
    if (typeof image === 'string') {
      downloadUrl = await uploadBase64ToFirebase(image, storagePath);
    } else {
      downloadUrl = await uploadFileToFirebase(image, storagePath);
    }

    // Register the metadata globally in Firestore "thumbnails" collection
    await saveGlobalThumbnailMetadata(carName, downloadUrl);
    
    // Register in user-specific thumbnail records if logged in
    if (auth.currentUser) {
      await saveThumbnailMetadataToFirestore(carName, downloadUrl);
    }

    return downloadUrl;
  } catch (error: any) {
    console.warn('Failed to upload thumbnail to cloud storage, falling back to local storage:', error);
    
    // Graceful fallback: If we have a base64 string, keep using it instead of failing
    // Storage errors like retry-limit-exceeded or unauthorized are caught here
    if (typeof image === 'string' && image.startsWith('data:')) {
      console.warn('Falling back to local base64 storage due to upload error');
      return image;
    }
    
    // If it's a file/blob, we could try to convert to base64, but for now we throw
    // as large files might exceed Firestore document limits if stored as base64
    throw error;
  }
}

/**
 * Uploads an evidence image directly to Firebase Storage.
 * This replaces local storage fallbacks with a secure cloud-persistent solution.
 * @param file - The File or Blob representing the evidence image.
 * @returns A promise resolving to the public download URL.
 */
export async function uploadEvidenceDirectly(file: File | Blob): Promise<string> {
  if (!isFirebaseConfigured) {
    throw new Error('Firebase is not configured.');
  }
  
  const userId = auth.currentUser ? auth.currentUser.uid : 'anonymous';
  const fileExt = file instanceof File ? (file.name.split('.').pop() || 'jpg') : 'jpg';
  const storagePath = `evidences/${userId}/${Date.now()}.${fileExt}`;
  
  try {
    return await uploadFileToFirebase(file, storagePath);
  } catch (error) {
    console.warn('Failed to upload evidence to storage, attempting base64 fallback:', error);
    
    // Fallback: Convert the file/blob to a base64 Data URL so it can still be processed/saved
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => reject(error); // Reject with original upload error if reader fails too
      reader.readAsDataURL(file);
    });
  }
}

