import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { isFirebaseConfigured, uploadBase64ToFirebase, uploadFileToFirebase } from './firebaseService';

export type TrackAssetType = 'logo' | 'background';

const safeSegment = (value: string) =>
  String(value || 'asset')
    .normalize('NFD') // decomposes characters like á to a + ´
    .replace(/[\u0300-\u036f]/g, '') // removes accents
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .slice(0, 80);

function dataUrlToBlob(dataUrl: string): Blob {
  const [header, base64] = dataUrl.split(',');
  const mime = header.match(/data:(.*?);base64/)?.[1] || 'image/webp';
  const binary = atob(base64 || '');
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

function extensionFromDataUrl(dataUrl: string) {
  const mime = dataUrl.match(/^data:image\/(.*?);base64/)?.[1] || 'webp';
  if (mime.includes('jpeg')) return 'jpg';
  if (mime.includes('svg')) return 'svg';
  return mime.replace(/[^a-z0-9]/gi, '') || 'webp';
}

export async function uploadTrackAsset(trackId: string, assetType: TrackAssetType, image: string): Promise<string> {
  if (!image) return '';
  if (!image.startsWith('data:image/')) return image;

  try {
    const ext = extensionFromDataUrl(image);
    const path = `tracks/${safeSegment(trackId)}/${assetType}_${Date.now()}.${ext}`;

    // Prefer Firebase if configured
    if (isFirebaseConfigured) {
      try {
        const publicUrl = await uploadBase64ToFirebase(image, path);
        
        // Even if using Firebase for storage, we might want to sync the record to Supabase if session exists
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from('track_assets').upsert({
            user_id: user.id,
            track_id: trackId,
            asset_type: assetType,
            image_url: publicUrl,
            storage_path: path,
            updated_at: new Date().toISOString()
          }, { onConflict: 'user_id,track_id,asset_type' });
        }
        
        return publicUrl;
      } catch (fbErr) {
        console.warn('Firebase track asset upload failed, falling back to Supabase:', fbErr);
      }
    }

    // Fallback to Supabase
    if (isSupabaseConfigured) {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return image;

      const blob = dataUrlToBlob(image);
      const supabasePath = `tracks/${user.id}/${safeSegment(trackId)}/${assetType}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from('gt7-assets')
        .upload(supabasePath, blob, {
          upsert: true,
          contentType: blob.type || `image/${ext}`,
          cacheControl: '3600'
        });

      if (!uploadError) {
        const { data: { publicUrl } } = supabase.storage.from('gt7-assets').getPublicUrl(supabasePath);
        await supabase.from('track_assets').upsert({
          user_id: user.id,
          track_id: trackId,
          asset_type: assetType,
          image_url: publicUrl,
          storage_path: supabasePath,
          updated_at: new Date().toISOString()
        }, { onConflict: 'user_id,track_id,asset_type' });
        return publicUrl;
      }
    }

    return image;
  } catch (err) {
    console.warn('Track asset upload failed due to exception; keeping local data URL:', err);
    return image;
  }
}

export async function getTrackAssetOverrides(): Promise<Record<string, string>> {
  if (!isSupabaseConfigured) return {};
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return {};

  const { data, error } = await supabase
    .from('track_assets')
    .select('track_id, asset_type, image_url')
    .eq('user_id', user.id);

  if (error || !data) {
    if (error) console.warn('Could not load track_assets:', error);
    return {};
  }

  return data.reduce((acc: Record<string, string>, item: any) => {
    const key = item.asset_type === 'background'
      ? `track_bg_${item.track_id}`
      : `track_${item.track_id}`;
    if (item.image_url) acc[key] = item.image_url;
    return acc;
  }, {});
}
