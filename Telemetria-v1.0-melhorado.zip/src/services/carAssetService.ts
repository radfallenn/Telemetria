import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { isFirebaseConfigured, uploadBase64ToFirebase, uploadFileToFirebase } from './firebaseService';

export interface CarAsset {
  id: string;
  user_id?: string | null;
  car_name: string;
  car_slug: string;
  image_url: string;
  storage_path?: string;
}

export async function uploadCarAsset(file: File | Blob | string, carName: string, carSlug: string): Promise<string> {
  const fileExt = file instanceof File ? (file.name.split('.').pop() || 'webp') : 'webp';
  const fileName = `${carSlug}_${Date.now()}.${fileExt}`;
  
  // Prefer Firebase if configured
  if (isFirebaseConfigured) {
    try {
      const storagePath = `cars/${fileName}`;
      let publicUrl = '';
      if (typeof file === 'string') {
        publicUrl = await uploadBase64ToFirebase(file, storagePath);
      } else {
        publicUrl = await uploadFileToFirebase(file, storagePath);
      }

      // Sync record to Supabase if session exists
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('car_assets').upsert({
          user_id: user.id,
          car_name: carName,
          car_slug: carSlug,
          image_url: publicUrl,
          storage_path: storagePath
        }, { onConflict: 'car_slug' });
      }
      
      return publicUrl;
    } catch (fbErr) {
      console.warn('Firebase car asset upload failed, falling back to Supabase/Local:', fbErr);
    }
  }

  // Fallback to Supabase
  if (isSupabaseConfigured) {
    const { data: { user } } = await supabase.auth.getUser();
    const owner = user?.id || 'public';
    const storagePath = `cars/${owner}/${fileName}`;
    
    let fileBody: File | Blob;
    if (typeof file === 'string') {
      const obj = await fetch(file);
      fileBody = await obj.blob();
    } else {
      fileBody = file;
    }
    
    const { error: uploadError } = await supabase.storage
      .from('gt7-assets')
      .upload(storagePath, fileBody, { upsert: true });

    if (!uploadError) {
      const { data: { publicUrl } } = supabase.storage
        .from('gt7-assets')
        .getPublicUrl(storagePath);

      await supabase.from('car_assets').upsert({
        user_id: user?.id || null,
        car_name: carName,
        car_slug: carSlug,
        image_url: publicUrl,
        storage_path: storagePath
      }, { onConflict: 'car_slug' });
        
      return publicUrl;
    }
  }

  // Final fallback to base64
  if (typeof file === 'string') {
    return file;
  }
  return new Promise((resolve, reject) => {
     const reader = new FileReader();
     reader.onload = (e) => resolve(e.target?.result as string);
     reader.onerror = (e) => reject(e);
     reader.readAsDataURL(file);
  });
}

export async function listCarAssets(): Promise<CarAsset[]> {
  if (!isSupabaseConfigured) return [];
  const { data, error } = await supabase
    .from('car_assets')
    .select('*');

  if (error) {
    console.warn("Error fetching car_assets, might not exist:", error);
    return [];
  }
  return data as CarAsset[];
}

export async function deleteCarAsset(carSlug: string): Promise<void> {
  if (!isSupabaseConfigured) return;
  const { data: asset } = await supabase
      .from('car_assets')
      .select('storage_path')
      .eq('car_slug', carSlug)
      .single();

  if (asset && asset.storage_path) {
      await supabase.storage.from('gt7-assets').remove([asset.storage_path]);
  }

  await supabase
    .from('car_assets')
    .delete()
    .eq('car_slug', carSlug);
}

export function subscribeToCarAssets(onUpdate: (assets: CarAsset[]) => void) {
  if (!isSupabaseConfigured) return () => {};
  const channel = supabase.channel('car_assets_changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'car_assets' }, async () => {
      const assets = await listCarAssets();
      onUpdate(assets);
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
