import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Track, Entry, LayoutProfile, UserProfile } from '../types';
import { INITIAL_TRACKS } from '../constants';
import { isFirebaseConfigured, uploadFileToFirebase, uploadEvidenceDirectly } from './firebaseService';
import { safeLocalStorage, safeSessionStorage } from '../lib/safeBrowserStorage';

let activeUserPromise: Promise<any> | null = null;
let lastAuthCheck = 0;

/**
 * Generic wrapper for Supabase calls without offline caching since localStorage is removed.
 */
async function safeSupabaseCall<T>(call: () => Promise<T>, defaultValue: T): Promise<T> {
  if (!isSupabaseConfigured) return defaultValue;
  try {
    return await call();
  } catch (error: any) {
    const errMsg = error?.message || error?.error?.message || String(error);
    if (errMsg.toLowerCase().includes('refresh token') || errMsg.toLowerCase().includes('refresh_token')) {
      safeLocalStorage.clear();
      safeSessionStorage.clear();
      window.location.reload();
      return defaultValue;
    }
    throw error;
  }
}

async function getAuthenticatedUser() {
  if (!isSupabaseConfigured) {
    return { data: { user: null }, error: null };
  }

  try {
    const { data: { session }, error: sessionErr } = await supabase.auth.getSession();
    if (session?.user) {
      return { data: { user: session.user }, error: null };
    }
  } catch (e: any) {
    console.warn('getSession threw an exception:', e);
  }

  const now = Date.now();
  if (activeUserPromise && now - lastAuthCheck < 10000) {
    return activeUserPromise;
  }
  
  activeUserPromise = supabase.auth.getUser()
    .then(res => {
      if (res.error && (res.error.message.toLowerCase().includes('refresh') || res.error.message.toLowerCase().includes('not found') || res.error.message.toLowerCase().includes('lock'))) {
        try { safeLocalStorage.clear(); } catch(e) {}
        try { safeSessionStorage.clear(); } catch(e) {}
        return { data: { user: null }, error: null };
      }
      return { data: { user: res.data.user || null }, error: res.error };
    })
    .catch(err => {
      if (err?.message?.toLowerCase().includes('refresh') || err?.message?.toLowerCase().includes('not found') || err?.message?.toLowerCase().includes('lock')) {
        try { safeLocalStorage.clear(); } catch(e) {}
        try { safeSessionStorage.clear(); } catch(e) {}
        return { data: { user: null }, error: null };
      }
      return { data: { user: null }, error: err };
    });
  
  lastAuthCheck = now;
  return activeUserPromise;
}

export const supabaseService = {
  // Profile
  async getProfile(): Promise<UserProfile | null> {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return null;
    
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error);
        return null;
      }
      return data;
    }, null);
  },
  
  async saveProfile(profile: Partial<UserProfile>) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      const payload = {
        id: user.id,
        ...profile
      };
      const { error } = await supabase.from('profiles').upsert(payload);
      if (error) {
        console.error('Supabase error saving profile:', error);
        if (error.code === 'PGRST204' || error.message?.includes('schema cache') || error.message?.includes('column') || error.code === '42703') {
           throw new Error(`Outdated tables on Supabase.\n\nError details: ${error.message}\n\nYou must copy the 'SUPABASE_SCHEMA.sql' code and execute it in your Supabase SQL Editor. The schema cache will automatically refresh.`);
        }
        throw error;
      }
    }, undefined);
  },

  async updateOnlineStatus() {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      await supabase.from('profiles').update({ 
        last_online: new Date().toISOString() 
      }).eq('id', user.id);
    }, undefined);
  },

  // Fetches all profiles for admin area using secure RPC
  async getAllProfilesAdmin(): Promise<UserProfile[]> {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return [];

    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.rpc('admin_list_users');

      if (error) {
        console.error('Error fetching admin users list:', error);
        throw new Error(error.message || 'Erro ao carregar usuários cadastrados.');
      }

      return data || [];
    }, []);
  },

  // Tracks
  async getTracks() {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return [];
    
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.from('tracks').select('*').eq('user_id', user.id);
      if (error) { 
        console.error('Error fetching tracks:', error); 
        throw error; 
      }
      return data || [];
    }, []);
  },
  
  async saveTrack(track: Track) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      const payload = {
        id: track.id,
        user_id: user.id,
        name: track.name,
        location: track.location || null,
        is_public: track.is_public ?? false
      };
      const { error } = await supabase.from('tracks').upsert(payload);
      if (error) {
        console.error('Supabase error saving track:', error);
        throw error;
      }
    }, undefined);
  },
  
  async deleteTrack(id: string) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      const { error } = await supabase.from('tracks').delete().eq('id', id).eq('user_id', user.id);
      if (error) throw error;
    }, undefined);
  },

  // Entries
  async getEntries() {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return [];
    
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.from('entries').select('*').eq('user_id', user.id);
      if (error) { 
        console.error('Error fetching entries:', error); 
        throw error;
      }
      return data || [];
    }, []);
  },
  
  async saveEntry(entry: Entry) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      // 1. Ensure track exists in DB for this user (required for FK)
      const { data: trackExists } = await supabase
        .from('tracks')
        .select('id')
        .eq('id', entry.trackId)
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (!trackExists) {
        // Find track name to create if it's an initial track
        const initialTrack = INITIAL_TRACKS.find(t => String(t.id).toLowerCase() === String(entry.trackId).toLowerCase());
        const trackName = initialTrack ? initialTrack.name : entry.trackId;
        
        await supabase.from('tracks').upsert({
          id: entry.trackId,
          user_id: user.id,
          name: trackName,
          is_public: true
        });
      }

      const payload = {
        id: entry.id,
        user_id: user.id,
        trackId: entry.trackId,
        carBrand: entry.carBrand,
        carName: entry.carName,
        carSetup: entry.carSetup,
        racePosition: entry.racePosition,
        tractionControl: entry.tractionControl,
        carMap: entry.carMap,
        pitStops: entry.pitStops,
        runDate: entry.runDate,
        weather: entry.weather,
        lapTime: entry.lapTime,
        totalTime: entry.totalTime,
        provaDeTempo: entry.provaDeTempo || null,
        avgLapTime: entry.avgLapTime,
        laps: entry.laps || null,
        pilot_name: entry.pilot_name || null,
        transmission: entry.transmission || 'Automatic',
        peripheral: entry.peripheral || 'Controller',
        customFields: entry.customFields || {},
        evidence_image: entry.evidence_image || null,
        is_public: entry.is_public ?? true
      };

      const { error } = await supabase.from('entries').upsert(payload);
      if (error) {
        console.error('Supabase error saving entry:', error);
        const errorMsg = error.message || '';
        const errorCode = error.code || '';
        
        if (errorCode === 'PGRST204' || errorMsg.includes('schema cache') || errorMsg.includes('column') || errorCode === '42703') {
          // Robust auto-fallback if "provaDeTempo" is missing from user's Supabase columns: retry without it
          if (errorMsg.includes('provaDeTempo') || errorMsg.includes('provadetempo') || errorCode === '42703') {
            const { provaDeTempo, ...strippedPayload } = payload;
            const retryRes = await supabase.from('entries').upsert(strippedPayload);
            if (!retryRes.error) {
              console.log('Saved entry successfully after dynamically stripping missing provaDeTempo column.');
              await this.updateUserStats(user.id);
              return;
            }
          }
          throw new Error(`Outdated tables on Supabase.\n\nError details: ${error.message}\n\nYou must copy the 'SUPABASE_SCHEMA.sql' code and execute it in your Supabase SQL Editor. The schema cache will automatically refresh.`);
        }
        throw error;
      }

      // Update pilot stats
      await this.updateUserStats(user.id);
    }, undefined);
  },

  async updateUserStats(userId: string) {
    return safeSupabaseCall(async () => {
      const { data: entries, error } = await supabase
        .from('entries')
        .select('racePosition')
        .eq('user_id', userId);
      
      if (error) throw error;
      
      const totalRaces = entries?.length || 0;
      // Treats "1" or "1º" or "1st" as win
      const totalWins = entries?.filter(e => {
        const pos = String(e.racePosition).toLowerCase();
        return pos === '1' || pos === '1º' || pos === '1st' || pos.includes('1st');
      }).length || 0;
      
      await supabase
        .from('profiles')
        .update({ 
          total_races: totalRaces, 
          total_wins: totalWins 
        })
        .eq('id', userId);
    }, undefined);
  },

  async recalculateAllPilotStats() {
    return safeSupabaseCall(async () => {
      const { data: profiles, error } = await supabase.from('profiles').select('id');
      if (error) throw error;
      
      for (const p of profiles) {
        await this.updateUserStats(p.id);
      }
      return profiles.length;
    }, 0);
  },

  // Public Profile & Rankings
  async getAllPublicProfiles(): Promise<UserProfile[]> {
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('total_wins', { ascending: false })
        .limit(150);
      
      if (error) {
        console.error('Error fetching all public profiles:', error);
        return [];
      }
      // Filter in JS to be resilient if column is missing (though it shouldn't be)
      return (data || []).filter(p => p.is_banned !== true);
    }, []);
  },

  async getPublicHubProfiles(query?: string): Promise<UserProfile[]> {
    return safeSupabaseCall(async () => {
      let b = supabase.from('profiles').select('*');
      
      if (query) {
        b = b.or(`display_name.ilike.%${query}%,psn_id.ilike.%${query}%,bio.ilike.%${query}%`);
      }
      
      const { data, error } = await b.order('display_name').limit(150);
      if (error) {
        console.error('Error fetching hub profiles:', error);
        return [];
      }
      return (data || []).filter(p => p.is_banned !== true);
    }, []);
  },

  async getPublicProfile(userId: string): Promise<UserProfile | null> {
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single();
      if (error) {
        console.error('Error fetching public profile:', error);
        return null;
      }
      if (data.is_banned) return null;
      return data;
    }, null);
  },

  async getPublicEntries(userId: string): Promise<(Entry & { tracks: Track | null })[]> {
    return safeSupabaseCall(async () => {
      console.log('Fetching entries and tracks for userId:', userId);
      
      // Fetch both in parallel for better performance
      const [entriesRes, tracksRes] = await Promise.all([
        supabase.from('entries').select('*').eq('user_id', userId).order('runDate', { ascending: false }),
        supabase.from('tracks').select('*').eq('user_id', userId)
      ]);
      
      if (entriesRes.error) {
        console.error('Error fetching public entries:', entriesRes.error);
        return [];
      }

      const entries = entriesRes.data || [];
      const tracks = tracksRes.data || [];
      
      console.log(`Found ${entries.length} entries and ${tracks.length} tracks for user profile.`);
      
      // Manual join in JS to be safe from composite FK join issues in PostgREST
      return entries.map(entry => {
        const track = tracks.find(t => String(t.id).toLowerCase() === String(entry.trackId).toLowerCase());
        if (!track) {
          console.warn(`Track not found for entry ${entry.id}. trackId: ${entry.trackId}`);
        }
        return {
          ...entry,
          tracks: track || null
        };
      }) as any;
    }, []);
  },

  async getGlobalRankings(trackId: string): Promise<(Entry & { profiles: UserProfile | null })[]> {
    return safeSupabaseCall(async () => {
      console.log('Fetching global rankings for trackId:', trackId);
      
      // 1. Get current track data
      let { data: currentTrack } = await supabase
        .from('tracks')
        .select('name')
        .eq('id', trackId)
        .maybeSingle();
      
      let trackName = currentTrack ? currentTrack.name : null;
      
      // Fallback for INITIAL_TRACKS
      if (!trackName) {
        const initialTrack = INITIAL_TRACKS.find(t => String(t.id).toLowerCase() === String(trackId).toLowerCase());
        if (initialTrack) {
          trackName = initialTrack.name;
          console.log('Track name found in constants:', trackName);
        }
      }

      // If we don't have a name, use the original ID
      if (!trackName) {
        console.warn('No track name found for ranking lookup, using only ID:', trackId);
      }

      // NORMALIZATION FOR ROBUST SEARCH
      const normalize = (s: string) => s.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      const normalizedTarget = trackName ? normalize(trackName) : null;

      let finalTrackIds = [trackId];

      // 2. Search for similar tracks on the database side to avoid a full-table scan and timeout
      if (trackName) {
        const { data: matchedTracks } = await supabase
          .from('tracks')
          .select('id, name')
          .ilike('name', `%${trackName}%`);
        
        if (matchedTracks) {
          const matchingIds = matchedTracks.map(t => t.id);
          if (matchingIds.length > 0) {
            finalTrackIds = Array.from(new Set([...finalTrackIds, ...matchingIds]));
            console.log(`Fuzzy match [${trackName}]: IDs found: ${finalTrackIds.join(', ')}`);
          }
        }
      }

      console.log('Starting entries search for track IDs:', finalTrackIds);

      let query = supabase
        .from('entries')
        .select(`
          *,
          profiles:profiles!fk_entries_profiles (*)
        `);

      // Usamos IN para os IDs encontrados
      if (finalTrackIds.length > 0) {
        query = query.in('trackId', finalTrackIds);
      }

      let { data, error } = await query.limit(1000);

      // If nothing found by ID, try a desperate search for other similar tracks
      // This helps if the trackId was saved with an unexpected value or if tracks relation is incomplete
      if ((!data || data.length === 0) && normalizedTarget) {
         console.log('No results by ID. Trying expanded search by name via join...');
         // Search entries filtering by track name via join (slower but robust)
         const { data: fuzzyData, error: fuzzyError } = await supabase
           .from('entries')
           .select('*, tracks!inner(name), profiles:profiles!fk_entries_profiles(*)')
           .ilike('tracks.name', `%${trackName}%`)
           .limit(200);
         
         if (fuzzyData && fuzzyData.length > 0) {
            console.log(`Expanded search found ${fuzzyData.length} records.`);
            return this.processRankingData(fuzzyData);
         }
      }

      if (error) {
        console.error('Error in getGlobalRankings query:', error);
        // Fallback: tentar sem profiles join caso haja problema com a relação
        const { data: simpleData, error: simpleError } = await supabase
          .from('entries')
          .select('*')
          .in('trackId', finalTrackIds)
          .limit(500);
        
        if (simpleError) return [];
        return this.processRankingData(simpleData || []);
      }

      if (!data || data.length === 0) {
        console.warn('No items found for ranking.');
        return [];
      }

      return this.processRankingData(data);
    }, []);
  },

  // Helper to process and group rankings
  processRankingData(data: any[]): (Entry & { profiles: UserProfile | null })[] {
    const pilotBestTimes = new Map<string, any>();
    
    data.forEach(item => {
      // Profile visibility and ban criteria
      if (item.profiles && item.profiles.is_banned === true) return;

      // Validate time
      if (!item.lapTime || item.lapTime === '-' || item.lapTime === '00:00.000') return;

      const pilotId = item.user_id;
      if (!pilotBestTimes.has(pilotId)) {
        pilotBestTimes.set(pilotId, item);
      } else {
        const currentBest = pilotBestTimes.get(pilotId);
        // Time string comparison (ex: 01:23.444 < 01:23.555)
        if (item.lapTime < currentBest.lapTime) {
          pilotBestTimes.set(pilotId, item);
        }
      }
    });
    
    return Array.from(pilotBestTimes.values())
      .sort((a, b) => a.lapTime.localeCompare(b.lapTime))
      .slice(0, 15);
  },

  async getLeaderboard(): Promise<UserProfile[]> {
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('total_wins', { ascending: false })
        .limit(100);

      if (error) {
        console.error('Error fetching leaderboard:', error);
        return [];
      }
      return (data || []).filter(p => p.is_banned !== true).slice(0, 50);
    }, []);
  },

  async getTopSpeedRankings(): Promise<(Entry & { profiles: UserProfile | null })[]> {
    return safeSupabaseCall(async () => {
      console.log('Fetching top speed rankings...');
      const { data, error } = await supabase
        .from('entries')
        .select(`
          *,
          profiles:profiles!fk_entries_profiles (*)
        `);

      if (error) {
        console.error('Error fetching speed rankings:', error);
        return [];
      }

      if (!data || data.length === 0) return [];

      const parseSpeedLocal = (sStr: string | undefined | null): number => {
        if (!sStr) return 0;
        const matched = sStr.match(/[\d.]+/);
        return matched ? parseFloat(matched[0]) : 0;
      };

      const validEntries = data.filter(item => {
        if (item.profiles && item.profiles.is_banned === true) return false;
        const speedNum = parseSpeedLocal(item.velocidade_final);
        return speedNum > 0;
      });

      const pilotBestSpeeds = new Map<string, any>();
      validEntries.forEach(item => {
        const pilotId = item.user_id || item.pilot_name || 'unknown';
        const speedNum = parseSpeedLocal(item.velocidade_final);
        if (!pilotBestSpeeds.has(pilotId)) {
          pilotBestSpeeds.set(pilotId, item);
        } else {
          const currentBest = pilotBestSpeeds.get(pilotId);
          if (speedNum > parseSpeedLocal(currentBest.velocidade_final)) {
            pilotBestSpeeds.set(pilotId, item);
          }
        }
      });

      return Array.from(pilotBestSpeeds.values())
        .sort((a, b) => parseSpeedLocal(b.velocidade_final) - parseSpeedLocal(a.velocidade_final))
        .slice(0, 15);
    }, []);
  },

  async deleteEntry(id: string) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      await supabase.from('entries').delete().eq('id', id).eq('user_id', user.id);
      await this.updateUserStats(user.id);
    }, undefined);
  },

  async deleteProfile(userId: string) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;

    return safeSupabaseCall(async () => {
      // 1. Apagar todas as imagens do storage (bucket 'evidences')
      // O policy "Admin Management Access" que adicionamos no SUPABASE_SCHEMA deve permitir isso.
      try {
        const { data: files } = await supabase.storage.from('evidences').list(userId);
        if (files && files.length > 0) {
          const filePaths = files.map(f => `${userId}/${f.name}`);
          const { error: storageError } = await supabase.storage.from('evidences').remove(filePaths);
          if (storageError) {
             console.warn('Isso não é crítico, mas houve erro ao limpar arquivos de evidência:', storageError);
          }
        }
      } catch (err) {
        console.warn('Aviso: falha ao verificar storage objects:', err);
      }

      // 2. Chamar o RPC para deletar o usuário
      const { error } = await supabase.rpc('admin_delete_auth_user', {
        target_user_id: userId
      });

      if (error) {
        console.error('Error deleting auth user:', error);
        
        // Se a função 'admin_delete_auth_user' não existir (PGRST202) ou se tivermos problemas com policy...
        if (error.code === 'PGRST202' || error.message?.includes('admin_delete_auth_user')) {
          throw new Error('A função "admin_delete_auth_user" não existe no banco. Por favor, COPIE TODO o código do SUPABASE_SCHEMA.sql (disponível no menu de importação) e rode no SQL Editor do Supabase para atualizar as funções administrativas.');
        }

        // Se ainda assim der erro de constraint do trigger de storage...
        if (error.message?.includes('Direct deletion from storage tables is not allowed')) {
          throw new Error('Erro de bloqueio de Storage do Supabase: Os arquivos do usuário precisam ser apagados antes (ou a policy de Admin do Storage está faltando no SUPABASE_SCHEMA.sql). Resync as SQLs do app.');
        }

        throw new Error(error.message || 'Erro ao excluir usuário.');
      }
    }, undefined);
  },

  async toggleBanProfile(userId: string, banStatus: boolean) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;

    return safeSupabaseCall(async () => {
      const { error } = await supabase.rpc('admin_toggle_user_ban', {
        target_user_id: userId,
        should_ban: banStatus
      });

      if (error) {
        console.error('Error toggling ban:', error);
        if (error.code === 'PGRST202' || error.message?.includes('admin_toggle_user_ban')) {
          throw new Error('A função não existe. Por favor, COPIE TODO o código do SUPABASE_SCHEMA.sql e rode no SQL Editor do Supabase.');
        }
        throw new Error(error.message || 'Erro ao alterar banimento.');
      }
    }, undefined);
  },

  async getCurrentUserIsAdmin(): Promise<boolean> {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return false;

    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.rpc('current_user_is_admin');
      if (error) return false;
      return data === true;
    }, false);
  },
  
  async uploadEvidenceImage(file: File): Promise<string> {
    const { data: { user }, error } = await getAuthenticatedUser();
    const fileExt = file.name.split('.').pop() || 'jpg';
    
    if (isFirebaseConfigured) {
      try {
        console.log('Uploading evidence image to Firebase Storage...');
        const firebase_url = await uploadEvidenceDirectly(file);
        return firebase_url;
      } catch (fbErr) {
        console.error('Firebase Storage upload failed, trying fallback:', fbErr);
      }
    }

    if (!user || error) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }
    
    return safeSupabaseCall(async () => {
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('evidences')
        .upload(filePath, file);

      if (uploadError) {
        console.error('Error uploading image:', uploadError);
        throw uploadError;
      }

      const { data } = supabase.storage
        .from('evidences')
        .getPublicUrl(filePath);

      return data.publicUrl;
    }, '');
  },

  // Settings and Logs
  async getUserSettings() {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return null;
    
    return safeSupabaseCall(async () => {
      const { data, error } = await supabase.from('user_settings').select('*').eq('user_id', user.id).single();
      if (error && error.code !== 'PGRST116') { console.error(error); return null; }
      return data;
    }, null);
  },
  
  async saveUserSettings(layout: LayoutProfile, logoOverrides: Record<string, string>, logosDatabase?: any[], carsDatabase?: any[]) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) return;
    
    return safeSupabaseCall(async () => {
      // Robust payload construction with automatic heavy-asset pruning
      const cleanData = (obj: any): any => {
        if (!obj) return obj;
        if (Array.isArray(obj)) {
          return obj.map(item => {
            // If it's a huge base64 image (logo/car), we might need to skip or warn
            const newItem = { ...item };
            for (const key in newItem) {
              if (typeof newItem[key] === 'string' && newItem[key].startsWith('data:image/') && newItem[key].length > 500000) {
                 newItem[key] = null; // Prune really heavy images from sync to avoid DB errors
              }
            }
            return newItem;
          });
        }
        return obj;
      };

      // Strips heavy local base64 data URLs from overrides before saving to the database.
      // We keep URLs and small base64 strings.
      const cleanedOverrides: Record<string, string> = {};
      if (logoOverrides) {
        for (const [key, val] of Object.entries(logoOverrides)) {
          if (typeof val === 'string' && val.startsWith('data:image/')) {
            // Keep small ones (< 100KB), prune huge ones (>500KB) to avoid DB limits
            // The UI should handle uploading these to Storage properly.
            if (val.length > 500000) {
              console.warn(`Pruning large base64 override: ${key} (${Math.round(val.length/1024)}KB)`);
              continue;
            }
          }
          cleanedOverrides[key] = val;
        }
      }

      const payload: any = { 
        user_id: user.id, 
        layout, 
        logo_overrides: cleanedOverrides
      };
      
      if (logosDatabase) {
        payload.logos_database = cleanData(logosDatabase);
      }
      if (carsDatabase) {
        payload.cars_database = cleanData(carsDatabase);
      }

      // Check approximate stringified size (Supabase usually has a 1MB - 10MB limit per row/request)
      const estimatedSize = JSON.stringify(payload).length;
      if (estimatedSize > 2 * 1024 * 1024) { // 2MB alert
        console.warn('Sync payload is very large:', (estimatedSize / (1024 * 1024)).toFixed(2), 'MB');
      }

      const { error } = await supabase.from('user_settings').upsert(payload);
      if (error) {
        console.error('Error saving user settings:', error);
        const errorMsg = error.message || '';
        const errorCode = error.code || '';
        
        // Handle common heavy payload or timeout errors
        if ((errorCode === 'PGRST204' || errorCode === '57014' || errorCode === '413' || errorMsg.includes('payload too large') || errorMsg.includes('timeout') || errorCode === '42703')) {
          console.warn('Sync failed due to heavy payload. Retrying without databases...');
          const { cars_database, logos_database, ...strippedPayload } = payload;
          const retryRes = await supabase.from('user_settings').upsert(strippedPayload);
          
          if (retryRes.error) {
            throw retryRes.error;
          } else {
            throw new Error('Sync parcial: O banco de dados recusou salvar o dicionário inteiro de base64 (Limite excedido). Suas configurações básicas foram salvas, mas imagens pesadas (carros/logos) foram ignoradas para evitar erro permanente.');
          }
        }
        throw error;
      }
    }, undefined);
  },
  async saveAllData(tracks: Track[], entries: Entry[], layout: LayoutProfile, logoOverrides: Record<string, string>, logosDatabase?: any[], carsDatabase?: any[]) {
    const { data: { user } } = await getAuthenticatedUser();
    if (!user) {
      console.warn('User not authenticated in saveAllData - aborting migration/save');
      return; 
    }

    const trackPayloads = tracks
      .filter(t => t && t.id && t.name) 
      .map(t => ({ 
         id: String(t.id), 
         user_id: user.id, 
         name: String(t.name || 'No Name'), 
         location: t.location ? String(t.location) : null,
         is_public: t.is_public ?? true
      }));

    const entryPayloads = entries
      .filter(e => e && e.id && e.trackId) 
      .map(e => ({
        id: String(e.id),
        user_id: user.id,
        trackId: String(e.trackId),
        carBrand: String(e.carBrand || ''),
        carName: String(e.carName || 'Unknown Car'),
        carSetup: String(e.carSetup || ''),
        racePosition: String(e.racePosition || ''),
        tractionControl: String(e.tractionControl || ''),
        carMap: String(e.carMap || ''),
        pitStops: String(e.pitStops || ''),
        runDate: e.runDate || new Date().toISOString().split('T')[0],
        weather: String(e.weather || 'Clear'),
        lapTime: String(e.lapTime || ''),
        totalTime: String(e.totalTime || ''),
        provaDeTempo: e.provaDeTempo ? String(e.provaDeTempo) : null,
        avgLapTime: String(e.avgLapTime || ''),
        laps: e.laps ? String(e.laps) : null,
        pilot_name: e.pilot_name ? String(e.pilot_name) : null,
        transmission: String(e.transmission || 'Automatic'),
        peripheral: String(e.peripheral || 'Controller'),
        customFields: e.customFields || {},
        evidence_image: e.evidence_image || null,
        is_public: e.is_public ?? true
      }));

    return safeSupabaseCall(async () => {
      // Save sequentially: Tracks -> Entries -> Settings
      // This avoids Foreign Key violations (Entries pointing to Tracks not yet saved)
      try {
        const chunkArray = <T>(arr: T[], size: number): T[][] => {
          const chunks: T[][] = [];
          for (let i = 0; i < arr.length; i += size) {
            chunks.push(arr.slice(i, i + size));
          }
          return chunks;
        };

        if (trackPayloads.length > 0) {
          const trackChunks = chunkArray(trackPayloads, 50);
          for (const chunk of trackChunks) {
            const { error } = await supabase.from('tracks').upsert(chunk);
            if (error) throw { table: 'Tracks', error };
          }
        }
        
        if (entryPayloads.length > 0) {
          const entryChunks = chunkArray(entryPayloads, 50);
          for (const chunk of entryChunks) {
            const { error } = await supabase.from('entries').upsert(chunk);
            if (error) {
              const errorMsg = error.message || '';
              const errorCode = error.code || '';
              if (errorCode === 'PGRST204' || errorMsg.includes('schema cache') || errorMsg.includes('column') || errorCode === '42703') {
                // Robust auto-fallback if "provaDeTempo" is missing from user's Supabase columns: retry without it
                if (errorMsg.includes('provaDeTempo') || errorMsg.includes('provadetempo') || errorCode === '42703') {
                  const strippedPayloads = chunk.map(({ provaDeTempo, ...rest }: any) => rest);
                  const retryRes = await supabase.from('entries').upsert(strippedPayloads);
                  if (retryRes.error) {
                    throw { table: 'Entries', error: retryRes.error };
                  }
                } else {
                  throw { table: 'Entries', error };
                }
              } else {
                throw { table: 'Entries', error };
              }
            }
          }
        }
        
        const cleanedOverrides: Record<string, string> = {};
        if (logoOverrides) {
          for (const [key, val] of Object.entries(logoOverrides)) {
            if (typeof val === 'string' && val.startsWith('data:image/')) {
              continue;
            }
            cleanedOverrides[key] = val;
          }
        }

        const settingsPayload: any = { 
          user_id: user.id, 
          layout, 
          logo_overrides: cleanedOverrides,
          logos_database: logosDatabase
        };
        if (carsDatabase) {
          settingsPayload.cars_database = carsDatabase;
        }

        let { error } = await supabase.from('user_settings').upsert(settingsPayload);
        if (error) {
          const errorMsg = error.message || '';
          const errorCode = error.code || '';
          if ((errorCode === 'PGRST204' || errorCode === '57014' || errorMsg.includes('schema cache') || errorMsg.includes('column') || errorMsg.includes('timeout') || errorCode === '42703') && carsDatabase) {
            console.warn('Retrying user settings save in saveAllData without cars_database (outdated columns or timeout)...');
            const { cars_database, ...strippedSettingsPayload } = settingsPayload;
            const retryRes = await supabase.from('user_settings').upsert(strippedSettingsPayload);
            if (retryRes.error) {
              throw { table: 'Settings', error: retryRes.error };
            } else {
              throw new Error('Falha parcial no SAVE ALL: O banco de dados recusou salvar o dicionário inteiro de base64. Suas configurações foram salvas, mas os carros podem não ter sido.');
            }
          } else {
            throw { table: 'Settings', error };
          }
        }
        
        // Update stats
        await this.updateUserStats(user.id);

        console.log('Data synchronized successfully.');
      } catch (failedObj: any) {
        console.error(`Save failed (${failedObj.table}):`, failedObj.error);
        
        const errorMsg = failedObj.error?.message || 'Unknown error';
        const errorCode = failedObj.error?.code || '';
        const errorHint = failedObj.error?.hint || '';
        
        if (errorCode === 'PGRST204' || (failedObj.error?.message && failedObj.error.message.includes('schema cache')) || (failedObj.error?.message && failedObj.error.message.includes('column')) || errorCode === '42703') {
           throw new Error(`In table ${failedObj.table}: Outdated tables on Supabase.\n\nError details: ${errorMsg}\n\nIMPORTANT: Do NOT copy this error message!\n\nYou must open the 'SUPABASE_SCHEMA.sql' file in your project files, copy all of its SQL code, and execute it in the SQL Editor of your Supabase dashboard to update your columns.\n\nNOTE: The script has just been updated to automatically refresh the database cache. Please run it again over there.`);
        }

        throw new Error(
          `Error in ${failedObj.table}: ${errorMsg} (${errorCode}). ${errorHint} Verify if database columns are correct.`
        );
      }
    }, undefined);
  }
};
