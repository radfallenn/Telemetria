import { openDB, DBSchema, IDBPDatabase } from 'idb';

export interface GT7TelemetrySession {
  session_id: string;
  created_at: string;
  updated_at: string;
  source: string;
  pc_bridge_url: string;
  track_name: string | null;
  car_name: string | null;
  started_at: string;
  ended_at: string | null;
  status: 'recording' | 'paused' | 'finished';
  best_lap_ms: number | null;
  best_lap_text: string | null;
  total_race_time_ms: number;
  total_race_time_text: string;
  completed_laps: number;
  max_speed_kmh: number;
  max_rpm: number;
  min_fuel: number | null;
  max_rain_intensity: number | null;
  traction_control_last: number | string | null;
  pit_stops_count: number;
  notes: string | null;
}

export interface GT7TelemetrySample {
  sample_id: string;
  session_id: string;
  timestamp: string;
  speed_kmh: number;
  rpm: number;
  gear: string | number;
  throttle_percent: number;
  brake_percent: number;
  fuel: number | null;
  fuel_percent?: number | null;
  rain_intensity: number | null;
  traction_control: number | string | null;
  completed_laps: number | null;
  total_race_time_ms: number | null;
  position_x: number | null;
  position_y: number | null;
  position_z: number | null;
  heading: number | null;
  lap_progress_percent: number | null;
  packetVersion?: string | null;
  decodeOk?: boolean;
}

export interface GT7TelemetryLap {
  lap_id: string;
  session_id: string;
  lap_number: number;
  lap_time_ms: number | null;
  lap_time_text: string | null;
  is_best_lap: boolean;
  max_speed_kmh: number | null;
  avg_speed_kmh: number | null;
  max_rpm: number | null;
  fuel_start: number | null;
  fuel_end: number | null;
  rain_max: number | null;
  pit_stop_on_lap: boolean;
}

export interface GT7TelemetryPitStop {
  pit_stop_id: string;
  session_id: string;
  lap_number: number | null;
  started_at: string;
  ended_at: string | null;
  duration_ms: number | null;
  fuel_before: number | null;
  fuel_after: number | null;
  source: 'bridge' | 'inferred';
}

export interface GT7TelemetryMapPoint {
  point_id: string;
  session_id: string;
  timestamp: string;
  lap_number: number | null;
  x: number;
  y: number;
  z: number | null;
  speed_kmh: number | null;
  brake_percent: number | null;
  throttle_percent: number | null;
  rain_intensity: number | null;
}

interface GT7TelemetryDB extends DBSchema {
  gt7_telemetry_sessions: {
    key: string;
    value: GT7TelemetrySession;
  };
  gt7_telemetry_samples: {
    key: string;
    value: GT7TelemetrySample;
    indexes: {
      'by-session': string;
      'by-timestamp': string;
    };
  };
  gt7_telemetry_laps: {
    key: string;
    value: GT7TelemetryLap;
    indexes: {
      'by-session': string;
      'by-lap_number': number;
    };
  };
  gt7_telemetry_pit_stops: {
    key: string;
    value: GT7TelemetryPitStop;
    indexes: {
      'by-session': string;
      'by-lap_number': number;
    };
  };
  gt7_telemetry_map_points: {
    key: string;
    value: GT7TelemetryMapPoint;
    indexes: {
      'by-session': string;
      'by-lap_number': number;
    };
  };
}

let dbPromise: Promise<IDBPDatabase<GT7TelemetryDB>> | null = null;

export const initTelemetryDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<GT7TelemetryDB>('GT7TelemetryDB', 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('gt7_telemetry_sessions')) {
          db.createObjectStore('gt7_telemetry_sessions', { keyPath: 'session_id' });
        }
        if (!db.objectStoreNames.contains('gt7_telemetry_samples')) {
          const sampleStore = db.createObjectStore('gt7_telemetry_samples', { keyPath: 'sample_id' });
          sampleStore.createIndex('by-session', 'session_id');
          sampleStore.createIndex('by-timestamp', 'timestamp');
        }
        if (!db.objectStoreNames.contains('gt7_telemetry_laps')) {
          const lapStore = db.createObjectStore('gt7_telemetry_laps', { keyPath: 'lap_id' });
          lapStore.createIndex('by-session', 'session_id');
          lapStore.createIndex('by-lap_number', 'lap_number');
        }
        if (!db.objectStoreNames.contains('gt7_telemetry_pit_stops')) {
          const pitStore = db.createObjectStore('gt7_telemetry_pit_stops', { keyPath: 'pit_stop_id' });
          pitStore.createIndex('by-session', 'session_id');
          pitStore.createIndex('by-lap_number', 'lap_number');
        }
        if (!db.objectStoreNames.contains('gt7_telemetry_map_points')) {
          const mapStore = db.createObjectStore('gt7_telemetry_map_points', { keyPath: 'point_id' });
          mapStore.createIndex('by-session', 'session_id');
          mapStore.createIndex('by-lap_number', 'lap_number');
        }
      },
    });
  }
  return dbPromise;
};

export const saveTelemetrySession = async (session: GT7TelemetrySession) => {
  const db = await initTelemetryDB();
  await db.put('gt7_telemetry_sessions', session);
};

export const saveTelemetrySample = async (sample: GT7TelemetrySample) => {
  const db = await initTelemetryDB();
  await db.put('gt7_telemetry_samples', sample);
};

export const saveTelemetryLap = async (lap: GT7TelemetryLap) => {
  const db = await initTelemetryDB();
  await db.put('gt7_telemetry_laps', lap);
};

export const saveTelemetryPitStop = async (pitStop: GT7TelemetryPitStop) => {
  const db = await initTelemetryDB();
  await db.put('gt7_telemetry_pit_stops', pitStop);
};

export const saveTelemetryMapPoint = async (point: GT7TelemetryMapPoint) => {
  const db = await initTelemetryDB();
  await db.put('gt7_telemetry_map_points', point);
};

export const getAllTelemetrySessions = async (): Promise<GT7TelemetrySession[]> => {
  const db = await initTelemetryDB();
  return db.getAll('gt7_telemetry_sessions');
};

export const deleteTelemetrySession = async (sessionId: string) => {
  const db = await initTelemetryDB();
  await db.delete('gt7_telemetry_sessions', sessionId);
};
