package com.gt7.telemetry;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF = "telemetria_v10_melhorado";
    static final String DEF_BRIDGE = "http://192.168.1.70:8787";

    Handler handler = new Handler(Looper.getMainLooper());
    LinearLayout root, lapList;
    TextView status, bridgeInfo, rpmText, speedText, gearText, bestLapText, lastLapText, totalText, maxSpeedText, avgText, lapCountText, avgHintText;
    RpmBar rpmBar;

    String bridge = DEF_BRIDGE;
    boolean connected = false;
    long lastPacket = 0;
    float maxSpeed = 0f;
    float currentLapMax = 0f;
    String lastLapSeen = "";

    Map<String, String> fields = new HashMap<>();
    Map<String, String> lastGood = new HashMap<>();
    ArrayList<LapData> laps = new ArrayList<>();

    Runnable poll = new Runnable() {
        public void run() {
            pollBridge();
            handler.postDelayed(this, 650);
        }
    };

    public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        load();
        buildUi();
        handler.post(poll);
    }

    public void onDestroy() {
        saveSessionState();
        handler.removeCallbacks(poll);
        super.onDestroy();
    }

    void load() {
        SharedPreferences sp = getSharedPreferences(PREF, 0);
        bridge = sp.getString("bridge", DEF_BRIDGE);
        maxSpeed = sp.getFloat("maxSpeed", 0f);
        currentLapMax = sp.getFloat("currentLapMax", 0f);
        lastLapSeen = sp.getString("lastLapSeen", "");
        try {
            JSONArray a = new JSONArray(sp.getString("laps", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                laps.add(new LapData(o.optInt("number", i + 1), o.optLong("timeMs", 0), (float) o.optDouble("maxSpeed", 0)));
            }
        } catch (Exception ignored) {}
    }

    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    int green() { return Color.rgb(84,255,20); }
    int green2() { return Color.rgb(0,205,90); }
    int blue() { return Color.rgb(0,184,255); }
    int yellow() { return Color.rgb(255,210,0); }
    int orange() { return Color.rgb(255,120,0); }
    int red() { return Color.rgb(255,40,48); }
    int white() { return Color.rgb(245,248,250); }
    int muted() { return Color.rgb(155,165,170); }
    int bg() { return Color.rgb(1,5,8); }
    int panel() { return Color.rgb(3,11,15); }
    int panel2() { return Color.rgb(5,17,22); }
    int stroke() { return Color.rgb(42,58,62); }

    TextView tv(String text, float sp, int color, int style) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        t.setIncludeFontPadding(true);
        return t;
    }

    GradientDrawable box(int strokeWidth, int strokeColor, int fill, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(strokeWidth), strokeColor);
        return g;
    }

    LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }

    void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(bg());
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        root = vbox();
        root.setPadding(dp(14), dp(16), dp(14), dp(88));
        scroll.addView(root);
        frame.addView(scroll);
        setContentView(frame);
        header();
        rpmPanel();
        cards();
        lapSummary();
        bottomBar(frame);
        updateUi();
    }

    void header() {
        LinearLayout top = hbox();
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView menu = tv("☰", 30, white(), Typeface.BOLD);
        menu.setGravity(Gravity.CENTER);
        menu.setBackground(box(1, stroke(), Color.TRANSPARENT, 10));
        menu.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ showActions(); }});

        LinearLayout mid = vbox();
        mid.setGravity(Gravity.CENTER);
        TextView title = tv("TELEMETRIA", 25, green(), Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        status = tv("● CONECTANDO", 14, muted(), Typeface.BOLD);
        status.setGravity(Gravity.CENTER);
        bridgeInfo = tv("", 10, muted(), Typeface.NORMAL);
        bridgeInfo.setGravity(Gravity.CENTER);
        mid.addView(title); mid.addView(status); mid.addView(bridgeInfo);

        TextView cfg = tv("⚙", 27, white(), Typeface.BOLD);
        cfg.setGravity(Gravity.CENTER);
        cfg.setBackground(box(1, stroke(), Color.TRANSPARENT, 10));
        cfg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ settings(); }});

        top.addView(menu, new LinearLayout.LayoutParams(dp(58), dp(58)));
        top.addView(mid, new LinearLayout.LayoutParams(0, dp(72), 1));
        top.addView(cfg, new LinearLayout.LayoutParams(dp(58), dp(58)));
        root.addView(top);
    }

    void rpmPanel() {
        LinearLayout box = vbox();
        box.setPadding(dp(14), dp(14), dp(14), dp(12));
        box.setBackground(box(1, stroke(), panel(), 16));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(172));
        bp.setMargins(0, dp(14), 0, dp(12));

        LinearLayout line = hbox();
        line.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = vbox();
        left.addView(tv("CONTA-GIROS", 15, white(), Typeface.BOLD));
        left.addView(tv("barra RPM x1000", 11, muted(), Typeface.NORMAL));
        rpmText = tv("--\nRPM", 30, white(), Typeface.BOLD);
        rpmText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        line.addView(left, new LinearLayout.LayoutParams(dp(150), dp(62)));
        line.addView(new Space(this), new LinearLayout.LayoutParams(0, 1, 1));
        line.addView(rpmText, new LinearLayout.LayoutParams(dp(132), dp(66)));
        box.addView(line);

        rpmBar = new RpmBar(this);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(76));
        rp.setMargins(0, dp(4), 0, 0);
        box.addView(rpmBar, rp);
        root.addView(box, bp);
    }

    void cards() {
        LinearLayout r1 = hbox();
        speedText = bigCard(r1, "VELOCIDADE", "--\nkm/h", white(), 2.0f);
        gearText = bigCard(r1, "MARCHA", "--", green(), 1.1f);
        LinearLayout.LayoutParams r1lp = new LinearLayout.LayoutParams(-1, dp(190));
        r1lp.setMargins(0,0,0,dp(10));
        root.addView(r1, r1lp);

        LinearLayout r2 = hbox();
        bestLapText = smallCard(r2, "VOLTA MAIS RÁPIDA", "--:--.---", green());
        lastLapText = smallCard(r2, "ÚLTIMA VOLTA", "--:--.---", blue());
        root.addView(r2, rowLp());

        LinearLayout r3 = hbox();
        totalText = smallCard(r3, "TEMPO TOTAL", "--:--.---", yellow());
        maxSpeedText = smallCard(r3, "VELOCIDADE MÁXIMA", "-- km/h", red());
        root.addView(r3, rowLp());

        LinearLayout r4 = hbox();
        avgText = smallCard(r4, "MÉDIA DA CORRIDA", "--:--.---", white());
        lapCountText = smallCard(r4, "VOLTAS COMPLETAS", "0", white());
        root.addView(r4, rowLp());

        avgHintText = tv("A média aparece a partir de 5 voltas completas.", 11, muted(), Typeface.NORMAL);
        avgHintText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, 0, 0, dp(12));
        root.addView(avgHintText, hp);
    }

    LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(118));
        lp.setMargins(0,0,0,dp(10));
        return lp;
    }

    TextView bigCard(LinearLayout row, String title, String value, int color, float weight) {
        LinearLayout c = vbox();
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), dp(10), dp(10), dp(10));
        c.setBackground(box(1, stroke(), Color.rgb(2,10,14), 14));
        TextView label = tv(title, 14, white(), Typeface.BOLD);
        label.setGravity(Gravity.CENTER);
        TextView val = tv(value, title.equals("VELOCIDADE") ? 58 : 66, color, Typeface.BOLD);
        val.setGravity(Gravity.CENTER);
        c.addView(label, new LinearLayout.LayoutParams(-1, dp(34)));
        c.addView(val, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, weight);
        lp.setMargins(row.getChildCount()==0?0:dp(8),0,0,0);
        row.addView(c, lp);
        return val;
    }

    TextView smallCard(LinearLayout row, String title, String value, int color) {
        LinearLayout c = vbox();
        c.setPadding(dp(12), dp(12), dp(10), dp(8));
        c.setBackground(box(1, stroke(), Color.rgb(2,10,14), 12));
        TextView label = tv(title, 12, white(), Typeface.BOLD);
        TextView val = tv(value, 23, color, Typeface.BOLD);
        val.setGravity(Gravity.BOTTOM | Gravity.LEFT);
        c.addView(label, new LinearLayout.LayoutParams(-1, dp(34)));
        c.addView(val, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.setMargins(row.getChildCount()==0?0:dp(8),0,0,0);
        row.addView(c, lp);
        return val;
    }

    void lapSummary() {
        LinearLayout panel = vbox();
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        panel.setBackground(box(1, stroke(), Color.rgb(2,10,14), 14));
        panel.addView(tv("⚑  RESUMO DAS VOLTAS", 19, green(), Typeface.BOLD));
        panel.addView(tv("Exibe até 30 voltas. A média descarta as 2 melhores e as 2 piores.", 11, muted(), Typeface.NORMAL));
        lapList = vbox();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        panel.addView(lapList, lp);
        root.addView(panel, new LinearLayout.LayoutParams(-1, -2));
    }

    void bottomBar(FrameLayout frame) {
        LinearLayout b = hbox();
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(Color.rgb(2,8,10));
        String[] items = {"◉\nDASH", "◷\nZERAR", "▧\nCOPIAR", "⚙\nCONFIG."};
        for (int i=0;i<items.length;i++) {
            TextView x = tv(items[i], 11, i==0?green():Color.rgb(170,170,170), Typeface.BOLD);
            x.setGravity(Gravity.CENTER);
            b.addView(x, new LinearLayout.LayoutParams(0, dp(78), 1));
            if (i==1) x.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ confirmReset(); }});
            if (i==2) x.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ copySummary(); }});
            if (i==3) x.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ settings(); }});
        }
        frame.addView(b, new FrameLayout.LayoutParams(-1, dp(82), Gravity.BOTTOM));
    }

    void showActions() {
        final String[] opts = {"Copiar resumo", "Zerar sessão", "Configurar Bridge"};
        new AlertDialog.Builder(this).setTitle("Telemetria v1.0").setItems(opts, (d, which) -> {
            if (which == 0) copySummary();
            if (which == 1) confirmReset();
            if (which == 2) settings();
        }).show();
    }

    void settings() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(bridge);
        new AlertDialog.Builder(this)
            .setTitle("Bridge URL")
            .setView(input)
            .setPositiveButton("Salvar", (d,w)->{ bridge=input.getText().toString().trim(); getSharedPreferences(PREF,0).edit().putString("bridge",bridge).apply(); updateUi(); })
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Zerar corrida", (d,w)->confirmReset())
            .show();
    }

    void confirmReset() {
        new AlertDialog.Builder(this)
            .setTitle("Zerar sessão?")
            .setMessage("Isso limpa as voltas atuais, tempo total e velocidade máxima da sessão.")
            .setPositiveButton("Zerar", (d,w)->resetRace())
            .setNegativeButton("Cancelar", null)
            .show();
    }

    void resetRace() {
        laps.clear(); maxSpeed=0f; currentLapMax=0f; lastLapSeen=""; saveSessionState(); updateUi();
        Toast.makeText(this, "Sessão zerada", Toast.LENGTH_SHORT).show();
    }

    void pollBridge() {
        new Thread(new Runnable(){ public void run(){
            boolean ok=false;
            try {
                String body = http(fix(bridge)+"/api/fields");
                if (!valid(body)) body = http(fix(bridge)+"/api/telemetry");
                Map<String,String> data = parse(body);
                if (!data.isEmpty()) {
                    fields.clear(); fields.putAll(data);
                    for (String k:data.keySet()) { String v=data.get(k); if (valid(v) && !bad(v)) lastGood.put(k,v); }
                    lastPacket = System.currentTimeMillis();
                    consumeTelemetry(); ok=true;
                }
            } catch(Exception ignored) {}
            connected = ok || System.currentTimeMillis()-lastPacket < 3500;
            handler.post(new Runnable(){ public void run(){ updateUi(); }});
        }}).start();
    }

    String http(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(800); c.setReadTimeout(800);
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line=r.readLine())!=null) sb.append(line);
        r.close(); c.disconnect(); return sb.toString();
    }

    Map<String,String> parse(String body) throws Exception {
        Map<String,String> map = new HashMap<>();
        if (!valid(body)) return map;
        flatten(map, "", new JSONTokener(body.trim()).nextValue());
        return map;
    }

    void flatten(Map<String,String> map, String prefix, Object obj) throws Exception {
        if (obj instanceof JSONObject) {
            JSONObject jo=(JSONObject)obj; Iterator<String> keys=jo.keys();
            while(keys.hasNext()){
                String k=keys.next(); Object v=jo.get(k); String name=prefix.length()==0?k:prefix+"."+k;
                flatten(map,name,v);
                if (v instanceof JSONObject && (k.equals("fields")||k.equals("telemetry")||k.equals("session")||k.equals("car")||k.equals("lap"))) flatten(map,"",v);
            }
        } else if (obj instanceof JSONArray) {
            JSONArray a=(JSONArray)obj; for(int i=0;i<a.length();i++) flatten(map,prefix+"."+i,a.get(i));
        } else map.put(prefix, String.valueOf(obj));
    }

    void consumeTelemetry() {
        float speed = num("speed_kmh","speedKmh","speed","velocityKmh","velocidade");
        if (!Float.isNaN(speed)) { if (speed>maxSpeed) maxSpeed=speed; if (speed>currentLapMax) currentLapMax=speed; }
        String lap = val("lastLap","last_lap","ultimaVolta","lastLaptime","lastLapTime","lap.last","lap.lastTime");
        if (valid(lap) && !lap.equals(lastLapSeen)) {
            long ms = parseTime(lap);
            if (ms>0 && !isDuplicateLap(ms)) { laps.add(new LapData(laps.size()+1, ms, currentLapMax)); currentLapMax=0f; saveSessionState(); }
            lastLapSeen = lap;
        }
    }

    boolean isDuplicateLap(long ms) {
        if (laps.size()==0) return false;
        LapData last = laps.get(laps.size()-1);
        return Math.abs(last.timeMs - ms) < 30;
    }

    void updateUi() {
        if (status==null) return;
        status.setText(connected?"● CONECTADO":"● DESCONECTADO");
        status.setTextColor(connected?green():red());
        long age = lastPacket == 0 ? 0 : Math.max(0, (System.currentTimeMillis()-lastPacket)/1000);
        bridgeInfo.setText(fix(bridge) + (connected ? "  •  " + age + "s" : ""));
        float rpm = num("rpm","engine_rpm","currentRpm","engineRpm");
        float speed = num("speed_kmh","speedKmh","speed","velocityKmh","velocidade");
        String gear = val("gear","marcha","currentGear");
        rpmBar.rpm = Float.isNaN(rpm)?0f:rpm; rpmBar.invalidate();
        rpmText.setText(Float.isNaN(rpm)?"--\nRPM":String.format(Locale.US,"%.0f\nRPM",rpm));
        speedText.setText((Float.isNaN(speed)?"--":String.valueOf(Math.round(speed)))+"\nkm/h");
        gearText.setText(valid(gear)?gear:"--");
        bestLapText.setText(bestLap());
        lastLapText.setText(laps.size()==0?"--:--.---":format(laps.get(laps.size()-1).timeMs));
        totalText.setText(format(totalMs()));
        maxSpeedText.setText((maxSpeed<=0?"--":String.valueOf(Math.round(maxSpeed)))+" km/h");
        avgText.setText(raceAverage());
        lapCountText.setText(String.valueOf(laps.size()));
        avgHintText.setText(laps.size()<5 ? "A média aparece a partir de 5 voltas completas." : "Média calculada com " + Math.max(0, laps.size()-4) + " voltas válidas.");
        renderLapList();
    }

    void renderLapList() {
        if (lapList==null) return;
        lapList.removeAllViews();
        TextView head = tv("VOLTA        TEMPO         DELTA        VEL.MAX", 11, muted(), Typeface.BOLD);
        head.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        lapList.addView(head);
        long best = bestMs();
        int start = Math.max(0, laps.size()-30);
        if (laps.size()==0) {
            TextView empty = tv("Nenhuma volta completa ainda.", 13, muted(), Typeface.NORMAL);
            empty.setPadding(0, dp(12), 0, 0);
            lapList.addView(empty);
            return;
        }
        for (int i=start;i<laps.size();i++) {
            LapData lap=laps.get(i);
            long delta = best>0 ? lap.timeMs-best : 0;
            String d = delta==0 ? "MELHOR" : "+"+formatDelta(delta);
            String row = String.format(Locale.US, "%02d      %s     %-8s     %3.0f km/h", lap.number, format(lap.timeMs), d, lap.maxSpeed);
            TextView line = tv(row, 12, delta==0?green():white(), Typeface.NORMAL);
            line.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            lapList.addView(line);
        }
    }

    String bestLap(){ long best=bestMs(); return best==0?"--:--.---":format(best); }
    long bestMs(){ long best=0; for(LapData l:laps) if(best==0||l.timeMs<best) best=l.timeMs; return best; }
    long totalMs(){ long total=0; for(LapData l:laps) total+=l.timeMs; return total; }

    String raceAverage(){
        if (laps.size()<5) return "--:--.---";
        ArrayList<Long> times = new ArrayList<>();
        for(LapData l:laps) times.add(l.timeMs);
        Collections.sort(times);
        long sum=0; for(int i=2;i<times.size()-2;i++) sum+=times.get(i);
        int divisor = times.size()-4;
        return divisor<=0?"--:--.---":format(sum/divisor);
    }

    void saveSessionState() {
        try {
            JSONArray a = new JSONArray();
            for (LapData l : laps) {
                JSONObject o = new JSONObject();
                o.put("number", l.number); o.put("timeMs", l.timeMs); o.put("maxSpeed", l.maxSpeed);
                a.put(o);
            }
            getSharedPreferences(PREF, 0).edit()
                .putString("laps", a.toString())
                .putFloat("maxSpeed", maxSpeed)
                .putFloat("currentLapMax", currentLapMax)
                .putString("lastLapSeen", lastLapSeen)
                .apply();
        } catch (Exception ignored) {}
    }

    void copySummary() {
        String text = summaryText();
        ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Telemetria v1.0", text));
        Toast.makeText(this, "Resumo copiado", Toast.LENGTH_SHORT).show();
    }

    String summaryText() {
        StringBuilder sb = new StringBuilder();
        sb.append("TELEMETRIA v1.0\n");
        sb.append("Voltas completas: ").append(laps.size()).append("\n");
        sb.append("Melhor volta: ").append(bestLap()).append("\n");
        sb.append("Última volta: ").append(laps.size()==0?"--:--.---":format(laps.get(laps.size()-1).timeMs)).append("\n");
        sb.append("Tempo total: ").append(format(totalMs())).append("\n");
        sb.append("Velocidade máxima: ").append(maxSpeed<=0?"--":String.valueOf(Math.round(maxSpeed))).append(" km/h\n");
        sb.append("Média da corrida: ").append(raceAverage()).append("\n\n");
        sb.append("Resumo das voltas (até 30):\n");
        int start = Math.max(0, laps.size()-30);
        for (int i=start;i<laps.size();i++) {
            LapData l = laps.get(i);
            sb.append(String.format(Locale.US, "%02d - %s - %.0f km/h\n", l.number, format(l.timeMs), l.maxSpeed));
        }
        return sb.toString();
    }

    String val(String...keys){ for(String k:keys){ String v=fields.get(k); if(valid(v)&&!bad(v))return v; v=lastGood.get(k); if(valid(v)&&!bad(v))return v; } return "--"; }
    float num(String...keys){ try{return Float.parseFloat(val(keys).replace("%","").replace(',','.'));}catch(Exception e){return Float.NaN;} }
    boolean valid(String s){return s!=null&&s.trim().length()>0&&!s.equals("--");}
    boolean bad(String s){String x=s.trim().toLowerCase(Locale.US);return x.equals("null")||x.equals("undefined")||x.equals("nan");}
    String fix(String u){return u.startsWith("http")?(u.endsWith("/")?u.substring(0,u.length()-1):u):"http://"+u;}

    long parseTime(String s){try{String[] p=s.trim().replace(',','.').split(":");float sec=Float.parseFloat(p[p.length-1]);long min=p.length>=2?Long.parseLong(p[p.length-2]):0;long hr=p.length>=3?Long.parseLong(p[p.length-3]):0;return hr*3600000L+min*60000L+Math.round(sec*1000f);}catch(Exception e){return 0;}}
    String format(long ms){if(ms<=0)return "--:--.---";long m=ms/60000L;ms%=60000L;long s=ms/1000L,z=ms%1000L;return String.format(Locale.US,"%02d:%02d.%03d",m,s,z);}
    String formatDelta(long ms){if(ms<=0)return "0.000";long s=ms/1000L,z=ms%1000L;return String.format(Locale.US,"%d.%03d",s,z);}

    static class LapData{int number;long timeMs;float maxSpeed;LapData(int n,long t,float s){number=n;timeMs=t;maxSpeed=s;}}

    public class RpmBar extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float rpm=0f;
        public RpmBar(Context c){super(c);}
        protected void onDraw(Canvas c){
            super.onDraw(c);
            int w=getWidth(),h=getHeight();
            int bars=70;
            float max=10000f;
            float filled=Math.max(0f,Math.min(1f,rpm/max));
            float gap=dp(2.5f);
            float bw=(w-gap*(bars-1))/bars;
            for(int i=0;i<bars;i++){
                float pct=i/(float)(bars-1);
                if(pct<.52f)p.setColor(green());else if(pct<.70f)p.setColor(yellow());else if(pct<.84f)p.setColor(orange());else p.setColor(red());
                p.setAlpha(i<filled*bars?255:42);
                float x=i*(bw+gap);
                c.drawRoundRect(x,dp(10),x+bw,h-dp(24),dp(2),dp(2),p);
            }
            p.setAlpha(255);
            p.setColor(white());
            p.setStrokeWidth(dp(2));
            float marker=Math.max(0,Math.min(w,filled*w));
            c.drawLine(marker,dp(4),marker,h-dp(15),p);
            p.setTextSize(dp(11));
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setColor(white());
            for(int i=0;i<=10;i++){
                String text=String.valueOf(i);
                float x=i*(w/10f);
                c.drawText(text,Math.min(w-dp(14),x),h-dp(3),p);
            }
        }
    }
}
