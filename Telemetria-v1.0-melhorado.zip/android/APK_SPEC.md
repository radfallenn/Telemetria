# Especificação do APK: GT7 Bridge Mobile v1.4.7
> **ID da Versão**: 1.4.8  
> **Repositório Alvo**: [radfallenn/GT7-Bridge-Mobile](https://github.com/radfallenn/GT7-Bridge-Mobile)  
> **Objetivo**: Aplicar design unificado moderno, escuro e premium (GT Dashboard) no aplicativo nativo ou híbrido, removendo a antiga aparência fragmentada ("topo branco e fundo escuro").

---

## 🎨 Linguagem Visual Desejada (Visual Direction)
- **Tema**: Dark Premium GT Dashboard.
- **Paleta de Cores**:
  - **Fundo**: Grafite/Azul Escuro (`#07090e`, `#0a0d14`).
  - **Cards**: Cinza escuro fosco quase preto (`#10141f`) com bordas finas semi-transparentes (`rgba(255,255,255,0.05)`).
  - **Destaques / Accent**: Azul elétrico/neon suave (`#5ca1ff`/`#3b82f6`).
  - **Sucesso / Ativo**: Verde neon suave (`#10b981`).
  - **Aviso**: Amarelo/Laranja suave (`#ffd35c`).
  - **Perigo**: Vermelho suave (`#ef4444`).
- **Cards**: Bordas suaves, cantos arredondados (`CardView` ou `shape` com rádio adequado no Android), e sombreamento sutil.

---

## 📱 Estrutura e Layout do Dashboard Unificado

A tela principal do APK deve fluir de maneira contínua, unificando todo o conteúdo em uma única linguagem visual de alto contraste:

### 1. Bloco Hero de Status (Hero Status Card)
- **Substitui** o antigo bloco de texto cru no topo.
- Contém:
  - **Campo de IP do PS5**: Editável, padrão preenchido com `192.168.1.54`. Salva e lê do `localStorage`/`SharedPreferences`.
  - **Badge de Status**: *Conectado (Emerald)* / *Aguardando (Amber)* / *Sem Dados (Orange)* / *Offline (Red)*.
  - **Tamanho do Pacote**: Indicador dinâmico de decodificação UDP (`C / 368` ou semelhante).
  - **Mini Live Summary**: Pequenos indicadores inline para Velocidade atual, RPM e Marcha ativa.
  - **Ações**: Botões modernos para *Iniciar*, *Parar*, *Salvar Sessão* e *Alternar HUD*.

### 2. Grid de Métricas Principais (Live Metrics Grid)
- Disposto em **2 colunas no mobile** para garantir densidade e facilidade de leitura ao dirigir:
  - **Card Velocidade**: Valor grande + unidade `km/h`.
  - **Card Velocidade Máxima**: Armazena e exibe a maior velocidade registrada na sessão.
  - **Card RPM**: Indicador numérico.
  - **Card Marcha**: Letra ou número em fonte Display grande de alto contraste.
  - **Card Acelerador e Freio**: Barras de progresso horizontais de alta responsividade (Verde para aceleração, Vermelho para freio).
  - **Card Combustível**: Exibe em litros e porcentagem de forma correspondente.

### 3. Voltas e Resultados (Laps & Race)
- **Melhor Volta** (Best Lap) e **Última Volta** (Last Lap) com fallback elegante para `--:--.--`.
- **Tempo Total Corrida** preservado e atualizado em tempo real.
- **Voltas Completadas** e **Voltas Corrigidas** (`Math.max(0, completadas - 1)`).
- **Voltas Alvo** (Target Laps): Customizável pelo usuário.
- **Estado da Corrida**: Em andamento ou Finalizada (🏁).

### 4. Motor e Dinâmica (Engine & Dynamics)
- Temperatura da Água e do Óleo (ex. `95ºC`).
- Pressão de Turbo / Boost.
- Velocidades e Aceleração Vetorial (X, Y, Z).
- Indicadores de Rotacional (Pitch, Roll, Yaw).

### 5. Painel Recolhível de Detalhes do Bridge
- Substitui a exibição crua de dados do topo.
- Funciona como um painel sanfona (`collapsible`):
  - **Fechado**: Exibe um botão discreto com label *"Mostrar detalhes do Bridge ▽"*.
  - **Aberto**: Exibe a lista organizada de campos numerados (de 1 a 45) com chaves técnicas normativas e valores em tempo real correspondentes.

---

## 🛠️ Regras de Comportamento dos Dados (Behavior Rules)
1. **Preservação do Último Estado Válido**: Se o pacote/conexão falhar momentaneamente, a interface **não** deve zerar os dados ou piscar. Os últimos valores válidos lidos devem ser mantidos até que novos se estabeleçam.
2. **IP Redundante**: O IP do PS5 deve ser inicializado por ordem de prioridade: `localStorage.gt7Ps5Ip` -> `localStorage.gt7_bridge_pc_lan_ip` -> `192.168.1.54`.

---

## 📂 Aba Completa: "Todos os Dados" (Telemetry Groups)
Caso o usuário ative a aba / tela de auditoria, exibir em grupos modernos os seguintes dados (sem expor JSON cru):
- **Status do Bridge**: Conexão, decodeOk, status, updatedAt, packetVersion, lastPacketSize.
- **Carro ao Vivo**: Velocidade, velocidade máxima, RPM, marcha, acelerador, freio, combustível, % de combustível.
- **Voltas e Tempo**: Melhor volta, última volta, total da corrida, voltas brutas, voltas corrigidas.
- **Motor e Dinâmica**: Água, óleo, turbo, vetores lineares e rotacionais.
- **Posição e Mapa**: Coordenadas X, Y, Z, rastro do circuito, tipo de superfície.

---
*Especificação gerada em conformidade com as diretrizes do APK v1.4.8 para aplicação direta no repositório GitHub.*
