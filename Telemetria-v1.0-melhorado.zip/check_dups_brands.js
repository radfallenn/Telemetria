import fs from 'fs';
const text = fs.readFileSync('src/data/gt7_brands.ts', 'utf-8');
const ids = [...text.matchAll(/id:\s*"([^"]+)"|maker_id:\s*"([^"]+)"/g)].map(m => m[1] || m[2]);
const duplicates = ids.filter((item, index) => ids.indexOf(item) !== index);
console.log('Duplicates in brands:', duplicates);
