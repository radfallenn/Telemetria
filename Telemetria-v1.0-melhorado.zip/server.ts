import express from "express";
import { createServer as createViteServer } from "vite";
import { Server } from "socket.io";
import { createServer } from "http";
import dgram from "dgram";
import path from "path";
import fs from "fs";
import { GoogleGenAI, Type } from "@google/genai";

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    },
  });

  const PORT = 3000;
  const GT7_UDP_RECEIVE_PORT = 33739;

  let ps5Ip: string | null = null;
  let ps5Port: number = 33740;
  let heartbeatInterval: NodeJS.Timeout | null = null;

  // UDP Listener for GT7
  const udpClient = dgram.createSocket("udp4");

  const sendHeartbeat = () => {
    if (ps5Ip) {
      const message = Buffer.from('A', 'ascii'); // GT7 needs an arbitrary payload like 'A'
      udpClient.send(message, ps5Port, ps5Ip, (err) => {
        if (err) console.error(`Heartbeat error to ${ps5Ip}:`, err);
      });
    }
  };

  io.on("connection", (socket) => {
    socket.emit("config", { ps5Ip, ps5Port });

    socket.on("set_config", (config) => {
      ps5Ip = config.ip;
      ps5Port = config.port || 33740;
      console.log(`Telemetry config updated: PS5 IP=${ps5Ip}, Port=${ps5Port}`);
      
      if (heartbeatInterval) clearInterval(heartbeatInterval);
      if (ps5Ip) {
        sendHeartbeat();
        heartbeatInterval = setInterval(sendHeartbeat, 10000);
      }
    });
  });

  udpClient.on("message", (msg, rinfo) => {
    // GT7 Packet parsing logic
    // Packet size: 336 bytes
    if (msg.length === 336) {
      try {
        const data = {
          speed: msg.readFloatLE(0x4C) * 3.6, // m/s to km/h
          rpm: msg.readFloatLE(0x3C),
          maxRpm: msg.readFloatLE(0x40),
          gear: msg.readUInt8(0x90) & 0x0F,
          boost: msg.readFloatLE(0x50),
          fuelLevel: msg.readFloatLE(0x44),
          fuelCapacity: msg.readFloatLE(0x48),
          lapCount: msg.readInt16LE(0x74),
          currentLapTime: msg.readInt32LE(0x60),
          bestLapTime: msg.readInt32LE(0x64),
          lastLapTime: msg.readInt32LE(0x68),
          tireTempFL: msg.readFloatLE(0x100),
          tireTempFR: msg.readFloatLE(0x104),
          tireTempRL: msg.readFloatLE(0x108),
          tireTempRR: msg.readFloatLE(0x10C),
        };
        io.emit("telemetry", data);
      } catch (e) {
        // Silently ignore parsing errors
      }
    }
  });

  udpClient.on("error", (err) => {
    console.error(`UDP Error: ${err.stack}`);
  });

  udpClient.bind(GT7_UDP_RECEIVE_PORT, "0.0.0.0", () => {
    console.log(`GT7 UDP Listener running on port ${GT7_UDP_RECEIVE_PORT}`);
  });

  // API routes
  app.use(express.json({ limit: '50mb' }));

  app.get("/api/identify-brand", async (req, res) => {
    try {
      const carName = req.query.carName;
      if (!carName || typeof carName !== "string" || carName.trim().length === 0) {
        return res.status(400).json({ error: "Missing carName query parameter" });
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.json({ brand: "Unknown" });
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: [{
          parts: [{
            text: `Identify the car manufacturer (brand) for the following car model: "${carName}". 
            Return ONLY the brand name (e.g., "Porsche", "Ferrari", "Dodge", "Bugatti"). 
            If you are unsure, return "Unknown".`
          }]
        }],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              brand: {
                type: Type.STRING,
                description: "The identified car brand name.",
              },
            },
            required: ["brand"],
          },
        },
      });

      const result = JSON.parse(response.text || "{}");
      res.json({ brand: result.brand || "Unknown" });
    } catch (error: any) {
      console.error("Error identifying brand:", error);
      res.json({ brand: "Unknown" });
    }
  });

  app.get("/api/search-car-image", async (req, res) => {
    try {
      const carName = req.query.carName;
      if (!carName || typeof carName !== "string" || carName.trim().length === 0) {
        return res.status(400).json({ error: "Missing carName query parameter" });
      }

      console.log("[AI Image Search] Searching image for car:", carName);

      if (!process.env.GEMINI_API_KEY) {
        console.warn("[AI Image Search] GEMINI_API_KEY is not defined");
        return res.json({ imageUrl: null, source: "no_api_key_fallback" });
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Search for a high-quality, public domain, royalty-free, or creative commons direct image URL (jpg, jpeg, png, or webp) for the following car model: "${carName}". 
Prefer direct images from open sources like Wikimedia Commons, Unsplash, or public car manufacturers repositories.
Return ONLY a valid JSON object matching the schema: { "imageUrl": "url_string" }. Do not put markdown blocks like \`\`\`json. Just raw JSON.`,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              imageUrl: {
                type: Type.STRING,
                description: "A valid direct, absolute HTTP/HTTPS URL of an image of the car."
              }
            },
            required: ["imageUrl"]
          }
        }
      });

      const text = response.text?.trim() || "{}";
      const data = JSON.parse(text);

      if (data.imageUrl && data.imageUrl.startsWith("http")) {
        console.log("[AI Image Search] Found public image URL:", data.imageUrl);
        return res.json({ imageUrl: data.imageUrl, source: "AI Web Search" });
      }

      res.json({ imageUrl: null, source: "AI search did not return a URL" });
    } catch (error: any) {
      console.error("[AI Image Search] Error searching car image:", error);
      res.status(500).json({ error: error.message || "Failed to search car image via AI" });
    }
  });

  app.get("/api/list-car-thumbnails", (req, res) => {
    try {
      const publicDir = path.join(process.cwd(), "public", "assets", "cars");
      const distDir = path.join(process.cwd(), "dist", "assets", "cars");
      
      const fileNamesSet = new Set<string>();

      // Scan public/assets/cars if exists
      if (fs.existsSync(publicDir)) {
        fs.readdirSync(publicDir).forEach((f: string) => {
          if (f.endsWith('.webp') && f !== 'placeholder.webp') {
            fileNamesSet.add(f.replace('.webp', ''));
          }
        });
      }

      // Scan dist/assets/cars if exists
      if (fs.existsSync(distDir)) {
        fs.readdirSync(distDir).forEach((f: string) => {
          if (f.endsWith('.webp') && f !== 'placeholder.webp') {
            fileNamesSet.add(f.replace('.webp', ''));
          }
        });
      }

      const names = Array.from(fileNamesSet);
      const ids = names.map((n: string) => parseInt(n, 10)).filter((id: number) => !isNaN(id));
      res.json({ names, ids });
    } catch (error) {
      console.error("Error listing thumbnails:", error);
      res.status(500).json({ error: "Failed to list thumbnails" });
    }
  });

  app.post("/api/upload-car-thumbnail", (req, res) => {
    try {
      const { name, id, base64 } = req.body;
      const targetName = name || id;
      if (!targetName || !base64) return res.status(400).json({ error: "Missing name/id or base64 data" });

      const publicDir = path.join(process.cwd(), "public", "assets", "cars");
      const distDir = path.join(process.cwd(), "dist", "assets", "cars");
      const buffer = Buffer.from(base64.replace(/^data:image\/\w+;base64,/, ""), "base64");

      // Save to public dir
      if (!fs.existsSync(publicDir)) {
        fs.mkdirSync(publicDir, { recursive: true });
      }
      fs.writeFileSync(path.join(publicDir, `${targetName}.webp`), buffer);

      // Save to dist dir if in production/dist dir exists so it's instantly available without a rebuild
      if (fs.existsSync(path.join(process.cwd(), "dist"))) {
        const destDir = path.join(distDir);
        if (!fs.existsSync(destDir)) {
          fs.mkdirSync(destDir, { recursive: true });
        }
        fs.writeFileSync(path.join(destDir, `${targetName}.webp`), buffer);
      }

      res.json({ success: true, path: `assets/cars/${targetName}.webp` });
    } catch (error) {
      console.error("Error uploading thumbnail:", error);
      res.status(500).json({ error: "Failed to save thumbnail" });
    }
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
