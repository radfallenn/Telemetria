# Telemetria v1.0 Melhorado

Interface escura com neon verde, focada somente nos dados essenciais.

## Dados na tela
- Conta-giros em barra com RPM
- Velocidade
- Marcha
- Volta mais rápida
- Última volta
- Tempo total
- Velocidade máxima
- Média da corrida
- Voltas completas
- Resumo de até 30 voltas

## Média da corrida
Remove as 2 melhores voltas e as 2 piores voltas. Soma o restante e divide por voltas completas menos 4.

## Melhorias aplicadas
- Resumo copiável para área de transferência.
- Sessão restaurada ao reabrir o app.
- Confirmação antes de zerar a corrida.
- Proteção contra pacotes vazios, null, undefined e NaN.
- Últimos dados válidos permanecem na tela.
- Resumo mostra no máximo as últimas 30 voltas.
- A média usa todas as voltas completas registradas.
