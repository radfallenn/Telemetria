const fs = require('fs');
let content = fs.readFileSync('src/data/trackPack.ts', 'utf8');

// Update Interface
content = content.replace(
  "svgPath: string;",
  "svgPath: string;\n  svgVariants?: {\n    outline: string;\n    outline_thick: string;\n    filled: string;\n    telemetry_path: string;\n  };"
);

// Map through the array and add variants
const regex = /svgPath: "(.*?)",\n\s*layouts: (.*?)\n\s*}/g;
content = content.replace(regex, (match, path, layouts) => {
  return `svgPath: "${path}",
    svgVariants: {
      outline: "${path}",
      outline_thick: "${path}",
      filled: "${path}",
      telemetry_path: "${path}"
    },
    layouts: ${layouts}
  }`;
});

fs.writeFileSync('src/data/trackPack.ts', content);
console.log("Updated variants in trackPack");
